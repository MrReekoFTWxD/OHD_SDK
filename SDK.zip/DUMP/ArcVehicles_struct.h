// Enum ArcVehicles.EArcVehicleSeatChangeType
enum class EArcVehicleSeatChangeType : uint8 {
	Invalid = 0,
	EnterVehicle = 1,
	ExitVehicle = 2,
	SwitchSeats = 3,
	EArcVehicleSeatChangeType_MAX = 4
};

// ScriptStruct ArcVehicles.ArcVehicleSeatChangeEvent
// Size: 0x18 (Inherited: 0x00)
struct FArcVehicleSeatChangeEvent {
	char pad_0[0x10]; // 0x00(0x10)
	struct APlayerState* Player; // 0x10(0x08)
};

// ScriptStruct ArcVehicles.ArcVehicleTurretMovementPostPhysicsTickFunction
// Size: 0x30 (Inherited: 0x28)
struct FArcVehicleTurretMovementPostPhysicsTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct ArcVehicles.ArcVehicleSeatReference
// Size: 0x10 (Inherited: 0x00)
struct FArcVehicleSeatReference {
	struct AArcBaseVehicle* Vehicle; // 0x00(0x08)
	int32_t SeatID; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct ArcVehicles.ArcOwnerAttachmentReference
// Size: 0x10 (Inherited: 0x00)
struct FArcOwnerAttachmentReference {
	struct FName ComponentName; // 0x00(0x08)
	struct FName SocketName; // 0x08(0x08)
};

