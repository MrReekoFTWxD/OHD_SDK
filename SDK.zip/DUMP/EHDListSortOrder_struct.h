// UserDefinedEnum EHDListSortOrder.EHDListSortOrder
enum class EHDListSortOrder : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EHDListSortOrder_MAX = 2
};

