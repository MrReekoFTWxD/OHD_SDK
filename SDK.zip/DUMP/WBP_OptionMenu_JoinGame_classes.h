// WidgetBlueprintGeneratedClass WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C
// Size: 0x329 (Inherited: 0x280)
struct UWBP_OptionMenu_JoinGame_C : UHDJoinGameMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x280(0x08)
	struct UWBP_JoinServerDetailsPanel_C* DetailsPanel; // 0x288(0x08)
	struct UButton* FiltersOpenCloseBtn; // 0x290(0x08)
	struct UWBP_JoinServerFiltersPanel_C* FiltersPanel; // 0x298(0x08)
	struct USizeBox* FiltersPanelOpenCloseBox; // 0x2a0(0x08)
	struct UWBP_JoinServer_Header_C* GameModeHeader; // 0x2a8(0x08)
	struct UWBP_JoinServer_Header_C* MapHeader; // 0x2b0(0x08)
	struct UWBP_JoinServer_Header_C* ModHeader; // 0x2b8(0x08)
	struct UWBP_JoinServer_Header_C* PingHeader; // 0x2c0(0x08)
	struct UWBP_JoinServer_Header_C* PlayersHeader; // 0x2c8(0x08)
	struct UButton* RefreshListBtn; // 0x2d0(0x08)
	struct UCircularThrobber* RefreshListThrobber; // 0x2d8(0x08)
	struct UWBP_ServerDetails_C* ServerDetails; // 0x2e0(0x08)
	struct UBorder* ServerDetailsContainer; // 0x2e8(0x08)
	struct USizeBox* ServerListBox; // 0x2f0(0x08)
	struct UWBP_JoinServer_Header_C* ServerNameHeader; // 0x2f8(0x08)
	struct UHDServerListItemData* SelectedServerListItem; // 0x300(0x08)
	bool bShowServerDetailsInDesigner; // 0x308(0x01)
	char pad_309[0x7]; // 0x309(0x07)
	struct UDataTable* ServerBadgeTable; // 0x310(0x08)
	struct TArray<struct FFServerBadgeUIDefinition> ServerBadgeDefs; // 0x318(0x10)
	bool bDesignTime; // 0x328(0x01)

	void HasSubMenus(bool& bSubMenuOptions); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.HasSubMenus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSubMenuOptions(struct TArray<struct FFSubMenuOption>& SubOptions); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSubMenuOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetDesiredHorizontalAlignment(enum class EHorizontalAlignment& Alignment); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredHorizontalAlignment // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetDesiredVerticalAlignment(enum class EVerticalAlignment& Alignment); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredVerticalAlignment // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OpenPasswordPrompt(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.OpenPasswordPrompt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ApplyActiveServerFilters(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ApplyActiveServerFilters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RefreshServerList(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.RefreshServerList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleServerDetails(bool bShown); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ToggleServerDetails // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetServerListSortPreference(struct FFServerSortPreference& SortPreference); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetServerListSortPreference // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsValidServerListItemIndex(int32_t IndexToTest, bool& bValidIndex); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.IsValidServerListItemIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetSelectedServerListItem(struct UHDServerListItemData*& ServerItem); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSelectedServerListItem // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ClearServerListItemSelection(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ClearServerListItemSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerListItemSelectionCleared(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ServerListItemSelectionCleared // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerListItemSelectionUpdated(struct UHDServerListItemData* InSelectedServerListItem); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ServerListItemSelectionUpdated // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetActiveSubMenuByIndex(int32_t SubMenuIndex); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SetActiveSubMenuByIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRefreshStart(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ReceiveOnRefreshStart // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRefreshComplete(bool bSortAscending, enum class EHDServerListSortBy SortBy); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ReceiveOnRefreshComplete // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__RefreshListBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__RefreshListBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature(struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DetailsPanel_K2Node_ComponentBoundEvent_3_OnJoinServerBtnClicked__DelegateSignature(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__DetailsPanel_K2Node_ComponentBoundEvent_3_OnJoinServerBtnClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature(struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void SortPreferenceChanged(struct FFServerSortPreference SortPreference); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SortPreferenceChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ConfirmServerPasswordInput(struct FText InputText); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ConfirmServerPasswordInput // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionMenu_JoinGame(int32_t EntryPoint); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ExecuteUbergraph_WBP_OptionMenu_JoinGame // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

