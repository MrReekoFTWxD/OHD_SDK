// BlueprintGeneratedClass BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C
// Size: 0x41 (Inherited: 0x30)
struct UBP_ContextWidgetPrereq_ExcludeSquadLeader_C : UDFContextualWidgetPrerequisiteBase {
	struct AHDSquadState* MemberSQState; // 0x30(0x08)
	struct AHDPlayerState* MemberPSToTest; // 0x38(0x08)
	bool bInitialized; // 0x40(0x01)

	void IsValidContext(bool& bValidData); // Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.IsValidContext // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	bool SatisfiesPrerequisite(); // Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.SatisfiesPrerequisite // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void SetupContext(struct AHDSquadState* InMemberSQState, struct AHDPlayerState* InMemberPSToTest); // Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.SetupContext // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

