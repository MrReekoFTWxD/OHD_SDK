// BlueprintGeneratedClass BP_HDGameInstanceBase.BP_HDGameInstanceBase_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct UBP_HDGameInstanceBase_C : UHDGameInstance {
};

