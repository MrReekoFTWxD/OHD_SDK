// BlueprintGeneratedClass BP_MenuGM.BP_MenuGM_C
// Size: 0x318 (Inherited: 0x308)
struct ABP_MenuGM_C : AGameMode {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x308(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x310(0x08)

	void ReceiveBeginPlay(); // Function BP_MenuGM.BP_MenuGM_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_MenuGM(int32_t EntryPoint); // Function BP_MenuGM.BP_MenuGM_C.ExecuteUbergraph_BP_MenuGM // (Final|UbergraphFunction) // @ game+0xec54e0
};

