// BlueprintGeneratedClass BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C
// Size: 0x4f8 (Inherited: 0x4e8)
struct ABP_ImpactFX_DefaultWeap_C : ADFBaseImpactEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x4f0(0x08)

	void ReceiveTick(float DeltaSeconds); // Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_ImpactFX_DefaultWeap(int32_t EntryPoint); // Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ExecuteUbergraph_BP_ImpactFX_DefaultWeap // (Final|UbergraphFunction) // @ game+0xec54e0
};

