// UserDefinedEnum EServerBadgeType.EServerBadgeType
enum class EServerBadgeType : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	EServerBadgeType_MAX = 4
};

