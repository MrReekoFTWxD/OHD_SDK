// WidgetBlueprintGeneratedClass WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C
// Size: 0x2a0 (Inherited: 0x230)
struct UWBP_GameModifierSettingsSection_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UNamedSlot* Content; // 0x238(0x08)
	struct UCheckBox* SectionActiveToggleChkBox; // 0x240(0x08)
	struct UImage* SectionExpansionArrow; // 0x248(0x08)
	struct UButton* SectionExpansionToggleBtn; // 0x250(0x08)
	struct UTextBlock* SectionTitleText; // 0x258(0x08)
	struct FText TitleText; // 0x260(0x18)
	bool bShowToggleBtn; // 0x278(0x01)
	bool bExpanded; // 0x279(0x01)
	bool bActive; // 0x27a(0x01)
	char pad_27B[0x5]; // 0x27b(0x05)
	struct FMulticastInlineDelegate OnActivated; // 0x280(0x10)
	struct FMulticastInlineDelegate OnDeactivated; // 0x290(0x10)

	void InternalRecursiveSetContentIsEnabled(bool bInIsEnabled); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.InternalRecursiveSetContentIsEnabled // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsActive(bool& bActive); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsActive // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsExpanded(bool& bExpanded); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsExpanded // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetTitleText(struct FText& TitleText); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.GetTitleText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetIsActive(bool bActive); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetIsActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetExpansionState(bool bExpanded); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetExpansionState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetTitleText(struct FText InTitleText); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetTitleText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SectionExpansionToggleBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.BndEvt__SectionExpansionToggleBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.BndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_GameModifierSettingsSection(int32_t EntryPoint); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.ExecuteUbergraph_WBP_GameModifierSettingsSection // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnDeactivated__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.OnDeactivated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnActivated__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.OnActivated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

