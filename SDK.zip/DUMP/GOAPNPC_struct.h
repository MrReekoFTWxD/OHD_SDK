// ScriptStruct GOAPNPC.Atom
// Size: 0x18 (Inherited: 0x00)
struct FAtom {
	struct FString Name; // 0x00(0x10)
	bool bValue; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

