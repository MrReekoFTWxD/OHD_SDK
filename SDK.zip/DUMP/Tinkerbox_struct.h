// Enum Tinkerbox.EMinimapCaptureResolution
enum class EMinimapCaptureResolution : int32 {
	Size1024 = 1024,
	Size2048 = 2048,
	Size4096 = 4096,
	EMinimapCaptureResolution_MAX = 4097
};

// ScriptStruct Tinkerbox.MinimapGenerationSettings
// Size: 0x28 (Inherited: 0x00)
struct FMinimapGenerationSettings {
	struct AActor* BoundaryMarkerA; // 0x00(0x08)
	struct AActor* BoundaryMarkerB; // 0x08(0x08)
	struct FVector BoundaryMidPointLoc; // 0x10(0x0c)
	enum class EMinimapCaptureResolution CaptureResolution; // 0x1c(0x02)
	char pad_1E[0x2]; // 0x1e(0x02)
	float PlayableBoundaryLength; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

