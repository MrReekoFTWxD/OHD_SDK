// UserDefinedStruct FSubMenuOption.FSubMenuOption
// Size: 0x1c (Inherited: 0x00)
struct FFSubMenuOption {
	struct FText DisplayName_6_20C60ABE4E1D3DC408ADFB8AD9C5D97D; // 0x00(0x18)
	int32_t Index_2_19EBD71C49382CE4814855A78355736F; // 0x18(0x04)
};

