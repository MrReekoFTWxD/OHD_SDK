// WidgetBlueprintGeneratedClass WBP_SQOption.WBP_SQOption_C
// Size: 0x268 (Inherited: 0x24c)
struct UWBP_SQOption_C : UWBP_HDContextualWidgetBase_C {
	char pad_24C[0x4]; // 0x24c(0x04)
	struct UNamedSlot* InsertContentHere; // 0x250(0x08)
	struct UWBP_DeployMenu_SquadList_C* ParentContainer; // 0x258(0x08)
	struct USquadListEntry* ParentSquadData; // 0x260(0x08)

	void GetParentSquadData(struct USquadListEntry*& SquadData); // Function WBP_SQOption.WBP_SQOption_C.GetParentSquadData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupOption(struct USquadListEntry* InSquadData); // Function WBP_SQOption.WBP_SQOption_C.SetupOption // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

