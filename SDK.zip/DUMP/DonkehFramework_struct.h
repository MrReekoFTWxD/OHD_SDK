// Enum DonkehFramework.EFireMode
enum class EFireMode : uint8 {
	Semi = 0,
	Auto = 1,
	Burst = 2,
	EFireMode_MAX = 3
};

// Enum DonkehFramework.EDFPlayerWhitelistType
enum class EDFPlayerWhitelistType : uint8 {
	None = 0,
	Manual = 1,
	Token = 2,
	EDFPlayerWhitelistType_MAX = 3
};

// Enum DonkehFramework.EDFItemEnabledMode
enum class EDFItemEnabledMode : uint8 {
	Enabled = 0,
	Disabled = 1,
	Hidden = 2,
	EDFItemEnabledMode_MAX = 3
};

// Enum DonkehFramework.ESessionSearchPresenceType
enum class ESessionSearchPresenceType : uint8 {
	AllServers = 0,
	ListenServersOnly = 1,
	DedicatedServersOnly = 2,
	ESessionSearchPresenceType_MAX = 3
};

// Enum DonkehFramework.ECharacterStance
enum class ECharacterStance : uint8 {
	None = 0,
	Stand = 1,
	Crouch = 2,
	Prone = 3,
	Custom = 4,
	ECharacterStance_MAX = 5
};

// Enum DonkehFramework.EDFCharacterCustomMovementMode
enum class EDFCharacterCustomMovementMode : uint8 {
	None = 0,
	Vaulting = 1,
	MAX = 2
};

// Enum DonkehFramework.EPlayerVoiceState
enum class EPlayerVoiceState : uint8 {
	NotTalking = 0,
	Talking = 1,
	Muted = 2,
	EPlayerVoiceState_MAX = 3
};

// Enum DonkehFramework.EPlayerKind
enum class EPlayerKind : uint8 {
	Human = 0,
	Bot = 1,
	Either = 2,
	EPlayerKind_MAX = 3
};

// Enum DonkehFramework.ELogVerbosityBP
enum class ELogVerbosityBP : uint8 {
	Error = 2,
	Warning = 3,
	Log = 5,
	Verbose = 6,
	VeryVerbose = 7,
	MAX = 0
};

// Enum DonkehFramework.EGunReloadState
enum class EGunReloadState : uint8 {
	NotReloading = 0,
	PartialReloadStart = 1,
	FullReloadStart = 2,
	PartialReload = 3,
	FullReload = 4,
	PartialReloadEnd = 5,
	FullReloadEnd = 6,
	EGunReloadState_MAX = 7
};

// Enum DonkehFramework.EAmmoClipReloadBehavior
enum class EAmmoClipReloadBehavior : uint8 {
	DiscardOnEmpty = 0,
	DiscardOnReload = 1,
	NoDiscard = 2,
	EAmmoClipReloadBehavior_MAX = 3
};

// Enum DonkehFramework.ECardinalDirection
enum class ECardinalDirection : uint8 {
	North = 0,
	South = 1,
	East = 2,
	West = 3,
	ECardinalDirection_MAX = 4
};

// Enum DonkehFramework.EVaultBehavior
enum class EVaultBehavior : uint8 {
	None = 0,
	VaultOver = 1,
	SprintVaultOver = 2,
	ClimbOnto = 3,
	SprintClimbOnto = 4,
	EVaultBehavior_MAX = 5
};

// Enum DonkehFramework.ELeanDirection
enum class ELeanDirection : uint8 {
	None = 0,
	Left = 1,
	Right = 2,
	ELeanDirection_MAX = 3
};

// Enum DonkehFramework.ESpecificItemType
enum class ESpecificItemType : uint8 {
	None = 0,
	Rifle = 10,
	MachineGun = 11,
	GrenadeLauncher = 12,
	RocketLauncher = 13,
	SniperRifle = 14,
	SubmachineGun = 30,
	Pistol = 31,
	FragGrenade = 50,
	SmokeGrenade = 51,
	Melee = 80,
	Bandage = 110,
	AmmoBag = 120,
	MedicBag = 121,
	Binoculars = 150,
	Radio = 151,
	Shovel = 152,
	SpecialItem1 = 210,
	SpecialItem2 = 211,
	SpecialItem3 = 212,
	SpecialItem4 = 212,
	SpecialItem5 = 212,
	CustomItem1 = 220,
	CustomItem2 = 221,
	CustomItem3 = 222,
	CustomItem4 = 223,
	CustomItem5 = 224,
	Undefined = 255,
	ESpecificItemType_MAX = 256
};

// Enum DonkehFramework.EItemType
enum class EItemType : uint8 {
	Melee = 0,
	Other = 1,
	Pistol = 2,
	Throwable = 3,
	Rifle = 4,
	Equipment = 5,
	EItemType_MAX = 6
};

// ScriptStruct DonkehFramework.DFPropertyAssetBundles
// Size: 0x01 (Inherited: 0x00)
struct FDFPropertyAssetBundles {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DonkehFramework.DFGenericObjectContainer
// Size: 0x180 (Inherited: 0x108)
struct FDFGenericObjectContainer : FFastArraySerializer {
	struct TArray<struct FDFGenericObject> GenericObjects; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
	struct UObject* RequiredClass; // 0x120(0x08)
	char pad_128[0x58]; // 0x128(0x58)
};

// ScriptStruct DonkehFramework.DFGenericObject
// Size: 0x28 (Inherited: 0x0c)
struct FDFGenericObject : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UObject* Object; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	char bPendingRemoval : 1; // 0x20(0x01)
	char bPredictivelyRemoved : 1; // 0x20(0x01)
	char pad_20_2 : 6; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DonkehFramework.DFVaultTraceData
// Size: 0x18 (Inherited: 0x00)
struct FDFVaultTraceData {
	struct FDFVaultTargetParams TargetParams; // 0x00(0x10)
	enum class EVaultBehavior Behavior; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float Height; // 0x14(0x04)
};

// ScriptStruct DonkehFramework.DFVaultTargetParams
// Size: 0x10 (Inherited: 0x00)
struct FDFVaultTargetParams {
	enum class EVaultBehavior DesiredBehavior; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector_NetQuantize10 Location; // 0x04(0x0c)
};

// ScriptStruct DonkehFramework.DFVaultTraceResult
// Size: 0x1c (Inherited: 0x18)
struct FDFVaultTraceResult : FDFVaultTraceData {
	bool bSuccess; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

// ScriptStruct DonkehFramework.SpawnPointDef
// Size: 0x50 (Inherited: 0x00)
struct FSpawnPointDef {
	int32_t SpawnID; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FTransform SpawnTransform; // 0x10(0x30)
	struct UObject* SpawnContextObject; // 0x40(0x08)
	char pad_48[0x8]; // 0x48(0x08)
};

// ScriptStruct DonkehFramework.PlayerChatMsg
// Size: 0x30 (Inherited: 0x00)
struct FPlayerChatMsg {
	struct APlayerState* SenderPS; // 0x00(0x08)
	struct FString SenderName; // 0x08(0x10)
	char MsgTeamId; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString MsgContent; // 0x20(0x10)
};

// ScriptStruct DonkehFramework.AssetDescriptor
// Size: 0x20 (Inherited: 0x00)
struct FAssetDescriptor {
	struct FName AssetName; // 0x00(0x08)
	struct FText DisplayText; // 0x08(0x18)
};

// ScriptStruct DonkehFramework.DFCharacterVariationDataHandle
// Size: 0x18 (Inherited: 0x00)
struct FDFCharacterVariationDataHandle {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DonkehFramework.DFCharacterVariationDataSource
// Size: 0x08 (Inherited: 0x00)
struct FDFCharacterVariationDataSource {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct DonkehFramework.DFCharacterVariationDataSource_TableRow
// Size: 0x20 (Inherited: 0x08)
struct FDFCharacterVariationDataSource_TableRow : FDFCharacterVariationDataSource {
	struct FDataTableRowHandle RowHandle; // 0x08(0x10)
	bool bValidRowHandle; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DonkehFramework.DFCharacterVariationData
// Size: 0x68 (Inherited: 0x08)
struct FDFCharacterVariationData : FTableRowBase {
	struct FDFCharacterVariation Variation; // 0x08(0x30)
	struct FDFCharacterVariation VariationFPP; // 0x38(0x30)
};

// ScriptStruct DonkehFramework.DFCharacterVariation
// Size: 0x30 (Inherited: 0x00)
struct FDFCharacterVariation {
	char pad_0[0x8]; // 0x00(0x08)
	struct TSoftObjectPtr<USkeletalMesh> Mesh; // 0x08(0x28)
};

// ScriptStruct DonkehFramework.WeaponSoundCollection
// Size: 0x80 (Inherited: 0x00)
struct FWeaponSoundCollection {
	struct FPerspectiveSound EquipSound; // 0x00(0x10)
	struct FPerspectiveSound UnEquipSound; // 0x10(0x10)
	struct FPerspectiveSound FireSound; // 0x20(0x10)
	struct FPerspectiveSound FireLastSound; // 0x30(0x10)
	struct FPerspectiveSound DryFireSound; // 0x40(0x10)
	struct FPerspectiveSound ReloadSound; // 0x50(0x10)
	struct FPerspectiveSound ReloadFullSound; // 0x60(0x10)
	struct FPerspectiveSound FireModeSound; // 0x70(0x10)
};

// ScriptStruct DonkehFramework.PerspectiveSound
// Size: 0x10 (Inherited: 0x00)
struct FPerspectiveSound {
	struct USoundBase* Sound1P; // 0x00(0x08)
	struct USoundBase* Sound3P; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.CharacterSoundCollection
// Size: 0x10 (Inherited: 0x00)
struct FCharacterSoundCollection {
	struct FPerspectiveSound DeathSound; // 0x00(0x10)
};

// ScriptStruct DonkehFramework.CharacterAnimCollection
// Size: 0x128 (Inherited: 0x00)
struct FCharacterAnimCollection {
	struct UAnimSequence* BasePose; // 0x00(0x08)
	struct UAnimSequence* BasePoseTPP; // 0x08(0x08)
	struct UAnimSequence* AimBasePose; // 0x10(0x08)
	struct UAnimMontage* Death; // 0x18(0x08)
	struct FIntrinsicWeaponAnimSubset Intrinsic; // 0x20(0x28)
	struct FLocomotionWeaponAnimSubset Locomotion; // 0x48(0x18)
	struct FSingleActionWeaponAnimSubset SingleAction; // 0x60(0x08)
	struct FSingleLoadWeaponAnimSubset SingleLoad; // 0x68(0x10)
	struct FThrowableWeaponAnimSubset Throwable; // 0x78(0x20)
	struct FPerspectiveAnim DeathAnim; // 0x98(0x10)
	struct FPerspectiveAnim EquipAnim; // 0xa8(0x10)
	struct FPerspectiveAnim UnEquipAnim; // 0xb8(0x10)
	struct FPerspectiveAnim FireAnim; // 0xc8(0x10)
	struct FPerspectiveAnim ActionAnim; // 0xd8(0x10)
	struct FPerspectiveAnim ReloadAnim; // 0xe8(0x10)
	struct FPerspectiveAnim ReloadFullAnim; // 0xf8(0x10)
	struct FPerspectiveAnim StartReloadAnim; // 0x108(0x10)
	struct FPerspectiveAnim EndReloadAnim; // 0x118(0x10)
};

// ScriptStruct DonkehFramework.PerspectiveAnim
// Size: 0x10 (Inherited: 0x00)
struct FPerspectiveAnim {
	struct UAnimSequenceBase* Anim1P; // 0x00(0x08)
	struct UAnimSequenceBase* Anim3P; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.ThrowableWeaponAnimSubset
// Size: 0x20 (Inherited: 0x00)
struct FThrowableWeaponAnimSubset {
	struct UAnimSequence* ReadyBasePose; // 0x00(0x08)
	struct UAnimMontage* Cock; // 0x08(0x08)
	struct UAnimMontage* ThrowOverhand; // 0x10(0x08)
	struct UAnimMontage* ThrowUnderhand; // 0x18(0x08)
};

// ScriptStruct DonkehFramework.SingleLoadWeaponAnimSubset
// Size: 0x10 (Inherited: 0x00)
struct FSingleLoadWeaponAnimSubset {
	struct UAnimMontage* StartReload; // 0x00(0x08)
	struct UAnimMontage* EndReload; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.SingleActionWeaponAnimSubset
// Size: 0x08 (Inherited: 0x00)
struct FSingleActionWeaponAnimSubset {
	struct UAnimMontage* Action; // 0x00(0x08)
};

// ScriptStruct DonkehFramework.LocomotionWeaponAnimSubset
// Size: 0x18 (Inherited: 0x00)
struct FLocomotionWeaponAnimSubset {
	struct UAnimSequence* Idle; // 0x00(0x08)
	struct UAnimSequence* Move; // 0x08(0x08)
	struct UAnimSequence* Sprint; // 0x10(0x08)
};

// ScriptStruct DonkehFramework.IntrinsicWeaponAnimSubset
// Size: 0x28 (Inherited: 0x00)
struct FIntrinsicWeaponAnimSubset {
	struct UAnimMontage* Equip; // 0x00(0x08)
	struct UAnimMontage* UnEquip; // 0x08(0x08)
	struct UAnimMontage* Fire; // 0x10(0x08)
	struct UAnimMontage* Reload; // 0x18(0x08)
	struct UAnimMontage* ReloadEmpty; // 0x20(0x08)
};

// ScriptStruct DonkehFramework.WeaponAnimCollection
// Size: 0xf0 (Inherited: 0x00)
struct FWeaponAnimCollection {
	struct UAnimSequence* BasePose; // 0x00(0x08)
	struct UAnimSequence* EmptyBasePose; // 0x08(0x08)
	struct FIntrinsicWeaponAnimSubset Intrinsic; // 0x10(0x28)
	struct FSingleActionWeaponAnimSubset SingleAction; // 0x38(0x08)
	struct FSingleLoadWeaponAnimSubset SingleLoad; // 0x40(0x10)
	struct FThrowableWeaponAnimSubset Throwable; // 0x50(0x20)
	struct FPerspectiveAnim EquipAnim; // 0x70(0x10)
	struct FPerspectiveAnim UnEquipAnim; // 0x80(0x10)
	struct FPerspectiveAnim FireAnim; // 0x90(0x10)
	struct FPerspectiveAnim ActionAnim; // 0xa0(0x10)
	struct FPerspectiveAnim ReloadAnim; // 0xb0(0x10)
	struct FPerspectiveAnim ReloadFullAnim; // 0xc0(0x10)
	struct FPerspectiveAnim StartReloadAnim; // 0xd0(0x10)
	struct FPerspectiveAnim EndReloadAnim; // 0xe0(0x10)
};

// ScriptStruct DonkehFramework.PerspectiveStaticMesh
// Size: 0x10 (Inherited: 0x00)
struct FPerspectiveStaticMesh {
	struct UStaticMesh* Mesh1P; // 0x00(0x08)
	struct UStaticMesh* Mesh3P; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.PerspectiveSkeletalMesh
// Size: 0x10 (Inherited: 0x00)
struct FPerspectiveSkeletalMesh {
	struct USkeletalMesh* Mesh1P; // 0x00(0x08)
	struct USkeletalMesh* Mesh3P; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.PerspectiveAnimSequence
// Size: 0x10 (Inherited: 0x00)
struct FPerspectiveAnimSequence {
	struct UAnimSequence* Anim1P; // 0x00(0x08)
	struct UAnimSequence* Anim3P; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.WeaponAnimMontage
// Size: 0x10 (Inherited: 0x00)
struct FWeaponAnimMontage {
	struct UAnimMontage* CharAnim; // 0x00(0x08)
	struct UAnimMontage* WeapAnim; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.WeaponAnimSequence
// Size: 0x10 (Inherited: 0x00)
struct FWeaponAnimSequence {
	struct UAnimSequence* CharAnim; // 0x00(0x08)
	struct UAnimSequence* WeapAnim; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.WeaponAnim
// Size: 0x10 (Inherited: 0x00)
struct FWeaponAnim {
	struct UAnimSequenceBase* CharAnim; // 0x00(0x08)
	struct UAnimSequenceBase* WeapAnim; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.AnimMontagePlaybackParams
// Size: 0x10 (Inherited: 0x00)
struct FAnimMontagePlaybackParams {
	struct UAnimMontage* Montage; // 0x00(0x08)
	struct USkeletalMeshComponent* SourceMeshComp; // 0x08(0x08)
};

// ScriptStruct DonkehFramework.RepShotInfo
// Size: 0x04 (Inherited: 0x00)
struct FRepShotInfo {
	uint16_t ShotCounter; // 0x00(0x02)
	bool bIsFiring; // 0x02(0x01)
	bool bCompressByte; // 0x03(0x01)
};

// ScriptStruct DonkehFramework.CSHitInfo
// Size: 0x70 (Inherited: 0x00)
struct FCSHitInfo {
	char bBlockingHit : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Distance; // 0x04(0x04)
	struct FVector_NetQuantize Location; // 0x08(0x0c)
	struct FVector_NetQuantizeNormal Normal; // 0x14(0x0c)
	struct FName BoneName; // 0x20(0x08)
	struct FVector_NetQuantize ShootLoc; // 0x28(0x0c)
	struct FVector_NetQuantizeNormal ShootDir; // 0x34(0x0c)
	struct FVector_NetQuantize TraceStart; // 0x40(0x0c)
	struct FVector_NetQuantize TraceEnd; // 0x4c(0x0c)
	struct TWeakObjectPtr<struct AActor> Actor; // 0x58(0x08)
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // 0x60(0x08)
	struct TWeakObjectPtr<struct AController> InstigatingController; // 0x68(0x08)
};

// ScriptStruct DonkehFramework.DFDamageParams
// Size: 0x14 (Inherited: 0x14)
struct FDFDamageParams : FRadialDamageParams {
};

// ScriptStruct DonkehFramework.TakeHitInfo
// Size: 0x120 (Inherited: 0x00)
struct FTakeHitInfo {
	float ActualDamage; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UObject* DamageTypeClass; // 0x08(0x08)
	struct TWeakObjectPtr<struct APawn> PawnInstigator; // 0x10(0x08)
	struct TWeakObjectPtr<struct AActor> DamageCauser; // 0x18(0x08)
	int32_t DamageEventClassID; // 0x20(0x04)
	char bKilled : 1; // 0x24(0x01)
	char pad_24_1 : 7; // 0x24(0x01)
	char EnsureReplicationByte; // 0x25(0x01)
	char pad_26[0x2]; // 0x26(0x02)
	struct FDamageEvent GeneralDamageEvent; // 0x28(0x10)
	struct FPointDamageEvent PointDamageEvent; // 0x38(0xa8)
	struct FRadialDamageEvent RadialDamageEvent; // 0xe0(0x40)
};

// ScriptStruct DonkehFramework.DecalData
// Size: 0x10 (Inherited: 0x00)
struct FDecalData {
	struct UMaterial* DecalMaterial; // 0x00(0x08)
	float DecalSize; // 0x08(0x04)
	float LifeSpan; // 0x0c(0x04)
};

