// WidgetBlueprintGeneratedClass WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C
// Size: 0x258 (Inherited: 0x230)
struct UWBP_HUDElement_EquipmentSelect_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UVerticalBox* SlotVBox; // 0x238(0x08)
	int32_t CurrentSlotIndex; // 0x240(0x04)
	int32_t CurrentSlotNum; // 0x244(0x04)
	struct TArray<struct FFEqpSlotData> SlotData; // 0x248(0x10)

	void SelectItemBySlotNum(int32_t SlotNum); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItemBySlotNum // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSelectedItem(struct FFEqpSlotData& OutSlotData, bool& bFoundItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetSelectedItem // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetMinSlotIndex(struct TArray<struct FFEqpSlotData>& SlotDataArray, int32_t& MinSlotIndex); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetMinSlotIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CreateAndAddEquipmentWidget(struct UTexture2D* Icon, int32_t SlotNum, bool bEnabled, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.CreateAndAddEquipmentWidget // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearEquipmentList(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.ClearEquipmentList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveEquipmentAtSlotNum(int32_t SlotNum, bool& bRemoved); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RemoveEquipmentAtSlotNum // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RebuildEquipmentList(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RebuildEquipmentList // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddEquipment(struct FHDItemEntry& EqpInfo, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.AddEquipment // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectItem(int32_t NewSlotIndex); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectPrevItem(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectPrevItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectNextItem(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectNextItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64(struct UObject* Loaded); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.OnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64 // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void LoadEquipmentAsset(struct TSoftObjectPtr<UTexture2D> IconToLoad, int32_t SlotNum, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.LoadEquipmentAsset // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnEquipmentListModified(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.OnEquipmentListModified // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_EquipmentSelect(int32_t EntryPoint); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.ExecuteUbergraph_WBP_HUDElement_EquipmentSelect // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

