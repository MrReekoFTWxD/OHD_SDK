// Class DonkehFrameworkComms.CreateCommChannelCallbackProxy
// Size: 0x88 (Inherited: 0x30)
struct UCreateCommChannelCallbackProxy : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnPerformSetup; // 0x30(0x10)
	struct FMulticastInlineDelegate OnSuccess; // 0x40(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x50(0x10)
	struct APlayerController* CreateChannelOwnerPC; // 0x60(0x08)
	struct UDFCommChannelDefinition* CreateChannelDef; // 0x68(0x08)
	char pad_70[0x18]; // 0x70(0x18)

	struct UCreateCommChannelCallbackProxy* CreateCommChannelFor(struct APlayerController* Player, struct UDFCommChannelDefinition* ChannelDef, struct FName ChannelNameOverride); // Function DonkehFrameworkComms.CreateCommChannelCallbackProxy.CreateCommChannelFor // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x72b7f0
};

// Class DonkehFrameworkComms.DFCommChannel
// Size: 0x90 (Inherited: 0x28)
struct UDFCommChannel : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	char bChannelPreInitialized : 1; // 0x30(0x01)
	char bChannelClosed : 1; // 0x30(0x01)
	char bCompletedSetup : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName ChannelName; // 0x34(0x08)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UDFCommChannelDefinition* ChannelDefinition; // 0x40(0x08)
	struct UObject* ChannelState; // 0x48(0x08)
	struct TArray<struct UDFCommsFormatBase*> AssociatedCommsFormats; // 0x50(0x10)
	char pad_60[0x30]; // 0x60(0x30)

	void SetChannelState(struct UObject* NewChannelState); // Function DonkehFrameworkComms.DFCommChannel.SetChannelState // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x72dc30
	bool IsReady(); // Function DonkehFrameworkComms.DFCommChannel.IsReady // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72c720
	bool HasFormat(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommChannel.HasFormat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72c380
	struct FString GetChannelNameStr(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelNameStr // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72c010
	struct FName GetChannelName(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bfd0
	struct FName GetChannelGroupNameIfValid(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelGroupNameIfValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bf90
	struct FText GetChannelDisplayName(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bef0
};

// Class DonkehFrameworkComms.DFCommChannelDefinition
// Size: 0xb8 (Inherited: 0x30)
struct UDFCommChannelDefinition : UDataAsset {
	struct FName ChannelName; // 0x30(0x08)
	struct FText ChannelDisplayName; // 0x38(0x18)
	char bInstanceChannelWithGroup : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	struct FName ChannelGroupName; // 0x54(0x08)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct UObject* ChannelStateClass; // 0x60(0x08)
	struct TMap<struct UDFCommsFormatBase*, enum class EDFCommsFormatAccessRule> FormatAccessRules; // 0x68(0x50)

	bool InstancesChannelWithGroup(); // Function DonkehFrameworkComms.DFCommChannelDefinition.InstancesChannelWithGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72c490
};

// Class DonkehFrameworkComms.DFCommChannelStateInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFCommChannelStateInterface : UInterface {

	void BP_OnSetupState(struct FDFCommStateSetupParams& SetupParams); // Function DonkehFrameworkComms.DFCommChannelStateInterface.BP_OnSetupState // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
};

// Class DonkehFrameworkComms.DFCommChannelStateLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDFCommChannelStateLibrary : UBlueprintFunctionLibrary {

	void NotifyChannelOfPreparedState(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.NotifyChannelOfPreparedState // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x72c750
	bool IsChannelStatePrepared(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.IsChannelStatePrepared // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c4c0
	struct UDFCommChannel* GetOwningCommChannel(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.GetOwningCommChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c090
};

// Class DonkehFrameworkComms.DFCommDeveloperSettings
// Size: 0xf0 (Inherited: 0x38)
struct UDFCommDeveloperSettings : UDeveloperSettings {
	struct FSoftClassPath PlayerCommsCompClass; // 0x38(0x18)
	struct TSet<struct FDFCommsFormatEntry> CommsFormatDefinitions; // 0x50(0x50)
	struct TSet<struct FDFCommChannelEntry> CommChannelDefinitions; // 0xa0(0x50)
};

// Class DonkehFrameworkComms.DFCommsFormatBase
// Size: 0xd0 (Inherited: 0x28)
struct UDFCommsFormatBase : UObject {
	char bSingleChannelUsageOnly : 1; // 0x28(0x01)
	char bRequiresValidSingleChannelAssignment : 1; // 0x28(0x01)
	char pad_28_2 : 6; // 0x28(0x01)
	char pad_29[0x17]; // 0x29(0x17)
	struct FDFGenericChannelMsg LastReceivedCommMsg; // 0x40(0x38)
	char pad_78[0x50]; // 0x78(0x50)
	struct FName FormatName; // 0xc8(0x08)

	bool HasAccessToChannel(struct FName ChannelName, enum class EDFCommsFormatAccessRule AccessRulesToCheck); // Function DonkehFrameworkComms.DFCommsFormatBase.HasAccessToChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72c2c0
	bool CanWriteToChannel(struct FName ChannelName); // Function DonkehFrameworkComms.DFCommsFormatBase.CanWriteToChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72ab90
	bool CanReadFromChannel(struct FName ChannelName); // Function DonkehFrameworkComms.DFCommsFormatBase.CanReadFromChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72a610
};

// Class DonkehFrameworkComms.DFCommStatics
// Size: 0x28 (Inherited: 0x28)
struct UDFCommStatics : UBlueprintFunctionLibrary {

	void UpdateExclusiveChannelForFormatByName(struct APlayerController* Player, struct FName FormatNameToUpdate, struct FName SingleChannelNameToUse); // Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormatByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x72dda0
	void UpdateExclusiveChannelForFormat(struct APlayerController* Player, struct UDFCommsFormatBase* FormatToUpdate, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormat // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x72dcb0
	void SendCommsViaChannelByName(struct APlayerController* PlayerSender, struct FName FormatName, struct FName ReceivingChannelName, struct FDFGenericChannelMsg& MsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannelByName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x72d0d0
	void SendCommsViaChannel(struct APlayerController* PlayerSender, struct UDFCommsFormatBase* FormatToUse, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& MsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x72cef0
	bool PlayerHasCommChannelByName(struct APlayerController* Player, struct FName ChannelName); // Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannelByName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c920
	bool PlayerHasCommChannel(struct APlayerController* Player, struct UDFCommChannel* Channel); // Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c860
	bool FindCommsComponentByPlayer(struct APlayerController* Player, struct UDFPlayerCommsComponent*& OutPlayerCommsComp); // Function DonkehFrameworkComms.DFCommStatics.FindCommsComponentByPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x72ba80
	bool CommsFormatUsesChannelByName(struct APlayerController* Player, struct FName FormatName, struct FName ChannelNameToCheck); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannelByName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b550
	bool CommsFormatUsesChannel(struct APlayerController* Player, struct UDFCommsFormatBase* Format, struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b460
	bool CommsFormatHasExclusiveChannelByName(struct APlayerController* PlayerFormatOwner, struct FName FormatName); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannelByName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b3a0
	bool CommsFormatHasExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b320
	struct UDFCommChannel* CommsFormatGetExclusiveChannelByName(struct APlayerController* PlayerFormatOwner, struct FName FormatName); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannelByName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b260
	struct UDFCommChannel* CommsFormatGetExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72b1e0
	void ClearCurrentExclusiveChannelForFormatByName(struct APlayerController* Player, struct FName FormatNameToUpdate); // Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormatByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x72ade0
	void ClearCurrentExclusiveChannelForFormat(struct APlayerController* Player, struct UDFCommsFormatBase* FormatToUpdate); // Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormat // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x72ad30
};

// Class DonkehFrameworkComms.DFCommWorldSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UDFCommWorldSubsystem : UWorldSubsystem {

	void PostSeamlessTravelPCDestroyed(struct AActor* DestroyedPlayerActor); // Function DonkehFrameworkComms.DFCommWorldSubsystem.PostSeamlessTravelPCDestroyed // (Final|Native|Private) // @ game+0x72c9e0
	struct UDFPlayerCommsComponent* InitPlayerComms(struct APlayerController* Player); // Function DonkehFrameworkComms.DFCommWorldSubsystem.InitPlayerComms // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x72c410
	void GameModePostLogin(struct AGameModeBase* GameMode, struct APlayerController* NewPlayer); // Function DonkehFrameworkComms.DFCommWorldSubsystem.GameModePostLogin // (Final|Native|Private) // @ game+0x72be30
};

// Class DonkehFrameworkComms.DFPlayerCommsComponent
// Size: 0x3ab0 (Inherited: 0xb0)
struct UDFPlayerCommsComponent : UActorComponent {
	struct TMap<struct FName, struct UDFCommsFormatBase*> CommsFormats; // 0xb0(0x50)
	struct FDFCommChannelMap OpenCommChannels; // 0x100(0x170)
	struct FDFChannelMsgRecord MsgSendBuffer[0x64]; // 0x270(0x1c20)
	struct FDFChannelMsgRecord MsgRecvBuffer[0x64]; // 0x1e90(0x1c20)

	void UpdateExclusiveChannelToUseForCommsFormatByName(struct FName& FormatName, struct FName& SingleChannelNameToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormatByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x72df50
	void UpdateExclusiveChannelToUseForCommsFormat(struct UDFCommsFormatBase* Format, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormat // (Final|Native|Public|BlueprintCallable) // @ game+0x72de90
	void ServerVerifyCommMsg(int32_t VerifyMsgID); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerVerifyCommMsg // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x72dba0
	void ServerUpdateExclusiveChannelToUseForCommsFormat(struct FName FormatName, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerUpdateExclusiveChannelToUseForCommsFormat // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x72dad0
	void ServerSendCommMsgViaExclChannel(struct FName FormatName, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaExclChannel // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x72d750
	void ServerSendCommMsgViaChannel(struct FName FormatName, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaChannel // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x72d3d0
	void ServerRequestExclusiveChannelUsedForCommsFormat(struct FName RequestedFormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerRequestExclusiveChannelUsedForCommsFormat // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x72d340
	void ServerClearCurrentExclusiveChannelForCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerClearCurrentExclusiveChannelForCommsFormat // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x72d2b0
	void SendCommMsgViaChannelByName(struct FName& FormatName, struct FName& ReceivingChannelName, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannelByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x72cd10
	void SendCommMsgViaChannel(struct UDFCommsFormatBase* FormatToUse, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannel // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x72cb60
	void RemoveCommChannelByName(struct FName ChannelNameToRemove); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannelByName // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x72cae0
	void RemoveCommChannel(struct UDFCommChannel* ChannelToRemove); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannel // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x72ca60
	void RemoveAllCommChannels(); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveAllCommChannels // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c7310
	void ReceiveCommChannelPreRemoved(struct UDFCommChannel* RemovedChannel); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelPreRemoved // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveCommChannelAdded(struct UDFCommChannel* AddedChannel); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelAdded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool FormatUsesChannelByName(struct FName& FormatName, struct FName& ChannelNameToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannelByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bd40
	bool FormatUsesChannel(struct UDFCommsFormatBase* Format, struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bc80
	bool FormatHasExclusiveChannelByName(struct FName& FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannelByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bbe0
	bool FormatHasExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72bb50
	bool FindCommChannel(struct FName ChannelName, struct UDFCommChannel*& OutChannelFound); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FindCommChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72b9b0
	bool FindAssociatedCommsFormat(struct FName FormatName, struct UDFCommsFormatBase*& OutFormatFound); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FindAssociatedCommsFormat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72b8e0
	bool ContainsCommChannelByName(struct FName ChannelNameToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannelByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72b760
	bool ContainsCommChannel(struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72b6d0
	bool ContainsAssociatedCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsAssociatedCommsFormat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x72b640
	void ClientVerifyCommMsgFailed(int32_t VerifyMsgID); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientVerifyCommMsgFailed // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x72b150
	void ClientUpdateExclusiveChannelToUseForCommsFormat(struct FName FormatName, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientUpdateExclusiveChannelToUseForCommsFormat // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x72b080
	void ClientRecvCommMsgFromChannel(struct FName SourceFormatName, struct UDFCommChannel* SourceChannel, struct FDFGenericChannelMsg ReceivedCommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientRecvCommMsgFromChannel // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x72af20
	void ClientClearCurrentExclusiveChannelForCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientClearCurrentExclusiveChannelForCommsFormat // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x72ae90
	void ClearCurrentExclusiveChannelForCommsFormatByName(struct FName& FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormatByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x72aca0
	void ClearCurrentExclusiveChannelForCommsFormat(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormat // (Final|Native|Public|BlueprintCallable) // @ game+0x72ac20
	bool CanSendCommMsgViaChannel(struct UDFCommsFormatBase* ReceivingFormat, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendCommMsgViaChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72a9e0
	bool CanSendAndRecvCommMsgViaChannel(struct FName& FormatName, struct FName& ChannelName, struct FDFGenericChannelMsg& CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendAndRecvCommMsgViaChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72a840
	bool CanRecvCommMsgViaChannel(struct FName& SourceFormatName, struct FName& SourceChannelName, struct FDFGenericChannelMsg& CommMsgToReceive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanRecvCommMsgViaChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x72a6a0
};

// Class DonkehFrameworkComms.DFTextCommsFormat
// Size: 0xe0 (Inherited: 0xd0)
struct UDFTextCommsFormat : UDFCommsFormatBase {
	struct FMulticastInlineDelegate OnChatMsgReceived; // 0xd0(0x10)
};

// Class DonkehFrameworkComms.DFVOIPCommsFormat
// Size: 0x100 (Inherited: 0xd0)
struct UDFVOIPCommsFormat : UDFCommsFormatBase {
	struct FMulticastInlineDelegate OnPlayerTalkingStateChangedOnChannel; // 0xd0(0x10)
	char pad_E0[0x20]; // 0xe0(0x20)

	void OnTalkerPSDestroyed(struct AActor* DestroyedPS); // Function DonkehFrameworkComms.DFVOIPCommsFormat.OnTalkerPSDestroyed // (Final|Native|Protected) // @ game+0x72c7e0
};

// Class DonkehFrameworkComms.DFVOIPCommStatics
// Size: 0x28 (Inherited: 0x28)
struct UDFVOIPCommStatics : UBlueprintFunctionLibrary {

	bool WasPlayerTalking(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.WasPlayerTalking // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72e030
	bool IsPlayerTalkingOverChannel(struct APlayerState* PlayerState, struct UDFCommChannel* TalkChannel); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkingOverChannel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c660
	bool IsPlayerTalking(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalking // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c5e0
	bool IsPlayerTalkerPendingReset(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkerPendingReset // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c560
	struct UVoipListenerSynthComponent* GetVoiceSynthOwnerOfAudioComponent(struct UAudioComponent* TalkerAudioComp); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthOwnerOfAudioComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c240
	struct UVoipListenerSynthComponent* GetVoiceSynthComponentForVOIPTalker(struct UVOIPTalker* Talker); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthComponentForVOIPTalker // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c1c0
	struct FDFPlayerVOIPTalkingState GetValidVoiceEntryForPlayer(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetValidVoiceEntryForPlayer // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x72c130
	void ApplyVOIPTalkerSettingsForPlayer(struct APlayerState* TalkerPlayerState, char ListenerLocalUserNum); // Function DonkehFrameworkComms.DFVOIPCommStatics.ApplyVOIPTalkerSettingsForPlayer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x72a560
};

