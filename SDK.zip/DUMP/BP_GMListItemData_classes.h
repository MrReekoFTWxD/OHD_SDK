// BlueprintGeneratedClass BP_GMListItemData.BP_GMListItemData_C
// Size: 0x50 (Inherited: 0x28)
struct UBP_GMListItemData_C : UObject {
	struct FFGameModeInfo GMInfo; // 0x28(0x28)
};

