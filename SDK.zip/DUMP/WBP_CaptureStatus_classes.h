// WidgetBlueprintGeneratedClass WBP_CaptureStatus.WBP_CaptureStatus_C
// Size: 0x2f8 (Inherited: 0x268)
struct UWBP_CaptureStatus_C : UHDUIUWCaptureStatus {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x268(0x08)
	struct UWidgetAnimation* DisplayCaptureUIAnim; // 0x270(0x08)
	struct UProgressBar* ControlPointProgressBar; // 0x278(0x08)
	struct UTextBlock* ControlPointText; // 0x280(0x08)
	struct UHorizontalBox* GarrisonedUnitHBox; // 0x288(0x08)
	struct UTextBlock* TeamOwnerText; // 0x290(0x08)
	struct FLinearColor LocalOwnershipColorToUse; // 0x298(0x10)
	int32_t PreviewNumFriendlies; // 0x2a8(0x04)
	int32_t PreviewNumEnemies; // 0x2ac(0x04)
	int32_t PreviewMinNumRequiredToCapture; // 0x2b0(0x04)
	bool bFriendlyUnitsRightToLeft; // 0x2b4(0x01)
	bool bEnemyUnitsRightToLeft; // 0x2b5(0x01)
	bool bUseFriendlyOwnershipColor; // 0x2b6(0x01)
	char pad_2B7[0x1]; // 0x2b7(0x01)
	struct FMargin UnitPadding; // 0x2b8(0x10)
	struct FLinearColor FriendlyOwnershipColor; // 0x2c8(0x10)
	struct FLinearColor NeutralOwnershipColor; // 0x2d8(0x10)
	struct FLinearColor EnemyOwnershipColor; // 0x2e8(0x10)

	void UpdateActiveUnits(bool bFriendly, int32_t UnitCount, int32_t MinUnitsRequired); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateActiveUnits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetMinCountToCapture(int32_t MinCount); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.SetMinCountToCapture // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ResizeGarrisonContainer(int32_t NewUnitIconCount); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ResizeGarrisonContainer // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamOwnerText(enum class EHDTeam CaptureTeam); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateTeamOwnerText // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateProgressBarColor(enum class EHDTeam OwningTeam); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateProgressBarColor // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwnerTouchingControlPoint(struct AHDBaseCapturePoint* OverlappingCP, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OwnerTouchingControlPoint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerNoControlPoint(); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OwnerNoControlPoint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ControlPointSetCaptureProgress(bool bContested, float NewValueNorm, float OldValueNorm, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetCaptureProgress // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ControlPointSetOwnershipState(bool bCaptured, enum class EHDTeam NewOwningTeam, enum class EHDTeam OldOwningTeam, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetOwnershipState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ControlPointSetGarrisonedPlayerCount(int32_t NumFriendlies, int32_t NumEnemies, int32_t MinNumRequiredForCapture, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetGarrisonedPlayerCount // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CaptureStatus(int32_t EntryPoint); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ExecuteUbergraph_WBP_CaptureStatus // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

