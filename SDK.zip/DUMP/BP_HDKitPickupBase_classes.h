// BlueprintGeneratedClass BP_HDKitPickupBase.BP_HDKitPickupBase_C
// Size: 0x278 (Inherited: 0x278)
struct ABP_HDKitPickupBase_C : AHDBasePickup_Kit {

	void UserConstructionScript(); // Function BP_HDKitPickupBase.BP_HDKitPickupBase_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

