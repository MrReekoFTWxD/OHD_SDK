// WidgetBlueprintGeneratedClass WBP_DeployMenu.WBP_DeployMenu_C
// Size: 0xfd0 (Inherited: 0x238)
struct UWBP_DeployMenu_C : UDeployMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* BgImg; // 0x240(0x08)
	struct UWBP_DeployMenu_ClassSelectionPanel_C* ClassSelectionPanel; // 0x248(0x08)
	struct UWBP_DeployMenu_DeployButton_C* DeployBtn; // 0x250(0x08)
	struct UTextBlock* MapNameText; // 0x258(0x08)
	struct UTextBlock* MatchTimeText; // 0x260(0x08)
	struct UWBP_DeployMenu_SpawnMapView_C* SpawnMapView; // 0x268(0x08)
	struct UWBP_DeployMenu_SquadSelectionPanel_C* SquadSelectionPanel; // 0x270(0x08)
	struct UButton* SuicideBtn; // 0x278(0x08)
	struct UImage* Team0CheckmarkImage; // 0x280(0x08)
	struct UImage* Team0CheckmarkImage_Vert; // 0x288(0x08)
	struct UImage* Team0SelectionOverlay; // 0x290(0x08)
	struct UImage* Team0SelectionOverlay_Vert; // 0x298(0x08)
	struct UTextBlock* Team0TicketNumText; // 0x2a0(0x08)
	struct UTextBlock* Team0TicketNumText_Vert; // 0x2a8(0x08)
	struct UImage* Team1CheckmarkImage; // 0x2b0(0x08)
	struct UImage* Team1CheckmarkImage_Vert; // 0x2b8(0x08)
	struct UImage* Team1SelectionOverlay; // 0x2c0(0x08)
	struct UImage* Team1SelectionOverlay_Vert; // 0x2c8(0x08)
	struct UTextBlock* Team1TicketNumText; // 0x2d0(0x08)
	struct UTextBlock* Team1TicketNumText_Vert; // 0x2d8(0x08)
	struct UButton* TeamSwitch0Btn; // 0x2e0(0x08)
	struct UButton* TeamSwitch0Btn_Vert; // 0x2e8(0x08)
	struct UTextBlock* TeamSwitch0BtnText; // 0x2f0(0x08)
	struct UTextBlock* TeamSwitch0BtnText_Vert; // 0x2f8(0x08)
	struct UButton* TeamSwitch1Btn; // 0x300(0x08)
	struct UButton* TeamSwitch1Btn_Vert; // 0x308(0x08)
	struct UTextBlock* TeamSwitch1BtnText; // 0x310(0x08)
	struct UTextBlock* TeamSwitch1BtnText_Vert; // 0x318(0x08)
	struct UHorizontalBox* TeamSwitchHBox; // 0x320(0x08)
	struct UVerticalBox* TeamSwitchVBox; // 0x328(0x08)
	bool bBlockAllOtherInput; // 0x330(0x01)
	bool bMenuInitialized; // 0x331(0x01)
	char pad_332[0x6]; // 0x332(0x06)
	struct FMulticastInlineDelegate OnPreloadFinished; // 0x338(0x10)
	bool bDonePreloading; // 0x348(0x01)
	bool bSpawnPointSelected; // 0x349(0x01)
	bool bDeploying; // 0x34a(0x01)
	bool bClearPOISelectionOnDeploy; // 0x34b(0x01)
	char pad_34C[0x4]; // 0x34c(0x04)
	struct FButtonStyle Team0Selected; // 0x350(0x278)
	struct FButtonStyle Team0Deselected; // 0x5c8(0x278)
	struct FButtonStyle Team1Selected; // 0x840(0x278)
	struct FButtonStyle Team1Deselected; // 0xab8(0x278)
	struct FSlateBrush Team0SelectedOverlayBrush; // 0xd30(0x88)
	struct FSlateBrush Team1SelectedOverlayBrush; // 0xdb8(0x88)
	struct FSlateBrush Team0DeselectedOverlayBrush; // 0xe40(0x88)
	struct FSlateBrush Team1DeselectedOverlayBrush; // 0xec8(0x88)
	bool bUseVerticalTeamLayout; // 0xf50(0x01)
	char pad_F51[0x7]; // 0xf51(0x07)
	struct UImage* Team1SelectionOverlayToUse; // 0xf58(0x08)
	struct UImage* Team1CheckmarkImageToUse; // 0xf60(0x08)
	struct UTextBlock* Team1TicketNumTextToUse; // 0xf68(0x08)
	bool bMenuPreInitialized; // 0xf70(0x01)
	char pad_F71[0x7]; // 0xf71(0x07)
	struct UImage* Team0SelectionOverlayToUse; // 0xf78(0x08)
	struct UImage* Team0CheckmarkImageToUse; // 0xf80(0x08)
	struct UTextBlock* Team0TicketNumTextToUse; // 0xf88(0x08)
	struct UTextBlock* Team0SwitchBtnTextToUse; // 0xf90(0x08)
	struct UTextBlock* Team1SwitchBtnTextToUse; // 0xf98(0x08)
	struct UButton* Team1SwitchBtnToUse; // 0xfa0(0x08)
	struct UButton* Team0SwitchBtnToUse; // 0xfa8(0x08)
	struct AHDTeamState* BluforTeamState; // 0xfb0(0x08)
	struct AHDTeamState* OpforTeamState; // 0xfb8(0x08)
	struct UBP_HDFactionInfoBase_C* BluforFactionInfo; // 0xfc0(0x08)
	struct UBP_HDFactionInfoBase_C* OpforFactionInfo; // 0xfc8(0x08)

	void OnPaint(struct FPaintContext& Context); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPaint // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void UpdateMatchTime(); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateMatchTime // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamLayoutElements(bool bUseVerticalLayout, bool bUpdateTeam0); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamLayoutElements // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetTeamSwitchLayout(bool bUseVerticalLayout); // Function WBP_DeployMenu.WBP_DeployMenu_C.SetTeamSwitchLayout // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitTeamLayout(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitTeamLayout // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitSquadSelectionUI(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitSquadSelectionUI // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTicketCounts(); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTicketCounts // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamSwitchUISettings(enum class EHDTeam TeamToUpdate); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchUISettings // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamSwitchVisuals(enum class EHDTeam TeamToUpdate); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchVisuals // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitClassSelectionUI(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitClassSelectionUI // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DeselectCurrentPOI(); // Function WBP_DeployMenu.WBP_DeployMenu_C.DeselectCurrentPOI // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DeployAtSelectedSpawnPoint(); // Function WBP_DeployMenu.WBP_DeployMenu_C.DeployAtSelectedSpawnPoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDeployBtnState(); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateDeployBtnState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CloseDeployMenu(bool bForce); // Function WBP_DeployMenu.WBP_DeployMenu_C.CloseDeployMenu // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreloadContent(); // Function WBP_DeployMenu.WBP_DeployMenu_C.PreloadContent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateSuicideBtnState(); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateSuicideBtnState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CleanupOwningPlayerDelegates(); // Function WBP_DeployMenu.WBP_DeployMenu_C.CleanupOwningPlayerDelegates // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitOwningPlayerDelegates(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitOwningPlayerDelegates // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitTeamUI(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitTeamUI // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitMapUI(); // Function WBP_DeployMenu.WBP_DeployMenu_C.InitMapUI // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RequestSuicide(); // Function WBP_DeployMenu.WBP_DeployMenu_C.RequestSuicide // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamSwitchBtnState(enum class EHDTeam NewTeam); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchBtnState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TeamSwitch(enum class EHDTeam NewTeam); // Function WBP_DeployMenu.WBP_DeployMenu_C.TeamSwitch // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnMouseWheel // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DeployMenu.WBP_DeployMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnDeployMenuInputToggle(); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnDeployMenuInputToggle // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SuicideBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__SuicideBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void Destruct(); // Function WBP_DeployMenu.WBP_DeployMenu_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnOwningCharDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnOwningCharDeath // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnUnpossessedPawn(struct APawn* UnpossessedPawn); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnUnpossessedPawn // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPossessedPawn(struct APawn* PossessedPawn); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPossessedPawn // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerTeamUpdated(char PrevTeam, char NewTeam); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPlayerTeamUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_4_OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_4_OnPreloadFinished__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_5_OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_5_OnSpawnPointSelected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_6_OnSpawnPointDeselected__DelegateSignature(); // Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_6_OnSpawnPointDeselected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnPlayerSpawnTimerElapsed(); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPlayerSpawnTimerElapsed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnRepPlayerStatePC(); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnRepPlayerStatePC // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu.WBP_DeployMenu_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu.WBP_DeployMenu_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void On Team 1 Switch Btn Clicked(); // Function WBP_DeployMenu.WBP_DeployMenu_C.On Team 1 Switch Btn Clicked // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void On Team 0 Switch Btn Clicked(); // Function WBP_DeployMenu.WBP_DeployMenu_C.On Team 0 Switch Btn Clicked // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateTeamStateRefs(); // Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamStateRefs // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnBluforPostInitTeam(struct ADFTeamState* TeamState); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnBluforPostInitTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnOpforPostInitTeam(struct ADFTeamState* TeamState); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnOpforPostInitTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerTeamStateUpdated(struct ADFTeamState* LastTeamState, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPlayerTeamStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu(int32_t EntryPoint); // Function WBP_DeployMenu.WBP_DeployMenu_C.ExecuteUbergraph_WBP_DeployMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu.WBP_DeployMenu_C.OnPreloadFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

