// WidgetBlueprintGeneratedClass WBP_WeaponStatus.WBP_WeaponStatus_C
// Size: 0x2a0 (Inherited: 0x260)
struct UWBP_WeaponStatus_C : UHDUIUWWeaponStatus {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* MagCounterChangeUIAnim; // 0x268(0x08)
	struct UWidgetAnimation* AimStyleInputUIAnim; // 0x270(0x08)
	struct UWidgetAnimation* FireModeInputUIAnim; // 0x278(0x08)
	struct UTextBlock* AimStyleText; // 0x280(0x08)
	struct UTextBlock* FireModeText; // 0x288(0x08)
	struct UTextBlock* MagCounterText; // 0x290(0x08)
	struct UImage* Separator; // 0x298(0x08)

	void ShouldDisplayTotalAmmo(bool& bDisplayTotalAmmo); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.ShouldDisplayTotalAmmo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void UpdateElementVisibility(); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.UpdateElementVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerWeaponChanged(struct AHDBaseWeapon* NewWeap, struct AHDBaseWeapon* PrevWeap); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.BPOwnerWeaponChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerWeaponSetFireMode(enum class EFireMode NewFireMode, enum class EFireMode PreviousFireMode, bool bFromPlayerInput); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.BPOwnerWeaponSetFireMode // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerWeaponAmmoUpdated(struct FHDUIWeaponAmmoState& AmmoState, bool bFromReload, bool bTotalFreeAmmoUpdated, bool bNumFreeAmmoClipsUpdated); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.BPOwnerWeaponAmmoUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetAimStyle(enum class EHDWeaponAimStyle NewAimStyle, enum class EHDWeaponAimStyle PrevAimStyle, bool bFromPlayerInput); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.OwnerSetAimStyle // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_WeaponStatus(int32_t EntryPoint); // Function WBP_WeaponStatus.WBP_WeaponStatus_C.ExecuteUbergraph_WBP_WeaponStatus // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

