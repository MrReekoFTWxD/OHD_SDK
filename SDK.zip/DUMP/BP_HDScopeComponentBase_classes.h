// BlueprintGeneratedClass BP_HDScopeComponentBase.BP_HDScopeComponentBase_C
// Size: 0x820 (Inherited: 0x1f0)
struct UBP_HDScopeComponentBase_C : UHDWeaponScopeComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1f0(0x08)
	bool UseOverlay; // 0x1f8(0x01)
	char pad_1F9[0x3]; // 0x1f9(0x03)
	float ScopeRadius; // 0x1fc(0x04)
	float AimingFOV; // 0x200(0x04)
	float ADSOffset; // 0x204(0x04)
	int32_t ScopeMaterialIndex; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)
	struct TArray<struct FWeightedBlendable> PostProcessMaterial; // 0x210(0x10)
	struct UMaterialInterface* ScopeGlassMaterial; // 0x220(0x08)
	struct UMaterialInterface* ScopeOpticMaterial; // 0x228(0x08)
	struct UUserWidget* ScopeOverlayClass; // 0x230(0x08)
	float FreeAimMaxPitch; // 0x238(0x04)
	float FreeAimMaxYaw; // 0x23c(0x04)
	float ReticleOffsetY; // 0x240(0x04)
	float ReticleOffsetX; // 0x244(0x04)
	struct UMaterialInstanceDynamic* ScopeMIDGlass; // 0x248(0x08)
	struct UUserWidget* ScopeOverlay; // 0x250(0x08)
	float AimInterpSpeed; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct UMaterialInstanceDynamic* ScopeMID; // 0x260(0x08)
	float DefaultAimingFOV; // 0x268(0x04)
	float DefaultAimInterpSpeed; // 0x26c(0x04)
	float DefaultFreeAimPitch; // 0x270(0x04)
	float DefaultFreeAimYaw; // 0x274(0x04)
	char pad_278[0x8]; // 0x278(0x08)
	struct FPostProcessSettings DefaultCameraPostProcess; // 0x280(0x540)
	bool bIsScopedIn; // 0x7c0(0x01)
	char pad_7C1[0x3]; // 0x7c1(0x03)
	float DefaultADSOffset; // 0x7c4(0x04)
	struct UMeshComponent* ParentMesh; // 0x7c8(0x08)
	struct AHDPlayerController* ControllerRef; // 0x7d0(0x08)
	struct ABP_HDPlayerCharacterBase_C* CharacterRef; // 0x7d8(0x08)
	struct ABP_HDWeaponBase_C* ParentWeaponRef; // 0x7e0(0x08)
	struct TArray<struct FWeightedBlendable> PostProcessRef; // 0x7e8(0x10)
	struct ADFPlayerCameraManager* CameraRef; // 0x7f8(0x08)
	struct TArray<struct UBP_HDScopeComponentBase_C*> ParentSightList; // 0x800(0x10)
	struct FMaterialParameterInfo MPC; // 0x810(0x10)

	void ClearOwnerData(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ClearOwnerData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupOwnerData(bool& IsValid); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.SetupOwnerData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LoadDefaults(bool IsPlayerDead); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.LoadDefaults // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SaveDefaults(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.SaveDefaults // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Init(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.Init // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ScopeEffect(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ScopeEffect // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CanScope(bool& CanScope); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.CanScope // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetData(struct ABP_HDPlayerCharacterBase_C*& Character, struct AHDPlayerController*& Controller, struct UDFCharacterMovementComponent*& Movement, struct ADFPlayerCameraManager*& Camera, struct ABP_HDWeaponBase_C*& Parent, struct USkeletalMeshComponent*& CharacterMesh, struct UMeshComponent*& WeaponMesh, struct TArray<struct UBP_HDScopeComponentBase_C*>& ParentSightList, struct TArray<struct UMaterialInstanceDynamic*>& FirstPersonMatArray, struct TArray<struct UMaterialInstanceDynamic*>& ThirdPersonMatArray); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.GetData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AimOut(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimOut // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AimIn(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimIn // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AimTransition(bool bIsStartTransition); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimTransition // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AimStyle(struct AHDPlayerCharacter* Character, enum class EHDWeaponAimStyle NewAimStyle, enum class EHDWeaponAimStyle PrevAimStyle, bool bFromPlayerInput); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimStyle // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DeathEvent(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.DeathEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ChangeSights(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ChangeSights // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaSeconds); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void EventActivated(struct UActorComponent* Component, bool bReset); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.EventActivated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EventDeactivated(struct UActorComponent* Component); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.EventDeactivated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BindEvents(struct ABP_HDPlayerCharacterBase_C* NewCharacter, struct ABP_HDWeaponBase_C* NewWeapon); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.BindEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UnbindEvents(struct ABP_HDPlayerCharacterBase_C* OldCharacter, struct ABP_HDWeaponBase_C* OldWeapon); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.UnbindEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDScopeComponentBase(int32_t EntryPoint); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ExecuteUbergraph_BP_HDScopeComponentBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

