// WidgetBlueprintGeneratedClass WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C
// Size: 0x2b9 (Inherited: 0x230)
struct UWBP_DeployMenu_ClassSelectionPanel_C : UDeployMenu_ClassSelectionPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UScrollBox* ClassScrollBox; // 0x238(0x08)
	bool bPanelInitialized; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct ABP_HDPlayerControllerBase_C* HDOwningPlayer; // 0x248(0x08)
	struct FTimerHandle TimerHandle_CheckRestrictions; // 0x250(0x08)
	struct UWBP_DeployMenu_ClassSelectionListing_C* KitListingWidgetClass; // 0x258(0x08)
	struct TSet<struct UHDKit*> DesignPreviewKits; // 0x260(0x50)
	struct UHDKit* SelectedClass; // 0x2b0(0x08)
	enum class EHDTeam LastFaction; // 0x2b8(0x01)

	void SetClassSelectionState(struct UHDKit* ClassToUpdate, bool bSelected, bool bMatchDisplayNames, bool& bClassUpdated); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalUpdateSelectionState(struct UDeployMenu_ClassSelectionListing* NewSelection); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalUpdateSelectionState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectFirstUnrestrictedClass(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SelectFirstUnrestrictedClass // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalDeselectAllClasses(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalDeselectAllClasses // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsValidClassListingIndex(int32_t ChildIndex, bool& bValidIndex); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.IsValidClassListingIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void SetClassSelectionStateByIndex(int32_t ChildIndex, bool bSelected); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionStateByIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleRestrictionsTimer(bool bEnabled, bool bFireOnceImmediately); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ToggleRestrictionsTimer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalCreateClassListingWidget(struct UHDKit* Kit, struct UWBP_DeployMenu_ClassSelectionListing_C*& NewKitListingWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalCreateClassListingWidget // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalPopulateListWithClasses(struct TSet<struct UHDKit*> TeamKits); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalPopulateListWithClasses // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RepopulateListByFaction(enum class EHDTeam OwningPlayerTeam); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.RepopulateListByFaction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void LateInit_RepPlayerState(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.LateInit_RepPlayerState // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CheckRestrictions(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.CheckRestrictions // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Destruct(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnClassSelected(struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassSelected // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnClassDeselected(struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassDeselected // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel(int32_t EntryPoint); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel // (Final|UbergraphFunction) // @ game+0xec54e0
};

