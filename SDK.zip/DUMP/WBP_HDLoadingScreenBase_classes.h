// WidgetBlueprintGeneratedClass WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C
// Size: 0x342 (Inherited: 0x230)
struct UWBP_HDLoadingScreenBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* BackgroundImage_Map; // 0x238(0x08)
	struct UTextBlock* BluforFactionName; // 0x240(0x08)
	struct UOverlay* BluforTeamInfo; // 0x248(0x08)
	struct UTextBlock* BluforTeamReinforcementText; // 0x250(0x08)
	struct UTextBlock* DeploymentText; // 0x258(0x08)
	struct UThrobber* DeploymentThrobber; // 0x260(0x08)
	struct UOverlay* GameModeHeader; // 0x268(0x08)
	struct UTextBlock* GameModeNameText; // 0x270(0x08)
	struct UTextBlock* MapNameText; // 0x278(0x08)
	struct UOverlay* MapOverview; // 0x280(0x08)
	struct UImage* MinimapImage; // 0x288(0x08)
	struct UTextBlock* OpforFactionName; // 0x290(0x08)
	struct UOverlay* OpforTeamInfo; // 0x298(0x08)
	struct UTextBlock* OpforTeamReinforcementText; // 0x2a0(0x08)
	struct TArray<struct TSoftObjectPtr<UTexture2D>> MapBgImages; // 0x2a8(0x10)
	struct FSlateBrush MapBgBrush; // 0x2b8(0x88)
	bool bEnableMapOverviewUI; // 0x340(0x01)
	bool bEnableTeamInfoUI; // 0x341(0x01)

	void SetMapBgImage(struct TSoftObjectPtr<UTexture2D> InBgImage); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapBgImage // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetOpforStartingTicketCount(int32_t TicketCount); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetOpforStartingTicketCount // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetBluforStartingTicketCount(int32_t TicketCount); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetBluforStartingTicketCount // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetMapElementVisibility(enum class ESlateVisibility NewVisibility); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapElementVisibility // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetLoadingScreenDescription(struct FLoadingScreenDescription& Description); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLoadingScreenDescription // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void SetLevelLoadData(struct FLoadScreenLevelData& LevelData); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLevelLoadData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDLoadingScreenBase(int32_t EntryPoint); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.ExecuteUbergraph_WBP_HDLoadingScreenBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

