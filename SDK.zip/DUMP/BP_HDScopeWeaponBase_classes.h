// BlueprintGeneratedClass BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C
// Size: 0x1070 (Inherited: 0xa54)
struct ABP_HDScopeWeaponBase_C : ABP_HDWeaponBase_C {
	char pad_A54[0x4]; // 0xa54(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa58(0x08)
	struct USphereComponent* RadiusDebugSphere; // 0xa60(0x08)
	struct USceneComponent* RadiusDebugTopPoint; // 0xa68(0x08)
	struct ABP_HDPlayerCharacterBase_C* PlayerCharOwner; // 0xa70(0x08)
	struct UDFCharacterMovementComponent* PlayerCharOwnerMoveComp; // 0xa78(0x08)
	struct AHDPlayerController* PCOwner; // 0xa80(0x08)
	struct ADFPlayerCameraManager* PlayerOwnerCamMgr; // 0xa88(0x08)
	float DefaultAimingFOV; // 0xa90(0x04)
	float DefaultAimingDistance; // 0xa94(0x04)
	float DefaultAimInterpSpeed; // 0xa98(0x04)
	float DefaultFreeAimPitch; // 0xa9c(0x04)
	float DefaultFreeAimYaw; // 0xaa0(0x04)
	char pad_AA4[0xc]; // 0xaa4(0x0c)
	struct FPostProcessSettings DefaultCameraPostProcess; // 0xab0(0x540)
	struct UMaterialInstanceDynamic* ScopeMID; // 0xff0(0x08)
	struct UMaterialInstanceDynamic* ScopeMIDGlass; // 0xff8(0x08)
	bool bUseOverlay; // 0x1000(0x01)
	char pad_1001[0x3]; // 0x1001(0x03)
	float AimingFOV; // 0x1004(0x04)
	float AimInterpSpeed; // 0x1008(0x04)
	float AimInDelay; // 0x100c(0x04)
	float BlurEffectDelay; // 0x1010(0x04)
	float ScopeRadius; // 0x1014(0x04)
	float FreeAimMaxPitch; // 0x1018(0x04)
	float FreeAimMaxYaw; // 0x101c(0x04)
	int32_t ScopeMaterialIndex; // 0x1020(0x04)
	char pad_1024[0x4]; // 0x1024(0x04)
	struct TArray<struct FWeightedBlendable> PostProcessMaterial; // 0x1028(0x10)
	struct UMaterialInterface* ScopeGlassMaterial; // 0x1038(0x08)
	struct UMaterialInterface* ScopeOpticMaterial; // 0x1040(0x08)
	struct UUserWidget* ScopeOverlay; // 0x1048(0x08)
	struct UUserWidget* ScopeOverlayClass; // 0x1050(0x08)
	float ReticleOffsetY; // 0x1058(0x04)
	float ReticleOffsetX; // 0x105c(0x04)
	struct TArray<struct FWeightedBlendable> PostProcessRef; // 0x1060(0x10)

	void ShouldUseScope(bool& bUseScope); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ShouldUseScope // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SaveOwnerDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SaveOwnerDefaultValues // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestoreOwnerDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.RestoreOwnerDefaultValues // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ScopeEffects(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ScopeEffects // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AimOut(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimOut // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AimIn(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimIn // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HasLocallyPlayerControlledOwner(bool& bLocalPlayerOwner); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasLocallyPlayerControlledOwner // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void HasValidOwnerData(bool bCharAliveCheck, bool& bValidOwnerData); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasValidOwnerData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ResetDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ResetDefaultValues // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CleanupOwnerData(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.CleanupOwnerData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupOwnerData(bool& bValidOwnerData); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetupOwnerData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UserConstructionScript(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void StartAimInScope(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.StartAimInScope // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void StartAimOutScope(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.StartAimOutScope // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaSeconds); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEquipFinished(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnEquipFinished // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnUnEquip // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ResetAimOutGate(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ResetAimOutGate // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnLeaveInventory // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void SetCurrentSight(struct USceneComponent* Sight); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetCurrentSight // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnBraceAimEnd(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.OnBraceAimEnd // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDScopeWeaponBase(int32_t EntryPoint); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ExecuteUbergraph_BP_HDScopeWeaponBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

