// WidgetBlueprintGeneratedClass WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C
// Size: 0x238 (Inherited: 0x230)
struct UWBP_MouseInputCatcherOverlay_C : UUserWidget {
	struct UWBP_OptionsMenuItem_InputKeySelector_C* TargetIKS; // 0x230(0x08)

	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseWheel // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectKey(struct FKey Key); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.SelectKey // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

