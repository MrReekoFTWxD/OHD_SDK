// BlueprintGeneratedClass BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C
// Size: 0x710 (Inherited: 0x6a0)
struct ABP_HDPlayerControllerBase_C : AHDPlayerController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6a0(0x08)
	struct UWBP_DeployMenu_C* DeployMenu; // 0x6a8(0x08)
	bool bInitialSpawn; // 0x6b0(0x01)
	bool bWantsToOpenDeployMenu; // 0x6b1(0x01)
	bool bDeployMenuShown; // 0x6b2(0x01)
	char pad_6B3[0x5]; // 0x6b3(0x05)
	struct FMulticastInlineDelegate OnRepPlayerState; // 0x6b8(0x10)
	bool bOpenDeployMenuOnBeginPlay; // 0x6c8(0x01)
	char pad_6C9[0x7]; // 0x6c9(0x07)
	struct UUserWidget* DeathScreen; // 0x6d0(0x08)
	bool bDeathScreenShown; // 0x6d8(0x01)
	char pad_6D9[0x7]; // 0x6d9(0x07)
	struct UUserWidget* WatermarkWidget; // 0x6e0(0x08)
	struct TSoftClassPtr<UObject> WatermarkWidgetClass; // 0x6e8(0x28)

	void GetJoystickDirection(enum class EJoystickTypes Stick, struct FVector2D& StickInput); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetJoystickDirection // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestoreCamDefaultViewRotationYawLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationYawLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestoreCamDefaultViewRotationPitchLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationPitchLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestoreCamDefaultViewRotationRollLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationRollLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestoreCamDefaultViewRotationLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCamViewRotationYawLimits(float ViewYawMin, float ViewYawMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationYawLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCamViewRotationPitchLimits(float ViewPitchMin, float ViewPitchMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationPitchLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCamViewRotationRollLimits(float ViewRollMin, float ViewRollMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationRollLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCamViewRotationLimits(struct FRotator ViewRotMin, struct FRotator ViewRotMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSquadLockedState(struct AHDSquadState* Squad, bool bLocked); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetSquadLockedState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void KickSquadMember(struct AHDSquadState* Squad, struct AHDPlayerState* MemberToRemove, bool& bRemoveSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.KickSquadMember // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LeaveCurrentSquad(bool& bLeaveSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LeaveCurrentSquad // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsSquadLeader(struct AHDSquadState* Squad, bool& bSquadLeader); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsSquadLeader // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CanJoinSquad(struct AHDSquadState* SquadToJoin, bool& bJoinableSquad); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CanJoinSquad // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void JoinSquad(struct AHDSquadState* SquadToJoin, bool& bJoinSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.JoinSquad // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalCreateUnnamedSquad(struct AHDPlatoonState* ForPlatoon, bool bJoinSquadAfterCreation, bool bStartLocked, bool& bSuccess, struct AHDSquadState*& NewSquad); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InternalCreateUnnamedSquad // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetHDTeamState(struct AHDTeamState*& TeamState); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDTeamState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetHDPlayerState(struct AHDPlayerState*& PlayerState); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDPlayerState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SpawnVehicleAtPlayer(struct ABP_HDVehicleBase_C* VehicleClass); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SpawnVehicleAtPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HideHUD(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.HideHUD // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ShowHUD(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ShowHUD // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetTeamKits(struct TSet<struct UHDKit*>& TeamKits); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetTeamKits // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void GetMinimapWidget(struct UDFMinimap*& MinimapWidget); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetMinimapWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsVictoryMenuShown(bool& bShown); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsVictoryMenuShown // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void DeathScreenToggle(bool bShow); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeathScreenToggle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UnloadDeathScreen(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UnloadDeathScreen // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LoadDeathScreen(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeathScreen // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DeployMenuToggle(bool bShowMenu, bool bForce); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeployMenuToggle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UnloadDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UnloadDeployMenu // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LoadDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeployMenu // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LoadAndActivateDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadAndActivateDeployMenu // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_Fire_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_5 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_Fire_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_4 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_DeployMenu_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_DeployMenu_K2Node_InputActionEvent_3 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_F1_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F1_K2Node_InputKeyEvent_4 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_F2_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F2_K2Node_InputKeyEvent_3 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_F3_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F3_K2Node_InputKeyEvent_2 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_Use_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Use_K2Node_InputActionEvent_2 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_F4_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F4_K2Node_InputKeyEvent_1 // (BlueprintEvent) // @ game+0xec54e0
	void OnLoaded_97A2A56D4425648AEE60ECA073085E53(struct UObject* Loaded); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnLoaded_97A2A56D4425648AEE60ECA073085E53 // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1 // (BlueprintEvent) // @ game+0xec54e0
	void ServerCreateAndJoinUserSquadUnnamed(struct AHDPlatoonState* ForPlatoon); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerCreateAndJoinUserSquadUnnamed // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerLeaveCurrentSquad(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerLeaveCurrentSquad // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerJoinSquad(struct AHDSquadState* SquadToJoin); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerJoinSquad // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerSetSquadLockedState(struct AHDSquadState* Squad, bool bLocked); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerSetSquadLockedState // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerKickSquadMember(struct AHDSquadState* Squad, struct AHDPlayerState* MemberToRemove); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerKickSquadMember // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdatePlayerPOIs(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UpdatePlayerPOIs // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveBeginPlay(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnDeployMenuPreloadFinished(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnDeployMenuPreloadFinished // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRepPlayerState(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveOnRepPlayerState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerSpawnTimerElapsed(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnPlayerSpawnTimerElapsed // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlayerTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePlayerTeamNumUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void TryGetInVehicle(struct AArcBaseVehicle* Vehicle); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.TryGetInVehicle // (Net|NetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RequestExitVehicle(struct AArcBaseVehicle* Vehicle); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RequestExitVehicle // (Net|NetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Server_RequestSeatChange(int32_t Seat); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.Server_RequestSeatChange // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceivePossessPawn(struct APawn* NewPawn); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void CharacterDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CharacterDeath // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Auth_SpawnVehicle(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.Auth_SpawnVehicle // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveGameHasEnded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveUnpossessPawn(struct APawn* UnpossessedPawn); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveUnpossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDPlayerControllerBase(int32_t EntryPoint); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ExecuteUbergraph_BP_HDPlayerControllerBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnRepPlayerState__DelegateSignature(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnRepPlayerState__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

