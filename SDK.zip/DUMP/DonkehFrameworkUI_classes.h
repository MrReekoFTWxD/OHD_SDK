// Class DonkehFrameworkUI.DFBaseMenu
// Size: 0x238 (Inherited: 0x230)
struct UDFBaseMenu : UUserWidget {
	char bMenuConstructedInDesigner : 1; // 0x230(0x01)
	char bMenuPopped : 1; // 0x230(0x01)
	char bFlushPlayerInputUponConstruction : 1; // 0x230(0x01)
	char pad_230_3 : 5; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)

	void RemoveFromMenuStack(); // Function DonkehFrameworkUI.DFBaseMenu.RemoveFromMenuStack // (Final|Native|Public|BlueprintCallable) // @ game+0x703520
	void ReceiveOnMenuUncovered(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuUncovered // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMenuPush(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuPush // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMenuPop(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuPop // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMenuCovered(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuCovered // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsTopOfMenuStack(); // Function DonkehFrameworkUI.DFBaseMenu.IsTopOfMenuStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x703070
};

// Class DonkehFrameworkUI.DFContextualWidgetBase
// Size: 0x240 (Inherited: 0x230)
struct UDFContextualWidgetBase : UUserWidget {
	struct TArray<struct UDFContextualWidgetPrerequisiteBase*> Prerequisites; // 0x230(0x10)

	bool TestPrerequisites(bool bInvokeEvents); // Function DonkehFrameworkUI.DFContextualWidgetBase.TestPrerequisites // (Final|Native|Public|BlueprintCallable) // @ game+0x703b40
	void PrerequisitesMet(); // Function DonkehFrameworkUI.DFContextualWidgetBase.PrerequisitesMet // (Native|Event|Protected|BlueprintEvent) // @ game+0x703390
	void PrerequisiteNotMet(struct UDFContextualWidgetPrerequisiteBase* FailedPrereq); // Function DonkehFrameworkUI.DFContextualWidgetBase.PrerequisiteNotMet // (Native|Event|Protected|BlueprintEvent) // @ game+0x703300
};

// Class DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase
// Size: 0x30 (Inherited: 0x28)
struct UDFContextualWidgetPrerequisiteBase : UObject {
	char bForceSuccess : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)

	bool TestPrerequisite(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.TestPrerequisite // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x703ac0
	bool SatisfiesPrerequisite(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.SatisfiesPrerequisite // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x703840
	struct UDFContextualWidgetBase* GetWidgetOuter(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.GetWidgetOuter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702c70
};

// Class DonkehFrameworkUI.DFMenuManager
// Size: 0x58 (Inherited: 0x28)
struct UDFMenuManager : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FMenuStackEntry> MenuStack; // 0x30(0x10)
	struct FSoftClassPath MenuManagerClassName; // 0x40(0x18)

	struct UDFBaseMenu* Top(); // Function DonkehFrameworkUI.DFMenuManager.Top // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x703bd0
	void RemoveMenu(struct UDFBaseMenu* MenuToRemove); // Function DonkehFrameworkUI.DFMenuManager.RemoveMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x703540
	void PopMenu(); // Function DonkehFrameworkUI.DFMenuManager.PopMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x7032e0
	void ClearMenuStack(); // Function DonkehFrameworkUI.DFMenuManager.ClearMenuStack // (Final|Native|Public|BlueprintCallable) // @ game+0x702350
	void ActivateMenu(struct UDFBaseMenu* MenuToAdd, enum class EMenuActivationMode ActivationMode, bool bShowMouseCursor, bool bUIOnlyInput); // Function DonkehFrameworkUI.DFMenuManager.ActivateMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x702130
};

// Class DonkehFrameworkUI.DFMenuManagerBlueprintFunctions
// Size: 0x28 (Inherited: 0x28)
struct UDFMenuManagerBlueprintFunctions : UBlueprintFunctionLibrary {

	struct UDFMenuManager* GetMenuManager(struct UObject* WorldContextObject); // Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.GetMenuManager // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x702a20
	struct UDFBaseMenu* CreateAndActivate(struct UObject* WorldContextObject, struct UDFBaseMenu* MenuWidgetType, struct APlayerController* OwningPlayer, enum class EMenuActivationMode ActivationMode, bool bShowMouseCursor, bool bUIOnlyInput); // Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.CreateAndActivate // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x702470
};

// Class DonkehFrameworkUI.DFMinimap
// Size: 0x298 (Inherited: 0x230)
struct UDFMinimap : UUserWidget {
	struct TArray<struct UDFPOIWidget*> MapPOIs; // 0x230(0x10)
	char pad_240[0x18]; // 0x240(0x18)
	struct FVector2D CurrentMapPos; // 0x258(0x08)
	float CurrentZoom; // 0x260(0x04)
	float MaxZoom; // 0x264(0x04)
	float MapLength; // 0x268(0x04)
	struct FVector MapOffset; // 0x26c(0x0c)
	struct UDataTable* POIDataTable; // 0x278(0x08)
	struct UCanvasPanel* OuterCanvas; // 0x280(0x08)
	struct UCanvasPanel* MapCanvas; // 0x288(0x08)
	struct UImage* MapImg; // 0x290(0x08)

	void UpdateZoomValue(float NewZoomValue); // Function DonkehFrameworkUI.DFMinimap.UpdateZoomValue // (Native|Protected|BlueprintCallable) // @ game+0x703cf0
	void UpdateMapPos(struct FVector2D& NewMapPos); // Function DonkehFrameworkUI.DFMinimap.UpdateMapPos // (Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x703c20
	void SetMapDirty(); // Function DonkehFrameworkUI.DFMinimap.SetMapDirty // (Final|Native|Protected|BlueprintCallable) // @ game+0x703a10
	bool RemovePOIByActorClass(struct AActor*& POIActorClass); // Function DonkehFrameworkUI.DFMinimap.RemovePOIByActorClass // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x703790
	bool RemovePOIByActor(struct AActor* POIActorToRemove); // Function DonkehFrameworkUI.DFMinimap.RemovePOIByActor // (Native|Public|BlueprintCallable) // @ game+0x7036f0
	bool RemovePOIAt(int32_t Index); // Function DonkehFrameworkUI.DFMinimap.RemovePOIAt // (Final|Native|Public|BlueprintCallable) // @ game+0x703660
	bool RemovePOI(struct UDFPOIWidget* POIToRemove); // Function DonkehFrameworkUI.DFMinimap.RemovePOI // (Native|Public|BlueprintCallable) // @ game+0x7035c0
	void ReceiveOnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function DonkehFrameworkUI.DFMinimap.ReceiveOnPOISelectionStateChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	bool ProjectWorldLocationToMap(struct FVector WorldLocation, struct FVector2D& MapLocation); // Function DonkehFrameworkUI.DFMinimap.ProjectWorldLocationToMap // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7033b0
	void OnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function DonkehFrameworkUI.DFMinimap.OnPOISelectionStateChanged // (Native|Public) // @ game+0x703210
	bool HasPOI(struct UDFPOIWidget* POI); // Function DonkehFrameworkUI.DFMinimap.HasPOI // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702cf0
	bool HasAnyPOIs(); // Function DonkehFrameworkUI.DFMinimap.HasAnyPOIs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702c90
	int32_t GetPOIIndex(struct UDFPOIWidget* POI); // Function DonkehFrameworkUI.DFMinimap.GetPOIIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702ba0
	int32_t GetPOICount(); // Function DonkehFrameworkUI.DFMinimap.GetPOICount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702b70
	struct UDFPOIWidget* GetPOIAt(int32_t Index); // Function DonkehFrameworkUI.DFMinimap.GetPOIAt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702ae0
	struct FVector2D GetMapSizeLocal(); // Function DonkehFrameworkUI.DFMinimap.GetMapSizeLocal // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7029e0
	struct FVector2D GetMapSizeAbsolute(); // Function DonkehFrameworkUI.DFMinimap.GetMapSizeAbsolute // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x702980
	bool FindPOIByActor(struct AActor* POIActor, struct UDFPOIWidget*& OutFoundPOI); // Function DonkehFrameworkUI.DFMinimap.FindPOIByActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x702720
	bool DeprojectMapLocationToWorld(struct FVector2D MapLocation, struct FVector& WorldLocation); // Function DonkehFrameworkUI.DFMinimap.DeprojectMapLocationToWorld // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x702620
	bool ConvertMapLocationToLocalWidgetLocation(struct FVector2D MapLocation, struct FVector2D& WidgetLocation); // Function DonkehFrameworkUI.DFMinimap.ConvertMapLocationToLocalWidgetLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7023a0
	int32_t ClearPOIs(); // Function DonkehFrameworkUI.DFMinimap.ClearPOIs // (Final|Native|Public|BlueprintCallable) // @ game+0x702370
	struct UDFPOIWidget* AddNewPOI(struct AActor* POIActor); // Function DonkehFrameworkUI.DFMinimap.AddNewPOI // (Native|Public|BlueprintCallable) // @ game+0x702280
};

// Class DonkehFrameworkUI.DFPOIComponent
// Size: 0xc8 (Inherited: 0xb0)
struct UDFPOIComponent : UActorComponent {
	char pad_B0[0x14]; // 0xb0(0x14)
	char bAutoRegisterPOI : 1; // 0xc4(0x01)
	char pad_C4_1 : 7; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)

	void UnregisterPOI(); // Function DonkehFrameworkUI.DFPOIComponent.UnregisterPOI // (Final|Native|Public|BlueprintCallable) // @ game+0x703c00
	void RegisterPOI(struct UDFMinimap* MinimapWidget); // Function DonkehFrameworkUI.DFPOIComponent.RegisterPOI // (Final|Native|Public|BlueprintCallable) // @ game+0x7034a0
	void OnMinimapLateInit(struct UDFMinimap* NewMinimap); // Function DonkehFrameworkUI.DFPOIComponent.OnMinimapLateInit // (Final|Native|Private) // @ game+0x7030a0
	bool IsPOIRegistered(); // Function DonkehFrameworkUI.DFPOIComponent.IsPOIRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x703010
	struct UDFPOIWidget* GetPOIWidget(); // Function DonkehFrameworkUI.DFPOIComponent.GetPOIWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702c30
	struct UDFMinimap* GetMinimap(); // Function DonkehFrameworkUI.DFPOIComponent.GetMinimap // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702aa0
};

// Class DonkehFrameworkUI.DFPOIWidget
// Size: 0x3a0 (Inherited: 0x230)
struct UDFPOIWidget : UUserWidget {
	char pad_230[0x10]; // 0x230(0x10)
	struct AActor* POIActor; // 0x240(0x08)
	struct FMinimapPOITableRow POIActorData; // 0x248(0x130)
	char pad_378[0x8]; // 0x378(0x08)
	struct FMulticastInlineDelegate OnSelectionStateChanged; // 0x380(0x10)
	char bSelected : 1; // 0x390(0x01)
	char pad_390_1 : 7; // 0x390(0x01)
	char pad_391[0x7]; // 0x391(0x07)
	struct UNamedSlot* IconSlot; // 0x398(0x08)

	void UpdateRotation(); // Function DonkehFrameworkUI.DFPOIWidget.UpdateRotation // (Final|Native|Protected|BlueprintCallable) // @ game+0x703cd0
	void UpdatePosition(); // Function DonkehFrameworkUI.DFPOIWidget.UpdatePosition // (Final|Native|Protected|BlueprintCallable) // @ game+0x703cb0
	void SetPOISelectionState(bool bNewSelected); // Function DonkehFrameworkUI.DFPOIWidget.SetPOISelectionState // (Final|Native|Protected|BlueprintCallable) // @ game+0x703a30
	void SelectPOI(); // Function DonkehFrameworkUI.DFPOIWidget.SelectPOI // (Final|Native|Public|BlueprintCallable) // @ game+0x703870
	void ReceivePOISelected(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOISelected // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePOIInitialized(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOIInitialized // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePOIDeselected(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOIDeselected // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnPOIActorEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function DonkehFrameworkUI.DFPOIWidget.ReceiveOnPOIActorEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool ReceiveCanSelect(); // Function DonkehFrameworkUI.DFPOIWidget.ReceiveCanSelect // (Event|Protected|BlueprintEvent|Const) // @ game+0xec54e0
	void OnPOIActorEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function DonkehFrameworkUI.DFPOIWidget.OnPOIActorEndPlay // (Native|Protected) // @ game+0x703140
	void OnOwningMapDirty(); // Function DonkehFrameworkUI.DFPOIWidget.OnOwningMapDirty // (Final|Native|Private) // @ game+0x703120
	bool IsSelectable(); // Function DonkehFrameworkUI.DFPOIWidget.IsSelectable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x703040
	bool IsPOIActorValid(); // Function DonkehFrameworkUI.DFPOIWidget.IsPOIActorValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702fa0
	bool IsInitialized(); // Function DonkehFrameworkUI.DFPOIWidget.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702f60
	bool IsDynamic(); // Function DonkehFrameworkUI.DFPOIWidget.IsDynamic // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702f30
	void InitPOI(struct UDFMinimap* OwningMapWidget, struct AActor* ActorToTrack, struct FMinimapPOITableRow& ActorPOIData); // Function DonkehFrameworkUI.DFPOIWidget.InitPOI // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x702d80
	bool HasFixedRotation(); // Function DonkehFrameworkUI.DFPOIWidget.HasFixedRotation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702cc0
	struct FSlateBrush GetDefaultIconBrush(); // Function DonkehFrameworkUI.DFPOIWidget.GetDefaultIconBrush // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7027f0
	void DeselectPOI(); // Function DonkehFrameworkUI.DFPOIWidget.DeselectPOI // (Final|Native|Public|BlueprintCallable) // @ game+0x702700
	bool CanSelect(); // Function DonkehFrameworkUI.DFPOIWidget.CanSelect // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x702320
};

// Class DonkehFrameworkUI.POIWidgetSlotInterface
// Size: 0x28 (Inherited: 0x28)
struct UPOIWidgetSlotInterface : UInterface {

	void SetIconBrush(struct FSlateBrush& NewIconBrush); // Function DonkehFrameworkUI.POIWidgetSlotInterface.SetIconBrush // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x703890
	struct UNamedSlot* GetIconSlot(); // Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconSlot // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x702950
	struct FSlateBrush GetIconBrush(); // Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconBrush // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x7028a0
};

