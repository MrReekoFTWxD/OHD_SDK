// WidgetBlueprintGeneratedClass WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C
// Size: 0x280 (Inherited: 0x230)
struct UWBP_DeployMenu_SpawnMapView_C : UDeployMenu_SpawnMapView {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_DeployMenu_SpawnMinimap_C* Minimap; // 0x238(0x08)
	bool bMenuInitialized; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct FMulticastInlineDelegate OnPreloadFinished; // 0x248(0x10)
	struct AActor* SelectedPOIActor; // 0x258(0x08)
	struct FMulticastInlineDelegate OnSpawnPointSelected; // 0x260(0x10)
	struct FMulticastInlineDelegate OnSpawnPointDeselected; // 0x270(0x10)

	void UpdatePlayerPOIs(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.UpdatePlayerPOIs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetMinimapData(bool& bSuccess, struct TSoftObjectPtr<UTexture2D>& MinimapImg, struct FMinimapGenerationSettings& MinimapSettings); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.GetMinimapData // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void PreloadContent(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.PreloadContent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_1_OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_1_OnPreloadFinished__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnPreloadFinished (SpawnMapView)(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnPreloadFinished (SpawnMapView) // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_SpawnMapView(int32_t EntryPoint); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMapView // (Final|UbergraphFunction) // @ game+0xec54e0
	void OnSpawnPointDeselected__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnSpawnPointDeselected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnSpawnPointSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnPreloadFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

