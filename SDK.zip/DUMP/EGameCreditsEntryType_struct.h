// UserDefinedEnum EGameCreditsEntryType.EGameCreditsEntryType
enum class EGameCreditsEntryType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EGameCreditsEntryType_MAX = 2
};

