// AnimBlueprintGeneratedClass ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C
// Size: 0xecd (Inherited: 0x270)
struct UABP_HDPlayerCharacter_SharedIK_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct FAnimNode_Root AnimGraphNode_Root_3; // 0x278(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_3; // 0x2a8(0x78)
	struct FAnimNode_Root AnimGraphNode_Root_2; // 0x320(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2; // 0x350(0x78)
	struct FAnimNode_HandIKRetargeting AnimGraphNode_HandIKRetargeting; // 0x3c8(0x120)
	char pad_4E8[0x8]; // 0x4e8(0x08)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2; // 0x4f0(0x1e0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK; // 0x6d0(0x1e0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x8b0(0x20)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik_2; // 0x8d0(0x190)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik; // 0xa60(0x190)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0xbf0(0x20)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xc10(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0xc40(0x78)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer_2; // 0xcb8(0xb0)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer; // 0xd68(0xb0)
	char pad_E18[0x8]; // 0xe18(0x08)
	struct FTransform LeftHandIKTransform; // 0xe20(0x30)
	struct FTransform RightHandIKTransform; // 0xe50(0x30)
	bool bUseLeftHandIK; // 0xe80(0x01)
	bool bUseRightHandIK; // 0xe81(0x01)
	bool bUseHandIKRetargeting; // 0xe82(0x01)
	char pad_E83[0x1]; // 0xe83(0x01)
	float HandFKWeight; // 0xe84(0x04)
	bool bPreventAOHandDriftFromWeapon; // 0xe88(0x01)
	char pad_E89[0x3]; // 0xe89(0x03)
	struct FVector FootIK_R_Displacement; // 0xe8c(0x0c)
	struct FVector FootIK_L_Displacement; // 0xe98(0x0c)
	struct FRotator FootIK_R_Rotation; // 0xea4(0x0c)
	struct FRotator FootIK_L_Rotation; // 0xeb0(0x0c)
	bool bDoFootIK_L; // 0xebc(0x01)
	bool bDoFootIK_R; // 0xebd(0x01)
	char pad_EBE[0x2]; // 0xebe(0x02)
	struct FVector PelvisIK_Displacement; // 0xec0(0x0c)
	bool DoPelvisDisplacement; // 0xecc(0x01)

	void FootIK(struct FPoseLink InLocoPose, struct FPoseLink& FootIK); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.FootIK // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HandIK(struct FPoseLink InLocoPose, struct FPoseLink& HandIK); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.HandIK // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK(int32_t EntryPoint); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.ExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK // (Final|UbergraphFunction) // @ game+0xec54e0
};

