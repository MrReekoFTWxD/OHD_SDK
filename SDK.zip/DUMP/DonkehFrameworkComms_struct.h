// Enum DonkehFrameworkComms.EDFCommsFormatAccessRule
enum class EDFCommsFormatAccessRule : uint8 {
	None = 0,
	ReadWrite = 1,
	ReadOnly = 2,
	WriteOnly = 3,
	EDFCommsFormatAccessRule_MAX = 4
};

// ScriptStruct DonkehFrameworkComms.DFCommStateSetupParams
// Size: 0x18 (Inherited: 0x00)
struct FDFCommStateSetupParams {
	struct UDFCommChannel* OwningChannel; // 0x00(0x08)
	struct UDFCommChannelDefinition* OwningChannelDefinition; // 0x08(0x08)
	struct UDFPlayerCommsComponent* OwningChannelCommsCompOwner; // 0x10(0x08)
};

// ScriptStruct DonkehFrameworkComms.DFChannelMsgRecord
// Size: 0x48 (Inherited: 0x00)
struct FDFChannelMsgRecord {
	struct FDFGenericChannelMsg Msg; // 0x00(0x38)
	struct UDFCommsFormatBase* MsgFormat; // 0x38(0x08)
	struct UDFCommChannel* MsgChannel; // 0x40(0x08)
};

// ScriptStruct DonkehFrameworkComms.DFGenericChannelMsg
// Size: 0x38 (Inherited: 0x00)
struct FDFGenericChannelMsg {
	struct FString ChatMsgContent; // 0x00(0x10)
	char bSenderIsTalking : 1; // 0x10(0x01)
	char pad_10_1 : 7; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FString> OptionalMsgData; // 0x18(0x10)
	struct APlayerState* SenderPS; // 0x28(0x08)
	int32_t MsgID; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DonkehFrameworkComms.DFCommChannelMap
// Size: 0x170 (Inherited: 0x108)
struct FDFCommChannelMap : FFastArraySerializer {
	struct TArray<struct FDFCommChannelMapItemEntry> ChannelEntries; // 0x108(0x10)
	struct TMap<struct FName, struct UDFCommChannel*> ChannelMap; // 0x118(0x50)
	char pad_168[0x8]; // 0x168(0x08)
};

// ScriptStruct DonkehFrameworkComms.DFCommChannelMapItemEntry
// Size: 0x28 (Inherited: 0x0c)
struct FDFCommChannelMapItemEntry : FFastArraySerializerItem {
	struct FName Key; // 0x0c(0x08)
	char pad_14[0x4]; // 0x14(0x04)
	struct UDFCommChannel* Value; // 0x18(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DonkehFrameworkComms.DFCommsFormatEntry
// Size: 0x20 (Inherited: 0x00)
struct FDFCommsFormatEntry {
	struct FName FormatName; // 0x00(0x08)
	struct FSoftClassPath FormatClass; // 0x08(0x18)
};

// ScriptStruct DonkehFrameworkComms.DFCommChannelEntry
// Size: 0x18 (Inherited: 0x00)
struct FDFCommChannelEntry {
	struct FSoftObjectPath ChannelDefinition; // 0x00(0x18)
};

// ScriptStruct DonkehFrameworkComms.DFPlayerVOIPTalkingState
// Size: 0x10 (Inherited: 0x00)
struct FDFPlayerVOIPTalkingState {
	char bWasTalking : 1; // 0x00(0x01)
	char bIsTalking : 1; // 0x00(0x01)
	char bPendingTalkerReset : 1; // 0x00(0x01)
	char pad_0_3 : 5; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UDFCommChannel* TalkerChannel; // 0x08(0x08)
};

