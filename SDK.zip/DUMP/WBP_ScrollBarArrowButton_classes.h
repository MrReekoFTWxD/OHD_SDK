// WidgetBlueprintGeneratedClass WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C
// Size: 0x24a (Inherited: 0x230)
struct UWBP_ScrollBarArrowButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* ArrowBtn; // 0x238(0x08)
	struct UScrollBox* ScrollBox; // 0x240(0x08)
	bool bScrollDown; // 0x248(0x01)
	bool bInit; // 0x249(0x01)

	void GetMaxScrollOffset(float& MaxOffset); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.GetMaxScrollOffset // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsInitialized(bool& bInitialized); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.IsInitialized // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetScrollBox(struct UScrollBox* ScrollBoxToUse); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.SetScrollBox // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ArrowBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.BndEvt__ArrowBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ScrollBarArrowButton(int32_t EntryPoint); // Function WBP_ScrollBarArrowButton.WBP_ScrollBarArrowButton_C.ExecuteUbergraph_WBP_ScrollBarArrowButton // (Final|UbergraphFunction) // @ game+0xec54e0
};

