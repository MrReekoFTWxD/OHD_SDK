// WidgetBlueprintGeneratedClass WBP_StanceIndicator.WBP_StanceIndicator_C
// Size: 0x248 (Inherited: 0x238)
struct UWBP_StanceIndicator_C : UHDUIUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* StanceIcon; // 0x240(0x08)

	void SetHealth(float NewHealthValueNorm, float PrevHealthValueNorm); // Function WBP_StanceIndicator.WBP_StanceIndicator_C.SetHealth // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void StanceStateUpdate(enum class EHDUICharacterStanceState State); // Function WBP_StanceIndicator.WBP_StanceIndicator_C.StanceStateUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_StanceIndicator(int32_t EntryPoint); // Function WBP_StanceIndicator.WBP_StanceIndicator_C.ExecuteUbergraph_WBP_StanceIndicator // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

