// WidgetBlueprintGeneratedClass WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C
// Size: 0x340 (Inherited: 0x298)
struct UWBP_DeployMenu_SpawnMinimap_C : UDeployMenu_SpawnMinimap {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct UMaterialInstanceDynamic* MapMI; // 0x2a0(0x08)
	struct TSoftObjectPtr<UTexture2D> MapTexture; // 0x2a8(0x28)
	float InitialZoom; // 0x2d0(0x04)
	char pad_2D4[0x4]; // 0x2d4(0x04)
	struct UMaterialInterface* MapMaterial; // 0x2d8(0x08)
	float PanSpeedFactor; // 0x2e0(0x04)
	float ZoomDivisor; // 0x2e4(0x04)
	float ZoomStep; // 0x2e8(0x04)
	struct FLinearColor MapTint; // 0x2ec(0x10)
	bool bDonePreloading; // 0x2fc(0x01)
	bool bMenuInitialized; // 0x2fd(0x01)
	char pad_2FE[0x2]; // 0x2fe(0x02)
	struct UTexture2D* CurrentMapTexture; // 0x300(0x08)
	int32_t NumContentToLoad; // 0x308(0x04)
	int32_t NumLoadedContent; // 0x30c(0x04)
	struct FMulticastInlineDelegate OnPreloadFinished; // 0x310(0x10)
	struct FMulticastInlineDelegate OnSpawnPointSelected; // 0x320(0x10)
	struct FMulticastInlineDelegate OnSpawnPointDeselected; // 0x330(0x10)

	void UpdatePlayerPOIs(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdatePlayerPOIs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCurrentMapTexture(struct UTexture2D* NewMapTexture); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.SetCurrentMapTexture // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HasPreloadInProgress(bool& bPreloading); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.HasPreloadInProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ApplyPreloadedContent(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ApplyPreloadedContent // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreloadContent(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreloadContent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ZoomOut(float ZoomDecrement); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ZoomIn(float ZoomIncrement); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomIn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseWheel // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateMapMatParams(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdateMapMatParams // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetLocalCursorDelta(struct FGeometry& Geometry, struct FPointerEvent& MouseEvent, struct FVector2D& LocalDelta); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.GetLocalCursorDelta // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseMove // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitMapBg(struct UTexture2D* MapTexture); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.InitMapBg // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnLoaded_BACDC4954F814289E55DD7AAEBE3E34E(struct UObject* Loaded); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BACDC4954F814289E55DD7AAEBE3E34E // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnLoaded_BB8D079144A98AFE7BD3849D43A40947(struct UObject* Loaded); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BB8D079144A98AFE7BD3849D43A40947 // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnContentPreloadStarted(struct TArray<struct TSoftObjectPtr<UObject>>& AssetsToLoad, struct TArray<struct TSoftClassPtr<UObject>>& ClassesToLoad); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnContentPreloadStarted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnContentPreloadFinished(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnContentPreloadFinished // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnAsyncLoadCompleted(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnAsyncLoadCompleted // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ReceiveOnPOISelectionStateChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_SpawnMinimap(int32_t EntryPoint); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMinimap // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnSpawnPointDeselected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointDeselected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnPreloadFinished__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

