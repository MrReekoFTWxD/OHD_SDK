// WidgetBlueprintGeneratedClass WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C
// Size: 0x278 (Inherited: 0x230)
struct UWBP_HDRadialMenuBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct FMulticastInlineDelegate SubmenuCommit; // 0x238(0x10)
	struct TArray<struct FKey> SubmitKeys; // 0x248(0x10)
	struct TArray<struct FKey> BackKeys; // 0x258(0x10)
	struct FMulticastInlineDelegate Cancel; // 0x268(0x10)

	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDoubleClick // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Submit(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.Submit // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GoBack(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.GoBack // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDRadialMenuBase(int32_t EntryPoint); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.ExecuteUbergraph_WBP_HDRadialMenuBase // (Final|UbergraphFunction) // @ game+0xec54e0
	void Cancel__DelegateSignature(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.Cancel__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SubmenuCommit__DelegateSignature(struct FName Category, struct FName SubItem); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.SubmenuCommit__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

