// BlueprintGeneratedClass BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_ServerFilterRuleSetting_C : UInterface {

	void IsFilterEnabled(bool& bActive); // Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.IsFilterEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetFilterRulePair(struct UHDServerListFilterRule*& Rule, struct FHDFilterRuleParams& RuleParams); // Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.GetFilterRulePair // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
};

