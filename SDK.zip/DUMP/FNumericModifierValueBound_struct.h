// UserDefinedStruct FNumericModifierValueBound.FNumericModifierValueBound
// Size: 0x08 (Inherited: 0x00)
struct FFNumericModifierValueBound {
	bool bEnabled_6_0293F2C7458E05C676241791D8AD3719; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Bound_3_25213DFA41A567AA433FC4A5458865AE; // 0x04(0x04)
};

