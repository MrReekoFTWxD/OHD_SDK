// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWTransmissionData
// Size: 0x40 (Inherited: 0x00)
struct FVehicleNWTransmissionData {
	bool bUseGearAutoBox; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float GearSwitchTime; // 0x04(0x04)
	float GearAutoBoxLatency; // 0x08(0x04)
	float FinalRatio; // 0x0c(0x04)
	struct TArray<struct FVehicleNWGearData> ForwardGears; // 0x10(0x10)
	struct TArray<struct FVehicleNWGearData> BackwardGears; // 0x20(0x10)
	float ReverseGearRatio; // 0x30(0x04)
	float NeutralGearUpRatio; // 0x34(0x04)
	float NeutralGearDownRatio; // 0x38(0x04)
	float ClutchStrength; // 0x3c(0x04)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWGearData
// Size: 0x0c (Inherited: 0x00)
struct FVehicleNWGearData {
	float Ratio; // 0x00(0x04)
	float DownRatio; // 0x04(0x04)
	float UpRatio; // 0x08(0x04)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWEngineData
// Size: 0xa0 (Inherited: 0x00)
struct FVehicleNWEngineData {
	struct FRuntimeFloatCurve TorqueCurve; // 0x00(0x88)
	float MaxRPM; // 0x88(0x04)
	float MOI; // 0x8c(0x04)
	float DampingRateFullThrottle; // 0x90(0x04)
	float DampingRateZeroThrottleClutchEngaged; // 0x94(0x04)
	float DampingRateZeroThrottleClutchDisengaged; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWWheelDifferentialData
// Size: 0x01 (Inherited: 0x00)
struct FVehicleNWWheelDifferentialData {
	bool bDriven; // 0x00(0x01)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankTransmissionData
// Size: 0x40 (Inherited: 0x00)
struct FVehicleTankTransmissionData {
	bool bUseGearAutoBox; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float GearSwitchTime; // 0x04(0x04)
	float GearAutoBoxLatency; // 0x08(0x04)
	float FinalRatio; // 0x0c(0x04)
	struct TArray<struct FVehicleTankGearData> ForwardGears; // 0x10(0x10)
	struct TArray<struct FVehicleTankGearData> BackwardGears; // 0x20(0x10)
	float ReverseGearRatio; // 0x30(0x04)
	float NeutralGearUpRatio; // 0x34(0x04)
	float NeutralGearDownRatio; // 0x38(0x04)
	float ClutchStrength; // 0x3c(0x04)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankGearData
// Size: 0x0c (Inherited: 0x00)
struct FVehicleTankGearData {
	float Ratio; // 0x00(0x04)
	float DownRatio; // 0x04(0x04)
	float UpRatio; // 0x08(0x04)
};

// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankEngineData
// Size: 0xa0 (Inherited: 0x00)
struct FVehicleTankEngineData {
	struct FRuntimeFloatCurve TorqueCurve; // 0x00(0x88)
	float MaxRPM; // 0x88(0x04)
	float MOI; // 0x8c(0x04)
	float DampingRateFullThrottle; // 0x90(0x04)
	float DampingRateZeroThrottleClutchEngaged; // 0x94(0x04)
	float DampingRateZeroThrottleClutchDisengaged; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

