// WidgetBlueprintGeneratedClass WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C
// Size: 0x278 (Inherited: 0x230)
struct UWBP_ServerListModifierSetting_FilterRule_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_ModifierSetting_ComboBox_C* FilterSetting; // 0x238(0x08)
	struct FText Text; // 0x240(0x18)
	struct FHDFilterRuleParams RuleParams; // 0x258(0x02)
	char pad_25A[0x6]; // 0x25a(0x06)
	struct UHDServerListFilterRule* Rule; // 0x260(0x08)
	struct FMulticastInlineDelegate OnDropdownSettingChanged; // 0x268(0x10)

	void IsFilterEnabled(bool& bActive); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.IsFilterEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetFilterRulePair(struct UHDServerListFilterRule*& Rule, struct FHDFilterRuleParams& RuleParams); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.GetFilterRulePair // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetRuleParams(struct FHDFilterRuleParams& Params); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.GetRuleParams // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetRuleParams(struct FHDFilterRuleParams NewParams); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.SetRuleParams // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__FilterSetting_K2Node_ComponentBoundEvent_0_OnSelectionChanged__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.BndEvt__FilterSetting_K2Node_ComponentBoundEvent_0_OnSelectionChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ServerListModifierSetting_FilterRule(int32_t EntryPoint); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.ExecuteUbergraph_WBP_ServerListModifierSetting_FilterRule // (Final|UbergraphFunction) // @ game+0xec54e0
	void OnDropdownSettingChanged__DelegateSignature(struct UHDServerListFilterRule* Rule, struct FHDFilterRuleParams RuleParams); // Function WBP_ServerListModifierSetting_FilterRule.WBP_ServerListModifierSetting_FilterRule_C.OnDropdownSettingChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

