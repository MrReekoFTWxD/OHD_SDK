// Class FantasticPerspectivePlugin.FantasticPerspectiveActor
// Size: 0x368 (Inherited: 0x220)
struct AFantasticPerspectiveActor : AActor {
	char pad_220[0x60]; // 0x220(0x60)
	struct FFantasticPerspectiveSettings Settings; // 0x280(0xe4)
	bool Cache; // 0x364(0x01)
	char pad_365[0x3]; // 0x365(0x03)

	bool Apply(struct APlayerController* PlayerController, enum class EFantasticPerspectiveStereoscopicPass StereoPass, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveActor.Apply // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x852820
};

// Class FantasticPerspectivePlugin.FantasticPerspectiveComponent
// Size: 0x1f8 (Inherited: 0xb0)
struct UFantasticPerspectiveComponent : UActorComponent {
	char pad_B0[0x60]; // 0xb0(0x60)
	struct FFantasticPerspectiveSettings Settings; // 0x110(0xe4)
	bool Cache; // 0x1f4(0x01)
	char pad_1F5[0x3]; // 0x1f5(0x03)

	bool Apply(struct APlayerController* PlayerController, enum class EFantasticPerspectiveStereoscopicPass StereoPass, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveComponent.Apply // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x852b20
};

// Class FantasticPerspectivePlugin.FantasticPerspectiveFunctions
// Size: 0x28 (Inherited: 0x28)
struct UFantasticPerspectiveFunctions : UBlueprintFunctionLibrary {

	struct FRotator WorldToScreenConversionRotator(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionRotator // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x854b30
	struct FMatrix WorldToScreenConversionMatrix(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionMatrix // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x854ae0
	void SetTransformSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveTransform Transform); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetTransformSettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x854980
	void SetFrustumSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveFrustum Frustum); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetFrustumSettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8547e0
	void SetDebugSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveDebug Debug); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetDebugSettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8546c0
	struct FRotator ScreenToWorldConversionRotator(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionRotator // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x854690
	struct FMatrix ScreenToWorldConversionMatrix(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionMatrix // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x854640
	void ResetSettings(struct FFantasticPerspectiveSettings& Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ResetSettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8545b0
	void ResetCache(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ResetCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x854590
	struct FFantasticPerspectiveTransform GetTransformSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetTransformSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x854450
	struct FFantasticPerspectiveFrustum GetFrustumSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetFrustumSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x854310
	struct FFantasticPerspectiveDebug GetDebugSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetDebugSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8541e0
	void DrawDebugPositionedFrustum(struct UObject* WorldContextObject, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FLinearColor Color, float PerspectiveFrustumDepth, bool bPersistentLines, float LifeTime, char DepthPriority, float Thickness); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.DrawDebugPositionedFrustum // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x853ea0
	void ApplyTransformEffects(struct FFantasticPerspectiveTransform Transform, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyTransformEffects // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x853c50
	void ApplyToSceneCapture2D(struct USceneCaptureComponent2D* SceneCapture, struct FVector& ViewOrigin, struct FMatrix& ViewRotationMatrix, struct FMatrix& ProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyToSceneCapture2D // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x853ae0
	void ApplySettingsAndDrawDebug(struct UObject* WorldContextObject, struct FFantasticPerspectiveSettings Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettingsAndDrawDebug // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x853770
	void ApplySettings(struct FFantasticPerspectiveSettings Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettings // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x853440
	void ApplyPointsBasing(struct FFantasticPerspectivePoints Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyPointsBasing // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x853180
	void ApplyFrustumEffects(struct FFantasticPerspectiveFrustum Frustum, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyFrustumEffects // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x852e20
};

// Class FantasticPerspectivePlugin.FantasticPerspectiveLocalPlayer
// Size: 0x258 (Inherited: 0x258)
struct UFantasticPerspectiveLocalPlayer : ULocalPlayer {
};

