// WidgetBlueprintGeneratedClass WBP_RadialMenuBase.WBP_RadialMenuBase_C
// Size: 0x34c (Inherited: 0x230)
struct UWBP_RadialMenuBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* RadialBackground; // 0x238(0x08)
	struct UImage* RadiusDebug; // 0x240(0x08)
	struct UOverlay* RootOverlay; // 0x248(0x08)
	int32_t Segments; // 0x250(0x04)
	char pad_254[0x4]; // 0x254(0x04)
	struct UMaterialInterface* MaterialBase; // 0x258(0x08)
	float IndexRaw; // 0x260(0x04)
	int32_t Index; // 0x264(0x04)
	struct UMaterialInstanceDynamic* dynaMat; // 0x268(0x08)
	struct TArray<struct UUserWidget*> Children; // 0x270(0x10)
	bool AllowResizing; // 0x280(0x01)
	char pad_281[0x3]; // 0x281(0x03)
	float ItemOffsetRadius; // 0x284(0x04)
	struct FMulticastInlineDelegate SelectionChanged; // 0x288(0x10)
	struct APlayerController* InputController; // 0x298(0x08)
	enum class EJoystickTypes JoystickToUse; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float MouseDeadzone; // 0x2a4(0x04)
	bool bInDeadzone; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct FMulticastInlineDelegate EnteredDeadzone; // 0x2b0(0x10)
	struct FMulticastInlineDelegate ExitedDeadzone; // 0x2c0(0x10)
	struct FVector2D CurrentInput; // 0x2d0(0x08)
	float JoystickDeadzone; // 0x2d8(0x04)
	bool DefaultToMouseIfNoJoystick; // 0x2dc(0x01)
	char pad_2DD[0x3]; // 0x2dd(0x03)
	int32_t DefaultPlayerIndex; // 0x2e0(0x04)
	bool UseDeadzoneEvents; // 0x2e4(0x01)
	char pad_2E5[0x3]; // 0x2e5(0x03)
	struct USoundBase* SelectionChangedSound; // 0x2e8(0x08)
	bool AutoCenterMouse; // 0x2f0(0x01)
	bool AutoRotateForUp; // 0x2f1(0x01)
	bool bUseCustomInput; // 0x2f2(0x01)
	char pad_2F3[0x1]; // 0x2f3(0x01)
	struct FVector2D CustomInput; // 0x2f4(0x08)
	bool UseCustomTexture; // 0x2fc(0x01)
	char pad_2FD[0x3]; // 0x2fd(0x03)
	struct UTexture* RadialTexture; // 0x300(0x08)
	bool UseCustomColors; // 0x308(0x01)
	char pad_309[0x3]; // 0x309(0x03)
	struct FLinearColor InnterRingColor; // 0x30c(0x10)
	struct FLinearColor OuterRingColor; // 0x31c(0x10)
	struct FLinearColor RingMainColor; // 0x32c(0x10)
	struct FLinearColor UnhighlightColor; // 0x33c(0x10)

	void UpdateMaterialVisuals(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateMaterialVisuals // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetCustomInput(struct FVector2D& Input, bool& Valid); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.GetCustomInput // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCustomInput(struct FVector2D CustomInput); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.SetCustomInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDirectionWithCustomInput(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateDirectionWithCustomInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveChildIndexFromRadialMenu(int32_t IndexToRemove); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.RemoveChildIndexFromRadialMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveChildWidgetFromRadialMenu(struct UUserWidget*& ItemToFind); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.RemoveChildWidgetFromRadialMenu // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FText DebugIndex(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.DebugIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	struct FVector2D FixInputRotation(struct FVector2D Input); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.FixInputRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void FixMainRotation(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.FixMainRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AutoRegisterToInput(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.AutoRegisterToInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateInput(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RegisterPlayerInput(struct APlayerController* Controller, bool& Success); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.RegisterPlayerInput // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDirectionWithJoystick(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateDirectionWithJoystick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetCurrentIndex(int32_t& Index, bool& Valid); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.GetCurrentIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetChild(int32_t Index, struct UUserWidget*& Output, bool& Success); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.GetChild // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetIndex(int32_t Index); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.SetIndex // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateAllChildrenPositions(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateAllChildrenPositions // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateChildPosition(int32_t Index); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateChildPosition // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearChildren(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.ClearChildren // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSelectedWidget(struct UUserWidget*& Output); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.GetSelectedWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AddChildToRadialMenu(struct UUserWidget* Content, bool& Success); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.AddChildToRadialMenu // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDirectionWithMouseCursor(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateDirectionWithMouseCursor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	float GetSectionDegreeSize(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.GetSectionDegreeSize // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetInputDirection(struct FVector2D Direction); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.SetInputDirection // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void UpdateSegments(int32_t Segments); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateSegments // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InDeadzone(bool InDeadzone); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.InDeadzone // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateMaterials(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.UpdateMaterials // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_RadialMenuBase(int32_t EntryPoint); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.ExecuteUbergraph_WBP_RadialMenuBase // (Final|UbergraphFunction) // @ game+0xec54e0
	void ExitedDeadzone__DelegateSignature(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.ExitedDeadzone__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EnteredDeadzone__DelegateSignature(); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.EnteredDeadzone__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectionChanged__DelegateSignature(int32_t NewSelection, int32_t OldSelection); // Function WBP_RadialMenuBase.WBP_RadialMenuBase_C.SelectionChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

