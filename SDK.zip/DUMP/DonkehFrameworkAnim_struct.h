// Enum DonkehFrameworkAnim.EFootstepVariant
enum class EFootstepVariant : uint8 {
	Walk = 0,
	Run = 1,
	Sprint = 2,
	Shuffle = 3,
	Jump = 4,
	Land = 5,
	EFootstepVariant_MAX = 6
};

// Enum DonkehFrameworkAnim.EMotionDirection
enum class EMotionDirection : uint8 {
	XPos = 0,
	YPos = 1,
	ZPos = 2,
	XNeg = 3,
	YNeg = 4,
	ZNeg = 5,
	EMotionDirection_MAX = 6
};

// Enum DonkehFrameworkAnim.EAnimDirection
enum class EAnimDirection : uint8 {
	None = 0,
	Left = 1,
	Right = 2,
	Up = 3,
	Down = 4,
	EAnimDirection_MAX = 5
};

// ScriptStruct DonkehFrameworkAnim.DFCharStanceContext
// Size: 0x01 (Inherited: 0x00)
struct FDFCharStanceContext {
	char bWantsToBeInStance : 1; // 0x00(0x01)
	char bIsInStance : 1; // 0x00(0x01)
	char bFullyTransitionedIntoStance : 1; // 0x00(0x01)
	char pad_0_3 : 5; // 0x00(0x01)
};

// ScriptStruct DonkehFrameworkAnim.FootstepFXSettings
// Size: 0xf8 (Inherited: 0x00)
struct FFootstepFXSettings {
	struct TMap<enum class EPhysicalSurface, struct FPerspectiveSound> SoundsToPlay; // 0x00(0x50)
	float VolumeMultiplier; // 0x50(0x04)
	float PitchMultiplier; // 0x54(0x04)
	char bAttachSound : 1; // 0x58(0x01)
	char bPlaySoundsWithPerspMeshOnly : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TMap<enum class EPhysicalSurface, struct UFXSystemAsset*> EffectsToSpawn; // 0x60(0x50)
	char bAttachEffect : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	struct FVector EffectLocationOffset; // 0xb4(0x0c)
	struct FRotator EffectRotationOffset; // 0xc0(0x0c)
	struct FVector EffectScale; // 0xcc(0x0c)
	char bSpawnEffectsWithPerspMeshOnly : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	enum class EFootstepVariant FootstepVariant; // 0xd9(0x01)
	char pad_DA[0x2]; // 0xda(0x02)
	struct FName FootstepVariantParamName; // 0xdc(0x08)
	struct FName FootBoneName; // 0xe4(0x08)
	float FootTraceOffset; // 0xec(0x04)
	char bDebug : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// ScriptStruct DonkehFrameworkAnim.BoneModifier
// Size: 0x0c (Inherited: 0x00)
struct FBoneModifier {
	struct FName Bone; // 0x00(0x08)
	float Offset; // 0x08(0x04)
};

