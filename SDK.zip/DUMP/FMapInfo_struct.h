// UserDefinedStruct FMapInfo.FMapInfo
// Size: 0x48 (Inherited: 0x00)
struct FFMapInfo {
	struct FName AssetName_12_E135D6274C61454F8865668EDE4F5D44; // 0x00(0x08)
	struct FText DisplayName_13_586136ED48833BFE10B4D488B6F7D832; // 0x08(0x18)
	struct FText ParentModName_29_97B8BD46410BE27E8278B784AD72AD29; // 0x20(0x18)
	struct UTexture2D* BannerImage_22_61EAF5FA4D6E063677E137BC29855664; // 0x38(0x08)
	struct UTexture2D* ThumbnailImage_24_B9256F084B5BF02811CA8ABF113ACD8D; // 0x40(0x08)
};

