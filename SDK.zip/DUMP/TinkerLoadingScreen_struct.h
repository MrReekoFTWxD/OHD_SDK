// ScriptStruct TinkerLoadingScreen.LoadScreenLevelData
// Size: 0x68 (Inherited: 0x00)
struct FLoadScreenLevelData {
	struct FText MapFriendlyName; // 0x00(0x18)
	struct FText GameModeFriendlyName; // 0x18(0x18)
	struct TSoftObjectPtr<UTexture2D> MapLoadingImage; // 0x30(0x28)
	char bMainMenuMap : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	int32_t StartingTicketsBlufor; // 0x5c(0x04)
	int32_t StartingTicketsOpfor; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct TinkerLoadingScreen.LoadingScreenDescription
// Size: 0x38 (Inherited: 0x00)
struct FLoadingScreenDescription {
	float MinimumLoadingScreenDisplayTime; // 0x00(0x04)
	bool bAutoCompleteWhenLoadingCompletes; // 0x04(0x01)
	bool bMoviesAreSkippable; // 0x05(0x01)
	bool bWaitForManualStop; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	struct TArray<struct FString> MoviePaths; // 0x08(0x10)
	enum class EMoviePlaybackType PlaybackType; // 0x18(0x01)
	bool bShowOverlayWidget; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct FSoftClassPath OverlayWidgetClass; // 0x20(0x18)
};

