// WidgetBlueprintGeneratedClass WBP_SQMemberOption.WBP_SQMemberOption_C
// Size: 0x268 (Inherited: 0x24c)
struct UWBP_SQMemberOption_C : UWBP_HDContextualWidgetBase_C {
	char pad_24C[0x4]; // 0x24c(0x04)
	struct UNamedSlot* InsertContentHere; // 0x250(0x08)
	struct UWBP_DeployMenu_SquadMemberListing_C* ParentContainer; // 0x258(0x08)
	struct USquadMemberInfo* ParentMemberInfo; // 0x260(0x08)

	void GetParentMemberInfo(struct USquadMemberInfo*& MemberInfo); // Function WBP_SQMemberOption.WBP_SQMemberOption_C.GetParentMemberInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupOption(struct USquadMemberInfo* InMemberInfo); // Function WBP_SQMemberOption.WBP_SQMemberOption_C.SetupOption // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

