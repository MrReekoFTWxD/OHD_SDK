// UserDefinedEnum ECaptureUnitType.ECaptureUnitType
enum class ECaptureUnitType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ECaptureUnitType_MAX = 3
};

