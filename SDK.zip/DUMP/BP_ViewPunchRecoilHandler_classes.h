// BlueprintGeneratedClass BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C
// Size: 0x74 (Inherited: 0x28)
struct UBP_ViewPunchRecoilHandler_C : UDFGunRecoilHandler {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x28(0x08)
	float CurrentCofAngleDegrees; // 0x30(0x04)
	float ConeOfFireAngleGrowthPerShotDegrees; // 0x34(0x04)
	float MaxConeOfFireAngleDegrees; // 0x38(0x04)
	float MinConeOfFireAngleDegrees; // 0x3c(0x04)
	float ConeOfFireDecayRate; // 0x40(0x04)
	float DesiredCoF; // 0x44(0x04)
	float RecoilDirection; // 0x48(0x04)
	float RecoilPunchMagnitude; // 0x4c(0x04)
	float RecoilCounter; // 0x50(0x04)
	struct FRotator InitialViewAngle; // 0x54(0x0c)
	float Recoil_DX; // 0x60(0x04)
	float Recoil_DY; // 0x64(0x04)
	float RecoilRestitutionTime; // 0x68(0x04)
	enum class EEasingFunc VerticalRecoilEasingMode; // 0x6c(0x01)
	enum class EEasingFunc HorizontalRecoilEasingMode; // 0x6d(0x01)
	char pad_6E[0x2]; // 0x6e(0x02)
	float RecoilDT; // 0x70(0x04)

	void GetController(struct AController*& Controller); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetController // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetControlRotation(struct FRotator& ViewRotation); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetControlRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	struct FVector GetConeOfFireOffset(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetConeOfFireOffset // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnWeaponFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponFire // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ViewPunch(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ViewPunch // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnTick(float DeltaTime); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ComputeConeOfFire(float DT); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeConeOfFire // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ComputeRecoil(float DT); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeRecoil // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnWeaponStopFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponStopFire // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnWeaponStartFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponStartFire // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_ViewPunchRecoilHandler(int32_t EntryPoint); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ExecuteUbergraph_BP_ViewPunchRecoilHandler // (Final|UbergraphFunction) // @ game+0xec54e0
};

