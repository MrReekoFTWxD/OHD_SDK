// WidgetBlueprintGeneratedClass WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C
// Size: 0x2c1 (Inherited: 0x280)
struct UWBP_HUDElement_VOIPIndicator_C : UHDVoipIndicatorWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x280(0x08)
	struct UWBP_VOIPOwnerChatIndicator_C* CommandChatIndicator; // 0x288(0x08)
	struct UWBP_VOIPOwnerChatIndicator_C* LocalChatIndicator; // 0x290(0x08)
	struct UWBP_VOIPOwnerChatIndicator_C* SquadChatIndicator; // 0x298(0x08)
	struct UVerticalBox* TalkerListVBox; // 0x2a0(0x08)
	int32_t NumFakeOutputListings; // 0x2a8(0x04)
	int32_t MaxTalkerListings; // 0x2ac(0x04)
	struct FMargin TalkerListingPadding; // 0x2b0(0x10)
	bool bTalkerListingTintClassIconOnly; // 0x2c0(0x01)

	void ContainsTalkerListing(struct UHDVoiceChatMsgInfo* PlayerMsgInfo, bool& bMatchFound); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ContainsTalkerListing // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FindTalkerListing(struct UHDVoiceChatMsgInfo* PlayerMsgInfo, bool& bListingFound, struct UWBP_HUDElement_VOIPIndicator_OutputListing_C*& TalkerListing); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.FindTalkerListing // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void PlayerStoppedTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStoppedTalking // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PlayerStartedTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStartedTalking // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerStartTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerStopTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnOwningPlayerStartTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnOwningPlayerStopTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_VOIPIndicator(int32_t EntryPoint); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ExecuteUbergraph_WBP_HUDElement_VOIPIndicator // (Final|UbergraphFunction) // @ game+0xec54e0
};

