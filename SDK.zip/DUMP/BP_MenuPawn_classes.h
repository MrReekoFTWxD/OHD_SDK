// BlueprintGeneratedClass BP_MenuPawn.BP_MenuPawn_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct ABP_MenuPawn_C : ADefaultPawn {
};

