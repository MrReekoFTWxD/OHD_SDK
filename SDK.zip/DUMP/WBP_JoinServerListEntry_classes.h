// WidgetBlueprintGeneratedClass WBP_JoinServerListEntry.WBP_JoinServerListEntry_C
// Size: 0x885 (Inherited: 0x270)
struct UWBP_JoinServerListEntry_C : UHDServerListing {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct UWBP_ServerListEntryColumn_C* GameVersionCol; // 0x278(0x08)
	struct UWBP_ServerListEntryColumn_C* GMNameCol; // 0x280(0x08)
	struct UImage* ItemBg; // 0x288(0x08)
	struct USizeBox* ItemBox; // 0x290(0x08)
	struct UCheckBox* ItemCheckBox; // 0x298(0x08)
	struct UImage* ItemSelectionHighlight; // 0x2a0(0x08)
	struct UWBP_ServerListEntryColumn_C* MapNameCol; // 0x2a8(0x08)
	struct UWBP_ServerListEntryColumn_C* PingCol; // 0x2b0(0x08)
	struct UWBP_ServerListEntryColumn_C* PlayerCountCol; // 0x2b8(0x08)
	struct UHorizontalBox* ServerBadgeHBox; // 0x2c0(0x08)
	struct UWBP_ServerListEntryColumn_C* ServerNameCol; // 0x2c8(0x08)
	struct FMulticastInlineDelegate OnSelectionStateChanged; // 0x2d0(0x10)
	struct UTexture2D* PlaceholderMapBannerImg; // 0x2e0(0x08)
	struct FMargin BadgePadding; // 0x2e8(0x10)
	struct FCheckBoxStyle ItemStyle; // 0x2f8(0x580)
	bool bSelectionToggle; // 0x878(0x01)
	char pad_879[0x3]; // 0x879(0x03)
	int32_t ItemMinWidth; // 0x87c(0x04)
	int32_t ItemMinHeight; // 0x880(0x04)
	bool bBadgesInitialized; // 0x884(0x01)

	void AddBadgeDefinitionToListIfFound(struct FName TableRowName, struct TArray<struct FFServerBadgeUIDefinition>& BadgeArr); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.AddBadgeDefinitionToListIfFound // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CreateAndAddBadgeWidgetFromDefinition(struct FFServerBadgeUIDefinition& BadgeUIDef); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.CreateAndAddBadgeWidgetFromDefinition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetBadgeDefinitionFromTable(struct FDataTableRowHandle RowHandle, bool& bFound, struct FFServerBadgeUIDefinition& BadgeUIDef); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBadgeDefinitionFromTable // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void HideAllBadges(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.HideAllBadges // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetBadgeVisibilityFromServerData(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetBadgeVisibilityFromServerData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PopulateBadges(struct TArray<struct FFServerBadgeUIDefinition>& BadgeDefs); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PopulateBadges // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetBrushWithItemDimensions(struct FSlateBrush& InBrush, struct FSlateBrush& OutBrush); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithItemDimensions // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetBrushWithImageTexture(struct FSlateBrush& Brush, struct UTexture2D* Image, struct FSlateBrush& UpdatedBrush); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithImageTexture // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void InternalRefreshDimensions(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalRefreshDimensions // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemMinHeight(int32_t& MinHeight); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinHeight // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemMinWidth(int32_t& MinWidth); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinWidth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemMinDimensions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemStyle(struct FCheckBoxStyle& ItemStyle); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemStyle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemImage(struct UTexture2D* InItemImg); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemImage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemStyle(struct FCheckBoxStyle InItemStyle); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemStyle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalUpdateItemBgTintColor(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalUpdateItemBgTintColor // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsItemSelected(bool& bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.IsItemSelected // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemSelectionState(enum class ECheckBoxState& SelectionState); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemSelectionState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemIsSelected(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemIsSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemSelectionState(enum class ECheckBoxState InSelectionState); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemSelectionState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void On Selection State Changed(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.On Selection State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnServerItemDataSet(bool bIsDesignTime); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnServerItemDataSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BP_OnEntryReleased(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_JoinServerListEntry(int32_t EntryPoint); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.ExecuteUbergraph_WBP_JoinServerListEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnSelectionStateChanged__DelegateSignature(struct UWBP_JoinServerListEntry_C* Item, bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnSelectionStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

