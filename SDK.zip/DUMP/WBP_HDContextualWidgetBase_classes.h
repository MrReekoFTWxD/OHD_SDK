// WidgetBlueprintGeneratedClass WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C
// Size: 0x24c (Inherited: 0x240)
struct UWBP_HDContextualWidgetBase_C : UDFContextualWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	enum class ESlateVisibility VisibilitySatisfiedPrereqs; // 0x248(0x01)
	bool bIsEnabledSatisfiedPrereqs; // 0x249(0x01)
	enum class ESlateVisibility VisibilityUnsatisfiedPrereqs; // 0x24a(0x01)
	bool bIsEnabledUnsatisfiedPrereqs; // 0x24b(0x01)

	void PrerequisitesMet(); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.PrerequisitesMet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PrerequisiteNotMet(struct UDFContextualWidgetPrerequisiteBase* FailedPrereq); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.PrerequisiteNotMet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDContextualWidgetBase(int32_t EntryPoint); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.ExecuteUbergraph_WBP_HDContextualWidgetBase // (Final|UbergraphFunction) // @ game+0xec54e0
};

