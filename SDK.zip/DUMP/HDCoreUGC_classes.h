// Class HDCoreUGC.HDCoreUGCProjectPolicies
// Size: 0x28 (Inherited: 0x28)
struct UHDCoreUGCProjectPolicies : UObject {
};

// Class HDCoreUGC.HDCoreDefaultUGCProjectPolicies
// Size: 0x28 (Inherited: 0x28)
struct UHDCoreDefaultUGCProjectPolicies : UHDCoreUGCProjectPolicies {
};

// Class HDCoreUGC.HDCoreUGCData
// Size: 0x30 (Inherited: 0x30)
struct UHDCoreUGCData : UPrimaryDataAsset {
};

// Class HDCoreUGC.HDCoreUGCPluginStateMachine
// Size: 0x208 (Inherited: 0x28)
struct UHDCoreUGCPluginStateMachine : UObject {
	char pad_28[0x20]; // 0x28(0x20)
	struct FHDCoreUGCPluginStateMachineProperties StateProperties; // 0x48(0xe8)
	char pad_130[0xd8]; // 0x130(0xd8)
};

// Class HDCoreUGC.HDCoreUGCSubsystem
// Size: 0x110 (Inherited: 0x30)
struct UHDCoreUGCSubsystem : UEngineSubsystem {
	char pad_30[0x30]; // 0x30(0x30)
	struct TMap<struct FString, struct UHDCoreUGCPluginStateMachine*> UGCPluginStateMachines; // 0x60(0x50)
	char pad_B0[0x50]; // 0xb0(0x50)
	struct UHDCoreUGCProjectPolicies* GameSpecificPolicies; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class HDCoreUGC.HDCoreUGCSubsystemSettings
// Size: 0x80 (Inherited: 0x38)
struct UHDCoreUGCSubsystemSettings : UDeveloperSettings {
	struct FSoftClassPath UGCManagerClassName; // 0x38(0x18)
	struct TArray<struct FString> DisabledPlugins; // 0x50(0x10)
	struct TArray<struct FString> AdditionalPluginMetadataKeys; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)
};

