// Class OWIEnhancedVehicleMovement.VehicleMovementNWheeledVehicle
// Size: 0x290 (Inherited: 0x290)
struct AVehicleMovementNWheeledVehicle : AWheeledVehicle {
};

// Class OWIEnhancedVehicleMovement.VehicleMovementTankVehicle
// Size: 0x290 (Inherited: 0x290)
struct AVehicleMovementTankVehicle : AWheeledVehicle {
};

// Class OWIEnhancedVehicleMovement.VehicleMovementWheelTracked
// Size: 0x100 (Inherited: 0xf0)
struct UVehicleMovementWheelTracked : UVehicleWheel {
	struct FVector SuspensionDirection; // 0xf0(0x0c)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// Class OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentNW
// Size: 0x408 (Inherited: 0x290)
struct UWheeledVehicleMovementComponentNW : UWheeledVehicleMovementComponent {
	struct FVehicleNWEngineData EngineSetup; // 0x290(0xa0)
	struct TArray<struct FVehicleNWWheelDifferentialData> DifferentialSetup; // 0x330(0x10)
	struct FVehicleNWTransmissionData TransmissionSetup; // 0x340(0x40)
	struct FRuntimeFloatCurve SteeringCurve; // 0x380(0x88)
};

// Class OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank
// Size: 0x3b8 (Inherited: 0x290)
struct UWheeledVehicleMovementComponentTank : UWheeledVehicleMovementComponent {
	struct FVehicleTankEngineData EngineSetup; // 0x290(0xa0)
	struct FVehicleTankTransmissionData TransmissionSetup; // 0x330(0x40)
	float RawBothTracksThrottleInput; // 0x370(0x04)
	float RawLeftTrackThrottleInput; // 0x374(0x04)
	float RawRightTrackThrottleInput; // 0x378(0x04)
	float BothTracksThrottleInput; // 0x37c(0x04)
	float LeftTrackThrottleInput; // 0x380(0x04)
	float RightTrackThrottleInput; // 0x384(0x04)
	struct TArray<float> WheelSpeeds; // 0x388(0x10)
	struct TArray<float> WheelAngles; // 0x398(0x10)
	float LeftTrackSpeed; // 0x3a8(0x04)
	float RightTrackSpeed; // 0x3ac(0x04)
	char pad_3B0[0x8]; // 0x3b0(0x08)

	void SetRightTrackThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetRightTrackThrottleInput // (Native|Public|BlueprintCallable) // @ game+0x81ab50
	void SetLeftTrackThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetLeftTrackThrottleInput // (Native|Public|BlueprintCallable) // @ game+0x81aad0
	void SetBothTracksThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetBothTracksThrottleInput // (Native|Public|BlueprintCallable) // @ game+0x81aa50
	float GetRightTrackSpeed(); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetRightTrackSpeed // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x81aa10
	float GetLeftTrackSpeed(); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetLeftTrackSpeed // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x81a9d0
};

