// BlueprintGeneratedClass BP_HDVOIPTalker.BP_HDVOIPTalker_C
// Size: 0x138 (Inherited: 0xe8)
struct UBP_HDVOIPTalker_C : UVOIPTalker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe8(0x08)
	struct APlayerState* OwningPS; // 0xf0(0x08)
	struct FVoiceSettings NonSpatializedSettings; // 0xf8(0x18)
	struct FVoiceSettings SpatializedSettings; // 0x110(0x18)
	bool bRegistered; // 0x128(0x01)
	bool bTalking; // 0x129(0x01)
	char pad_12A[0x6]; // 0x12a(0x06)
	struct UAudioComponent* CachedAudioComp; // 0x130(0x08)

	void ListenForTalkingStateChangedEvents(); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ListenForTalkingStateChangedEvents // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateSettingsUsageForNextBeginTalk(bool bUseSpatialized, bool& bSettingsUpdated); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.UpdateSettingsUsageForNextBeginTalk // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RegisterTalker(struct APlayerState* InRegisteredPS, struct FVoiceSettings& InSpatializedSettings, struct FVoiceSettings& InNonSpatializedSettings, bool bStartSpatialized); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.RegisterTalker // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BPOnTalkingBegin(struct UAudioComponent* AudioComponent); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.BPOnTalkingBegin // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOnTalkingEnd(); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.BPOnTalkingEnd // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void TalkStateChangedOnChannel(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.TalkStateChangedOnChannel // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDVOIPTalker(int32_t EntryPoint); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ExecuteUbergraph_BP_HDVOIPTalker // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

