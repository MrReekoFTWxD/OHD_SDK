// WidgetBlueprintGeneratedClass WBP_CommunityMediaLink.WBP_CommunityMediaLink_C
// Size: 0x310 (Inherited: 0x230)
struct UWBP_CommunityMediaLink_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* LinkBtn; // 0x238(0x08)
	struct UImage* LinkIcon; // 0x240(0x08)
	struct UTextBlock* LinkText; // 0x248(0x08)
	struct FFCommunityMediaLinkUIDefinition LinkUIDefinition; // 0x250(0xc0)

	void BndEvt__LinkBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.BndEvt__LinkBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CommunityMediaLink(int32_t EntryPoint); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.ExecuteUbergraph_WBP_CommunityMediaLink // (Final|UbergraphFunction) // @ game+0xec54e0
};

