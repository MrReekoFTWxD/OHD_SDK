// BlueprintGeneratedClass BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C
// Size: 0x1a0 (Inherited: 0x198)
struct UBP_HDVehiclePlayerSeatComponent_C : UHDVehiclePlayerSeatComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x198(0x08)

	void GetValidSeatConfig(struct UArcVehicleSeatConfig*& SeatConfig); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.GetValidSeatConfig // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void ReceiveBeginPlay(); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.OnDeath // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSeatChangeEvent(enum class EArcVehicleSeatChangeType SeatChangeType); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.OnSeatChangeEvent // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ResetPlayerCameraConstraints(struct APlayerController* PC); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ResetPlayerCameraConstraints // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupPlayerCameraConstraints(struct APlayerController* PC); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.SetupPlayerCameraConstraints // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDVehiclePlayerSeatComponent(int32_t EntryPoint); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ExecuteUbergraph_BP_HDVehiclePlayerSeatComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

