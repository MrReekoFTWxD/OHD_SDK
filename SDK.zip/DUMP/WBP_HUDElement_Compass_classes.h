// WidgetBlueprintGeneratedClass WBP_HUDElement_Compass.WBP_HUDElement_Compass_C
// Size: 0x26c (Inherited: 0x230)
struct UWBP_HUDElement_Compass_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UOverlay* CompassClips; // 0x238(0x08)
	struct URetainerBox* FadeEffectMask; // 0x240(0x08)
	struct UInvalidationBox* MarkerContainer; // 0x248(0x08)
	struct FVector2D CompassClippedRegion; // 0x250(0x08)
	struct FVector2D CompassSizeAbsolute; // 0x258(0x08)
	float CompassPosFactor; // 0x260(0x04)
	float CompassHalfWidth; // 0x264(0x04)
	float CompassHalfHeightNeg; // 0x268(0x04)

	void SetWidgetCanvasSlotSize(struct UWidget* Widget, struct FVector2D NewLayoutSize); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.SetWidgetCanvasSlotSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDirection(); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.UpdateDirection // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_Compass(int32_t EntryPoint); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.ExecuteUbergraph_WBP_HUDElement_Compass // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

