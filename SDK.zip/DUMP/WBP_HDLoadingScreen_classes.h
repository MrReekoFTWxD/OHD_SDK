// WidgetBlueprintGeneratedClass WBP_HDLoadingScreen.WBP_HDLoadingScreen_C
// Size: 0x342 (Inherited: 0x342)
struct UWBP_HDLoadingScreen_C : UWBP_HDLoadingScreenBase_C {
};

