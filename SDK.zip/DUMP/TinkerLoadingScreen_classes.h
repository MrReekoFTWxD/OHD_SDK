// Class TinkerLoadingScreen.LoadingScreenSettings
// Size: 0xb0 (Inherited: 0x38)
struct ULoadingScreenSettings : UDeveloperSettings {
	char bUseStartupScreen : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FLoadingScreenDescription StartupScreen; // 0x40(0x38)
	struct FLoadingScreenDescription DefaultScreen; // 0x78(0x38)
};

// Class TinkerLoadingScreen.LoadingScreenWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct ULoadingScreenWidgetInterface : UInterface {

	void SetLoadingScreenDescription(struct FLoadingScreenDescription& Description); // Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLoadingScreenDescription // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x80dee0
	void SetLevelLoadData(struct FLoadScreenLevelData& LevelData); // Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLevelLoadData // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x80ddc0
};

