// Class HDMain.DeployMenu
// Size: 0x238 (Inherited: 0x238)
struct UDeployMenu : UDFBaseMenu {
};

// Class HDMain.DeployMenu_ClassSelectionListing
// Size: 0x230 (Inherited: 0x230)
struct UDeployMenu_ClassSelectionListing : UUserWidget {
};

// Class HDMain.DeployMenu_ClassSelectionPanel
// Size: 0x230 (Inherited: 0x230)
struct UDeployMenu_ClassSelectionPanel : UUserWidget {
};

// Class HDMain.DeployMenu_PlatoonSquadListBase
// Size: 0x250 (Inherited: 0x230)
struct UDeployMenu_PlatoonSquadListBase : UUserWidget {
	struct UPlatoonListEntry* PlatoonData; // 0x230(0x08)
	bool bSortSquads; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct TArray<struct USquadListEntry*> CurrentSquads; // 0x240(0x10)

	void SquadPreRemoveFromPlatoon(struct AHDPlatoonState* SourcePlatoon, struct AHDSquadState* SquadToBeRemoved); // Function HDMain.DeployMenu_PlatoonSquadListBase.SquadPreRemoveFromPlatoon // (Final|Native|Private) // @ game+0x794670
	void SquadAddedToPlatoon(struct AHDPlatoonState* SourcePlatoon, struct AHDSquadState* NewSquad); // Function HDMain.DeployMenu_PlatoonSquadListBase.SquadAddedToPlatoon // (Final|Native|Private) // @ game+0x794230
	void SetupPlatoon(struct UPlatoonListEntry* InPlatoonData); // Function HDMain.DeployMenu_PlatoonSquadListBase.SetupPlatoon // (Final|Native|Public|BlueprintCallable) // @ game+0x794080
	void RepopulatePlatoon(); // Function HDMain.DeployMenu_PlatoonSquadListBase.RepopulatePlatoon // (Final|Native|Public|BlueprintCallable) // @ game+0x793f20
	void OnPlatoonSet(); // Function HDMain.DeployMenu_PlatoonSquadListBase.OnPlatoonSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	struct AHDPlatoonState* GetPlatoonStateFromData(); // Function HDMain.DeployMenu_PlatoonSquadListBase.GetPlatoonStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7937f0
	void GenerateSquad(struct USquadListEntry* SquadData); // Function HDMain.DeployMenu_PlatoonSquadListBase.GenerateSquad // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructSquad(struct USquadListEntry* RemovedSquadData, int32_t RemovedSquadIdx); // Function HDMain.DeployMenu_PlatoonSquadListBase.DeconstructSquad // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.DeployMenu_SpawnMapView
// Size: 0x230 (Inherited: 0x230)
struct UDeployMenu_SpawnMapView : UUserWidget {
};

// Class HDMain.DeployMenu_SpawnMinimap
// Size: 0x298 (Inherited: 0x298)
struct UDeployMenu_SpawnMinimap : UDFMinimap {
};

// Class HDMain.DeployMenu_SquadListBase
// Size: 0x260 (Inherited: 0x230)
struct UDeployMenu_SquadListBase : UUserWidget {
	struct USquadListEntry* SquadData; // 0x230(0x08)
	bool bSortSquadMembers; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct TArray<struct USquadMemberInfo*> CurrentSquadMembers; // 0x240(0x10)
	struct TArray<struct USquadMemberInfo*> MemberEntryWidgetsPendingRemoval; // 0x250(0x10)

	void SquadNameChanged(struct AHDSquadState* SourceSquad, struct FText& NewName, struct FText& PrevName); // Function HDMain.DeployMenu_SquadListBase.SquadNameChanged // (Final|Native|Private|HasOutParms) // @ game+0x7944c0
	void SquadLockStateUpdated(struct AHDSquadState* SourceSquad, bool bNewLocked); // Function HDMain.DeployMenu_SquadListBase.SquadLockStateUpdated // (Final|Native|Private) // @ game+0x7943f0
	void SquadLeaderChanged(struct AHDSquadState* SourceSquad, struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.DeployMenu_SquadListBase.SquadLeaderChanged // (Final|Native|Private) // @ game+0x7942f0
	void SetupSquad(struct USquadListEntry* InSquadData); // Function HDMain.DeployMenu_SquadListBase.SetupSquad // (Final|Native|Public|BlueprintCallable) // @ game+0x794100
	void RepopulateSquad(); // Function HDMain.DeployMenu_SquadListBase.RepopulateSquad // (Final|Native|Public|BlueprintCallable) // @ game+0x793f40
	void OnSquadSet(); // Function HDMain.DeployMenu_SquadListBase.OnSquadSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnSquadNameUpdated(struct FText& NewSquadName, struct FText& PreviousSquadName); // Function HDMain.DeployMenu_SquadListBase.OnSquadNameUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void OnSquadLockStateUpdated(bool bNewLockedState); // Function HDMain.DeployMenu_SquadListBase.OnSquadLockStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnSquadLeaderUpdated(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.DeployMenu_SquadListBase.OnSquadLeaderUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnListRefresh(); // Function HDMain.DeployMenu_SquadListBase.OnListRefresh // (Final|Native|Private) // @ game+0x793d40
	void MemberSquadInfoUpdated(struct AHDSquadState* SourceSquad, struct AHDPlayerState* MemberPS, struct FHDSquadAssignmentInfo& MemberSQInfo); // Function HDMain.DeployMenu_SquadListBase.MemberSquadInfoUpdated // (Final|Native|Private|HasOutParms) // @ game+0x793c20
	void MemberPreRemoveFromSquad(struct AHDSquadState* SourceSquad, struct AHDPlayerState* MemberPSToBeRemoved); // Function HDMain.DeployMenu_SquadListBase.MemberPreRemoveFromSquad // (Final|Native|Private) // @ game+0x793b60
	void MemberAddedToSquad(struct AHDSquadState* SourceSquad, struct AHDPlayerState* NewMemberPS); // Function HDMain.DeployMenu_SquadListBase.MemberAddedToSquad // (Final|Native|Private) // @ game+0x793980
	struct AHDSquadState* GetSquadStateFromData(); // Function HDMain.DeployMenu_SquadListBase.GetSquadStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7937f0
	struct AHDPlatoonState* GetParentPlatoonStateFromData(); // Function HDMain.DeployMenu_SquadListBase.GetParentPlatoonStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x793750
	void GenerateSquadMember(struct USquadMemberInfo* MemberData); // Function HDMain.DeployMenu_SquadListBase.GenerateSquadMember // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructSquadMember(struct USquadMemberInfo* RemovedMemberData); // Function HDMain.DeployMenu_SquadListBase.DeconstructSquadMember // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.DeployMenu_SquadMemberListingBase
// Size: 0x238 (Inherited: 0x230)
struct UDeployMenu_SquadMemberListingBase : UUserWidget {
	struct USquadMemberInfo* MemberData; // 0x230(0x08)

	void SetupMember(struct USquadMemberInfo* InMemberData); // Function HDMain.DeployMenu_SquadMemberListingBase.SetupMember // (Final|Native|Public|BlueprintCallable) // @ game+0x794000
	void OnMemberSet(); // Function HDMain.DeployMenu_SquadMemberListingBase.OnMemberSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnMemberPlayerNameUpdated(struct FString NewPlayerName); // Function HDMain.DeployMenu_SquadMemberListingBase.OnMemberPlayerNameUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void MemberPlayerNameChanged(struct APlayerState* PlayerState, struct FString NewPlayerName); // Function HDMain.DeployMenu_SquadMemberListingBase.MemberPlayerNameChanged // (Final|Native|Private) // @ game+0x793a40
	struct AHDPlayerState* GetPlayerStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetPlayerStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7937f0
	struct AHDSquadState* GetParentSquadStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetParentSquadStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7937a0
	struct AHDPlatoonState* GetParentPlatoonStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetParentPlatoonStateFromData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x793750
};

// Class HDMain.DeployMenu_SquadSelectionWidgetBase
// Size: 0x250 (Inherited: 0x230)
struct UDeployMenu_SquadSelectionWidgetBase : UUserWidget {
	struct AHDTeamState* PlatoonTeamState; // 0x230(0x08)
	bool bSortPlatoons; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct TArray<struct UPlatoonListEntry*> CurrentPlatoons; // 0x240(0x10)

	void SetupSquadSelection(struct AHDTeamState* InPlatoonTeamState); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.SetupSquadSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x794180
	void RepopulateSquadSelection(); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.RepopulateSquadSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x793f60
	void PlatoonPreRemoveFromTeam(struct AHDTeamState* SourceTeam, struct AHDPlatoonState* PlatoonToBeRemoved); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonPreRemoveFromTeam // (Final|Native|Private) // @ game+0x793e20
	void PlatoonAddedToTeam(struct AHDTeamState* SourceTeam, struct AHDPlatoonState* NewPlatoon); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonAddedToTeam // (Final|Native|Private) // @ game+0x793d60
	void OnSquadSelectionSet(); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.OnSquadSelectionSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void GeneratePlatoon(struct UPlatoonListEntry* PlatoonData); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.GeneratePlatoon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructPlatoon(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemovedPlatoonIdx); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.DeconstructPlatoon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDAIHandlerBase
// Size: 0x50 (Inherited: 0x28)
struct UHDAIHandlerBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct AHDAIController* Controller; // 0x30(0x08)
	struct UHDGOAPComponent* GOAPComponent; // 0x38(0x08)
	char pad_40[0x8]; // 0x40(0x08)
	struct UHDAIHandlerBase* HandlerDuplicate; // 0x48(0x08)
};

// Class HDMain.HDAIAimingHandler
// Size: 0x138 (Inherited: 0x50)
struct UHDAIAimingHandler : UHDAIHandlerBase {
	float RefreshTargetRate; // 0x50(0x04)
	float NewTargetStimulusStrengthThreshold; // 0x54(0x04)
	struct FMulticastInlineDelegate OnContactStateChanged; // 0x58(0x10)
	struct FVector CurrentTargetLocation; // 0x68(0x0c)
	float CurrentTargetStimulusStrength; // 0x74(0x04)
	float CurrentTargetStimulusAge; // 0x78(0x04)
	float RefreshTargetTime; // 0x7c(0x04)
	struct FVector AimingTargetPoint; // 0x80(0x0c)
	struct FVector ProjectileAimingTossVelocity; // 0x8c(0x0c)
	struct UHDAICombatHandler* CombatHandler; // 0x98(0x08)
	struct UHDAINavigationHandler* NavigationHandler; // 0xa0(0x08)
	struct UHDAIBehaviorHandler* BehaviorHandler; // 0xa8(0x08)
	struct UHDAIVocalHandler* VocalHandler; // 0xb0(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0xb8(0x08)
	float NextFocalPointTime; // 0xc0(0x04)
	float NextFocalPointIntervalMin; // 0xc4(0x04)
	float NextFocalPointIntervalMax; // 0xc8(0x04)
	float NextFocalPointAngleMin; // 0xcc(0x04)
	float NextFocalPointAngleMax; // 0xd0(0x04)
	float NextFocalPointDistanceMin; // 0xd4(0x04)
	float NextFocalPointDistanceMax; // 0xd8(0x04)
	struct FRotator RotationRate; // 0xdc(0x0c)
	struct FRotator DefaultRotationRate; // 0xe8(0x0c)
	float WeaponAimingDistance; // 0xf4(0x04)
	float WeaponMinConeOfFireAngleDegrees; // 0xf8(0x04)
	float WeaponMaxConeOfFireAngleDegrees; // 0xfc(0x04)
	struct FVector NoEnemyFocalPoint; // 0x100(0x0c)
	bool bEnableNoEnemyLookAround; // 0x10c(0x01)
	char bAimingAtTarget : 1; // 0x10d(0x01)
	char pad_10D_1 : 7; // 0x10d(0x01)
	char pad_10E[0x2]; // 0x10e(0x02)
	float ProjectileAimingTime; // 0x110(0x04)
	float ProjectileAimingRate; // 0x114(0x04)
	float ProjectileAimingRateVariation; // 0x118(0x04)
	float AimingAtTargetAngleThreshold; // 0x11c(0x04)
	float AimingSpeedAngleNear; // 0x120(0x04)
	float AimingSpeedAngleFar; // 0x124(0x04)
	float AimingSpeed; // 0x128(0x04)
	float AimingSpeedNear; // 0x12c(0x04)
	float AimingSpeedFar; // 0x130(0x04)
	float AimingSpeedMultiplier; // 0x134(0x04)

	bool SuggestProjectileVelocity(struct FVector& TossVelocity, struct FVector StartLocation, struct FVector EndLocation, float TossSpeed); // Function HDMain.HDAIAimingHandler.SuggestProjectileVelocity // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7947b0
	bool ShouldChangeNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.ShouldChangeNoEnemyFocalPoint // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x794200
	void SetEnableNoEnemyLookAround(bool bInEnableNoEnemyLookAround); // Function HDMain.HDAIAimingHandler.SetEnableNoEnemyLookAround // (Final|Native|Public|BlueprintCallable) // @ game+0x793f80
	void MakeNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.MakeNoEnemyFocalPoint // (Final|Native|Protected|BlueprintCallable) // @ game+0x793960
	bool IsCandidateTarget(struct AActor* ActorToCheck); // Function HDMain.HDAIAimingHandler.IsCandidateTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7938d0
	bool IsAimingAtTarget(); // Function HDMain.HDAIAimingHandler.IsAimingAtTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7938a0
	struct FVector GetNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.GetNoEnemyFocalPoint // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x793720
	bool GetIsNewTargetMoreRelevant(float OldTargetStrength, float NewTargetStrength); // Function HDMain.HDAIAimingHandler.GetIsNewTargetMoreRelevant // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x793620
	bool GetEnableNoEnemyLookAround(); // Function HDMain.HDAIAimingHandler.GetEnableNoEnemyLookAround // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7935d0
	void GetActorStimulusData(struct AActor* InActor, struct FVector& OutLocation, float& OutStrength, float& OutAge); // Function HDMain.HDAIAimingHandler.GetActorStimulusData // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x793460
	void EstablishNewTargetFromPerception(struct UAISense*& SenseToUse); // Function HDMain.HDAIAimingHandler.EstablishNewTargetFromPerception // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7933d0
	bool CheckForTarget(struct AActor* TargetActor, struct FAIStimulus Stimulus); // Function HDMain.HDAIAimingHandler.CheckForTarget // (Final|Native|Public|BlueprintCallable) // @ game+0x793230
	void CalcAimingDirection(); // Function HDMain.HDAIAimingHandler.CalcAimingDirection // (Final|Native|Protected|BlueprintCallable) // @ game+0x7931f0
	void AimAtCurrentTarget(); // Function HDMain.HDAIAimingHandler.AimAtCurrentTarget // (Final|Native|Protected|BlueprintCallable) // @ game+0x7931d0
};

// Class HDMain.HDAIBehaviorHandler
// Size: 0x140 (Inherited: 0x50)
struct UHDAIBehaviorHandler : UHDAIHandlerBase {
	struct FMulticastInlineDelegate OnSafeBehaviorStart; // 0x50(0x10)
	struct FMulticastInlineDelegate OnAwareBehaviorStart; // 0x60(0x10)
	struct FMulticastInlineDelegate OnCombatBehaviorStart; // 0x70(0x10)
	struct FMulticastInlineDelegate OnDangerBehaviorStart; // 0x80(0x10)
	enum class EHDAIThreatLevel CurrentThreatLevel; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct UHDAINavigationHandler* NavigationHandler; // 0x98(0x08)
	struct UHDAICombatHandler* CombatHandler; // 0xa0(0x08)
	struct UHDAIAimingHandler* AimingHandler; // 0xa8(0x08)
	struct UHDAIVocalHandler* VocalHandler; // 0xb0(0x08)
	float SuppressionThreatLevel; // 0xb8(0x04)
	float SuppressionLevelPerShot; // 0xbc(0x04)
	float SuppressionThreatThreshold; // 0xc0(0x04)
	float SuppressionFalloff; // 0xc4(0x04)
	float SuppressionTime; // 0xc8(0x04)
	float SuppressionFallingOffDelay; // 0xcc(0x04)
	float BeingHitThreatLevel; // 0xd0(0x04)
	float BeingHitThreatThreshold; // 0xd4(0x04)
	float BeingHitFalloff; // 0xd8(0x04)
	float BeingHitThreatLevelSpikeProbability; // 0xdc(0x04)
	float BeingHitThreatLevelSpikeAmount; // 0xe0(0x04)
	float BeingHitFallingOffDelay; // 0xe4(0x04)
	float BeingHitTime; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	char bIsSprinting : 1; // 0xf0(0x01)
	char pad_F0_1 : 7; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	float SprintTimeMin; // 0xf4(0x04)
	float SprintTimeMax; // 0xf8(0x04)
	float SprintTimeEnd; // 0xfc(0x04)
	float SprintStaminaThresholdMin; // 0x100(0x04)
	float SprintStaminaThresholdMax; // 0x104(0x04)
	float SprintStaminaThreshold; // 0x108(0x04)
	float SprintStaminaMin; // 0x10c(0x04)
	float SprintLookAroundTimeMin; // 0x110(0x04)
	float SprintLookAroundTimeMax; // 0x114(0x04)
	float SprintLookAroundTimeEnd; // 0x118(0x04)
	char bCombatCanCrouch : 1; // 0x11c(0x01)
	char bCombatCanProne : 1; // 0x11c(0x01)
	char pad_11C_2 : 6; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	float CombatSuppressionThresholdCrouching; // 0x120(0x04)
	float CombatSuppressionThresholdProning; // 0x124(0x04)
	char bDangerCanCrouch : 1; // 0x128(0x01)
	char bDangerCanProne : 1; // 0x128(0x01)
	char pad_128_2 : 6; // 0x128(0x01)
	char pad_129[0x3]; // 0x129(0x03)
	float DangerSuppressionThresholdCrouching; // 0x12c(0x04)
	float DangerSuppressionThresholdProning; // 0x130(0x04)
	float DangerHealthThresholdCrouching; // 0x134(0x04)
	float DangerHealthThresholdProning; // 0x138(0x04)
	char pad_13C[0x4]; // 0x13c(0x04)

	void StartSafeBehavior(); // Function HDMain.HDAIBehaviorHandler.StartSafeBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x794790
	void StartDangerBehavior(); // Function HDMain.HDAIBehaviorHandler.StartDangerBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x794770
	void StartCombatBehavior(); // Function HDMain.HDAIBehaviorHandler.StartCombatBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x794750
	void StartAwareBehavior(); // Function HDMain.HDAIBehaviorHandler.StartAwareBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x794730
	void ReceiveSuppression(); // Function HDMain.HDAIBehaviorHandler.ReceiveSuppression // (Final|Native|Public|BlueprintCallable) // @ game+0x793f00
	void ReceiveHitDamage(); // Function HDMain.HDAIBehaviorHandler.ReceiveHitDamage // (Final|Native|Public|BlueprintCallable) // @ game+0x793ee0
	void HandleSafeBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleSafeBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x793880
	void HandleDangerBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleDangerBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x793860
	void HandleCombatBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleCombatBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x793840
	void HandleBehaviorStates(); // Function HDMain.HDAIBehaviorHandler.HandleBehaviorStates // (Final|Native|Protected|BlueprintCallable) // @ game+0x793820
	void HandleAwareBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleAwareBehavior // (Final|Native|Protected|BlueprintCallable) // @ game+0x6c7310
	bool GetIsUnderSuppression(); // Function HDMain.HDAIBehaviorHandler.GetIsUnderSuppression // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7936f0
	bool GetIsBeingHit(); // Function HDMain.HDAIBehaviorHandler.GetIsBeingHit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7935f0
	void DetermineThreatLevel(); // Function HDMain.HDAIBehaviorHandler.DetermineThreatLevel // (Final|Native|Protected|BlueprintCallable) // @ game+0x7933b0
	void CalcThreatLevels(); // Function HDMain.HDAIBehaviorHandler.CalcThreatLevels // (Final|Native|Protected|BlueprintCallable) // @ game+0x793210
};

// Class HDMain.HDAICaptureHandler
// Size: 0x68 (Inherited: 0x50)
struct UHDAICaptureHandler : UHDAIHandlerBase {
	struct AHDBaseCapturePoint* CurrentCP; // 0x50(0x08)
	enum class EHDAICaptureMode CurrentCaptureMode; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	float AICaptureModePreference; // 0x5c(0x04)
	char bAutoUpdateNavHandlerDesiredLocation : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)

	bool ShouldEstablishNewControlPoint(); // Function HDMain.HDAICaptureHandler.ShouldEstablishNewControlPoint // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x797460
	void SetCurrentCP(struct AHDBaseCapturePoint* InCurrentCP); // Function HDMain.HDAICaptureHandler.SetCurrentCP // (Final|Native|Public|BlueprintCallable) // @ game+0x797040
	void SetCurrentCaptureMode(enum class EHDAICaptureMode NewCaptureMode); // Function HDMain.HDAICaptureHandler.SetCurrentCaptureMode // (Final|Native|Public|BlueprintCallable) // @ game+0x7970c0
	struct AActor* GetStartSpotClosestToControlPoint(struct AActor* InCapturePoint); // Function HDMain.HDAICaptureHandler.GetStartSpotClosestToControlPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x796820
	struct FVector GetCurrentCPLocation(); // Function HDMain.HDAICaptureHandler.GetCurrentCPLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x7966f0
	bool FindControlPointToCapture(struct AHDBaseCapturePoint*& OutFoundCP); // Function HDMain.HDAICaptureHandler.FindControlPointToCapture // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x796620
	struct AHDBaseCapturePoint* FindControlPointRandom(struct TArray<struct AHDBaseCapturePoint*>& CPs); // Function HDMain.HDAICaptureHandler.FindControlPointRandom // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x796560
	struct AHDBaseCapturePoint* FindControlPointClosestToPawn(struct TArray<struct AHDBaseCapturePoint*>& CPs); // Function HDMain.HDAICaptureHandler.FindControlPointClosestToPawn // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7964a0
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV3(enum class EHDAICaptureMode InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV3 // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x7963d0
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV2(enum class EHDAICaptureMode InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV2 // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x796300
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV1(enum class EHDAICaptureMode InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV1 // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x796230
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfType(enum class EHDAICaptureMode InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfType // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x796160
	bool EstablishNewControlPoint(); // Function HDMain.HDAICaptureHandler.EstablishNewControlPoint // (Native|Public|BlueprintCallable) // @ game+0x796130
};

// Class HDMain.HDAICombatHandler
// Size: 0x1d8 (Inherited: 0x50)
struct UHDAICombatHandler : UHDAIHandlerBase {
	struct UHDAIBehaviorHandler* BehaviorHandler; // 0x50(0x08)
	struct UHDAIVocalHandler* VocalHandler; // 0x58(0x08)
	char pad_60_0 : 1; // 0x60(0x01)
	char bWeaponAutoReload : 1; // 0x60(0x01)
	char bWeaponMovementFire : 1; // 0x60(0x01)
	char bWeaponHasAmmo : 1; // 0x60(0x01)
	char pad_60_4 : 4; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct AActor* Enemy; // 0x68(0x08)
	float WeaponNextFireTime; // 0x70(0x04)
	float AttackRateMin; // 0x74(0x04)
	float AttackRateMax; // 0x78(0x04)
	float BurstAttackProbability; // 0x7c(0x04)
	int32_t BurstAttackNumberMin; // 0x80(0x04)
	int32_t BurstAttackNumberMax; // 0x84(0x04)
	int32_t CurrentBurstAttackNumber; // 0x88(0x04)
	float WeaponStopFireTime; // 0x8c(0x04)
	float WeaponStopFireTimeMin; // 0x90(0x04)
	float WeaponStopFireTimeMax; // 0x94(0x04)
	char bWeaponInfiniteAmmo : 1; // 0x98(0x01)
	char bWeaponInfiniteClipAmmo : 1; // 0x98(0x01)
	char bIgnoreFriendlySuppression : 1; // 0x98(0x01)
	char bIgnoreFriendlyHits : 1; // 0x98(0x01)
	char pad_98_4 : 4; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FMulticastInlineDelegate OnReceiveSuppression; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnReceiveHitDamage; // 0xb0(0x10)
	struct FVector SuppressionDirection; // 0xc0(0x0c)
	float SuppressionOriginDistance; // 0xcc(0x04)
	struct FVector SuppressionOrigin; // 0xd0(0x0c)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct FMulticastInlineDelegate OnReload; // 0xe0(0x10)
	struct UHDKit* CurrentKit; // 0xf0(0x08)
	enum class ESpecificItemType CurrentSpecificItemType; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)
	struct TArray<struct FHDAIItemData> EquipmentReferences; // 0x100(0x10)
	float EquipmentHandlingTime; // 0x110(0x04)
	float EquipmentHandlingRate; // 0x114(0x04)
	float EquipmentHandlingRateVariation; // 0x118(0x04)
	char bSpecialtyItemInUse : 1; // 0x11c(0x01)
	char bProjectileWeaponInUse : 1; // 0x11c(0x01)
	char pad_11C_2 : 6; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	float AfterEquipCooldownTime; // 0x120(0x04)
	float SpecialtyItemUseTimeLimit; // 0x124(0x04)
	float AfterSpecialtyItemUsedTimeLimit; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct TMap<enum class ESpecificItemType, struct FHDAISpecificItemTypeAttackData> ItemAttackData; // 0x130(0x50)
	struct FHDAISpecificItemTypeAttackData DefaultItemAttackData; // 0x180(0x2c)
	float GrenadeLauncherRangeMin; // 0x1ac(0x04)
	float GrenadeLauncherRangeMax; // 0x1b0(0x04)
	float GrenadeLauncherChance; // 0x1b4(0x04)
	float RocketLauncherRangeMin; // 0x1b8(0x04)
	float RocketLauncherRangeMax; // 0x1bc(0x04)
	float RocketLauncherChance; // 0x1c0(0x04)
	float FragGrenadeRangeMin; // 0x1c4(0x04)
	float FragGrenadeRangeMax; // 0x1c8(0x04)
	float FragGrenadeChance; // 0x1cc(0x04)
	float SmokeGrenadeRangeMin; // 0x1d0(0x04)
	float SmokeGrenadeChance; // 0x1d4(0x04)

	void UpdateEquipmentHandling(); // Function HDMain.HDAICombatHandler.UpdateEquipmentHandling // (Final|Native|Public|BlueprintCallable) // @ game+0x7975a0
	void UpdateAttackParameters(); // Function HDMain.HDAICombatHandler.UpdateAttackParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x797580
	void StopUsingSpecialtyItem(); // Function HDMain.HDAICombatHandler.StopUsingSpecialtyItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x797560
	void StopAttack(); // Function HDMain.HDAICombatHandler.StopAttack // (Final|Native|Public|BlueprintCallable) // @ game+0x797520
	void StartAttack(); // Function HDMain.HDAICombatHandler.StartAttack // (Final|Native|Public|BlueprintCallable) // @ game+0x7974c0
	void SetWeaponMovementFireEnabled(bool bInWeaponMovementFire); // Function HDMain.HDAICombatHandler.SetWeaponMovementFireEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x797390
	void SetWeaponAutoReloadEnabled(bool bInWeaponAutoReload); // Function HDMain.HDAICombatHandler.SetWeaponAutoReloadEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x797300
	void SetupEquipmentReferences(); // Function HDMain.HDAICombatHandler.SetupEquipmentReferences // (Final|Native|Public|BlueprintCallable) // @ game+0x797420
	void SetNextAttackTime(); // Function HDMain.HDAICombatHandler.SetNextAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x7972c0
	void SetItemAttackParameters(struct FHDAISpecificItemTypeAttackData& InAttackData); // Function HDMain.HDAICombatHandler.SetItemAttackParameters // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7971e0
	void SetEnemy(struct AActor* NewEnemy); // Function HDMain.HDAICombatHandler.SetEnemy // (Final|Native|Public|BlueprintCallable) // @ game+0x797160
	void Reload(struct AHDBaseWeapon* InWeapon); // Function HDMain.HDAICombatHandler.Reload // (Native|Public|BlueprintCallable) // @ game+0x6e0110
	void ReceiveSuppression(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function HDMain.HDAICombatHandler.ReceiveSuppression // (Final|Native|Public|BlueprintCallable) // @ game+0x796f50
	void ReceiveHitDamage(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function HDMain.HDAICombatHandler.ReceiveHitDamage // (Final|Native|Public|BlueprintCallable) // @ game+0x796e90
	void PauseAttack(); // Function HDMain.HDAICombatHandler.PauseAttack // (Final|Native|Public|BlueprintCallable) // @ game+0x796d20
	bool IsFiring(); // Function HDMain.HDAICombatHandler.IsFiring // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x796990
	bool HasValidEnemy(bool bAliveCheck); // Function HDMain.HDAICombatHandler.HasValidEnemy // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x796900
	bool HasAmmoLoaded(); // Function HDMain.HDAICombatHandler.HasAmmoLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7968d0
	bool CanAttackEnemy(bool bCheckFireTime, bool bIgnoreAmmoReloadCheck); // Function HDMain.HDAICombatHandler.CanAttackEnemy // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x796050
};

// Class HDMain.HDAIController
// Size: 0x360 (Inherited: 0x330)
struct AHDAIController : ADFBaseAIController {
	struct UHDPlayerComponent* PlayerComponent; // 0x330(0x08)
	struct UHDGOAPComponent* GOAPComponent; // 0x338(0x08)
	char bCanJoinSquads : 1; // 0x340(0x01)
	char bCanJoinPlayerSquads : 1; // 0x340(0x01)
	char bCanCreateSquads : 1; // 0x340(0x01)
	char pad_340_3 : 5; // 0x340(0x01)
	char pad_341[0x3]; // 0x341(0x03)
	int32_t MaxNumberOfAILedSquads; // 0x344(0x04)
	int32_t MaxNumberOfSquadMembers; // 0x348(0x04)
	int32_t MaxNumberOfAISquadMembers; // 0x34c(0x04)
	char bUseFactionSpecifiedSquadLeaderKit : 1; // 0x350(0x01)
	char bUseFactionSpecifiedSquadMemberKit : 1; // 0x350(0x01)
	char pad_350_2 : 6; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	struct FVector FocusActorPerceivedLocation; // 0x354(0x0c)

	bool JoinOrCreateSquad(); // Function HDMain.HDAIController.JoinOrCreateSquad // (Final|Native|Public|BlueprintCallable) // @ game+0x7969f0
	struct APawn* GetStartPawnClass(); // Function HDMain.HDAIController.GetStartPawnClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7967e0
	struct UHDKit* GetFactionSpecifiedSquadMemberKit(); // Function HDMain.HDAIController.GetFactionSpecifiedSquadMemberKit // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x796760
	struct UHDKit* GetFactionSpecifiedSquadLeaderKit(); // Function HDMain.HDAIController.GetFactionSpecifiedSquadLeaderKit // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x796730
};

// Class HDMain.HDAIGroupBehaviorHandler
// Size: 0x160 (Inherited: 0x50)
struct UHDAIGroupBehaviorHandler : UHDAIHandlerBase {
	struct UHDAINavigationHandler* NavigationHandler; // 0x50(0x08)
	struct UHDAICaptureHandler* CaptureHandler; // 0x58(0x08)
	struct AHDPlayerState* PlayerState; // 0x60(0x08)
	char bIsGroupLeader : 1; // 0x68(0x01)
	char bIsGroupMember : 1; // 0x68(0x01)
	char bGroupDataIsSet : 1; // 0x68(0x01)
	char bGroupDataIsSynchronized : 1; // 0x68(0x01)
	char bIsRespawned : 1; // 0x68(0x01)
	char bLeaderIsHuman : 1; // 0x68(0x01)
	char pad_68_6 : 2; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float GroupFormationRadius; // 0x6c(0x04)
	float GroupFormationSlotRadius; // 0x70(0x04)
	float GroupFormationSlotDistance; // 0x74(0x04)
	struct TArray<struct FVector> FormationSlots; // 0x78(0x10)
	int32_t FormationIndex; // 0x88(0x04)
	float WaitingTimePerGroupMember; // 0x8c(0x04)
	float WaitingGroupRadiusMultiplier; // 0x90(0x04)
	int32_t NumValidGroupMembers; // 0x94(0x04)
	int32_t NumGroupMembersOnPoint; // 0x98(0x04)
	int32_t NumGroupMembersKIA; // 0x9c(0x04)
	char bWaitingForGroupMembers : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	float WaitingForMembersStartTime; // 0xa4(0x04)
	char bIsGroupWaiting : 1; // 0xa8(0x01)
	char pad_A8_1 : 7; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	float GroupWaitTimeEnd; // 0xac(0x04)
	float GroupWaitTimeDuration; // 0xb0(0x04)
	int32_t MinNumGroupMembersOnPoint; // 0xb4(0x04)
	float AdvanceWaitTimeDurationMin; // 0xb8(0x04)
	float AdvanceWaitTimeDurationMax; // 0xbc(0x04)
	float PatrolWaitTimeDurationMin; // 0xc0(0x04)
	float PatrolWaitTimeDurationMax; // 0xc4(0x04)
	char bIsGroupRetreating : 1; // 0xc8(0x01)
	char bGroupRetreatOnLeaderKIA : 1; // 0xc8(0x01)
	char pad_C8_2 : 6; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float GroupRetreatMemberPercentageThreshold; // 0xcc(0x04)
	char bEnableFollowHumanLeader : 1; // 0xd0(0x01)
	char pad_D0_1 : 7; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	float FollowHumanLeaderInterval; // 0xd4(0x04)
	float FollowHumanLeaderVelocityMultiplier; // 0xd8(0x04)
	float FollowHumanLeaderAcceptanceRadius; // 0xdc(0x04)
	float FollowHumanLeaderRange; // 0xe0(0x04)
	float FollowHumanLeaderPatrolTimeThreshold; // 0xe4(0x04)
	float FollowHumanLeaderTime; // 0xe8(0x04)
	float FollowHumanLeaderPatrolTime; // 0xec(0x04)
	struct FVector FollowHumanLeaderLastKnownLocation; // 0xf0(0x0c)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct TArray<struct FHDAIMasterNavPoint> MasterNavPath; // 0x100(0x10)
	float MasterNavPathLength; // 0x110(0x04)
	float NavPathSegmentLengthMin; // 0x114(0x04)
	float NavPathSegmentLengthMax; // 0x118(0x04)
	char bCompensatePartialPathForGroupFormationRadius : 1; // 0x11c(0x01)
	char pad_11C_1 : 7; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	float PartialPathGroupRadiusMultiplier; // 0x120(0x04)
	float RemainingNavPathLength; // 0x124(0x04)
	int32_t NavPointIndex; // 0x128(0x04)
	char bPawnIsAtTheEndOfPath : 1; // 0x12c(0x01)
	char pad_12C_1 : 7; // 0x12c(0x01)
	char pad_12D[0x3]; // 0x12d(0x03)
	struct FVector GroupCenterNavPoint; // 0x130(0x0c)
	struct FVector TargetNavPoint; // 0x13c(0x0c)
	float NavPointRandomRange; // 0x148(0x04)
	float MoveToFailedTime; // 0x14c(0x04)
	float MoveToFailedTimeDelay; // 0x150(0x04)
	char bMovetoFailedIsBeingHandled : 1; // 0x154(0x01)
	char pad_154_1 : 7; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
	struct AHDBaseCapturePoint* SavedCapturePoint; // 0x158(0x08)

	void StopRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.StopRetreat // (Final|Native|Public|BlueprintCallable) // @ game+0x797540
	void StartRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.StartRetreat // (Final|Native|Public|BlueprintCallable) // @ game+0x797500
	void StartGroupWaitTime(); // Function HDMain.HDAIGroupBehaviorHandler.StartGroupWaitTime // (Final|Native|Public|BlueprintCallable) // @ game+0x7974e0
	bool ShouldRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.ShouldRetreat // (Final|Native|Public|BlueprintCallable) // @ game+0x797490
	void SetupGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.SetupGroupData // (Final|Native|Public|BlueprintCallable) // @ game+0x797440
	void SetSquadParams(); // Function HDMain.HDAIGroupBehaviorHandler.SetSquadParams // (Final|Native|Public|BlueprintCallable) // @ game+0x7972e0
	void SetCurrentDestination(); // Function HDMain.HDAIGroupBehaviorHandler.SetCurrentDestination // (Final|Native|Public|BlueprintCallable) // @ game+0x797140
	bool RequestGroupDataSync(); // Function HDMain.HDAIGroupBehaviorHandler.RequestGroupDataSync // (Final|Native|Public|BlueprintCallable) // @ game+0x797010
	bool PointsAreEqualXY(struct FVector& Vector1, struct FVector& Vector2, float Tolerance); // Function HDMain.HDAIGroupBehaviorHandler.PointsAreEqualXY // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x796d40
	void OnOwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDAIGroupBehaviorHandler.OnOwnerDeath // (Final|Native|Private|HasOutParms) // @ game+0x796b40
	void OnMoveToFailed(); // Function HDMain.HDAIGroupBehaviorHandler.OnMoveToFailed // (Final|Native|Private|BlueprintCallable) // @ game+0x796b20
	void MakeNewMasterNavPath(struct FVector InStart, struct FVector InDestination); // Function HDMain.HDAIGroupBehaviorHandler.MakeNewMasterNavPath // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x796a40
	void MakeNavPathSegment(); // Function HDMain.HDAIGroupBehaviorHandler.MakeNavPathSegment // (Final|Native|Public|BlueprintCallable) // @ game+0x796a20
	bool IsGroupWaitTimeOver(); // Function HDMain.HDAIGroupBehaviorHandler.IsGroupWaitTimeOver // (Final|Native|Public|BlueprintCallable) // @ game+0x7969c0
	void HandleMoveToFailed(); // Function HDMain.HDAIGroupBehaviorHandler.HandleMoveToFailed // (Final|Native|Private|BlueprintCallable) // @ game+0x7968b0
	struct FHDAIGroupData GetGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.GetGroupData // (Final|Native|Public|BlueprintCallable) // @ game+0x796790
	void FollowHumanLeader(); // Function HDMain.HDAIGroupBehaviorHandler.FollowHumanLeader // (Final|Native|Private|BlueprintCallable) // @ game+0x7966d0
	void BroadcastGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.BroadcastGroupData // (Final|Native|Public|BlueprintCallable) // @ game+0x796030
	bool AllGroupMembersAreOnPoint(); // Function HDMain.HDAIGroupBehaviorHandler.AllGroupMembersAreOnPoint // (Final|Native|Public|BlueprintCallable) // @ game+0x796000
};

// Class HDMain.HDAINavigationHandler
// Size: 0x150 (Inherited: 0x50)
struct UHDAINavigationHandler : UHDAIHandlerBase {
	struct FMulticastInlineDelegate OnMoveToLocationFailed; // 0x50(0x10)
	struct UNavigationSystemV1* NavSystem; // 0x60(0x08)
	bool bMoving; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	struct FVector DesiredLocation; // 0x6c(0x0c)
	char pad_78[0x10]; // 0x78(0x10)
	int32_t TargetNavPointIndex; // 0x88(0x04)
	struct FVector TargetNavPoint; // 0x8c(0x0c)
	float AcceptanceRadius; // 0x98(0x04)
	bool bRandomizeNavPoints; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
	float NavPointRandomizationRadius; // 0xa0(0x04)
	float NavPointRandomizationOffset; // 0xa4(0x04)
	float StuckCheckTime; // 0xa8(0x04)
	float StuckCheckInterval; // 0xac(0x04)
	float StuckCheckDistance; // 0xb0(0x04)
	struct FVector StuckCheckLastLocation; // 0xb4(0x0c)
	char bEnableBoidsSteering : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	float SteeringMass; // 0xc4(0x04)
	float SteeringMaxForce; // 0xc8(0x04)
	struct FVector SteeringVector; // 0xcc(0x0c)
	float SteeringMovementSpeedModifier; // 0xd8(0x04)
	float FollowPathAcceptanceRadius; // 0xdc(0x04)
	float ArrivalSlowDownRadius; // 0xe0(0x04)
	struct FVector FollowPathVector; // 0xe4(0x0c)
	float SteeringNeighborhoodRadius; // 0xf0(0x04)
	char pad_F4[0x4]; // 0xf4(0x04)
	struct TArray<struct AActor*> SteeringNeighborhood; // 0xf8(0x10)
	float SeparationStrength; // 0x108(0x04)
	float InternalSeparationStrength; // 0x10c(0x04)
	float CohesionStrength; // 0x110(0x04)
	struct FVector SeparationVector; // 0x114(0x0c)
	struct FVector CohesionVector; // 0x120(0x0c)
	float ObstacleAvoidanceTraceLength; // 0x12c(0x04)
	float ObstacleAvoidanceStrength; // 0x130(0x04)
	struct FVector ObstacleAvoidanceVector; // 0x134(0x0c)
	char bEnableRVOAvoidance : 1; // 0x140(0x01)
	char pad_140_1 : 7; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float RVOAvoidanceConsiderationRadius; // 0x144(0x04)
	float RVOAvoidanceWeight; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)

	void SetupRVOAvoidance(); // Function HDMain.HDAINavigationHandler.SetupRVOAvoidance // (Final|Native|Public|BlueprintCallable) // @ game+0x79a110
	void SetupNextTargetNavPoint(); // Function HDMain.HDAINavigationHandler.SetupNextTargetNavPoint // (Final|Native|Public|BlueprintCallable) // @ game+0x79a0f0
	void SetDesiredLocation(struct FVector& InDesiredLocation); // Function HDMain.HDAINavigationHandler.SetDesiredLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x799f60
	void MoveToLocationFailed(); // Function HDMain.HDAINavigationHandler.MoveToLocationFailed // (Final|Native|Public|BlueprintCallable) // @ game+0x799840
	bool MakePathToDesiredLocation(); // Function HDMain.HDAINavigationHandler.MakePathToDesiredLocation // (Final|Native|Public|BlueprintCallable) // @ game+0x799810
	bool IsPawnAtDestination(); // Function HDMain.HDAINavigationHandler.IsPawnAtDestination // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7997e0
	bool IsNavigationPossible(); // Function HDMain.HDAINavigationHandler.IsNavigationPossible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7997b0
	bool IsNavDataValidForAllControlPoints(); // Function HDMain.HDAINavigationHandler.IsNavDataValidForAllControlPoints // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x799780
	void FixVectorValuesNaN(struct FVector& InVector, bool bRandomize); // Function HDMain.HDAINavigationHandler.FixVectorValuesNaN // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7993d0
	bool FindNewControlPointNavLocation(struct AHDBaseCapturePoint* CP); // Function HDMain.HDAINavigationHandler.FindNewControlPointNavLocation // (Final|Native|Public|BlueprintCallable) // @ game+0x799320
	bool FindNavLocationInsideControlPoint(struct AHDBaseCapturePoint* CP, struct FVector& OutNavLoc); // Function HDMain.HDAINavigationHandler.FindNavLocationInsideControlPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x799240
	bool CheckPawnStuckStatus(); // Function HDMain.HDAINavigationHandler.CheckPawnStuckStatus // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x799170
	struct FVector CalcSeparationVector(); // Function HDMain.HDAINavigationHandler.CalcSeparationVector // (Final|Native|Private|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x798dc0
	struct FVector CalcObstacleAvoidanceVector(); // Function HDMain.HDAINavigationHandler.CalcObstacleAvoidanceVector // (Final|Native|Private|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x798d80
	struct FVector CalcCohesionVector(); // Function HDMain.HDAINavigationHandler.CalcCohesionVector // (Final|Native|Private|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x798d40
};

// Class HDMain.HDAIPerceptionComponent
// Size: 0xf0 (Inherited: 0xb0)
struct UHDAIPerceptionComponent : UActorComponent {
	struct AHDPlayerCharacter* OwnerPlayer; // 0xb0(0x08)
	char bEnableAdvancedLineTracing : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	float ObserverSightRadius; // 0xbc(0x04)
	float ObserverLoseSightRadius; // 0xc0(0x04)
	float DistanceToObserverRangeFar; // 0xc4(0x04)
	float DistanceToObserverRangeNear; // 0xc8(0x04)
	char bComplexSightLineTrace : 1; // 0xcc(0x01)
	char pad_CC_1 : 7; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	float ShoulderLocationFactor; // 0xd0(0x04)
	float RangeFactorWeight; // 0xd4(0x04)
	float StanceFactorWeight; // 0xd8(0x04)
	float MovementFactorWeight; // 0xdc(0x04)
	float StanceFactorMaxValue; // 0xe0(0x04)
	float StanceFactorMinValue; // 0xe4(0x04)
	float OwnerMaxMovementSpeed; // 0xe8(0x04)
	float OwnerDefaultHalfHeight; // 0xec(0x04)

	bool CanBeSeenFrom(struct FVector& ObserverLocation, struct FVector& OutSeenLocation, int32_t& NumberOfLoSChecksPerformed, float& OutSightStrength, struct AActor* IgnoreActor); // Function HDMain.HDAIPerceptionComponent.CanBeSeenFrom // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x798e90
	float CalcSightStrength(float Distance); // Function HDMain.HDAIPerceptionComponent.CalcSightStrength // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x798e00
};

// Class HDMain.HDAIVocalHandler
// Size: 0x118 (Inherited: 0x50)
struct UHDAIVocalHandler : UHDAIHandlerBase {
	struct UHDAICombatHandler* CombatHandler; // 0x50(0x08)
	char bEnableVocalization : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FAICharacterVocalProfile CurrentProfile; // 0x60(0x68)
	char bEnableTimeLimitNotify : 1; // 0xc8(0x01)
	char bFactionOnlyTimeLimit : 1; // 0xc8(0x01)
	char pad_C8_2 : 6; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float TimeLimitNotifyRange; // 0xcc(0x04)
	float PitchMultiplier; // 0xd0(0x04)
	float MinPitchMultiplier; // 0xd4(0x04)
	float MaxPitchMultiplier; // 0xd8(0x04)
	float AnySoundTimeLimit; // 0xdc(0x04)
	float ContactTimeLimit; // 0xe0(0x04)
	float LostContactTimeLimit; // 0xe4(0x04)
	float ReloadingTimeLimit; // 0xe8(0x04)
	float BeenHitTimeLimit; // 0xec(0x04)
	float UnderSuppressionTimeLimit; // 0xf0(0x04)
	float DeathTimeLimit; // 0xf4(0x04)
	float NextAnySoundTime; // 0xf8(0x04)
	float NextContactTime; // 0xfc(0x04)
	float NextLostContactTime; // 0x100(0x04)
	float NextReloadingTime; // 0x104(0x04)
	float NextBeenHitTime; // 0x108(0x04)
	float NextUnderSuppressionTime; // 0x10c(0x04)
	float NextDeathTime; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)

	void VocalizeSuppression(); // Function HDMain.HDAIVocalHandler.VocalizeSuppression // (Final|Native|Public|BlueprintCallable) // @ game+0x79a280
	void VocalizeReload(); // Function HDMain.HDAIVocalHandler.VocalizeReload // (Final|Native|Public|BlueprintCallable) // @ game+0x79a260
	void VocalizeContact(bool bHasContact); // Function HDMain.HDAIVocalHandler.VocalizeContact // (Final|Native|Public|BlueprintCallable) // @ game+0x79a1d0
	void VocalizeBeenHit(); // Function HDMain.HDAIVocalHandler.VocalizeBeenHit // (Final|Native|Public|BlueprintCallable) // @ game+0x79a1b0
	void Vocalize(enum class EHDAIVocalizationType InVocalType); // Function HDMain.HDAIVocalHandler.Vocalize // (Final|Native|Public|BlueprintCallable) // @ game+0x79a130
	void SetTimeLimit(enum class EHDAIVocalizationType InVocalType); // Function HDMain.HDAIVocalHandler.SetTimeLimit // (Final|Native|Protected|BlueprintCallable) // @ game+0x79a070
	void SetPitchMultiplier(float InPitchMultiplier); // Function HDMain.HDAIVocalHandler.SetPitchMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x799ff0
	void RandomizePitchMultiplier(); // Function HDMain.HDAIVocalHandler.RandomizePitchMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x799e20
	void PlayVocalSound(enum class EHDAIVocalizationType InVocalType); // Function HDMain.HDAIVocalHandler.PlayVocalSound // (Final|Native|Protected|BlueprintCallable) // @ game+0x799da0
	void NotifySurroundingCharacters(enum class EHDAIVocalizationType InVocalType); // Function HDMain.HDAIVocalHandler.NotifySurroundingCharacters // (Final|Native|Protected|BlueprintCallable) // @ game+0x799860
};

// Class HDMain.HDAssetManager
// Size: 0x440 (Inherited: 0x440)
struct UHDAssetManager : UDFAssetManager {
};

// Class HDMain.HDBaseCapturePoint
// Size: 0x350 (Inherited: 0x220)
struct AHDBaseCapturePoint : AActor {
	char pad_220[0x8]; // 0x220(0x08)
	struct USkeletalMeshComponent* Mesh; // 0x228(0x08)
	struct USphereComponent* SphereCollision; // 0x230(0x08)
	struct UDFPOIComponent* POI; // 0x238(0x08)
	struct UNavigationInvokerComponent* NavigationInvoker; // 0x240(0x08)
	char bActive : 1; // 0x248(0x01)
	char bLocked : 1; // 0x248(0x01)
	char bContested : 1; // 0x248(0x01)
	char bCaptured : 1; // 0x248(0x01)
	char bCapturedOnce : 1; // 0x248(0x01)
	char pad_248_5 : 3; // 0x248(0x01)
	char pad_249[0x3]; // 0x249(0x03)
	int32_t CaptureProgress; // 0x24c(0x04)
	int32_t ActiveRoute; // 0x250(0x04)
	char pad_254[0xc]; // 0x254(0x0c)
	struct TArray<struct UChildActorComponent*> SpawnPoints; // 0x260(0x10)
	struct FMulticastInlineDelegate OnCaptureProgressUpdated; // 0x270(0x10)
	enum class EHDTeam StartingTeam; // 0x280(0x01)
	char pad_281[0x7]; // 0x281(0x07)
	struct FText CaptureDisplayName; // 0x288(0x18)
	float CaptureTimerRate; // 0x2a0(0x04)
	int32_t CaptureSpeed; // 0x2a4(0x04)
	float CaptureRadius; // 0x2a8(0x04)
	int32_t MinPlayersToCapture; // 0x2ac(0x04)
	char bEnforceMinPlayersToCaptureWithSmallerPlayerCount : 1; // 0x2b0(0x01)
	char bScaleCaptureSpeed : 1; // 0x2b0(0x01)
	char bRecapturable : 1; // 0x2b0(0x01)
	char bWinOnCapture : 1; // 0x2b0(0x01)
	char bProvideSpawnPoint : 1; // 0x2b0(0x01)
	char bProvideSpawnPointWhenUnderAttack : 1; // 0x2b0(0x01)
	char pad_2B0_6 : 2; // 0x2b0(0x01)
	char pad_2B1[0x7]; // 0x2b1(0x07)
	struct TSet<int32_t> PossibleRoutes; // 0x2b8(0x50)
	int32_t Tier; // 0x308(0x04)
	char pad_30C[0x4]; // 0x30c(0x04)
	struct TArray<struct FTransform> SpawnPointTransforms; // 0x310(0x10)
	enum class EHDTeam OwningTeam; // 0x320(0x01)
	enum class EHDTeam PrevNonNeutralOwningTeam; // 0x321(0x01)
	char pad_322[0x6]; // 0x322(0x06)
	struct FMulticastInlineDelegate OnOwningTeamUpdate; // 0x328(0x10)
	char bCapturableByTeamRed : 1; // 0x338(0x01)
	char bCapturableByTeamBlue : 1; // 0x338(0x01)
	char pad_338_2 : 6; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)
	struct FMulticastInlineDelegate OnTeamCaptureStatusUpdate; // 0x340(0x10)

	void Unlock(); // Function HDMain.HDBaseCapturePoint.Unlock // (Native|Public|BlueprintCallable) // @ game+0x6cfbf0
	void SetActiveRoute(int32_t NewActiveRoute); // Function HDMain.HDBaseCapturePoint.SetActiveRoute // (Native|Public|BlueprintCallable) // @ game+0x799ed0
	void SetActive(bool bNewActive); // Function HDMain.HDBaseCapturePoint.SetActive // (Native|Public|BlueprintCallable) // @ game+0x799e40
	void ReceiveOnTeamCaptureStatusUpdated(); // Function HDMain.HDBaseCapturePoint.ReceiveOnTeamCaptureStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnOwningTeamUpdated(enum class EHDTeam LastOwningTeam); // Function HDMain.HDBaseCapturePoint.ReceiveOnOwningTeamUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnLocked(bool bNewLocked); // Function HDMain.HDBaseCapturePoint.ReceiveOnLocked // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnCaptureProgress(bool bNewContested); // Function HDMain.HDBaseCapturePoint.ReceiveOnCaptureProgress // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnActive(bool bNewActive); // Function HDMain.HDBaseCapturePoint.ReceiveOnActive // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnRep_OwningTeam(enum class EHDTeam LastOwningTeam); // Function HDMain.HDBaseCapturePoint.OnRep_OwningTeam // (Final|Native|Protected) // @ game+0x799d20
	void OnRep_Locked(); // Function HDMain.HDBaseCapturePoint.OnRep_Locked // (Final|Native|Protected) // @ game+0x799d00
	void OnRep_Contested(); // Function HDMain.HDBaseCapturePoint.OnRep_Contested // (Final|Native|Protected) // @ game+0x799ce0
	void OnRep_CaptureProgress(); // Function HDMain.HDBaseCapturePoint.OnRep_CaptureProgress // (Final|Native|Protected) // @ game+0x799ce0
	void OnRep_CapturableByTeam(); // Function HDMain.HDBaseCapturePoint.OnRep_CapturableByTeam // (Final|Native|Protected) // @ game+0x799cc0
	void OnRep_Active(); // Function HDMain.HDBaseCapturePoint.OnRep_Active // (Final|Native|Protected) // @ game+0x799ca0
	void OnOwningTeamUpdated(enum class EHDTeam LastOwningTeam); // Function HDMain.HDBaseCapturePoint.OnOwningTeamUpdated // (Native|Protected|BlueprintCallable) // @ game+0x799c20
	void OnEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function HDMain.HDBaseCapturePoint.OnEndOverlap // (Native|Protected) // @ game+0x799ae0
	void OnBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function HDMain.HDBaseCapturePoint.OnBeginOverlap // (Native|Protected|HasOutParms) // @ game+0x7998e0
	void Lock(); // Function HDMain.HDBaseCapturePoint.Lock // (Native|Public|BlueprintCallable) // @ game+0x6cfaa0
	bool IsCapturableByTeam(enum class EHDTeam CaptureTeam); // Function HDMain.HDBaseCapturePoint.IsCapturableByTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7996f0
	void GetOverlappingCharactersByTeam(struct TArray<struct ADFBaseCharacter*>& OverlappingCharsRed, struct TArray<struct ADFBaseCharacter*>& OverlappingCharsBlue); // Function HDMain.HDBaseCapturePoint.GetOverlappingCharactersByTeam // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7995d0
	enum class EHDControlPointObjectiveType GetObjectiveTypeForTeam(enum class EHDTeam ObjTeam); // Function HDMain.HDBaseCapturePoint.GetObjectiveTypeForTeam // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x799540
	int32_t GetMinPlayersRequiredForCaptureTeam(enum class EHDTeam CaptureTeam); // Function HDMain.HDBaseCapturePoint.GetMinPlayersRequiredForCaptureTeam // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7994b0
	struct AActor* ChoosePlayerStart(struct AHDPlayerController* Player); // Function HDMain.HDBaseCapturePoint.ChoosePlayerStart // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x7991a0
	bool CanRestartPlayer(struct AController* Player); // Function HDMain.HDBaseCapturePoint.CanRestartPlayer // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7990d0
	bool CanCapture(); // Function HDMain.HDBaseCapturePoint.CanCapture // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7990a0
};

// Class HDMain.HDBaseGameMode
// Size: 0x488 (Inherited: 0x3f8)
struct AHDBaseGameMode : ADFBaseGameMode {
	struct UHDScoreboardBase* ScoreboardMenuClass; // 0x3f8(0x08)
	struct FHDGameRoundEndEventDetails RoundEndEventDetails; // 0x400(0x10)
	char bDisablePlayerSpawnKitRestrictions : 1; // 0x410(0x01)
	char bUseTickets : 1; // 0x410(0x01)
	char pad_410_2 : 6; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
	struct UHDTeamDefinition* DefaultBluforTeamDefinition; // 0x418(0x08)
	struct UHDTeamDefinition* DefaultOpforTeamDefinition; // 0x420(0x08)
	struct UHDTeamDefinition* BluforTeamDefinition; // 0x428(0x08)
	struct UHDTeamDefinition* OpforTeamDefinition; // 0x430(0x08)
	char bRandomPlayerTeamBalance : 1; // 0x438(0x01)
	char pad_438_1 : 7; // 0x438(0x01)
	char pad_439[0x37]; // 0x439(0x37)
	struct TArray<struct UHDPlatoonInfo*> PlatoonInfos; // 0x470(0x10)
	struct AHDPlatoonState* PlatoonStateClass; // 0x480(0x08)

	void RemoveOpforBots(int32_t Num); // Function HDMain.HDBaseGameMode.RemoveOpforBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x79e610
	void RemoveBluforBots(int32_t Num); // Function HDMain.HDBaseGameMode.RemoveBluforBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x79e580
	bool PlayerCanRestartAtPlayerStart(struct AController* Player, struct AActor* StartSpot, struct UDFLoadout* StartLoadout); // Function HDMain.HDBaseGameMode.PlayerCanRestartAtPlayerStart // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x79e470
	void AddOpforBots(int32_t Num); // Function HDMain.HDBaseGameMode.AddOpforBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x79da40
	void AddBluforBots(int32_t Num); // Function HDMain.HDBaseGameMode.AddBluforBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x79d9b0
};

// Class HDMain.HDBasePickup_Kit
// Size: 0x278 (Inherited: 0x258)
struct AHDBasePickup_Kit : ADFBasePickup {
	struct UDFInventoryComponent* Inventory; // 0x258(0x08)
	struct TArray<struct UPrimitiveComponent*> KitVisuals; // 0x260(0x10)
	struct UHDKit* KitLoadout; // 0x270(0x08)
};

// Class HDMain.HDBaseProjectile
// Size: 0x380 (Inherited: 0x380)
struct AHDBaseProjectile : ADFBaseProjectile {
};

// Class HDMain.HDBaseWeapon
// Size: 0x870 (Inherited: 0x858)
struct AHDBaseWeapon : ADFBaseGun_Projectile {
	struct UTexture2D* DisplayIcon; // 0x858(0x08)
	struct UTexture2D* DisplayEquipmentSymbol; // 0x860(0x08)
	char bUseFreeAim : 1; // 0x868(0x01)
	char bSelectable : 1; // 0x868(0x01)
	char bHideFireModeIndicator : 1; // 0x868(0x01)
	char pad_868_3 : 5; // 0x868(0x01)
	char pad_869[0x3]; // 0x869(0x03)
	float AmmoReplenishmentDelay; // 0x86c(0x04)

	bool IsSelectableEquipment(); // Function HDMain.HDBaseWeapon.IsSelectableEquipment // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e190
};

// Class HDMain.HDPlayerController
// Size: 0x6a0 (Inherited: 0x5f8)
struct AHDPlayerController : ADFBasePlayerController {
	struct AHDPlayerCharacter* HDCharacter; // 0x5f8(0x08)
	struct UHDPlayerComponent* PlayerComponent; // 0x600(0x08)
	struct TMap<struct FName, struct FPTTKeyState> PushToTalkKeyStates; // 0x608(0x50)
	char pad_658[0x4]; // 0x658(0x04)
	struct FName TextCommsFormatName; // 0x65c(0x08)
	struct FName TeamLocalVoipCommChannelGroupName; // 0x664(0x08)
	struct FName SquadVoipCommChannelGroupName; // 0x66c(0x08)
	struct FName CommandVoipCommChannelGroupName; // 0x674(0x08)
	char pad_67C[0x4]; // 0x67c(0x04)
	struct UDFPlayerCommsComponent* CachedPlayerCommsComp; // 0x680(0x08)
	struct UVictoryMenu* VictoryMenuClass; // 0x688(0x08)
	struct UVictoryMenu* VictoryMenu; // 0x690(0x08)
	char pad_698[0x8]; // 0x698(0x08)

	void UnloadVictoryMenu(); // Function HDMain.HDPlayerController.UnloadVictoryMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x7a7c00
	void TeamTalk(); // Function HDMain.HDPlayerController.TeamTalk // (Native|Public|BlueprintCallable) // @ game+0x7a7be0
	void Talk(); // Function HDMain.HDPlayerController.Talk // (Native|Public|BlueprintCallable) // @ game+0x7a7bc0
	void StopTalkingOverChannelIfActive(struct FName TalkStopChannelName); // Function HDMain.HDPlayerController.StopTalkingOverChannelIfActive // (Native|Protected|BlueprintCallable) // @ game+0x7a7b10
	void StopTalkingOverChannelGroupIfActive(struct FName TalkStopGroupName); // Function HDMain.HDPlayerController.StopTalkingOverChannelGroupIfActive // (Native|Protected|BlueprintCallable) // @ game+0x7a7a80
	void StopTalkingOnActiveChannels(); // Function HDMain.HDPlayerController.StopTalkingOnActiveChannels // (Native|Protected|BlueprintCallable) // @ game+0x7a7a60
	void StartTalkingOverChannelGroup(struct FName TalkStartGroupName); // Function HDMain.HDPlayerController.StartTalkingOverChannelGroup // (Native|Protected|BlueprintCallable) // @ game+0x7a79d0
	void StartTalkingOverChannel(struct FName TalkStartChannelName); // Function HDMain.HDPlayerController.StartTalkingOverChannel // (Native|Protected|BlueprintCallable) // @ game+0x7a7940
	void ServerSwitchTeam(); // Function HDMain.HDPlayerController.ServerSwitchTeam // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x7a78f0
	void ServerSpawnVehicle(); // Function HDMain.HDPlayerController.ServerSpawnVehicle // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x7a78a0
	void ServerRestartPlayerAtStartSpot(struct AActor* DesiredStartSpot, struct UDFLoadout* DesiredStartLoadout); // Function HDMain.HDPlayerController.ServerRestartPlayerAtStartSpot // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x7a77a0
	void ServerPickTeam(enum class EHDTeam DesiredTeam); // Function HDMain.HDPlayerController.ServerPickTeam // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x7a76f0
	void ServerCheatSetAllowIdleSway(bool bIdleSwayDisallowed); // Function HDMain.HDPlayerController.ServerCheatSetAllowIdleSway // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x7a7630
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function HDMain.HDPlayerController.ReceiveVoipTalkerMsgReceived // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnShowScoreboardReleased(); // Function HDMain.HDPlayerController.OnShowScoreboardReleased // (Native|Protected|BlueprintCallable) // @ game+0x7a73f0
	void OnShowScoreboardPressed(); // Function HDMain.HDPlayerController.OnShowScoreboardPressed // (Native|Protected|BlueprintCallable) // @ game+0x7a73d0
	void OnPlayerSpawnTimerElapsed(); // Function HDMain.HDPlayerController.OnPlayerSpawnTimerElapsed // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnPauseMenu(); // Function HDMain.HDPlayerController.OnPauseMenu // (Native|Protected|BlueprintCallable) // @ game+0x7a7250
	void LoadVictoryMenu(struct FHDGameRoundEndEventDetails& RoundDetails, bool bWinner); // Function HDMain.HDPlayerController.LoadVictoryMenu // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7a7160
	bool IsTalkingOverChannelName(struct FName TalkChannelName); // Function HDMain.HDPlayerController.IsTalkingOverChannelName // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a70d0
	bool IsTalkingOverChannelGroup(struct FName TalkGroupName); // Function HDMain.HDPlayerController.IsTalkingOverChannelGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a7040
	bool IsTalkingOverChannel(struct UDFCommChannel* TalkChannel); // Function HDMain.HDPlayerController.IsTalkingOverChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a6fb0
	bool IsTalking(bool bIncludeWantsToTalk); // Function HDMain.HDPlayerController.IsTalking // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6f20
	bool IsInVehicle(); // Function HDMain.HDPlayerController.IsInVehicle // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6ef0
	bool IsIdleSwayAllowed(); // Function HDMain.HDPlayerController.IsIdleSwayAllowed // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6ec0
	struct UDFCommChannel* GetTalkChannel(); // Function HDMain.HDPlayerController.GetTalkChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a6df0
	struct UDFPlayerCommsComponent* GetPlayerCommsComponent(); // Function HDMain.HDPlayerController.GetPlayerCommsComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a6dc0
	void ClientRoundEnd(struct FHDGameRoundEndEventDetails RoundDetails, bool bIsWinner); // Function HDMain.HDPlayerController.ClientRoundEnd // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7a6950
	void ClientLoadTeamData(struct TArray<struct FString> FactionAssetPaths); // Function HDMain.HDPlayerController.ClientLoadTeamData // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7a6890
	void ClientCheatSetAllowIdleSway(bool bIdleSwayDisallowed); // Function HDMain.HDPlayerController.ClientCheatSetAllowIdleSway // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x7a6800
	bool CanTalkOverChannel(struct FName TalkChannelName); // Function HDMain.HDPlayerController.CanTalkOverChannel // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a6760
	void Auth_SpawnVehicle(); // Function HDMain.HDPlayerController.Auth_SpawnVehicle // (Native|Event|Public|BlueprintEvent) // @ game+0x7a6740
};

// Class HDMain.HDCheatManager
// Size: 0x80 (Inherited: 0x78)
struct UHDCheatManager : UDFCheatManager {
	char pad_78[0x8]; // 0x78(0x08)

	void ToggleIdleSway(); // Function HDMain.HDCheatManager.ToggleIdleSway // (Final|Exec|Native|Public) // @ game+0x79f080
	void ToggleFreeAimADS(); // Function HDMain.HDCheatManager.ToggleFreeAimADS // (Final|Exec|Native|Private) // @ game+0x79f060
	void ToggleFreeAim(); // Function HDMain.HDCheatManager.ToggleFreeAim // (Final|Exec|Native|Private) // @ game+0x79f040
	void SpawnVehicle(); // Function HDMain.HDCheatManager.SpawnVehicle // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x6c7310
	void SetMaxFreeAimYawADS(float NewYaw); // Function HDMain.HDCheatManager.SetMaxFreeAimYawADS // (Final|Exec|Native|Private) // @ game+0x79ed80
	void SetMaxFreeAimYaw(float NewYaw); // Function HDMain.HDCheatManager.SetMaxFreeAimYaw // (Final|Exec|Native|Private) // @ game+0x79ed00
	void SetMaxFreeAimPitchADS(float NewPitch); // Function HDMain.HDCheatManager.SetMaxFreeAimPitchADS // (Final|Exec|Native|Private) // @ game+0x79ec80
	void SetMaxFreeAimPitch(float NewPitch); // Function HDMain.HDCheatManager.SetMaxFreeAimPitch // (Final|Exec|Native|Private) // @ game+0x79ec00
	void SetFreeAimReturnToCenterInterpSpeed(float NewInterpSpeed); // Function HDMain.HDCheatManager.SetFreeAimReturnToCenterInterpSpeed // (Final|Exec|Native|Private) // @ game+0x79e8e0
	void SetFreeAimDeadzoneCameraSpeedFactor(float NewSpeedFactor); // Function HDMain.HDCheatManager.SetFreeAimDeadzoneCameraSpeedFactor // (Final|Exec|Native|Private) // @ game+0x79e860
};

// Class HDMain.HDFactionInfo
// Size: 0xe0 (Inherited: 0x90)
struct UHDFactionInfo : UDFFactionInfo {
	struct TSet<struct TSoftObjectPtr<UHDKit>> Kits; // 0x90(0x50)
};

// Class HDMain.HDGame_AdvanceAndSecure
// Size: 0x4c0 (Inherited: 0x488)
struct AHDGame_AdvanceAndSecure : AHDBaseGameMode {
	int32_t StartingBlueTier; // 0x488(0x04)
	int32_t StartingRedTier; // 0x48c(0x04)
	int32_t ActiveRoute; // 0x490(0x04)
	int32_t CurrentBlueCaptureTier; // 0x494(0x04)
	int32_t CurrentRedCaptureTier; // 0x498(0x04)
	char bBlueIncreasesTier : 1; // 0x49c(0x01)
	char pad_49C_1 : 7; // 0x49c(0x01)
	char pad_49D[0x23]; // 0x49d(0x23)

	int32_t GetCurrentRedCaptureTier(); // Function HDMain.HDGame_AdvanceAndSecure.GetCurrentRedCaptureTier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dc30
	int32_t GetCurrentBlueCaptureTier(); // Function HDMain.HDGame_AdvanceAndSecure.GetCurrentBlueCaptureTier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dc10
};

// Class HDMain.HDGame_TeamDeathMatch
// Size: 0x488 (Inherited: 0x488)
struct AHDGame_TeamDeathMatch : AHDBaseGameMode {
};

// Class HDMain.HDGameEngine
// Size: 0xe30 (Inherited: 0xe30)
struct UHDGameEngine : UDFGameEngine {
};

// Class HDMain.HDGameInstance
// Size: 0x2a8 (Inherited: 0x2a0)
struct UHDGameInstance : UTBGameInstance {
	struct UHDScoreboardBase* ScoreboardMenu; // 0x2a0(0x08)

	void UnloadScoreboardMenu(); // Function HDMain.HDGameInstance.UnloadScoreboardMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x79f0a0
	bool OwnsAppBP(int64_t AppID); // Function HDMain.HDGameInstance.OwnsAppBP // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x79e3f0
	void LoadScoreboardMenu(); // Function HDMain.HDGameInstance.LoadScoreboardMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x79e310
	bool HasModsLoaded(); // Function HDMain.HDGameInstance.HasModsLoaded // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x79e010
	bool HasDLCBP(int64_t DLCAppID); // Function HDMain.HDGameInstance.HasDLCBP // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x79df90
};

// Class HDMain.HDGameModeDefinition
// Size: 0x110 (Inherited: 0xe8)
struct UHDGameModeDefinition : UDFGameModeDefinition {
	struct TSoftClassPtr<UObject> GameModeClass; // 0xe8(0x28)
};

// Class HDMain.HDGameModsProjectPolicies
// Size: 0x28 (Inherited: 0x28)
struct UHDGameModsProjectPolicies : UHDCoreDefaultUGCProjectPolicies {
};

// Class HDMain.HDGameProjectBuildSettings
// Size: 0x28 (Inherited: 0x28)
struct UHDGameProjectBuildSettings : UBlueprintFunctionLibrary {

	bool IsDemoBuild(); // Function HDMain.HDGameProjectBuildSettings.IsDemoBuild // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x79e0a0
};

// Class HDMain.HDGameRulesetBase
// Size: 0x60 (Inherited: 0x58)
struct UHDGameRulesetBase : UDFGameRulesetBase {
	char bUseTickets : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)

	void RevokeTicketsFromTeam(enum class EHDTeam TicketTeam, int32_t TicketsToRemove); // Function HDMain.HDGameRulesetBase.RevokeTicketsFromTeam // (Final|Native|Protected|BlueprintCallable) // @ game+0x79e7a0
	void GiveTicketsToTeam(enum class EHDTeam TicketTeam, int32_t TicketsToAdd); // Function HDMain.HDGameRulesetBase.GiveTicketsToTeam // (Final|Native|Protected|BlueprintCallable) // @ game+0x79ded0
	struct AHDGameState* GetHDGameState(); // Function HDMain.HDGameRulesetBase.GetHDGameState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dd40
	struct AHDBaseGameMode* GetHDGameMode(); // Function HDMain.HDGameRulesetBase.GetHDGameMode // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dd10
};

// Class HDMain.HDGameSession
// Size: 0x278 (Inherited: 0x270)
struct AHDGameSession : ADFGameSession {
	bool bSupportersOnlyWhitelist; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
};

// Class HDMain.HDGameState
// Size: 0x320 (Inherited: 0x300)
struct AHDGameState : ADFBaseGameState {
	float ReplicatedMinRespawnDelay; // 0x300(0x04)
	char bReplicatedDisableSpawnKitRestrictions : 1; // 0x304(0x01)
	char pad_304_1 : 7; // 0x304(0x01)
	char pad_305[0x3]; // 0x305(0x03)
	int32_t BluforTickets; // 0x308(0x04)
	int32_t OpforTickets; // 0x30c(0x04)
	struct AHDTeamState* BluforTeamState; // 0x310(0x08)
	struct AHDTeamState* OpforTeamState; // 0x318(0x08)

	void RevokeTicketsFromTeam(enum class EHDTeam TicketTeam, int32_t TicketsToRemove); // Function HDMain.HDGameState.RevokeTicketsFromTeam // (Native|Public|BlueprintCallable) // @ game+0x79e6d0
	bool IsGameUsingTickets(); // Function HDMain.HDGameState.IsGameUsingTickets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e160
	bool IsGameUsingPlayerSpawnKitRestrictions(struct AController* Controller); // Function HDMain.HDGameState.IsGameUsingPlayerSpawnKitRestrictions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e0d0
	void GiveTicketsToTeam(enum class EHDTeam TicketTeam, int32_t TicketsToAdd); // Function HDMain.HDGameState.GiveTicketsToTeam // (Native|Public|BlueprintCallable) // @ game+0x79de00
	int32_t GetNumPlayersOnTeam(enum class EHDTeam TeamToCheck); // Function HDMain.HDGameState.GetNumPlayersOnTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dd70
	void ClearTickets(); // Function HDMain.HDGameState.ClearTickets // (Native|Public|BlueprintCallable) // @ game+0x79dad0
};

// Class HDMain.HDGOAPActionBase
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPActionBase : UGOAPAction {
};

// Class HDMain.HDGOAPAct_AttackEnemy
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_AttackEnemy : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_CaptureControlPoint
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_CaptureControlPoint : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_DefendControlPoint
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_DefendControlPoint : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_LoadWeapon
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_LoadWeapon : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_MoveToDesiredLocation
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_MoveToDesiredLocation : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_MoveToLocation
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_MoveToLocation : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPAct_MoveToOrganic
// Size: 0x98 (Inherited: 0x98)
struct UHDGOAPAct_MoveToOrganic : UHDGOAPActionBase {
};

// Class HDMain.HDGOAPComponent
// Size: 0x1d8 (Inherited: 0x168)
struct UHDGOAPComponent : UGOAPComponent {
	struct AHDAIController* HDAIOwner; // 0x168(0x08)
	struct AHDPlayerCharacter* HDAICharOwner; // 0x170(0x08)
	struct TArray<struct UHDAIHandlerBase*> AIHandlers; // 0x178(0x10)
	struct UHDAINavigationHandler* NavigationHandler; // 0x188(0x08)
	struct UHDAICaptureHandler* CaptureHandler; // 0x190(0x08)
	struct UHDAICombatHandler* CombatHandler; // 0x198(0x08)
	struct UHDAIBehaviorHandler* BehaviorHandler; // 0x1a0(0x08)
	struct UHDAIGroupBehaviorHandler* GroupBehaviorHandler; // 0x1a8(0x08)
	struct UHDAIAimingHandler* AimingHandler; // 0x1b0(0x08)
	struct UHDAIVocalHandler* VocalHandler; // 0x1b8(0x08)
	char pad_1C0[0x10]; // 0x1c0(0x10)
	float DecisionFrequency; // 0x1d0(0x04)
	char pad_1D4[0x4]; // 0x1d4(0x04)

	void TargetPerceptionUpdated(struct AActor* Actor, struct FAIStimulus Stimulus); // Function HDMain.HDGOAPComponent.TargetPerceptionUpdated // (Native|Protected) // @ game+0x79eec0
	void ResetPlanningTimer(); // Function HDMain.HDGOAPComponent.ResetPlanningTimer // (Final|Native|Public|BlueprintCallable) // @ game+0x79e6a0
	bool IsAIActiveInWorld(); // Function HDMain.HDGOAPComponent.IsAIActiveInWorld // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e070
	bool IsAIActive(); // Function HDMain.HDGOAPComponent.IsAIActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e040
	struct UHDAIHandlerBase* GetAIHandler(struct UHDAIHandlerBase* HandlerClass); // Function HDMain.HDGOAPComponent.GetAIHandler // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79db80
};

// Class HDMain.HDGOAPGoalBase
// Size: 0x68 (Inherited: 0x68)
struct UHDGOAPGoalBase : UGOAPGoal {
};

// Class HDMain.HDGOAPGoal_CaptureControlPoint
// Size: 0x78 (Inherited: 0x68)
struct UHDGOAPGoal_CaptureControlPoint : UHDGOAPGoalBase {
	struct AHDBaseCapturePoint* CPToCaptureCurrent; // 0x68(0x08)
	struct AHDBaseCapturePoint* CPToCapturePending; // 0x70(0x08)
};

// Class HDMain.HDGOAPGoal_EliminateEnemy
// Size: 0x68 (Inherited: 0x68)
struct UHDGOAPGoal_EliminateEnemy : UHDGOAPGoalBase {
};

// Class HDMain.HDHUD
// Size: 0x310 (Inherited: 0x310)
struct AHDHUD : AHUD {
};

// Class HDMain.HDServerListView
// Size: 0x3c0 (Inherited: 0x368)
struct UHDServerListView : UListView {
	char pad_368[0x4]; // 0x368(0x04)
	bool bItemSortAscending; // 0x36c(0x01)
	enum class EHDServerListSortBy ItemSortBy; // 0x36d(0x01)
	char pad_36E[0x2]; // 0x36e(0x02)
	struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams> ItemFilterRules; // 0x370(0x50)

	void SortListItems(bool bSortAscending, enum class EHDServerListSortBy SortBy); // Function HDMain.HDServerListView.SortListItems // (Final|Native|Public|BlueprintCallable) // @ game+0x79ee00
	void SetItemSortBy(enum class EHDServerListSortBy SortBy); // Function HDMain.HDServerListView.SetItemSortBy // (Final|Native|Public|BlueprintCallable) // @ game+0x79eb80
	void SetItemSortAscending(bool bSortAscending); // Function HDMain.HDServerListView.SetItemSortAscending // (Final|Native|Public|BlueprintCallable) // @ game+0x79eaf0
	void SetItemFilterRules(struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function HDMain.HDServerListView.SetItemFilterRules // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x79e960
	float GetEntrySpacing(); // Function HDMain.HDServerListView.GetEntrySpacing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dcf0
	struct FMargin GetDesiredEntryPaddingForItem(struct UObject* Item); // Function HDMain.HDServerListView.GetDesiredEntryPaddingForItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79dc50
	bool DoesFilterExcludeListItem(struct UObject* Item); // Function HDMain.HDServerListView.DoesFilterExcludeListItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79daf0
};

// Class HDMain.HDJoinGameMenu
// Size: 0x280 (Inherited: 0x238)
struct UHDJoinGameMenu : UDFBaseMenu {
	struct UHDServerListView* ServerList; // 0x238(0x08)
	struct TArray<struct FPrimaryAssetId> MapIds; // 0x240(0x10)
	char pad_250[0x30]; // 0x250(0x30)

	void ReceiveOnRefreshStart(); // Function HDMain.HDJoinGameMenu.ReceiveOnRefreshStart // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRefreshComplete(bool bSortAscending, enum class EHDServerListSortBy SortBy); // Function HDMain.HDJoinGameMenu.ReceiveOnRefreshComplete // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnRefresh(bool bSortAscending, enum class EHDServerListSortBy SortBy); // Function HDMain.HDJoinGameMenu.OnRefresh // (Final|Native|Private|BlueprintCallable) // @ game+0x79e330
	void JoinGame(struct UHDServerListItemData* ServerItem, struct FString JoinPassword); // Function HDMain.HDJoinGameMenu.JoinGame // (Final|Native|Public|BlueprintCallable) // @ game+0x79e230
	bool IsUsingDebugServerListings(); // Function HDMain.HDJoinGameMenu.IsUsingDebugServerListings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x79e1c0
};

// Class HDMain.HDKit
// Size: 0xb8 (Inherited: 0x40)
struct UHDKit : UDFLoadout {
	struct TArray<struct FHDItemEntry> ItemEntries; // 0x40(0x10)
	int32_t PrimaryItemSlotNum; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct AHDBasePickup_Kit* KitDropPrefabClass; // 0x58(0x08)
	struct TArray<struct UHDKitPrerequisiteBase*> KitRequirements; // 0x60(0x10)
	struct TArray<struct FDataTableRowHandle> CharacterVariations; // 0x70(0x10)
	char bSquadLeaderKit : 1; // 0x80(0x01)
	char bAllowsRallyPointDeployment : 1; // 0x80(0x01)
	char pad_80_2 : 6; // 0x80(0x01)
	char pad_81[0x17]; // 0x81(0x17)
	struct FText KitDisplayName; // 0x98(0x18)
	struct UTexture2D* KitDisplaySymbol; // 0xb0(0x08)

	struct FDFCharacterVariationDataHandle RandomCharacterVariationDataFromKit(); // Function HDMain.HDKit.RandomCharacterVariationDataFromKit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2f30
	bool PlayerCanStartWithKit(struct AController* Player, struct FText& OutKitDenialReason); // Function HDMain.HDKit.PlayerCanStartWithKit // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2e10
	bool HasKitRequirements(); // Function HDMain.HDKit.HasKitRequirements // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2a50
	bool GetPrimaryItemEntryDisplayIcon(struct UTexture2D*& OutDisplayIcon); // Function HDMain.HDKit.GetPrimaryItemEntryDisplayIcon // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a28f0
	bool GetPrimaryItemEntry(struct FHDItemEntry& OutPrimaryEntry); // Function HDMain.HDKit.GetPrimaryItemEntry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2840
	int32_t GetPlayersUsingKit(struct UObject* WorldContextObject, struct TArray<struct AHDPlayerState*>& OutPSArray); // Function HDMain.HDKit.GetPlayersUsingKit // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2740
	int32_t GetNumPlayersUsingKit(struct UObject* WorldContextObject); // Function HDMain.HDKit.GetNumPlayersUsingKit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a25e0
	bool GetItemEntryDisplayIcon(struct FHDItemEntry& ItemEntry, struct UTexture2D*& OutDisplayIcon); // Function HDMain.HDKit.GetItemEntryDisplayIcon // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7a2410
	bool GetItemEntryDisplayEquipmentSymbol(struct FHDItemEntry& ItemEntry, struct UTexture2D*& OutDisplayEquipmentSymbol); // Function HDMain.HDKit.GetItemEntryDisplayEquipmentSymbol // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7a2320
	bool GetItemEntryBySlotNum(int32_t SlotNum, struct FHDItemEntry& OutEntry); // Function HDMain.HDKit.GetItemEntryBySlotNum // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2240
};

// Class HDMain.HDKitPrerequisiteBase
// Size: 0x40 (Inherited: 0x28)
struct UHDKitPrerequisiteBase : UObject {
	struct FText KitDenialReason; // 0x28(0x18)
};

// Class HDMain.HDKitPrerequisite_AdminOnly
// Size: 0x40 (Inherited: 0x40)
struct UHDKitPrerequisite_AdminOnly : UHDKitPrerequisiteBase {
};

// Class HDMain.HDKitPrerequisite_AlwaysDisable
// Size: 0x40 (Inherited: 0x40)
struct UHDKitPrerequisite_AlwaysDisable : UHDKitPrerequisiteBase {
};

// Class HDMain.HDKitPrerequisite_MinSquadMembers
// Size: 0x48 (Inherited: 0x40)
struct UHDKitPrerequisite_MinSquadMembers : UHDKitPrerequisiteBase {
	int32_t MinSquadMembers; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class HDMain.HDKitPrerequisite_SquadLeaderOnly
// Size: 0x40 (Inherited: 0x40)
struct UHDKitPrerequisite_SquadLeaderOnly : UHDKitPrerequisiteBase {
};

// Class HDMain.HDKitPrerequisite_SquadSizeLimit
// Size: 0x48 (Inherited: 0x40)
struct UHDKitPrerequisite_SquadSizeLimit : UHDKitPrerequisiteBase {
	int32_t MaxSquadCount; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class HDMain.HDKitPrerequisite_SquadUsageLimit
// Size: 0x48 (Inherited: 0x40)
struct UHDKitPrerequisite_SquadUsageLimit : UHDKitPrerequisiteBase {
	int32_t MaxSquadMembers; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class HDMain.HDKitPrerequisite_TeamSpecific
// Size: 0x48 (Inherited: 0x40)
struct UHDKitPrerequisite_TeamSpecific : UHDKitPrerequisiteBase {
	enum class EHDTeam RequiredTeam; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class HDMain.HDKitPrerequisite_TeamUsageLimit
// Size: 0x48 (Inherited: 0x40)
struct UHDKitPrerequisite_TeamUsageLimit : UHDKitPrerequisiteBase {
	int32_t MaxTeamMembers; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class HDMain.HDModData
// Size: 0x48 (Inherited: 0x30)
struct UHDModData : UHDCoreUGCData {
	struct TArray<struct FHDPrimaryAssetSearchPath> PrimaryAssetPathsToScan; // 0x30(0x10)
	uint32_t ModDataVersion; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)

	bool DoesModPluginUseLegacyMapScanning(struct FString PluginName); // Function HDMain.HDModData.DoesModPluginUseLegacyMapScanning // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a1f80
};

// Class HDMain.HDNavigationSystem
// Size: 0x538 (Inherited: 0x538)
struct UHDNavigationSystem : UDFNavigationSystem {
};

// Class HDMain.HDNavigationSystemConfig
// Size: 0x60 (Inherited: 0x60)
struct UHDNavigationSystemConfig : UDFNavigationSystemConfig {
};

// Class HDMain.HDOnlineSessionClient
// Size: 0x190 (Inherited: 0x190)
struct UHDOnlineSessionClient : UDFOnlineSessionClient {
};

// Class HDMain.HDOptionsMenu
// Size: 0x238 (Inherited: 0x238)
struct UHDOptionsMenu : UDFBaseMenu {
};

// Class HDMain.HDPhysicsCollisionHandler
// Size: 0x40 (Inherited: 0x40)
struct UHDPhysicsCollisionHandler : UDFPhysicsCollisionHandler {
};

// Class HDMain.HDPlatoonCreationRuleBase
// Size: 0x28 (Inherited: 0x28)
struct UHDPlatoonCreationRuleBase : UObject {

	bool SatisfiesRule(struct UHDTeamDefinition* TeamDef); // Function HDMain.HDPlatoonCreationRuleBase.SatisfiesRule // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x7a3100
};

// Class HDMain.HDPlatoonInfo
// Size: 0x68 (Inherited: 0x30)
struct UHDPlatoonInfo : UPrimaryDataAsset {
	struct FPrimaryAssetType PlatoonType; // 0x30(0x08)
	struct TArray<struct UHDPlatoonCreationRuleBase*> CreationRules; // 0x38(0x10)
	struct FText DisplayName; // 0x48(0x18)
	int32_t MaxSquadLimit; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)

	bool ShouldCreateForTeam(struct UHDTeamDefinition* TeamDef); // Function HDMain.HDPlatoonInfo.ShouldCreateForTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a3780
};

// Class HDMain.HDPlatoonStateCreationPayload
// Size: 0x38 (Inherited: 0x28)
struct UHDPlatoonStateCreationPayload : UObject {
	struct FHDPlatoonCreationParams CreationParams; // 0x28(0x10)
};

// Class HDMain.HDPlatoonState
// Size: 0x3f0 (Inherited: 0x220)
struct AHDPlatoonState : ADFReplInfo {
	char pad_220[0x8]; // 0x220(0x08)
	struct FMulticastInlineDelegate OnSquadAdded; // 0x228(0x10)
	struct FMulticastInlineDelegate OnSquadPreRemove; // 0x238(0x10)
	struct AHDSquadState* SquadStateClass; // 0x248(0x08)
	struct FDFGenericObjectContainer Squads; // 0x250(0x180)
	char bInitialized : 1; // 0x3d0(0x01)
	char pad_3D0_1 : 7; // 0x3d0(0x01)
	char pad_3D1[0x3]; // 0x3d1(0x03)
	int32_t ID; // 0x3d4(0x04)
	struct UHDPlatoonInfo* Info; // 0x3d8(0x08)
	char TeamId; // 0x3e0(0x01)
	char pad_3E1[0x7]; // 0x3e1(0x07)
	struct AHDTeamState* OwnerTeam; // 0x3e8(0x08)

	bool SquadExists(struct AHDSquadState* Squad, bool bIgnorePendingRemoval); // Function HDMain.HDPlatoonState.SquadExists // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a3810
	void RemoveSquadAt(int32_t RemoveIdx); // Function HDMain.HDPlatoonState.RemoveSquadAt // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a3080
	void RemoveSquad(struct AHDSquadState* SquadToRemove); // Function HDMain.HDPlatoonState.RemoveSquad // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a3000
	void RemoveFromOwner(); // Function HDMain.HDPlatoonState.RemoveFromOwner // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6cf9f0
	void ReceiveSquadPreRemove(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.ReceiveSquadPreRemove // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadAdded(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.ReceiveSquadAdded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsSquadPendingRemovalFromPlatoon(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.IsSquadPendingRemovalFromPlatoon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2af0
	bool HasReachedMaxSquadLimit(); // Function HDMain.HDPlatoonState.HasReachedMaxSquadLimit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2a70
	struct AHDSquadState* GetSquadAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDPlatoonState.GetSquadAt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2990
	int32_t GetNumSquads(bool bValidSquadsOnly); // Function HDMain.HDPlatoonState.GetNumSquads // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2670
	int32_t GetMaxSquadLimit(); // Function HDMain.HDPlatoonState.GetMaxSquadLimit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a25b0
	bool FindSquadByName(struct FText& SquadDisplayName, struct AHDSquadState*& OutFoundSquad); // Function HDMain.HDPlatoonState.FindSquadByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7a2090
	void DumpSquadState(); // Function HDMain.HDPlatoonState.DumpSquadState // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x7a2040
	struct AHDSquadState* AddSquad(struct FText& SquadDisplayName, struct AHDPlayerState* SquadLeader, bool bStartLocked); // Function HDMain.HDPlatoonState.AddSquad // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7a1e20
};

// Class HDMain.HDPlayerCameraManager
// Size: 0x2740 (Inherited: 0x2740)
struct AHDPlayerCameraManager : ADFPlayerCameraManager {
};

// Class HDMain.HDPlayerCharacter
// Size: 0xa40 (Inherited: 0x970)
struct AHDPlayerCharacter : ADFBasePlayerCharacter {
	bool bUseAttachedVehicleRelevancy; // 0x970(0x01)
	char pad_971[0x3]; // 0x971(0x03)
	float WalkingBobSpeed; // 0x974(0x04)
	char bDoHeadBob : 1; // 0x978(0x01)
	char bAllowFreeAim : 1; // 0x978(0x01)
	char bAllowFreeAimWhileAiming : 1; // 0x978(0x01)
	char bDoFreeAim : 1; // 0x978(0x01)
	char pad_978_4 : 4; // 0x978(0x01)
	char pad_979[0x7]; // 0x979(0x07)
	struct FDFCharacterVariationDataHandle VariationHandle; // 0x980(0x18)
	struct USpringArmComponent* SpringArm; // 0x998(0x08)
	struct USpringArmComponent* FreeAimSpringArm; // 0x9a0(0x08)
	struct UHDKit* CurrentLoadout; // 0x9a8(0x08)
	struct AHDBasePickup_Kit* KitClassFallback; // 0x9b0(0x08)
	float KitDropTraceDistance; // 0x9b8(0x04)
	char bInventoryMenuShown : 1; // 0x9bc(0x01)
	char pad_9BC_1 : 7; // 0x9bc(0x01)
	char pad_9BD[0x3]; // 0x9bd(0x03)
	struct FMulticastInlineDelegate OnAimStyleChanged; // 0x9c0(0x10)
	enum class EHDWeaponAimStyle AimStyle; // 0x9d0(0x01)
	char pad_9D1[0x7]; // 0x9d1(0x07)
	struct AHDTeamState* HDTeamState; // 0x9d8(0x08)
	struct UAudioComponent* AIVocalAC; // 0x9e0(0x08)
	struct UCameraShake* WalkingHeadBob; // 0x9e8(0x08)
	struct UCameraShake* SprintingHeadBob; // 0x9f0(0x08)
	char bCanAddYawInput : 1; // 0x9f8(0x01)
	char bCanAddPitchInput : 1; // 0x9f8(0x01)
	char bCanAddRollInput : 1; // 0x9f8(0x01)
	char pad_9F8_3 : 5; // 0x9f8(0x01)
	char pad_9F9[0x3]; // 0x9f9(0x03)
	float FreeAimDeadzoneCameraSpeedFactor; // 0x9fc(0x04)
	float FreeAimReturnToCenterInterpSpeed; // 0xa00(0x04)
	float MaxFreeAimYaw; // 0xa04(0x04)
	float MaxFreeAimPitch; // 0xa08(0x04)
	float MaxFreeAimYawADS; // 0xa0c(0x04)
	float MaxFreeAimPitchADS; // 0xa10(0x04)
	float CurrentFreeAimYaw; // 0xa14(0x04)
	float CurrentFreeAimPitch; // 0xa18(0x04)
	float FreeAimMouseDeltaX; // 0xa1c(0x04)
	float FreeAimMouseDeltaY; // 0xa20(0x04)
	float FreeAimExternalDeltaX; // 0xa24(0x04)
	float FreeAimExternalDeltaY; // 0xa28(0x04)
	enum class EHDAIVocalizationType LastAIVocalization; // 0xa2c(0x01)
	char pad_A2D[0x3]; // 0xa2d(0x03)
	struct UHDAIPerceptionComponent* HDAIPerceptionComponent; // 0xa30(0x08)
	char pad_A38[0x8]; // 0xa38(0x08)

	void VariationDataChangedInternal(struct FDFCharacterVariationDataHandle PreviousHandle); // Function HDMain.HDPlayerCharacter.VariationDataChangedInternal // (Final|Native|Private) // @ game+0x7a38d0
	void SetVariationHandle(struct FDFCharacterVariationDataHandle InVariationHandle); // Function HDMain.HDPlayerCharacter.SetVariationHandle // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a3690
	void SetMaxFreeAimYawADS(float NewYaw); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimYawADS // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3610
	void SetMaxFreeAimYaw(float NewYaw); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimYaw // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3590
	void SetMaxFreeAimPitchADS(float NewPitch); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitchADS // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3510
	void SetMaxFreeAimPitch(float NewPitch); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitch // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3490
	void SetFreeAimReturnToCenterInterpSpeed(float NewInterpSpeed); // Function HDMain.HDPlayerCharacter.SetFreeAimReturnToCenterInterpSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3410
	void SetFreeAimDeadzoneCameraSpeedFactor(float NewSpeedFactor); // Function HDMain.HDPlayerCharacter.SetFreeAimDeadzoneCameraSpeedFactor // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3390
	void SetAllowFreeAimADS(bool bEnabled); // Function HDMain.HDPlayerCharacter.SetAllowFreeAimADS // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3300
	void SetAllowFreeAim(bool bEnabled); // Function HDMain.HDPlayerCharacter.SetAllowFreeAim // (Final|Native|Public|BlueprintCallable) // @ game+0x7a3270
	void SetAimStyle(enum class EHDWeaponAimStyle InAimStyle, bool bFromPlayerInput); // Function HDMain.HDPlayerCharacter.SetAimStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x7a31a0
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function HDMain.HDPlayerCharacter.ReceiveVoipTalkerMsgReceived // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveVariationDataChanged(struct FDFCharacterVariationData& NewVariation, struct FDFCharacterVariationData& PreviousVariation); // Function HDMain.HDPlayerCharacter.ReceiveVariationDataChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveFreeAim(float DeltaSeconds); // Function HDMain.HDPlayerCharacter.ReceiveFreeAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveCurrentLoadout(); // Function HDMain.HDPlayerCharacter.ReceiveCurrentLoadout // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveAimStyleChanged(enum class EHDWeaponAimStyle NewAimStyle, enum class EHDWeaponAimStyle PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDPlayerCharacter.ReceiveAimStyleChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PlayVocalSoundAI(struct USoundBase* SoundToUse, enum class EHDAIVocalizationType VocalType, float PitchMultiplier); // Function HDMain.HDPlayerCharacter.PlayVocalSoundAI // (Net|Native|Event|NetMulticast|Public) // @ game+0x7a2d00
	void OnRep_CurrentLoadout(); // Function HDMain.HDPlayerCharacter.OnRep_CurrentLoadout // (Native|Protected) // @ game+0x7a2ce0
	void OnPickupKit(struct AHDBasePickup_Kit* Kit); // Function HDMain.HDPlayerCharacter.OnPickupKit // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a2c50
	void NotifyPlayerStateChanged(struct APlayerState* NewPlayerState, struct APlayerState* OldPlayerState); // Function HDMain.HDPlayerCharacter.NotifyPlayerStateChanged // (Native|Event|Public|BlueprintEvent) // @ game+0x7a2b80
	bool IsInVehicle(); // Function HDMain.HDPlayerCharacter.IsInVehicle // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2ac0
	void HeadBob(); // Function HDMain.HDPlayerCharacter.HeadBob // (Final|Native|Protected|BlueprintCallable) // @ game+0x7a2aa0
	struct UHDPlayerComponent* GetPlayerComponent(); // Function HDMain.HDPlayerCharacter.GetPlayerComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2710
	float GetMaxFreeAimYawToUse(); // Function HDMain.HDPlayerCharacter.GetMaxFreeAimYawToUse // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2570
	float GetMaxFreeAimPitchToUse(); // Function HDMain.HDPlayerCharacter.GetMaxFreeAimPitchToUse // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2530
	struct AHDBasePickup_Kit* GetKitClassToUse(); // Function HDMain.HDPlayerCharacter.GetKitClassToUse // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a2500
	void FreeAim(float DeltaSeconds); // Function HDMain.HDPlayerCharacter.FreeAim // (Final|Native|Protected|BlueprintCallable) // @ game+0x7a21c0
	bool EquipPrimaryItem(); // Function HDMain.HDPlayerCharacter.EquipPrimaryItem // (Native|Protected|BlueprintCallable) // @ game+0x7a2060
	void DropKit(); // Function HDMain.HDPlayerCharacter.DropKit // (BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x7a2020
};

// Class HDMain.HDPlayerCharacterAnimInstanceBase
// Size: 0x2e0 (Inherited: 0x2c0)
struct UHDPlayerCharacterAnimInstanceBase : UDFCharacterAnimInstance {
	struct AHDPlayerCharacter* HDPlyCharOwner; // 0x2b8(0x08)
	struct AHDPlayerController* HDPCOwner; // 0x2c0(0x08)
	struct AHDBaseWeapon* HDEquippedWeapon; // 0x2c8(0x08)
	char bInVehicle : 1; // 0x2d0(0x01)
	char pad_2D8_1 : 7; // 0x2d8(0x01)
	char pad_2D9[0x7]; // 0x2d9(0x07)
};

// Class HDMain.HDPlayerCharacterAnimInst_FPP
// Size: 0x2e0 (Inherited: 0x2e0)
struct UHDPlayerCharacterAnimInst_FPP : UHDPlayerCharacterAnimInstanceBase {
};

// Class HDMain.HDPlayerCharacterAnimInst_TPP
// Size: 0x2e0 (Inherited: 0x2e0)
struct UHDPlayerCharacterAnimInst_TPP : UHDPlayerCharacterAnimInstanceBase {
};

// Class HDMain.HDPlayerComponent
// Size: 0xd0 (Inherited: 0xc8)
struct UHDPlayerComponent : UDFPlayerComponent {
	struct UDFLoadout* StartLoadout; // 0xc8(0x08)

	void SwitchTeam(); // Function HDMain.HDPlayerComponent.SwitchTeam // (Exec|Native|Public|BlueprintCallable) // @ game+0x7a7ba0
	void RestartPlayerAtStartSpot(struct AActor* DesiredStartSpot, struct UDFLoadout* DesiredStartLoadout); // Function HDMain.HDPlayerComponent.RestartPlayerAtStartSpot // (Native|Public|BlueprintCallable) // @ game+0x7a7560
	void PickTeam(enum class EHDTeam DesiredTeam); // Function HDMain.HDPlayerComponent.PickTeam // (Native|Public|BlueprintCallable) // @ game+0x7a7410
};

// Class HDMain.HDPlayerStart
// Size: 0x250 (Inherited: 0x250)
struct AHDPlayerStart : APlayerStart {

	struct UCapsuleComponent* K2_GetCapsuleComponent(); // Function HDMain.HDPlayerStart.K2_GetCapsuleComponent // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cee30
};

// Class HDMain.HDPlayerState
// Size: 0x3a8 (Inherited: 0x378)
struct AHDPlayerState : ADFBasePlayerState {
	struct UHDKit* SpawnLoadout; // 0x378(0x08)
	struct UHDKit* CurrentLoadout; // 0x380(0x08)
	struct FHDSquadAssignmentInfo SquadInfo; // 0x388(0x10)
	struct FMulticastInlineDelegate OnPlayerSquadInfoUpdated; // 0x398(0x10)

	void UnregisterFromSquad(); // Function HDMain.HDPlayerState.UnregisterFromSquad // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a7c20
	void OnRep_SquadInfo(); // Function HDMain.HDPlayerState.OnRep_SquadInfo // (Native|Protected) // @ game+0x7a73b0
	void OnRep_SpawnLoadout(struct UHDKit* PrevSpawnLoadout); // Function HDMain.HDPlayerState.OnRep_SpawnLoadout // (Native|Protected) // @ game+0x7a7320
	void OnRep_CurrentLoadout(struct UHDKit* PrevLoadout); // Function HDMain.HDPlayerState.OnRep_CurrentLoadout // (Native|Protected) // @ game+0x7a7270
	void AssignSpawnLoadout(struct UHDKit* NewSpawnLoadout); // Function HDMain.HDPlayerState.AssignSpawnLoadout // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a66b0
	void AssignCurrentLoadout(struct UHDKit* NewCurrentLoadout); // Function HDMain.HDPlayerState.AssignCurrentLoadout // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a6620
};

// Class HDMain.HDProj_Bullet
// Size: 0x380 (Inherited: 0x380)
struct AHDProj_Bullet : AHDBaseProjectile {
	struct USphereComponent* ProjectileCollision; // 0x378(0x08)
};

// Class HDMain.HDProj_Deployable
// Size: 0x380 (Inherited: 0x380)
struct AHDProj_Deployable : AHDBaseProjectile {
};

// Class HDMain.HDProj_Grenade
// Size: 0x390 (Inherited: 0x380)
struct AHDProj_Grenade : AHDBaseProjectile {
	float FuzeDelay; // 0x37c(0x04)
	float PayloadPostTriggerLifeSpan; // 0x380(0x04)
	float PayloadServerActivationTime; // 0x384(0x04)
	char pad_38C[0x4]; // 0x38c(0x04)

	void OnRep_PayloadServerActivationTime(); // Function HDMain.HDProj_Grenade.OnRep_PayloadServerActivationTime // (Final|Native|Private) // @ game+0x7a7300
};

// Class HDMain.HDProj_SpawnPointDeployable
// Size: 0x390 (Inherited: 0x380)
struct AHDProj_SpawnPointDeployable : AHDProj_Deployable {
	enum class EHDTeam Team; // 0x380(0x01)
	char pad_381[0xf]; // 0x381(0x0f)
};

// Class HDMain.HDRecastNavMesh
// Size: 0x4b8 (Inherited: 0x4b8)
struct AHDRecastNavMesh : ADFRecastNavMesh {
};

// Class HDMain.HDRuleset_AAS
// Size: 0x60 (Inherited: 0x60)
struct UHDRuleset_AAS : UHDGameRulesetBase {
};

// Class HDMain.HDRuleset_ControlPoint
// Size: 0xa0 (Inherited: 0x60)
struct UHDRuleset_ControlPoint : UHDGameRulesetBase {
	struct FControlPointRulesetSettings BluforTeamCPSettings; // 0x60(0x20)
	struct FControlPointRulesetSettings OpforTeamCPSettings; // 0x80(0x20)

	struct FControlPointRulesetSettings GetControlPointSettingsForTeam(enum class EHDTeam ControlPointTeam); // Function HDMain.HDRuleset_ControlPoint.GetControlPointSettingsForTeam // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6c80
	void ControlPointTeamUpdated(struct AHDBaseCapturePoint* ControlPoint, enum class EHDTeam PrevTeam, enum class EHDTeam NewTeam, bool bCaptured); // Function HDMain.HDRuleset_ControlPoint.ControlPointTeamUpdated // (Native|Protected) // @ game+0x7a6b40
	void ControlPointCaptureProgressUpdated(struct AHDBaseCapturePoint* ControlPoint, bool bContested, int32_t Progress); // Function HDMain.HDRuleset_ControlPoint.ControlPointCaptureProgressUpdated // (Native|Protected) // @ game+0x7a6a30
};

// Class HDMain.HDRuleset_KillDeath
// Size: 0xb0 (Inherited: 0x60)
struct UHDRuleset_KillDeath : UHDGameRulesetBase {
	struct FKillDeathRulesetSettings BluforTeamKDSettings; // 0x60(0x28)
	struct FKillDeathRulesetSettings OpforTeamKDSettings; // 0x88(0x28)

	void PlayerTeamKilled(struct AController* Killer, struct AController* Victim); // Function HDMain.HDRuleset_KillDeath.PlayerTeamKilled // (Native|Event|Protected|BlueprintEvent) // @ game+0x7a7490
	struct FKillDeathRulesetSettings GetKillDeathSettingsForTeam(enum class EHDTeam KillDeathTeam); // Function HDMain.HDRuleset_KillDeath.GetKillDeathSettingsForTeam // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6d20
};

// Class HDMain.HDRuleset_NoPlayerSpawnKitRestrictions
// Size: 0x60 (Inherited: 0x60)
struct UHDRuleset_NoPlayerSpawnKitRestrictions : UHDGameRulesetBase {
};

// Class HDMain.HDRuleset_TicketBleed
// Size: 0x90 (Inherited: 0x60)
struct UHDRuleset_TicketBleed : UHDGameRulesetBase {
	char pad_60[0x8]; // 0x60(0x08)
	struct TArray<struct AHDBaseCapturePoint*> RegisteredCPs; // 0x68(0x10)
	struct FTicketBleedRulesetSettings BluforTeamTBSettings; // 0x78(0x0c)
	struct FTicketBleedRulesetSettings OpforTeamTBSettings; // 0x84(0x0c)

	void UpdateTicketBleedState(); // Function HDMain.HDRuleset_TicketBleed.UpdateTicketBleedState // (Native|Protected|BlueprintCallable) // @ game+0x7a7c40
	struct FTicketBleedRulesetSettings GetTicketBleedSettingsForTeam(enum class EHDTeam TicketBleedTeam); // Function HDMain.HDRuleset_TicketBleed.GetTicketBleedSettingsForTeam // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a6e20
	void ControlPointTeamUpdated(struct AHDBaseCapturePoint* ControlPoint, enum class EHDTeam PrevTeam, enum class EHDTeam NewTeam, bool bCaptured); // Function HDMain.HDRuleset_TicketBleed.ControlPointTeamUpdated // (Native|Protected) // @ game+0x7a6b40
	void ApplyTicketBleed(enum class EHDTeam BleedTeam, int32_t TicketBleedMultiplier, bool bUseMercyTicketBleed); // Function HDMain.HDRuleset_TicketBleed.ApplyTicketBleed // (Native|Protected|BlueprintCallable) // @ game+0x7a6520
};

// Class HDMain.HDScoreboardBase
// Size: 0x250 (Inherited: 0x238)
struct UHDScoreboardBase : UDFBaseMenu {
	struct UHDScoreboardListingRowBase* ScoreboardListRowClass; // 0x238(0x08)
	struct UPanelWidget* OpforPlayerList; // 0x240(0x08)
	struct UPanelWidget* BluforPlayerList; // 0x248(0x08)

	void ReceiveScoreboardListRowAdded(struct UHDScoreboardListingRowBase* NewListEntry); // Function HDMain.HDScoreboardBase.ReceiveScoreboardListRowAdded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDScoreboardListingRowBase
// Size: 0x318 (Inherited: 0x230)
struct UHDScoreboardListingRowBase : UUserWidget {
	struct UHDScoreboardBase* ParentMenu; // 0x230(0x08)
	struct ADFBasePlayerState* PlayerState; // 0x238(0x08)
	char pad_240[0x3]; // 0x240(0x03)
	char bRefreshListingOnTick : 1; // 0x243(0x01)
	char pad_243_1 : 7; // 0x243(0x01)
	char pad_244[0x4]; // 0x244(0x04)
	struct UButton* MutePlayerBtn; // 0x248(0x08)
	struct UTextBlock* PlayerName; // 0x250(0x08)
	struct UTextBlock* Score; // 0x258(0x08)
	struct UTextBlock* Kills; // 0x260(0x08)
	struct UTextBlock* Deaths; // 0x268(0x08)
	struct UTextBlock* Ping; // 0x270(0x08)
	struct TSoftObjectPtr<UTexture2D> NotTalkingVoiceIcon; // 0x278(0x28)
	struct TSoftObjectPtr<UTexture2D> TalkingVoiceIcon; // 0x2a0(0x28)
	struct TSoftObjectPtr<UTexture2D> MutedVoiceIcon; // 0x2c8(0x28)
	char pad_2F0[0x20]; // 0x2f0(0x20)
	struct UTextBlock* PlayerNumber; // 0x310(0x08)

	void SetVoiceStateIcon(struct UTexture2D* NewIcon); // Function HDMain.HDScoreboardListingRowBase.SetVoiceStateIcon // (Final|Native|Protected|BlueprintCallable) // @ game+0x7abb50
	void RefreshListing(); // Function HDMain.HDScoreboardListingRowBase.RefreshListing // (Native|Public|BlueprintCallable) // @ game+0x703390
	void ReceivePlayerVoiceStateChanged(enum class EPlayerVoiceState NewVoiceState); // Function HDMain.HDScoreboardListingRowBase.ReceivePlayerVoiceStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnMutePlayer(); // Function HDMain.HDScoreboardListingRowBase.OnMutePlayer // (Final|Native|Private) // @ game+0x7ab620
	void Init(struct UHDScoreboardBase* InParentMenu, struct ADFBasePlayerState* InPlayerState, bool bInRefreshListingOnTick); // Function HDMain.HDScoreboardListingRowBase.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x7ab1c0
	bool HasInitialized(); // Function HDMain.HDScoreboardListingRowBase.HasInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab0c0
	struct TSoftObjectPtr<UTexture2D> GetIconForVoiceState(enum class EPlayerVoiceState VoiceState); // Function HDMain.HDScoreboardListingRowBase.GetIconForVoiceState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aac90
	int32_t GetCurrentPing(); // Function HDMain.HDScoreboardListingRowBase.GetCurrentPing // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aac60
};

// Class HDMain.HDServerListFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDServerListFilterRule : UObject {

	bool MatchesServer(struct UHDServerListItemData* ListItem); // Function HDMain.HDServerListFilterRule.MatchesServer // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x7a3100
};

// Class HDMain.HDServerAtCapacityFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDServerAtCapacityFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDEmptyServerFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDEmptyServerFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDPasswordProtectedServerFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDPasswordProtectedServerFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDSupportersOnlyServerFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDSupportersOnlyServerFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDHasUGCServerFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDHasUGCServerFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDContainsAddressServerFilterRule
// Size: 0x28 (Inherited: 0x28)
struct UHDContainsAddressServerFilterRule : UHDServerListFilterRule {
};

// Class HDMain.HDServerListItemData
// Size: 0xc8 (Inherited: 0x28)
struct UHDServerListItemData : UObject {
	struct FHDServerInfo ServerInfo; // 0x28(0xa0)
};

// Class HDMain.HDServerListing
// Size: 0x270 (Inherited: 0x230)
struct UHDServerListing : UUserWidget {
	char bTextToUpper : 1; // 0x230(0x01)
	char pad_230_1 : 7; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct UHDServerListItemData* ServerData; // 0x238(0x08)
	struct UTextBlock* ServerNameText; // 0x240(0x08)
	struct UTextBlock* ModNameText; // 0x248(0x08)
	struct UTextBlock* GameModeText; // 0x250(0x08)
	struct UTextBlock* MapNameText; // 0x258(0x08)
	struct UTextBlock* PlayersText; // 0x260(0x08)
	struct UTextBlock* PingText; // 0x268(0x08)

	void SetupListing(struct UHDServerListItemData* InServerItemData); // Function HDMain.HDServerListing.SetupListing // (Final|Native|Public|BlueprintCallable) // @ game+0x7abbd0
	void OnServerItemDataSet(bool bIsDesignTime); // Function HDMain.HDServerListing.OnServerItemDataSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDSQCommChannelState
// Size: 0x58 (Inherited: 0x28)
struct UHDSQCommChannelState : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct AHDSquadState* SquadState; // 0x30(0x08)
	struct FDFCommStateSetupParams InitialSetupParams; // 0x38(0x18)
	char pad_50[0x8]; // 0x50(0x08)

	void SetupSQChannelState(struct AHDSquadState* ForSquadState); // Function HDMain.HDSQCommChannelState.SetupSQChannelState // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7abc50
	struct FName GetChannelNameForSquad(struct AHDSquadState* Squad); // Function HDMain.HDSQCommChannelState.GetChannelNameForSquad // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7aab40
};

// Class HDMain.HDSquadHiddenState
// Size: 0x230 (Inherited: 0x220)
struct AHDSquadHiddenState : AInfo {
	char pad_220[0x8]; // 0x220(0x08)
	struct AHDSquadState* SquadStateOwner; // 0x228(0x08)
};

// Class HDMain.HDSquadStateCreationPayload
// Size: 0x58 (Inherited: 0x28)
struct UHDSquadStateCreationPayload : UObject {
	struct FHDSquadCreationParams CreationParams; // 0x28(0x30)
};

// Class HDMain.HDSquadState
// Size: 0x460 (Inherited: 0x220)
struct AHDSquadState : ADFReplInfo {
	char pad_220[0x8]; // 0x220(0x08)
	char bInitialized : 1; // 0x228(0x01)
	char pad_228_1 : 7; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
	struct AHDSquadHiddenState* SquadHiddenStateClass; // 0x230(0x08)
	int32_t ID; // 0x238(0x04)
	char TeamId; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
	struct AHDPlatoonState* OwnerPlatoon; // 0x240(0x08)
	struct FText DisplayName; // 0x248(0x18)
	struct AHDSquadHiddenState* SquadHiddenState; // 0x260(0x08)
	struct AHDPlayerState* SquadLeader; // 0x268(0x08)
	char bLocked : 1; // 0x270(0x01)
	char pad_270_1 : 2; // 0x270(0x01)
	char bRequiresSquadLeader : 1; // 0x270(0x01)
	char bDisbandSquadOnEmpty : 1; // 0x270(0x01)
	char pad_270_5 : 3; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct FMulticastInlineDelegate OnSquadLeaderAssigned; // 0x278(0x10)
	struct FMulticastInlineDelegate OnSquadMemberRegistered; // 0x288(0x10)
	struct FMulticastInlineDelegate OnSquadMemberPreUnregister; // 0x298(0x10)
	struct FMulticastInlineDelegate OnSquadMemberInfoUpdated; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnSquadRenamed; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnSquadLockToggled; // 0x2c8(0x10)
	struct FDFGenericObjectContainer SquadMembers; // 0x2d8(0x180)
	int32_t MaxSquadMemberLimit; // 0x458(0x04)
	char pad_45C[0x4]; // 0x45c(0x04)

	bool UnregisterSquadMemberAt(int32_t RemoveIdx); // Function HDMain.HDSquadState.UnregisterSquadMemberAt // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ac0b0
	bool UnregisterSquadMember(struct AHDPlayerState* MemberPSToRemove); // Function HDMain.HDSquadState.UnregisterSquadMember // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ac020
	bool UnregisterPlayerSquadMember(struct AHDPlayerController* MemberPCToRemove); // Function HDMain.HDSquadState.UnregisterPlayerSquadMember // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7abf90
	void UnlockSquad(); // Function HDMain.HDSquadState.UnlockSquad // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7abf70
	void SquadMemberPSTeamUpdated(struct APlayerState* MemberPS, char LastTeamNum, char NewTeamNum); // Function HDMain.HDSquadState.SquadMemberPSTeamUpdated // (Final|Native|Private) // @ game+0x7abe70
	void SquadMemberPSSquadUpdated(struct AHDPlayerState* MemberPS, struct FHDSquadAssignmentInfo& MemberSQInfo); // Function HDMain.HDSquadState.SquadMemberPSSquadUpdated // (Final|Native|Private|HasOutParms) // @ game+0x7abd90
	void SquadMemberPSEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function HDMain.HDSquadState.SquadMemberPSEndPlay // (Final|Native|Private) // @ game+0x7abcd0
	void RenameSquad(struct FText& NewDisplayName); // Function HDMain.HDSquadState.RenameSquad // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7aba80
	void RemoveFromOwner(); // Function HDMain.HDSquadState.RemoveFromOwner // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d3a50
	bool RegisterSquadMember(struct AHDPlayerState* NewMemberPS); // Function HDMain.HDSquadState.RegisterSquadMember // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ab8f0
	bool RegisterPlayerSquadMember(struct AHDPlayerController* NewMemberPC); // Function HDMain.HDSquadState.RegisterPlayerSquadMember // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ab860
	void ReceiveSquadUnlocked(); // Function HDMain.HDSquadState.ReceiveSquadUnlocked // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadRenamed(struct FText& NewName, struct FText& PrevName); // Function HDMain.HDSquadState.ReceiveSquadRenamed // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadMemberRegistered(struct AHDPlayerState* MemberPS); // Function HDMain.HDSquadState.ReceiveSquadMemberRegistered // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadMemberPreUnregister(struct AHDPlayerState* MemberPS); // Function HDMain.HDSquadState.ReceiveSquadMemberPreUnregister // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadLocked(); // Function HDMain.HDSquadState.ReceiveSquadLocked // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSquadLeaderAssigned(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.HDSquadState.ReceiveSquadLeaderAssigned // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveInit(struct FHDSquadCreationParams& CreationParams); // Function HDMain.HDSquadState.ReceiveInit // (BlueprintAuthorityOnly|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void OnRep_SquadLeader(struct AHDPlayerState* PrevSquadLeader); // Function HDMain.HDSquadState.OnRep_SquadLeader // (Native|Protected) // @ game+0x7ab710
	void OnRep_SquadHiddenState(); // Function HDMain.HDSquadState.OnRep_SquadHiddenState // (Native|Protected) // @ game+0x6cf950
	void OnRep_DisplayName(struct FText& PrevDisplayName); // Function HDMain.HDSquadState.OnRep_DisplayName // (Native|Protected|HasOutParms) // @ game+0x7ab640
	void OnRep_bLocked(); // Function HDMain.HDSquadState.OnRep_bLocked // (Native|Protected) // @ game+0x6cfbf0
	void LockSquad(); // Function HDMain.HDSquadState.LockSquad // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ab600
	bool IsRegisteredSquadMember(struct AHDPlayerState* PS, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.IsRegisteredSquadMember // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab540
	bool IsPlayerRegisteredSquadMember(struct AHDPlayerController* PC, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.IsPlayerRegisteredSquadMember // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab480
	bool IsPlayerPendingRemovalFromSquad(struct AHDPlayerController* PC); // Function HDMain.HDSquadState.IsPlayerPendingRemovalFromSquad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab3f0
	bool IsPendingRemovalFromSquad(struct AHDPlayerState* PS); // Function HDMain.HDSquadState.IsPendingRemovalFromSquad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab2d0
	bool HasReachedMaxSquadMemberLimit(); // Function HDMain.HDSquadState.HasReachedMaxSquadMemberLimit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab160
	struct AHDPlayerState* GetSquadMemberAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.GetSquadMemberAt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aafe0
	int32_t GetNumSquadMembersBots(bool bValidMembersOnly); // Function HDMain.HDSquadState.GetNumSquadMembersBots // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aae90
	int32_t GetNumSquadMembers(bool bValidMembersOnly); // Function HDMain.HDSquadState.GetNumSquadMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aadf0
	void DumpSquadMemberState(); // Function HDMain.HDSquadState.DumpSquadMemberState // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x7aa890
	bool CanRegisterSquadMember(struct AHDPlayerState* NewMemberPS); // Function HDMain.HDSquadState.CanRegisterSquadMember // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aa7d0
	bool CanRegisterPlayerSquadMember(struct AHDPlayerController* NewMemberPC); // Function HDMain.HDSquadState.CanRegisterPlayerSquadMember // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aa740
	bool AssignSquadLeader(struct AHDPlayerState* NewLeaderPS); // Function HDMain.HDSquadState.AssignSquadLeader // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7aa6b0
};

// Class HDMain.HDTeamCommChannelState
// Size: 0x58 (Inherited: 0x28)
struct UHDTeamCommChannelState : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct AHDTeamState* TeamState; // 0x30(0x08)
	struct FDFCommStateSetupParams InitialSetupParams; // 0x38(0x18)
	char pad_50[0x8]; // 0x50(0x08)

	void SetupTeamChannelState(struct AHDTeamState* ForTeamState); // Function HDMain.HDTeamCommChannelState.SetupTeamChannelState // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7abc50
	struct FName GetChannelNameForTeam(struct AHDTeamState* Team); // Function HDMain.HDTeamCommChannelState.GetChannelNameForTeam // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7aabd0
	struct FName GetChannelNameForCommand(struct AHDTeamState* CmdTeam); // Function HDMain.HDTeamCommChannelState.GetChannelNameForCommand // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7aaab0
};

// Class HDMain.HDTeamDefinition
// Size: 0x68 (Inherited: 0x58)
struct UHDTeamDefinition : UDFTeamDefinition {
	int32_t StartingTickets; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct UDFCommChannelDefinition* CommChannelDefinition; // 0x60(0x08)
};

// Class HDMain.HDTeamState
// Size: 0x448 (Inherited: 0x250)
struct AHDTeamState : ADFTeamState {
	struct FMulticastInlineDelegate OnPlatoonAdded; // 0x250(0x10)
	struct FMulticastInlineDelegate OnPlatoonPreRemove; // 0x260(0x10)
	struct FDFGenericObjectContainer Platoons; // 0x270(0x180)
	int32_t MaxPlatoonLimit; // 0x3f0(0x04)
	char pad_3F4[0x4]; // 0x3f4(0x04)
	struct TSet<struct UHDKit*> Kits; // 0x3f8(0x50)

	void RemovePlatoonAt(int32_t RemoveIdx); // Function HDMain.HDTeamState.RemovePlatoonAt // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7aba00
	void RemovePlatoon(struct AHDPlatoonState* PlatoonToRemove); // Function HDMain.HDTeamState.RemovePlatoon // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7ab980
	void ReceivePlatoonPreRemove(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.ReceivePlatoonPreRemove // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlatoonAdded(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.ReceivePlatoonAdded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool PlatoonExists(struct AHDPlatoonState* Platoon, bool bIgnorePendingRemoval); // Function HDMain.HDTeamState.PlatoonExists // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab7a0
	bool IsPlatoonPendingRemovalFromTeam(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.IsPlatoonPendingRemovalFromTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab360
	bool HasReachedMaxPlatoonLimit(); // Function HDMain.HDTeamState.HasReachedMaxPlatoonLimit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab100
	enum class EHDTeam GetTeam(); // Function HDMain.HDTeamState.GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ab0a0
	struct AHDPlatoonState* GetPlatoonAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDTeamState.GetPlatoonAt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aaf20
	int32_t GetNumPlatoons(bool bValidPlatoonsOnly); // Function HDMain.HDTeamState.GetNumPlatoons // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7aad50
	bool FindPlatoonByName(struct FText& PlatoonDisplayName, struct AHDPlatoonState*& OutFoundPlatoon); // Function HDMain.HDTeamState.FindPlatoonByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7aa980
	bool FindPlatoonByDefinition(struct UHDPlatoonInfo* PlatoonDef, struct AHDPlatoonState*& OutFoundPlatoon); // Function HDMain.HDTeamState.FindPlatoonByDefinition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7aa8b0
	void DumpPlatoonState(); // Function HDMain.HDTeamState.DumpPlatoonState // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x7aa870
	struct AHDPlatoonState* AddPlatoon(struct UHDPlatoonInfo* PlatoonInfo); // Function HDMain.HDTeamState.AddPlatoon // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7aa620
};

// Class HDMain.HDTextChatInputWidgetBase
// Size: 0x240 (Inherited: 0x230)
struct UHDTextChatInputWidgetBase : UUserWidget {
	struct FName TextCommsFormatName; // 0x230(0x08)
	struct UDFCommChannel* CurrentTalkChannel; // 0x238(0x08)

	void SubmitChatMessage(struct FText ChatMsgText); // Function HDMain.HDTextChatInputWidgetBase.SubmitChatMessage // (Final|Native|Protected|BlueprintCallable) // @ game+0x7b0ac0
	void StopTalkingOnCurrentChannel(); // Function HDMain.HDTextChatInputWidgetBase.StopTalkingOnCurrentChannel // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x7b0aa0
	void StopTalking(struct UDFCommChannel* CurrentChannel); // Function HDMain.HDTextChatInputWidgetBase.StopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void StartTalkingOnChannel(struct UDFCommChannel* TalkChannel); // Function HDMain.HDTextChatInputWidgetBase.StartTalkingOnChannel // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x7b0a20
	void StartTalking(struct UDFCommChannel* NewTalkChannel); // Function HDMain.HDTextChatInputWidgetBase.StartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnChatMessageSubmitted(struct UHDTextChatMsgInfo* SubmittedChatMsg); // Function HDMain.HDTextChatInputWidgetBase.OnChatMessageSubmitted // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDTextChatMsgInfo
// Size: 0x48 (Inherited: 0x28)
struct UHDTextChatMsgInfo : UObject {
	struct UDFCommChannel* CommChannel; // 0x28(0x08)
	struct APlayerState* SenderPS; // 0x30(0x08)
	struct FString ChatMsgContent; // 0x38(0x10)
};

// Class HDMain.HDTextChatWidgetBase
// Size: 0x2a8 (Inherited: 0x230)
struct UHDTextChatWidgetBase : UUserWidget {
	char pad_230[0x38]; // 0x230(0x38)
	struct FName SayAllInputActionName; // 0x268(0x08)
	struct FName SayTeamInputActionName; // 0x270(0x08)
	struct FName SaySquadInputActionName; // 0x278(0x08)
	struct FName SayAllChannelName; // 0x280(0x08)
	int32_t MaxChatMsgsToCache; // 0x288(0x04)
	struct FName LastTalkChannelName; // 0x28c(0x08)
	char pad_294[0x4]; // 0x294(0x04)
	struct TArray<struct UHDTextChatMsgInfo*> CurrentChatMsgs; // 0x298(0x10)

	void StopTalking(); // Function HDMain.HDTextChatWidgetBase.StopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void StartTalking(struct UDFCommChannel* TalkChannel); // Function HDMain.HDTextChatWidgetBase.StartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void SetMaxChatMsgsToCache(int32_t NumChatMsgsToCache); // Function HDMain.HDTextChatWidgetBase.SetMaxChatMsgsToCache // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x7b09a0
	void SayTeamActionPressed(); // Function HDMain.HDTextChatWidgetBase.SayTeamActionPressed // (Final|Native|Private) // @ game+0x7b0980
	void SaySquadActionPressed(); // Function HDMain.HDTextChatWidgetBase.SaySquadActionPressed // (Final|Native|Private) // @ game+0x7b0960
	void SayAllActionPressed(); // Function HDMain.HDTextChatWidgetBase.SayAllActionPressed // (Final|Native|Private) // @ game+0x7b0940
	int32_t GetNumCachedChatMsgs(); // Function HDMain.HDTextChatWidgetBase.GetNumCachedChatMsgs // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afb60
	bool GetCachedChatMsgAt(int32_t MsgIndex, struct UHDTextChatMsgInfo*& OutFoundMsg); // Function HDMain.HDTextChatWidgetBase.GetCachedChatMsgAt // (Final|BlueprintCosmetic|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x7af890
	void DisplayChatMessage(struct UHDTextChatMsgInfo* NewChatMsg); // Function HDMain.HDTextChatWidgetBase.DisplayChatMessage // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDURLStatics
// Size: 0x28 (Inherited: 0x28)
struct UHDURLStatics : UBlueprintFunctionLibrary {

	struct FString GetNumTicketsOptionName(enum class EHDTeam Team); // Function HDMain.HDURLStatics.GetNumTicketsOptionName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7afb80
	struct FString GetNumBotsOptionName(enum class EHDTeam Team); // Function HDMain.HDURLStatics.GetNumBotsOptionName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7afaa0
	struct FString GetFactionOptionName(enum class EHDTeam Team); // Function HDMain.HDURLStatics.GetFactionOptionName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7af9e0
	struct FString GetDisableKitRestrictionsOptionName(); // Function HDMain.HDURLStatics.GetDisableKitRestrictionsOptionName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7af960
};

// Class HDMain.HDUIStatics
// Size: 0x28 (Inherited: 0x28)
struct UHDUIStatics : UBlueprintFunctionLibrary {

	int32_t GetServerPort(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerPort // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7b0020
	struct FString GetServerIpPort(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerIpPort // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7afec0
	struct FString GetServerIp(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerIp // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7afd60
};

// Class HDMain.HDUIUserWidget
// Size: 0x238 (Inherited: 0x230)
struct UHDUIUserWidget : UUserWidget {
	char bListenForPlayerCharacterEvents : 1; // 0x230(0x01)
	char pad_230_1 : 7; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)

	void OwnerUnpossessPawn(struct APawn* UnpossessedPawn); // Function HDMain.HDUIUserWidget.OwnerUnpossessPawn // (Final|Native|Private) // @ game+0x7b08c0
	void OwnerPossessPawn(struct APawn* NewPawn); // Function HDMain.HDUIUserWidget.OwnerPossessPawn // (Final|Native|Private) // @ game+0x7b0770
	void OwnerEquippedItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function HDMain.HDUIUserWidget.OwnerEquippedItemChanged // (Final|Native|Private) // @ game+0x7b0570
	void OwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDUIUserWidget.OwnerDeath // (Final|Native|Private|HasOutParms) // @ game+0x7b02d0
	struct AHUD* GetOwningPlayerHUD(); // Function HDMain.HDUIUserWidget.GetOwningPlayerHUD // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afd30
	struct AHDHUD* GetOwningHDPlayerHUD(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerHUD // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afd00
	struct UDFCharacterMovementComponent* GetOwningHDPlayerCharacterMovement(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacterMovement // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afcd0
	struct AHDPlayerCharacter* GetOwningHDPlayerCharacter(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacter // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afca0
	struct AHDPlayerController* GetOwningHDPlayer(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayer // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afc70
	struct AHDBaseWeapon* GetOwnerEquippedWeapon(); // Function HDMain.HDUIUserWidget.GetOwnerEquippedWeapon // (Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7afc40
	void BPOwnerWeaponChanged(struct AHDBaseWeapon* NewWeap, struct AHDBaseWeapon* PrevWeap); // Function HDMain.HDUIUserWidget.BPOwnerWeaponChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerUnpossessPawn(struct APawn* UnpossessedPawn); // Function HDMain.HDUIUserWidget.BPOwnerUnpossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerPossessPawn(struct APawn* NewPawn); // Function HDMain.HDUIUserWidget.BPOwnerPossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDUIUserWidget.BPOwnerDeath // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BPInitializeForOwnerWeapon(struct AHDBaseWeapon* OwnerWeap); // Function HDMain.HDUIUserWidget.BPInitializeForOwnerWeapon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPInitializeForOwnerPlayerCharacter(struct AHDPlayerCharacter* OwnerPlyChar); // Function HDMain.HDUIUserWidget.BPInitializeForOwnerPlayerCharacter // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPDeinitializeFromOwnerWeapon(struct AHDBaseWeapon* OwnerWeap); // Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerWeapon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPDeinitializeFromOwnerPlayerCharacter(struct AHDPlayerCharacter* OwnerPlyChar); // Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerPlayerCharacter // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDUIUWCaptureStatus
// Size: 0x268 (Inherited: 0x238)
struct UHDUIUWCaptureStatus : UHDUIUserWidget {
	char pad_238[0x30]; // 0x238(0x30)

	void OwnerTouchingControlPoint(struct AHDBaseCapturePoint* OverlappingCP, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.OwnerTouchingControlPoint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerNoControlPoint(); // Function HDMain.HDUIUWCaptureStatus.OwnerNoControlPoint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerEndOverlap(struct AActor* OverlappedOwnerChar, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.OwnerEndOverlap // (Final|Native|Private) // @ game+0x7b04b0
	void OwnerBeginOverlap(struct AActor* OverlappedOwnerChar, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.OwnerBeginOverlap // (Final|Native|Private) // @ game+0x7b0210
	void CPOwnershipUpdate(struct AHDBaseCapturePoint* ControlPoint, enum class EHDTeam PrevOwningTeam, enum class EHDTeam NewOwningTeam, bool bCaptured); // Function HDMain.HDUIUWCaptureStatus.CPOwnershipUpdate // (Final|Native|Private) // @ game+0x7af680
	void CPCaptureProgressUpdate(struct AHDBaseCapturePoint* ControlPoint, bool bInCaptureContested, int32_t InCaptureProgress); // Function HDMain.HDUIUWCaptureStatus.CPCaptureProgressUpdate // (Final|Native|Private) // @ game+0x7af500
	void CPBeginEndOverlap(struct AActor* OverlappedControlPointActor, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.CPBeginEndOverlap // (Final|Native|Private) // @ game+0x7af440
	void ControlPointSetOwnershipState(bool bCaptured, enum class EHDTeam NewOwningTeam, enum class EHDTeam OldOwningTeam, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetOwnershipState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ControlPointSetGarrisonedPlayerCount(int32_t NumFriendlies, int32_t NumEnemies, int32_t MinNumRequiredForCapture, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetGarrisonedPlayerCount // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ControlPointSetCaptureProgress(bool bContested, float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetCaptureProgress // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDUIUWHUD
// Size: 0x238 (Inherited: 0x238)
struct UHDUIUWHUD : UHDUIUserWidget {
};

// Class HDMain.HDUIUWPlayerStatus
// Size: 0x258 (Inherited: 0x238)
struct UHDUIUWPlayerStatus : UHDUIUserWidget {
	char pad_238[0x20]; // 0x238(0x20)

	void OwnerUpdateStamina(float SprintValueNorm, float JumpValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerUpdateStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerStartSprint(); // Function HDMain.HDUIUWPlayerStatus.OwnerStartSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerStartAim(); // Function HDMain.HDUIUWPlayerStatus.OwnerStartAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSprintTransitionUpdate(bool bIsSprinting); // Function HDMain.HDUIUWPlayerStatus.OwnerSprintTransitionUpdate // (Final|Native|Private) // @ game+0x7b07f0
	void OwnerSetStanceState(enum class EHDUICharacterStanceState NewState, enum class EHDUICharacterStanceState OldState, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetStanceState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetStance(enum class ECharacterStance NewStance, enum class ECharacterStance OldStance, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetStance // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetSprintStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetSprintStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetJumpStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetJumpStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetHealth(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetHealth // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerHealthUpdate(struct ADFBaseCharacter* Character, float NewHealthTotal, float PrevHealthTotal); // Function HDMain.HDUIUWPlayerStatus.OwnerHealthUpdate // (Final|Native|Private) // @ game+0x7b0670
	void OwnerEndSprint(); // Function HDMain.HDUIUWPlayerStatus.OwnerEndSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerEndAim(); // Function HDMain.HDUIUWPlayerStatus.OwnerEndAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerAimTransitionUpdate(bool bIsAiming); // Function HDMain.HDUIUWPlayerStatus.OwnerAimTransitionUpdate // (Final|Native|Private) // @ game+0x7b0140
};

// Class HDMain.HDUIUWWeaponStatus
// Size: 0x260 (Inherited: 0x238)
struct UHDUIUWWeaponStatus : UHDUIUserWidget {
	struct AHDBaseWeapon* OwnerEquippedWeapon; // 0x238(0x08)
	char pad_240[0x8]; // 0x240(0x08)
	struct FHDUIWeaponAmmoState WeapAmmoState; // 0x248(0x18)

	void OwnerWeaponFireModeChanged(struct ADFBaseGun* Gun, enum class EFireMode NewFireMode, enum class EFireMode PrevFireMode, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerWeaponFireModeChanged // (Final|Native|Private) // @ game+0x7b2600
	void OwnerSetAimStyle(enum class EHDWeaponAimStyle NewAimStyle, enum class EHDWeaponAimStyle PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerSetAimStyle // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerAimStyleChanged(struct AHDPlayerCharacter* Character, enum class EHDWeaponAimStyle NewAimStyle, enum class EHDWeaponAimStyle PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerAimStyleChanged // (Final|Native|Private) // @ game+0x7b24b0
	void BPOwnerWeaponSetFireMode(enum class EFireMode NewFireMode, enum class EFireMode PreviousFireMode, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponSetFireMode // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerWeaponAmmoUpdated(struct FHDUIWeaponAmmoState& AmmoState, bool bFromReload, bool bTotalFreeAmmoUpdated, bool bNumFreeAmmoClipsUpdated); // Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponAmmoUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDVehiclePlayerSeatComponent
// Size: 0x198 (Inherited: 0x198)
struct UHDVehiclePlayerSeatComponent : UArcVehiclePlayerSeatComponent {
};

// Class HDMain.HDVoiceChatMsgInfo
// Size: 0x40 (Inherited: 0x28)
struct UHDVoiceChatMsgInfo : UObject {
	struct UDFCommChannel* CommChannel; // 0x28(0x08)
	struct APlayerState* TalkerPS; // 0x30(0x08)
	char bTalking : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class HDMain.HDVoipIndicatorListingWidgetBase
// Size: 0x238 (Inherited: 0x230)
struct UHDVoipIndicatorListingWidgetBase : UUserWidget {
	struct UHDVoiceChatMsgInfo* VoiceMsgInfo; // 0x230(0x08)

	void SetupVoiceListing(struct UHDVoiceChatMsgInfo* InVoiceMsgInfo); // Function HDMain.HDVoipIndicatorListingWidgetBase.SetupVoiceListing // (Final|Native|Public|BlueprintCallable) // @ game+0x7b2750
	void OnVoiceMsgInfoSet(bool bIsDesignTime); // Function HDMain.HDVoipIndicatorListingWidgetBase.OnVoiceMsgInfoSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDVoipIndicatorWidgetBase
// Size: 0x280 (Inherited: 0x230)
struct UHDVoipIndicatorWidgetBase : UUserWidget {
	struct TMap<struct FUniqueNetIdVoipWrapper, struct UHDVoiceChatMsgInfo*> ActiveTalkerMap; // 0x230(0x50)

	void OnPlayerStopTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnPlayerStartTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnOwningPlayerStopTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnOwningPlayerStartTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class HDMain.HDWeaponAnimInstance
// Size: 0x280 (Inherited: 0x280)
struct UHDWeaponAnimInstance : UDFWeaponAnimInstance {
	struct AHDBaseWeapon* HDWeaponOwner; // 0x278(0x08)
};

// Class HDMain.HDWeaponScopeComponent
// Size: 0x1f0 (Inherited: 0x1f0)
struct UHDWeaponScopeComponent : USceneComponent {
};

// Class HDMain.HDWorldSettings
// Size: 0x528 (Inherited: 0x518)
struct AHDWorldSettings : ATBWorldSettings {
	struct UHDTeamDefinition* BluforTeamDefinition; // 0x518(0x08)
	struct UHDTeamDefinition* OpforTeamDefinition; // 0x520(0x08)
};

// Class HDMain.PlatoonListEntry
// Size: 0x50 (Inherited: 0x28)
struct UPlatoonListEntry : UObject {
	char TeamId; // 0x28(0x01)
	enum class EHDTeam Team; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
	struct AHDTeamState* TeamState; // 0x30(0x08)
	int32_t ID; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UHDPlatoonInfo* Info; // 0x40(0x08)
	struct AHDPlatoonState* PlatoonState; // 0x48(0x08)
};

// Class HDMain.SquadListEntry
// Size: 0x50 (Inherited: 0x28)
struct USquadListEntry : UObject {
	char TeamId; // 0x28(0x01)
	enum class EHDTeam Team; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
	struct AHDTeamState* TeamState; // 0x30(0x08)
	struct UPlatoonListEntry* ParentPlatoonData; // 0x38(0x08)
	int32_t ID; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct AHDSquadState* SquadState; // 0x48(0x08)

	struct AHDPlatoonState* GetParentPlatoonState(); // Function HDMain.SquadListEntry.GetParentPlatoonState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b2360
};

// Class HDMain.SquadMemberInfo
// Size: 0x50 (Inherited: 0x28)
struct USquadMemberInfo : UObject {
	char TeamId; // 0x28(0x01)
	enum class EHDTeam Team; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
	struct AHDTeamState* TeamState; // 0x30(0x08)
	struct UPlatoonListEntry* ParentPlatoonData; // 0x38(0x08)
	struct USquadListEntry* ParentSquadData; // 0x40(0x08)
	struct AHDPlayerState* PlayerState; // 0x48(0x08)

	struct AHDSquadState* GetParentSquadState(); // Function HDMain.SquadMemberInfo.GetParentSquadState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b2390
	struct AHDPlatoonState* GetParentPlatoonState(); // Function HDMain.SquadMemberInfo.GetParentPlatoonState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7b2360
};

// Class HDMain.VictoryMenu
// Size: 0x250 (Inherited: 0x238)
struct UVictoryMenu : UDFBaseMenu {
	struct FHDGameRoundEndEventDetails RoundDetails; // 0x238(0x10)
	char bWinner : 1; // 0x248(0x01)
	char pad_248_1 : 7; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)

	void OnVictoryInit(); // Function HDMain.VictoryMenu.OnVictoryInit // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void Init(struct FHDGameRoundEndEventDetails& InRoundDetails, bool bInWinner); // Function HDMain.VictoryMenu.Init // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7b23c0
};

