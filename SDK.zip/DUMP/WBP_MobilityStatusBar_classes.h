// WidgetBlueprintGeneratedClass WBP_MobilityStatusBar.WBP_MobilityStatusBar_C
// Size: 0x250 (Inherited: 0x230)
struct UWBP_MobilityStatusBar_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWidgetAnimation* PingUIAnim; // 0x238(0x08)
	struct UProgressBar* StatusBar; // 0x240(0x08)
	struct UImage* StatusPingImg; // 0x248(0x08)

	void SetPercent(float InPercent, bool bInitial); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.SetPercent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PingValueFull(); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.PingValueFull // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_MobilityStatusBar(int32_t EntryPoint); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.ExecuteUbergraph_WBP_MobilityStatusBar // (Final|UbergraphFunction) // @ game+0xec54e0
};

