// Class DonkehFramework.DFCfgDataManager
// Size: 0x78 (Inherited: 0x28)
struct UDFCfgDataManager : UObject {
	char pad_28[0x50]; // 0x28(0x50)
};

// Class DonkehFramework.DFMapRotationManager
// Size: 0x90 (Inherited: 0x78)
struct UDFMapRotationManager : UDFCfgDataManager {
	char pad_78[0x18]; // 0x78(0x18)
};

// Class DonkehFramework.DFPlayerAdminList
// Size: 0xc8 (Inherited: 0x78)
struct UDFPlayerAdminList : UDFCfgDataManager {
	char pad_78[0x50]; // 0x78(0x50)
};

// Class DonkehFramework.DFPlayerBanList
// Size: 0xc8 (Inherited: 0x78)
struct UDFPlayerBanList : UDFCfgDataManager {
	char pad_78[0x50]; // 0x78(0x50)
};

// Class DonkehFramework.DFPlayerWhitelist
// Size: 0xc8 (Inherited: 0x78)
struct UDFPlayerWhitelist : UDFCfgDataManager {
	char pad_78[0x50]; // 0x78(0x50)
};

// Class DonkehFramework.DFAssetManager
// Size: 0x440 (Inherited: 0x438)
struct UDFAssetManager : UAssetManager {
	char pad_438[0x8]; // 0x438(0x08)
};

// Class DonkehFramework.DFBaseAIController
// Size: 0x330 (Inherited: 0x328)
struct ADFBaseAIController : AAIController {
	char pad_328[0x8]; // 0x328(0x08)

	bool CanRestartPlayer(); // Function DonkehFramework.DFBaseAIController.CanRestartPlayer // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x6c0930
};

// Class DonkehFramework.DFBaseItem
// Size: 0x3a8 (Inherited: 0x220)
struct ADFBaseItem : AActor {
	struct ADFBaseCharacter* PawnOwner; // 0x220(0x08)
	struct UStaticMeshComponent* ItemMesh; // 0x228(0x08)
	struct UStaticMeshComponent* ItemMesh1P; // 0x230(0x08)
	struct USkeletalMesh* PawnMesh1P; // 0x238(0x08)
	struct UAnimInstance* PawnMesh1PAnimClass; // 0x240(0x08)
	struct FVector PawnMesh1PLocationOffset; // 0x248(0x0c)
	struct FRotator PawnMesh1PRotationOffset; // 0x254(0x0c)
	enum class EItemType ItemType; // 0x260(0x01)
	enum class ESpecificItemType SpecificItemType; // 0x261(0x01)
	char bCanEquip : 1; // 0x262(0x01)
	char bCanAimWhileEquipped : 1; // 0x262(0x01)
	char bDisableFireInput : 1; // 0x262(0x01)
	char bEquipped : 1; // 0x262(0x01)
	char bPendingEquip : 1; // 0x262(0x01)
	char bPendingUnEquip : 1; // 0x262(0x01)
	char bWantsToFire : 1; // 0x262(0x01)
	char pad_262_7 : 1; // 0x262(0x01)
	char pad_263[0x15]; // 0x263(0x15)
	char bDebug : 1; // 0x278(0x01)
	char pad_278_1 : 7; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct FCharacterAnimCollection CharacterAnimCollection; // 0x280(0x128)

	void StopFire(); // Function DonkehFramework.DFBaseItem.StopFire // (Native|Public|BlueprintCallable) // @ game+0x6d05d0
	void StartFire(); // Function DonkehFramework.DFBaseItem.StartFire // (Native|Public|BlueprintCallable) // @ game+0x643d90
	void SetOwningPawn(struct ADFBaseCharacter* NewOwner); // Function DonkehFramework.DFBaseItem.SetOwningPawn // (Native|Public|BlueprintCallable) // @ game+0x6d0540
	void SetMeshVisibility(bool bFirstPerson); // Function DonkehFramework.DFBaseItem.SetMeshVisibility // (Native|Public|BlueprintCallable) // @ game+0x6d0420
	void ServerStopFire(); // Function DonkehFramework.DFBaseItem.ServerStopFire // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d02c0
	void ServerStartFire(struct FVector_NetQuantize Origin, struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float Timestamp, int32_t ShotID); // Function DonkehFramework.DFBaseItem.ServerStartFire // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d00f0
	bool RemoveLegacyLocomotionAnims(bool bFPP); // Function DonkehFramework.DFBaseItem.RemoveLegacyLocomotionAnims // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveVisibilityChanged(bool bFirstPerson); // Function DonkehFramework.DFBaseItem.ReceiveVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveStopFire(); // Function DonkehFramework.DFBaseItem.ReceiveStopFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveStartFire(); // Function DonkehFramework.DFBaseItem.ReceiveStartFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnUnEquipFinished(bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.ReceiveOnUnEquipFinished // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.ReceiveOnUnEquip // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnTurnOff(); // Function DonkehFramework.DFBaseItem.ReceiveOnTurnOff // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.ReceiveOnLeaveInventory // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEquipFinished(); // Function DonkehFramework.DFBaseItem.ReceiveOnEquipFinished // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEquip(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseItem.ReceiveOnEquip // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEnterInventory(struct ADFBaseCharacter* NewOwner, struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.ReceiveOnEnterInventory // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool OwnerIsSprinting(); // Function DonkehFramework.DFBaseItem.OwnerIsSprinting // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cfbc0
	bool OwnerIsAiming(); // Function DonkehFramework.DFBaseItem.OwnerIsAiming // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cfb90
	void OnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.OnUnEquip // (Native|Public|BlueprintCallable) // @ game+0x6cfac0
	void OnTurnOff(); // Function DonkehFramework.DFBaseItem.OnTurnOff // (Native|Public|BlueprintCallable) // @ game+0x6cfaa0
	void OnRep_PawnOwner(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnRep_PawnOwner // (Final|Native|Protected) // @ game+0x6cf970
	void OnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnLeaveInventory // (Native|Public|BlueprintCallable) // @ game+0x6cf8a0
	void OnEquip(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseItem.OnEquip // (Native|Public|BlueprintCallable) // @ game+0x6cf790
	void OnEnterInventory(struct ADFBaseCharacter* NewOwner, struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnEnterInventory // (Native|Public|BlueprintCallable) // @ game+0x6cf6c0
	bool IsUnEquipping(); // Function DonkehFramework.DFBaseItem.IsUnEquipping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf440
	bool IsLocallyControlled(); // Function DonkehFramework.DFBaseItem.IsLocallyControlled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf3b0
	bool IsEquipping(); // Function DonkehFramework.DFBaseItem.IsEquipping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf2b0
	bool IsEquipped(); // Function DonkehFramework.DFBaseItem.IsEquipped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf280
	bool IsClientSimulated(); // Function DonkehFramework.DFBaseItem.IsClientSimulated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf250
	enum class ESpecificItemType GetSpecificItemType(); // Function DonkehFramework.DFBaseItem.GetSpecificItemType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf180
	struct ADFBaseCharacter* GetPawnOwner(); // Function DonkehFramework.DFBaseItem.GetPawnOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf160
	struct UDFInventoryComponent* GetPawnInventory(); // Function DonkehFramework.DFBaseItem.GetPawnInventory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf130
	struct FRotator GetOwnerViewRotation(); // Function DonkehFramework.DFBaseItem.GetOwnerViewRotation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf0b0
	bool GetOwnerViewPoint(struct FVector& OutViewLoc, struct FRotator& OutViewRot); // Function DonkehFramework.DFBaseItem.GetOwnerViewPoint // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cefb0
	struct FVector GetOwnerViewLocation(); // Function DonkehFramework.DFBaseItem.GetOwnerViewLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cef30
	struct TMap<struct FName, struct UAnimSequenceBase*> GetLegacyLocomotionAnims(bool bFPP); // Function DonkehFramework.DFBaseItem.GetLegacyLocomotionAnims // (Event|Protected|BlueprintEvent|Const) // @ game+0xec54e0
	enum class EItemType GetItemType(); // Function DonkehFramework.DFBaseItem.GetItemType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ceef0
	struct UStaticMeshComponent* GetItemMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseItem.GetItemMeshToUse // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cee50
	struct UStaticMeshComponent* GetItemMesh1P(); // Function DonkehFramework.DFBaseItem.GetItemMesh1P // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cee10
	struct UStaticMeshComponent* GetItemMesh(); // Function DonkehFramework.DFBaseItem.GetItemMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cee30
	struct FVector GetAdjustedAimDirection(); // Function DonkehFramework.DFBaseItem.GetAdjustedAimDirection // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6ced20
	void ForceStopFiring(); // Function DonkehFramework.DFBaseItem.ForceStopFiring // (Native|Public|BlueprintCallable) // @ game+0x6ced00
	bool CanTriggerFire(); // Function DonkehFramework.DFBaseItem.CanTriggerFire // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cecb0
	bool CanStartFire(); // Function DonkehFramework.DFBaseItem.CanStartFire // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cec80
	bool CanSprintWhileEquipped(); // Function DonkehFramework.DFBaseItem.CanSprintWhileEquipped // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cec50
	bool CanFire(); // Function DonkehFramework.DFBaseItem.CanFire // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6cec20
	bool CanEquip(); // Function DonkehFramework.DFBaseItem.CanEquip // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cebf0
	bool CanAimWhileEquipped(); // Function DonkehFramework.DFBaseItem.CanAimWhileEquipped // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ceb20
};

// Class DonkehFramework.DFBaseAmmoClip
// Size: 0x3c0 (Inherited: 0x3a8)
struct ADFBaseAmmoClip : ADFBaseItem {
	struct ADFBaseGun* GunOwner; // 0x3a8(0x08)
	int32_t CurrentClipAmmo; // 0x3b0(0x04)
	int32_t StartingClipAmmo; // 0x3b4(0x04)
	int32_t MaxClipAmmo; // 0x3b8(0x04)
	char pad_3BC[0x4]; // 0x3bc(0x04)

	int32_t StoreAmmoInInventory(struct UDFInventoryComponent* AmmoStore, int32_t AmmoAmt, struct ADFBaseAmmoClip*& AmmoType); // Function DonkehFramework.DFBaseAmmoClip.StoreAmmoInInventory // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c3f70
	void StoreAmmo(int32_t AmmoToStore); // Function DonkehFramework.DFBaseAmmoClip.StoreAmmo // (Native|Public|BlueprintCallable) // @ game+0x6c3ee0
	void SetOwningGun(struct ADFBaseGun* NewOwner); // Function DonkehFramework.DFBaseAmmoClip.SetOwningGun // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c39f0
	bool IsLoaded(); // Function DonkehFramework.DFBaseAmmoClip.IsLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2470
	int32_t GetStartingClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetStartingClipAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c21d0
	int32_t GetMaxClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetMaxClipAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1f90
	struct ADFBaseGun* GetGunOwner(); // Function DonkehFramework.DFBaseAmmoClip.GetGunOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1f10
	int32_t GetCurrentClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetCurrentClipAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1de0
	void ConsumeAmmo(int32_t AmmoToConsume); // Function DonkehFramework.DFBaseAmmoClip.ConsumeAmmo // (Native|Public|BlueprintCallable) // @ game+0x6c1780
};

// Class DonkehFramework.DFBaseCharacter
// Size: 0x910 (Inherited: 0x4c0)
struct ADFBaseCharacter : ACharacter {
	char RemoteViewYaw; // 0x4c0(0x01)
	char pad_4C1[0x7]; // 0x4c1(0x07)
	char bClientResimulateSprintStamina : 1; // 0x4c8(0x01)
	char pad_4C8_1 : 7; // 0x4c8(0x01)
	char pad_4C9[0x7]; // 0x4c9(0x07)
	struct FCharacterAnimCollection DefaultPawnAnimCollection; // 0x4d0(0x128)
	char bPlayFootstepFXWithPerspMeshOnly : 1; // 0x5f8(0x01)
	char bTickAllAnimationOnDedicatedServer : 1; // 0x5f8(0x01)
	char bOnlyTickAnimMontagesOnDedicatedServer : 1; // 0x5f8(0x01)
	char pad_5F8_3 : 5; // 0x5f8(0x01)
	char pad_5F9[0x7]; // 0x5f9(0x07)
	struct FCharacterSoundCollection DefaultPawnSoundCollection; // 0x600(0x10)
	struct ADFBaseItem* EquippedItem; // 0x610(0x08)
	struct ADFBaseItem* LastEquippedItem; // 0x618(0x08)
	struct FMulticastInlineDelegate OnEquippedItemChanged; // 0x620(0x10)
	struct FName ItemAttachPoint; // 0x630(0x08)
	struct UDFInventoryComponent* Inventory; // 0x638(0x08)
	struct UDFLoadout* DefaultLoadout; // 0x640(0x08)
	enum class EDFItemEnabledMode ItemEnabledMode; // 0x648(0x01)
	char pad_649[0x3]; // 0x649(0x03)
	int32_t ShotIDCounter; // 0x64c(0x04)
	char bDying : 1; // 0x650(0x01)
	char pad_650_1 : 7; // 0x650(0x01)
	char pad_651[0x7]; // 0x651(0x07)
	struct FMulticastInlineDelegate OnHealthChanged; // 0x658(0x10)
	float Health; // 0x668(0x04)
	char pad_66C[0x14]; // 0x66c(0x14)
	float RagdollLifeSpan; // 0x680(0x04)
	char pad_684[0x4]; // 0x684(0x04)
	struct FMulticastInlineDelegate OnCharacterDeath; // 0x688(0x10)
	float MaxHealth; // 0x698(0x04)
	char pad_69C[0x4]; // 0x69c(0x04)
	struct FTakeHitInfo LastTakeHitInfo; // 0x6a0(0x120)
	char pad_7C0[0x8]; // 0x7c0(0x08)
	struct TMap<struct FName, float> BoneDamageMultipliers; // 0x7c8(0x50)
	char bApplyDamageMomentumOnHit : 1; // 0x818(0x01)
	char pad_818_1 : 7; // 0x818(0x01)
	char pad_819[0x7]; // 0x819(0x07)
	struct FMulticastInlineDelegate OnSprintTransition; // 0x820(0x10)
	struct FMulticastInlineDelegate OnAimTransition; // 0x830(0x10)
	struct FMulticastInlineDelegate OnLeanTransition; // 0x840(0x10)
	struct FMulticastInlineDelegate OnVaultTransition; // 0x850(0x10)
	enum class ECharacterStance ReplicatedStance; // 0x860(0x01)
	enum class ECharacterStance PreviousStance; // 0x861(0x01)
	char bPressedVault : 1; // 0x862(0x01)
	char bSprinting : 1; // 0x862(0x01)
	char bAiming : 1; // 0x862(0x01)
	char bIsProne : 1; // 0x862(0x01)
	char bVaulting : 1; // 0x862(0x01)
	char bWasVaulting : 1; // 0x862(0x01)
	char pad_862_6 : 2; // 0x862(0x01)
	char pad_863[0x1]; // 0x863(0x01)
	struct FDFVaultTraceResult PendingVaultTraceResult; // 0x864(0x1c)
	struct FDFVaultTraceData VaultParams; // 0x880(0x18)
	float ReplicatedLeanAmount; // 0x898(0x04)
	char pad_89C[0x4]; // 0x89c(0x04)
	struct UDFCharacterLeanHandler* LeanHandler; // 0x8a0(0x08)
	struct UDFCharacterMovementComponent* DFCharacterMovement; // 0x8a8(0x08)
	float TargetEyeHeight; // 0x8b0(0x04)
	char pad_8B4_0 : 1; // 0x8b4(0x01)
	char bInterpCrouchedEyeHeight : 1; // 0x8b4(0x01)
	char pad_8B4_2 : 6; // 0x8b4(0x01)
	char pad_8B5[0x3]; // 0x8b5(0x03)
	float CrouchedTransitionInterpSpeed; // 0x8b8(0x04)
	char bInterpProneEyeHeight : 1; // 0x8bc(0x01)
	char pad_8BC_1 : 7; // 0x8bc(0x01)
	char pad_8BD[0x3]; // 0x8bd(0x03)
	float ProneTransitionInterpSpeed; // 0x8c0(0x04)
	float ProneEyeHeight; // 0x8c4(0x04)
	char TeamNum; // 0x8c8(0x01)
	char pad_8C9[0x7]; // 0x8c9(0x07)
	struct ADFTeamState* TeamState; // 0x8d0(0x08)
	struct ADFTeamState* PrevTeamState; // 0x8d8(0x08)
	char bAllowTeamIdOverride : 1; // 0x8e0(0x01)
	char pad_8E0_1 : 7; // 0x8e0(0x01)
	char pad_8E1[0x7]; // 0x8e1(0x07)
	struct FMulticastInlineDelegate OnPawnTeamNumUpdated; // 0x8e8(0x10)
	struct FMulticastInlineDelegate OnPawnTeamStateUpdated; // 0x8f8(0x10)
	char pad_908[0x8]; // 0x908(0x08)

	void Vault(); // Function DonkehFramework.DFBaseCharacter.Vault // (Native|Public|BlueprintCallable) // @ game+0x6c4280
	void UnSprint(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnSprint // (Native|Public|BlueprintCallable) // @ game+0x6c41f0
	void UnLean(enum class ELeanDirection UnDesiredLeanDir, bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnLean // (Native|Public|BlueprintCallable) // @ game+0x6c4120
	void UnAim(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnAim // (Native|Public|BlueprintCallable) // @ game+0x6c4090
	void Suicide(); // Function DonkehFramework.DFBaseCharacter.Suicide // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c4070
	void StopVaulting(); // Function DonkehFramework.DFBaseCharacter.StopVaulting // (Native|Public|BlueprintCallable) // @ game+0x6c3ec0
	void StopFire(); // Function DonkehFramework.DFBaseCharacter.StopFire // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3ea0
	void StopCharacterPerspectiveAnimation(struct FPerspectiveAnim& CharAnim); // Function DonkehFramework.DFBaseCharacter.StopCharacterPerspectiveAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c3e00
	void StopCharacterMontage(struct UAnimMontage* CharMontage); // Function DonkehFramework.DFBaseCharacter.StopCharacterMontage // (Native|Public|BlueprintCallable) // @ game+0x6c3d70
	void StopAllAnimMontages(bool bPerspectiveMeshOnly); // Function DonkehFramework.DFBaseCharacter.StopAllAnimMontages // (Native|Public|BlueprintCallable) // @ game+0x6c3ce0
	void StartFire(); // Function DonkehFramework.DFBaseCharacter.StartFire // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3cc0
	void SprintToggle(); // Function DonkehFramework.DFBaseCharacter.SprintToggle // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3ca0
	void Sprint(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Sprint // (Native|Public|BlueprintCallable) // @ game+0x6c3c10
	void SpawnHitImpactFX(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.SpawnHitImpactFX // (Final|BlueprintCosmetic|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x6c3aa0
	void SetRagdollPhysics(); // Function DonkehFramework.DFBaseCharacter.SetRagdollPhysics // (Final|Native|Protected|BlueprintCallable) // @ game+0x6c3a80
	void SetItemEnabledMode(enum class EDFItemEnabledMode ItemMode); // Function DonkehFramework.DFBaseCharacter.SetItemEnabledMode // (Native|Public|BlueprintCallable) // @ game+0x6c3970
	void SetHealth(float InHealth); // Function DonkehFramework.DFBaseCharacter.SetHealth // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c38f0
	void ServerSuicide(); // Function DonkehFramework.DFBaseCharacter.ServerSuicide // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6c38a0
	void ServerEquipItem(struct ADFBaseItem* ItemToEquip); // Function DonkehFramework.DFBaseCharacter.ServerEquipItem // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6c37e0
	void ServerDoVault(struct FDFVaultTraceData VaultStartParams); // Function DonkehFramework.DFBaseCharacter.ServerDoVault // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x6c3720
	void Reload(); // Function DonkehFramework.DFBaseCharacter.Reload // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3700
	void ReceiveRestart(); // Function DonkehFramework.DFBaseCharacter.ReceiveRestart // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlayHit(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser, bool bKilled); // Function DonkehFramework.DFBaseCharacter.ReceivePlayHit // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceivePawnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamNumUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartVault(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartVault // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartSprint(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartProne(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartProne // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartLean(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartLean // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartAim(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRepPlayerState(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnRepPlayerState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndVault(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndVault // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndSprint(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndProne(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndProne // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndLean(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndLean // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndAim(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveHealthChanged(float NewHealthTotal, float PrevHealthTotal); // Function DonkehFramework.DFBaseCharacter.ReceiveHealthChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveEquippedItemChanged(struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function DonkehFramework.DFBaseCharacter.ReceiveEquippedItemChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ProneToggle(); // Function DonkehFramework.DFBaseCharacter.ProneToggle // (Final|Native|Public|BlueprintCallable) // @ game+0x6c36e0
	float PlayCharacterUnEquipMontage(struct UAnimMontage* UnEquipMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterUnEquipMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3640
	float PlayCharacterThrowUnderhandMontage(struct UAnimMontage* ThrowUnderhandMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowUnderhandMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c35a0
	float PlayCharacterThrowOverhandMontage(struct UAnimMontage* ThrowOverhandMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowOverhandMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3500
	float PlayCharacterStartReloadMontage(struct UAnimMontage* StartReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterStartReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3430
	struct UAudioComponent* PlayCharacterSound(struct FPerspectiveSound& Sound); // Function DonkehFramework.DFBaseCharacter.PlayCharacterSound // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c3380
	float PlayCharacterReloadMontage(bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c32e0
	float PlayCharacterPerspectiveAnimation(struct FPerspectiveAnim& CharAnim, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseCharacter.PlayCharacterPerspectiveAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c31f0
	float PlayCharacterMontage(struct UAnimMontage* CharMontage, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseCharacter.PlayCharacterMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3120
	float PlayCharacterFireMontage(struct UAnimMontage* FireMontageToPlay, bool bFireLast, bool bFireADS); // Function DonkehFramework.DFBaseCharacter.PlayCharacterFireMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c3010
	float PlayCharacterEquipMontage(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseCharacter.PlayCharacterEquipMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2f70
	float PlayCharacterEndReloadMontage(struct UAnimMontage* EndReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterEndReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2ea0
	float PlayCharacterDeathMontage(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseCharacter.PlayCharacterDeathMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2e00
	float PlayCharacterCockMontage(struct UAnimMontage* CockMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterCockMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2d60
	float PlayCharacterActionMontage(struct UAnimMontage* ActionMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterActionMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2cc0
	void OnRep_TeamState(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBaseCharacter.OnRep_TeamState // (Final|Native|Private) // @ game+0x6c2c00
	void OnRep_TeamNum(char LastTeamNum); // Function DonkehFramework.DFBaseCharacter.OnRep_TeamNum // (Native|Protected) // @ game+0x6c2b80
	void OnRep_ReplicatedStance(); // Function DonkehFramework.DFBaseCharacter.OnRep_ReplicatedStance // (Native|Protected) // @ game+0x6c2b60
	void OnRep_ReplicatedLeanAmount(float LastReplicatedLeanAmount); // Function DonkehFramework.DFBaseCharacter.OnRep_ReplicatedLeanAmount // (Native|Protected) // @ game+0x6c2ae0
	void OnRep_LastTakeHitInfo(); // Function DonkehFramework.DFBaseCharacter.OnRep_LastTakeHitInfo // (Final|Native|Protected) // @ game+0x6c2ac0
	void OnRep_ItemEnabledMode(enum class EDFItemEnabledMode PreviousItemEnabledMode); // Function DonkehFramework.DFBaseCharacter.OnRep_ItemEnabledMode // (Native|Protected) // @ game+0x6c2a40
	void OnRep_IsProne(); // Function DonkehFramework.DFBaseCharacter.OnRep_IsProne // (Native|Protected) // @ game+0x6c2a20
	void OnRep_Health(float PreviousValue); // Function DonkehFramework.DFBaseCharacter.OnRep_Health // (Final|Native|Private) // @ game+0x6c29a0
	void OnRep_EquippedItem(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseCharacter.OnRep_EquippedItem // (Final|Native|Protected) // @ game+0x6c2920
	void OnRep_bSprinting(); // Function DonkehFramework.DFBaseCharacter.OnRep_bSprinting // (Native|Protected) // @ game+0x6c2ca0
	void OnRep_bAiming(); // Function DonkehFramework.DFBaseCharacter.OnRep_bAiming // (Native|Protected) // @ game+0x6c2c80
	void OnDeath(float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.OnDeath // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x6c27b0
	int32_t NextShotID(); // Function DonkehFramework.DFBaseCharacter.NextShotID // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2780
	void LeaveProne(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.LeaveProne // (Native|Public|BlueprintCallable) // @ game+0x6c26f0
	void LeanToggle(enum class ELeanDirection LeanDir); // Function DonkehFramework.DFBaseCharacter.LeanToggle // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2670
	void Lean(enum class ELeanDirection DesiredLeanDir, bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Lean // (Native|Public|BlueprintCallable) // @ game+0x6c25a0
	void ItemEnabledModeChanged(enum class EDFItemEnabledMode PreviousItemEnabledMode); // Function DonkehFramework.DFBaseCharacter.ItemEnabledModeChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsPrefiring(); // Function DonkehFramework.DFBaseCharacter.IsPrefiring // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2570
	bool IsPlayer(); // Function DonkehFramework.DFBaseCharacter.IsPlayer // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2540
	bool IsPerspectiveMesh(struct USkeletalMeshComponent* MeshCompToCheck); // Function DonkehFramework.DFBaseCharacter.IsPerspectiveMesh // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c24a0
	bool IsLeaning(); // Function DonkehFramework.DFBaseCharacter.IsLeaning // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2440
	bool IsFiring(); // Function DonkehFramework.DFBaseCharacter.IsFiring // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2410
	bool IsEquipped(); // Function DonkehFramework.DFBaseCharacter.IsEquipped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2390
	bool IsAlive(); // Function DonkehFramework.DFBaseCharacter.IsAlive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c2350
	void GoProne(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.GoProne // (Native|Public|BlueprintCallable) // @ game+0x6c22c0
	void GiveLoadout(struct UDFLoadout* Loadout, bool bEquipFirstItem); // Function DonkehFramework.DFBaseCharacter.GiveLoadout // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c21f0
	struct ADFBaseItem* GetRelevantEquippedItem(); // Function DonkehFramework.DFBaseCharacter.GetRelevantEquippedItem // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c21a0
	struct ADFBaseItem* GetPreviousInventoryItem(bool bEquippable); // Function DonkehFramework.DFBaseCharacter.GetPreviousInventoryItem // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2100
	struct ADFBaseItem* GetNextInventoryItem(bool bEquippable); // Function DonkehFramework.DFBaseCharacter.GetNextInventoryItem // (Final|Native|Public|BlueprintCallable) // @ game+0x6c2060
	struct UAnimMontage* GetMontageToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseCharacter.GetMontageToUseFromPerspectiveAnimPair // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1fb0
	enum class EDFItemEnabledMode GetItemEnabledMode(); // Function DonkehFramework.DFBaseCharacter.GetItemEnabledMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1f70
	struct FName GetItemAttachPoint(); // Function DonkehFramework.DFBaseCharacter.GetItemAttachPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1f50
	struct UDFInventoryComponent* GetInventory(); // Function DonkehFramework.DFBaseCharacter.GetInventory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1f30
	struct ADFBaseItem* GetEquippedItem(); // Function DonkehFramework.DFBaseCharacter.GetEquippedItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1ef0
	bool GetDamageMultiplierByBoneName(struct FName& BoneName, float& DamageMultiplier); // Function DonkehFramework.DFBaseCharacter.GetDamageMultiplierByBoneName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1e00
	struct USkeletalMeshComponent* GetCharacterMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseCharacter.GetCharacterMeshToUse // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1d40
	bool GetCharacterDeathMontageToUse(struct UAnimMontage*& OutCharDeathMontage); // Function DonkehFramework.DFBaseCharacter.GetCharacterDeathMontageToUse // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1c90
	enum class EVisibilityBasedAnimTickOption GetCharacterAnimTickOptionToUse(bool bVisibleMesh); // Function DonkehFramework.DFBaseCharacter.GetCharacterAnimTickOptionToUse // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1bf0
	struct UAnimSequenceBase* GetAnimToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseCharacter.GetAnimToUseFromPerspectiveAnimPair // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1b40
	struct FRotator GetAimOffsets(); // Function DonkehFramework.DFBaseCharacter.GetAimOffsets // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1b00
	void EquipPreviousItem(); // Function DonkehFramework.DFBaseCharacter.EquipPreviousItem // (Native|Public|BlueprintCallable) // @ game+0x6c1ae0
	void EquipNextItemByType(enum class EItemType ItemType); // Function DonkehFramework.DFBaseCharacter.EquipNextItemByType // (Native|Public|BlueprintCallable) // @ game+0x6c1a60
	void EquipNextItem(); // Function DonkehFramework.DFBaseCharacter.EquipNextItem // (Native|Public|BlueprintCallable) // @ game+0x6c1a40
	void EquipItem(struct ADFBaseItem* ItemToEquip); // Function DonkehFramework.DFBaseCharacter.EquipItem // (Native|Public|BlueprintCallable) // @ game+0x6c19b0
	bool Die(float KillingDamage, struct FDamageEvent& DamageEvent, struct AController* Killer, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.Die // (BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c1830
	void CrouchToggle(); // Function DonkehFramework.DFBaseCharacter.CrouchToggle // (Final|Native|Public|BlueprintCallable) // @ game+0x6c1810
	void ClientVeryShortAdjustPosition_CustomStamina(float Timestamp, struct FVector NewLoc, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientVeryShortAdjustPosition_CustomStamina // (Net|Native|Event|Public|HasDefaults|NetClient) // @ game+0x6c1520
	void ClientAdjustRootMotionSourcePosition_CustomStamina(float Timestamp, struct FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionSourcePosition_CustomStamina // (Net|Native|Event|Public|HasDefaults|NetClient) // @ game+0x6c1030
	void ClientAdjustRootMotionPosition_CustomStamina(float Timestamp, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionPosition_CustomStamina // (Net|Native|Event|Public|HasDefaults|NetClient) // @ game+0x6c0d00
	void ClientAdjustPosition_CustomStamina(float Timestamp, struct FVector NewLoc, struct FVector NewVel, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustPosition_CustomStamina // (Net|Native|Event|Public|HasDefaults|NetClient) // @ game+0x6c0a50
	void ClearCharacterAnimInstances(bool bPerspectiveMeshOnly); // Function DonkehFramework.DFBaseCharacter.ClearCharacterAnimInstances // (Native|Public|BlueprintCallable) // @ game+0x6c09c0
	bool CanVault(); // Function DonkehFramework.DFBaseCharacter.CanVault // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c0990
	bool CanSprint(); // Function DonkehFramework.DFBaseCharacter.CanSprint // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c0960
	bool CanLean(enum class ELeanDirection DesiredLeanDir); // Function DonkehFramework.DFBaseCharacter.CanLean // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c08a0
	bool CanGoProne(); // Function DonkehFramework.DFBaseCharacter.CanGoProne // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c0870
	bool CanDie(float KillingDamage, struct FDamageEvent& DamageEvent, struct AController* Killer, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.CanDie // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c06f0
	bool CanAim(); // Function DonkehFramework.DFBaseCharacter.CanAim // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c06c0
	bool AllowsWeaponFire(); // Function DonkehFramework.DFBaseCharacter.AllowsWeaponFire // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c0690
	void AimToggle(); // Function DonkehFramework.DFBaseCharacter.AimToggle // (Final|Native|Public|BlueprintCallable) // @ game+0x6c0670
	void Aim(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Aim // (Native|Public|BlueprintCallable) // @ game+0x6c05e0
};

// Class DonkehFramework.DFBaseGameMode
// Size: 0x3f8 (Inherited: 0x308)
struct ADFBaseGameMode : AGameMode {
	struct ADFGameSession* DFGameSession; // 0x308(0x08)
	char pad_310[0x8]; // 0x310(0x08)
	struct ADFTeamState* TeamStateClass; // 0x318(0x08)
	struct AAIController* AIControllerClass; // 0x320(0x08)
	struct TArray<char> WinningTeams; // 0x328(0x10)
	struct FTimerHandle TimerHandle_DefaultTimer; // 0x338(0x08)
	int32_t WarmupTime; // 0x340(0x04)
	int32_t RoundTimeLimit; // 0x344(0x04)
	int32_t RoundScoreLimit; // 0x348(0x04)
	int32_t TimeBetweenMatches; // 0x34c(0x04)
	char bBalanceTeams : 1; // 0x350(0x01)
	char pad_350_1 : 7; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	float BalanceTimerInterval; // 0x354(0x04)
	char AutoAssignHumanTeam; // 0x358(0x01)
	char bBotAutofill : 1; // 0x359(0x01)
	char pad_359_1 : 7; // 0x359(0x01)
	char pad_35A[0x6]; // 0x35a(0x06)
	struct FText GameDisplayName; // 0x360(0x18)
	int32_t NumTeams; // 0x378(0x04)
	char bAllowUnassignedTeams : 1; // 0x37c(0x01)
	char bAllowPlayerNameChanges : 1; // 0x37c(0x01)
	char bAllowPlayerNameChangesUnderNullOSS : 1; // 0x37c(0x01)
	char bAllowPlayerNameChangesUnderSteamOSS : 1; // 0x37c(0x01)
	char bAlwaysDestroyPlayerDuringSeamlessTravel : 1; // 0x37c(0x01)
	char bForceRespawn : 1; // 0x37c(0x01)
	char bRandomSpawns : 1; // 0x37c(0x01)
	char bRestartPlayerAtTransformOnly : 1; // 0x37c(0x01)
	char bFriendlyFire : 1; // 0x37d(0x01)
	char bUpdatePlayerGameplayMuteStates : 1; // 0x37d(0x01)
	char bTeamOnlyVoice : 1; // 0x37d(0x01)
	char pad_37D_3 : 5; // 0x37d(0x01)
	enum class ESpawnActorCollisionHandlingMethod DefaultPawnSpawnCollisionHandlingMethodOverride; // 0x37e(0x01)
	char bAllowBots : 1; // 0x37f(0x01)
	char pad_37F_1 : 7; // 0x37f(0x01)
	struct FTimerHandle TimerHandle_BalanceTimer; // 0x380(0x08)
	struct TSet<struct TSoftClassPtr<UObject>> GameRulesetClasses; // 0x388(0x50)
	struct TArray<struct AActor*> SignificantActors; // 0x3d8(0x10)
	struct TArray<struct UDFGameRulesetBase*> GameRulesets; // 0x3e8(0x10)

	void UpdatePlayerGameplayMuteStates(struct ADFBasePlayerController* ForPlayerController); // Function DonkehFramework.DFBaseGameMode.UpdatePlayerGameplayMuteStates // (Native|Protected|BlueprintCallable) // @ game+0x6c9220
	void UnregisterSignificantActor(struct AActor* ActorToRemove); // Function DonkehFramework.DFBaseGameMode.UnregisterSignificantActor // (Final|Native|Public|BlueprintCallable) // @ game+0x6c91a0
	void SwitchToNextMap(); // Function DonkehFramework.DFBaseGameMode.SwitchToNextMap // (Native|Public|BlueprintCallable) // @ game+0x6c9180
	void SignificantActorEndPlay(struct AActor* RemovedActor, enum class EEndPlayReason EndPlayReason); // Function DonkehFramework.DFBaseGameMode.SignificantActorEndPlay // (Final|Native|Private) // @ game+0x6c90c0
	bool ShouldHibernate(); // Function DonkehFramework.DFBaseGameMode.ShouldHibernate // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c9090
	bool ShouldGameplayMuteRemotePlayer(struct ADFBasePlayerController* ForPlayer, struct ADFBasePlayerController* PlayerToCheck); // Function DonkehFramework.DFBaseGameMode.ShouldGameplayMuteRemotePlayer // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6c8fc0
	bool ShouldBotAutofill(); // Function DonkehFramework.DFBaseGameMode.ShouldBotAutofill // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c8f90
	void RemoveTeamBots(char TeamId, int32_t Num); // Function DonkehFramework.DFBaseGameMode.RemoveTeamBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c8da0
	void RemovePlayerByAge(bool bNewest, bool bExcludeBots, bool bExcludeHumans); // Function DonkehFramework.DFBaseGameMode.RemovePlayerByAge // (Final|Native|Public|BlueprintCallable) // @ game+0x6c8c80
	void RemoveOldestPlayer(); // Function DonkehFramework.DFBaseGameMode.RemoveOldestPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x6c8c50
	void RemoveOldestBot(); // Function DonkehFramework.DFBaseGameMode.RemoveOldestBot // (Final|Native|Public|BlueprintCallable) // @ game+0x6c8c20
	void RemoveNewestPlayer(); // Function DonkehFramework.DFBaseGameMode.RemoveNewestPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x6c8bf0
	void RemoveNewestBot(); // Function DonkehFramework.DFBaseGameMode.RemoveNewestBot // (Final|Native|Public|BlueprintCallable) // @ game+0x6c8bc0
	bool RemoveBotByName(struct FString PlayerName); // Function DonkehFramework.DFBaseGameMode.RemoveBotByName // (Native|Public|BlueprintCallable) // @ game+0x6c8b10
	bool RemoveBot(struct APlayerState* BotPS); // Function DonkehFramework.DFBaseGameMode.RemoveBot // (Native|Public|BlueprintCallable) // @ game+0x6c8a70
	void RemoveAllBots(); // Function DonkehFramework.DFBaseGameMode.RemoveAllBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c8a50
	void RegisterSignificantActor(struct AActor* ActorToRegister); // Function DonkehFramework.DFBaseGameMode.RegisterSignificantActor // (Final|Native|Public|BlueprintCallable) // @ game+0x6c89d0
	void ReceiveOnSwapAIControllers(struct AAIController* OldAIC, struct AAIController* NewAIC); // Function DonkehFramework.DFBaseGameMode.ReceiveOnSwapAIControllers // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMatchIsWaitingToStart(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchIsWaitingToStart // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMatchHasStarted(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchHasStarted // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMatchHasEnded(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchHasEnded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnMatchAborted(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchAborted // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnLeavingMap(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnLeavingMap // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool PlayerCanRestartGeneric(struct AController* Player); // Function DonkehFramework.DFBaseGameMode.PlayerCanRestartGeneric // (Native|Public|BlueprintCallable) // @ game+0x6c8910
	bool PlayerBotCanRestart(struct AAIController* Player); // Function DonkehFramework.DFBaseGameMode.PlayerBotCanRestart // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x6c8870
	void NextMap(); // Function DonkehFramework.DFBaseGameMode.NextMap // (Final|Exec|Native|Public) // @ game+0x6c84a0
	float ModifyDamage(float Damage, struct AActor* DamagedActor, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseGameMode.ModifyDamage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c82d0
	bool KickPlayerByName(struct FString KickedPlayerName, struct FText& KickReason); // Function DonkehFramework.DFBaseGameMode.KickPlayerByName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c8190
	bool KickPlayerById(int32_t KickedPlayerId, struct FText& KickReason); // Function DonkehFramework.DFBaseGameMode.KickPlayerById // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c8070
	bool IsValidTeamId(char TeamId); // Function DonkehFramework.DFBaseGameMode.IsValidTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7d80
	bool IsMatchWinner(struct ADFBasePlayerState* PlayerStateToCheck); // Function DonkehFramework.DFBaseGameMode.IsMatchWinner // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x6c7ce0
	bool IsHibernating(); // Function DonkehFramework.DFBaseGameMode.IsHibernating // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7c90
	bool IsFriendlyFireEnabled(); // Function DonkehFramework.DFBaseGameMode.IsFriendlyFireEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7c60
	int32_t GetTotalNumPlayers(bool bIncludeTravellingPlayers); // Function DonkehFramework.DFBaseGameMode.GetTotalNumPlayers // (Native|Public|BlueprintCallable) // @ game+0x6c79c0
	int32_t GetNumPlayersOnTeam(char TeamId, enum class EPlayerKind PlayerType); // Function DonkehFramework.DFBaseGameMode.GetNumPlayersOnTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7860
	struct FString GetNextMapName(); // Function DonkehFramework.DFBaseGameMode.GetNextMapName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c77e0
	struct FString GetNextGameName(); // Function DonkehFramework.DFBaseGameMode.GetNextGameName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7760
	char GetAutoAssignHumanTeam(); // Function DonkehFramework.DFBaseGameMode.GetAutoAssignHumanTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7730
	bool ForceTeamId(int32_t SwitchedPlayerId, char TeamIdToAssign); // Function DonkehFramework.DFBaseGameMode.ForceTeamId // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c7640
	bool ForceTeam(struct FString SwitchedPlayerName, char TeamIdToAssign); // Function DonkehFramework.DFBaseGameMode.ForceTeam // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c7550
	bool FindPlayerStartTransform(struct AController* Player, struct FTransform& OutFoundSpawnTransform, struct FString IncomingName); // Function DonkehFramework.DFBaseGameMode.FindPlayerStartTransform // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x6c73d0
	void DumpActiveRulesets(); // Function DonkehFramework.DFBaseGameMode.DumpActiveRulesets // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x6c7310
	void DetermineMatchWinner(); // Function DonkehFramework.DFBaseGameMode.DetermineMatchWinner // (Native|Event|Protected|BlueprintEvent) // @ game+0x6c72f0
	struct ADFTeamState* CreateTeam(struct UDFTeamDefinition* NewTeamDef, char NewTeamIdToUse); // Function DonkehFramework.DFBaseGameMode.CreateTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x6c7230
	char ChooseTeam(struct ADFBasePlayerState* ForPlayerState); // Function DonkehFramework.DFBaseGameMode.ChooseTeam // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6c7190
	bool ChooseSpawnPointFromPlayerStart(struct AController* Player, struct AActor* StartSpot, struct FSpawnPointDef& OutChosenSpawnPoint, enum class ESpawnActorCollisionHandlingMethod& OutCollisionHandlingMethod); // Function DonkehFramework.DFBaseGameMode.ChooseSpawnPointFromPlayerStart // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x6c6ff0
	bool CheckWinConditions(); // Function DonkehFramework.DFBaseGameMode.CheckWinConditions // (Native|Event|Protected|BlueprintEvent) // @ game+0x6c6fc0
	bool CheckRulesetWinConditions(); // Function DonkehFramework.DFBaseGameMode.CheckRulesetWinConditions // (Final|Native|Protected|BlueprintCallable) // @ game+0x6c6f90
	bool CanRegisterSignificantActor(struct AActor* ActorToRegister, struct FString& ActorDenialReason); // Function DonkehFramework.DFBaseGameMode.CanRegisterSignificantActor // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6c6e90
	bool CanDealDamage(struct ADFBasePlayerState* DamageInstigator, struct ADFBasePlayerState* DamagedPlayer); // Function DonkehFramework.DFBaseGameMode.CanDealDamage // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6c6dc0
	bool CanAddRuleset(struct UDFGameRulesetBase*& RulesetClassToAdd, struct FString& RulesetDenialReason); // Function DonkehFramework.DFBaseGameMode.CanAddRuleset // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6c6cb0
	bool BanPlayerByName(struct FString BannedPlayerName, struct FText& BanReason, float BanDuration); // Function DonkehFramework.DFBaseGameMode.BanPlayerByName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c6b30
	bool BanPlayerById(int32_t BannedPlayerId, struct FText& BanReason, float BanDuration); // Function DonkehFramework.DFBaseGameMode.BanPlayerById // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c69c0
	void AutofillWithBots(); // Function DonkehFramework.DFBaseGameMode.AutofillWithBots // (Native|Public|BlueprintCallable) // @ game+0x6c69a0
	void AssignTeam(struct AController* ForController, char AssignedTeam); // Function DonkehFramework.DFBaseGameMode.AssignTeam // (Native|Public|BlueprintCallable) // @ game+0x6c68d0
	void AddTeamBots(char TeamId, int32_t Num); // Function DonkehFramework.DFBaseGameMode.AddTeamBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c6800
	void AddNamedBot(struct FString BotName); // Function DonkehFramework.DFBaseGameMode.AddNamedBot // (Exec|Native|Public) // @ game+0x6c6760
	void AddBots(int32_t Num); // Function DonkehFramework.DFBaseGameMode.AddBots // (Exec|Native|Public|BlueprintCallable) // @ game+0x6c66d0
	struct APlayerState* AddBot(char PlayerTeamID, struct FString PlayerName); // Function DonkehFramework.DFBaseGameMode.AddBot // (Native|Public|BlueprintCallable) // @ game+0x6c65a0
};

// Class DonkehFramework.DFBaseGame_DeathMatch
// Size: 0x400 (Inherited: 0x3f8)
struct ADFBaseGame_DeathMatch : ADFBaseGameMode {
	struct ADFBasePlayerState* WinningPlayerState; // 0x3f8(0x08)
};

// Class DonkehFramework.DFBaseGame_TeamDeathMatch
// Size: 0x3f8 (Inherited: 0x3f8)
struct ADFBaseGame_TeamDeathMatch : ADFBaseGameMode {
};

// Class DonkehFramework.DFBaseGameInstance
// Size: 0x250 (Inherited: 0x198)
struct UDFBaseGameInstance : UGameInstance {
	char pad_198[0x90]; // 0x198(0x90)
	struct FMulticastInlineDelegate OnPlayerStateTalkingStateChanged; // 0x228(0x10)
	char pad_238[0x18]; // 0x238(0x18)

	void ProjectVersion(); // Function DonkehFramework.DFBaseGameInstance.ProjectVersion // (Final|Exec|Native|Private|Const) // @ game+0x6c89b0
	void OnTravelFailure(struct UWorld* World, enum class ETravelFailure FailureType, struct FString ErrorString); // Function DonkehFramework.DFBaseGameInstance.OnTravelFailure // (Native|Protected) // @ game+0x6c8750
	void OnNetworkLagStateChanged(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkLagState LagType); // Function DonkehFramework.DFBaseGameInstance.OnNetworkLagStateChanged // (Native|Protected) // @ game+0x6c8610
	void OnNetworkFailure(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkFailure FailureType, struct FString ErrorString); // Function DonkehFramework.DFBaseGameInstance.OnNetworkFailure // (Native|Protected) // @ game+0x6c84c0
	void JoinGameByIP(struct FString IPAddress, struct FString JoinPassword); // Function DonkehFramework.DFBaseGameInstance.JoinGameByIP // (Native|Public|BlueprintCallable) // @ game+0x6c7f80
	void JoinGame(int32_t SearchResultIndex, struct FString JoinPassword); // Function DonkehFramework.DFBaseGameInstance.JoinGame // (Native|Public|BlueprintCallable) // @ game+0x6c7ea0
	bool IsHibernating(); // Function DonkehFramework.DFBaseGameInstance.IsHibernating // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7cc0
	void HostGame(struct FString TravelURL, bool bLANGame, int32_t MaxPlayers, struct FString HostName, struct FString Password); // Function DonkehFramework.DFBaseGameInstance.HostGame // (Native|Public|BlueprintCallable) // @ game+0x6c7a60
	void ForceUpdateSession(); // Function DonkehFramework.DFBaseGameInstance.ForceUpdateSession // (Final|Exec|Native|Private) // @ game+0x6c7710
	void FindGames(enum class ESessionSearchPresenceType SearchPresenceType); // Function DonkehFramework.DFBaseGameInstance.FindGames // (Native|Public|BlueprintCallable) // @ game+0x6c7350
	void DumpOnlineSessionState(); // Function DonkehFramework.DFBaseGameInstance.DumpOnlineSessionState // (Final|Exec|Native|Private) // @ game+0x6c7330
};

// Class DonkehFramework.DFBaseGameState
// Size: 0x300 (Inherited: 0x290)
struct ADFBaseGameState : AGameState {
	char NumTeams; // 0x290(0x01)
	bool bTimerPaused; // 0x291(0x01)
	char pad_292[0x2]; // 0x292(0x02)
	int32_t RemainingTime; // 0x294(0x04)
	int32_t ReplicatedRemainingTime; // 0x298(0x04)
	char pad_29C[0x4]; // 0x29c(0x04)
	struct TArray<float> TeamScores; // 0x2a0(0x10)
	struct TArray<struct ADFTeamState*> TeamArray; // 0x2b0(0x10)
	struct FMulticastInlineDelegate OnTeamStateAdded; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnTeamStateRemoved; // 0x2d0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateAdded; // 0x2e0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateRemoved; // 0x2f0(0x10)

	void SetTimerPauseState(bool bNewPauseState); // Function DonkehFramework.DFBaseGameState.SetTimerPauseState // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c8f00
	void SetRemainingTime(int32_t NewRemainingTime); // Function DonkehFramework.DFBaseGameState.SetRemainingTime // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6c8e70
	void OnRep_ReplicatedRemainingTime(); // Function DonkehFramework.DFBaseGameState.OnRep_ReplicatedRemainingTime // (Native|Protected) // @ game+0x6c8730
	void OnRep_NumTeams(); // Function DonkehFramework.DFBaseGameState.OnRep_NumTeams // (Final|Native|Private) // @ game+0x6c8710
	bool IsValidTeamId(char TeamId); // Function DonkehFramework.DFBaseGameState.IsValidTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7e10
	struct ADFTeamState* GetTeamStateById(char TeamIdNum); // Function DonkehFramework.DFBaseGameState.GetTeamStateById // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c7930
};

// Class DonkehFramework.DFBaseWeapon
// Size: 0x650 (Inherited: 0x3a8)
struct ADFBaseWeapon : ADFBaseItem {
	struct FMulticastInlineDelegate OnFire; // 0x3a8(0x10)
	char bFiring : 1; // 0x3b8(0x01)
	char pad_3B8_1 : 4; // 0x3b8(0x01)
	char bReadyToFirePendingRelease : 1; // 0x3b8(0x01)
	char bFireOnRelease : 1; // 0x3b8(0x01)
	char pad_3B8_7 : 1; // 0x3b8(0x01)
	char pad_3B9[0x3]; // 0x3b9(0x03)
	float PrefireDelayMin; // 0x3bc(0x04)
	char bPrefiring : 1; // 0x3c0(0x01)
	char pad_3C0_1 : 7; // 0x3c0(0x01)
	char pad_3C1[0x47]; // 0x3c1(0x47)
	char bADSFireOnly : 1; // 0x408(0x01)
	char bLastShotFired : 1; // 0x408(0x01)
	char bRepCounterPending : 1; // 0x408(0x01)
	char pad_408_3 : 5; // 0x408(0x01)
	char pad_409[0x1]; // 0x409(0x01)
	struct FRepShotInfo FireCounter; // 0x40a(0x04)
	struct FRepShotInfo PreviousRepFireCounter; // 0x40e(0x04)
	struct FRepShotInfo PostStoppedFireCounter; // 0x412(0x04)
	char pad_416[0x2]; // 0x416(0x02)
	float LastFireTime; // 0x418(0x04)
	float LastShotFireTime; // 0x41c(0x04)
	char pad_420[0x4]; // 0x420(0x04)
	char bUseServerSideFiringLogic : 1; // 0x424(0x01)
	char bSimulateWeaponFireOnDedicatedServer : 1; // 0x424(0x01)
	char pad_424_2 : 6; // 0x424(0x01)
	char pad_425[0x3]; // 0x425(0x03)
	struct FWeaponAnimCollection WeaponAnimCollection; // 0x428(0xf0)
	char bStopAllFireAnimsAfterFireRateDelay : 1; // 0x518(0x01)
	char bSimulate1PWeaponFireOnPawnOwner1PMesh : 1; // 0x518(0x01)
	char pad_518_2 : 6; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)
	struct FWeaponSoundCollection WeaponSoundCollection; // 0x520(0x80)
	char bSingleAction : 1; // 0x5a0(0x01)
	char bSingleLoad : 1; // 0x5a0(0x01)
	char pad_5A0_2 : 6; // 0x5a0(0x01)
	char pad_5A1[0x7]; // 0x5a1(0x07)
	struct USkeletalMeshComponent* WeaponMesh; // 0x5a8(0x08)
	struct USkeletalMeshComponent* WeaponMesh1P; // 0x5b0(0x08)
	char bCanSprintWhilePrefiring : 1; // 0x5b8(0x01)
	char pad_5B8_1 : 7; // 0x5b8(0x01)
	char pad_5B9[0x7]; // 0x5b9(0x07)
	struct FRuntimeFloatCurve DamageFalloffCurve; // 0x5c0(0x88)
	struct UDamageType* DamageTypeClass; // 0x648(0x08)

	void StopWeaponPerspectiveAnimation(struct FPerspectiveAnim& WeapAnim); // Function DonkehFramework.DFBaseWeapon.StopWeaponPerspectiveAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d5410
	void StopWeaponMontage(struct UAnimMontage* WeapMontage); // Function DonkehFramework.DFBaseWeapon.StopWeaponMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d5390
	void StopSimulatingWeaponFire(bool bForceStopAll); // Function DonkehFramework.DFBaseWeapon.StopSimulatingWeaponFire // (Native|Protected|BlueprintCallable) // @ game+0x6d5300
	void SimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.SimulateWeaponFire // (Native|Protected|BlueprintCallable) // @ game+0x6d5120
	bool ShouldSimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ShouldSimulateWeaponFire // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d50f0
	void ServerPreFire(); // Function DonkehFramework.DFBaseWeapon.ServerPreFire // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x6d4ee0
	void ServerFireShot(struct FVector_NetQuantize Origin, struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float Timestamp, int32_t ShotID); // Function DonkehFramework.DFBaseWeapon.ServerFireShot // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d4d10
	void ReceiveStopSimulatingWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveStopSimulatingWeaponFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveSimulateWeaponFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStopFiring(); // Function DonkehFramework.DFBaseWeapon.ReceiveOnStopFiring // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartFiring(); // Function DonkehFramework.DFBaseWeapon.ReceiveOnStartFiring // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PrefireDelayElapsed(bool bClientSimulation); // Function DonkehFramework.DFBaseWeapon.PrefireDelayElapsed // (Native|Protected) // @ game+0x6d44f0
	float PlayWeaponUnEquipMontage(struct UAnimMontage* UnEquipMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponUnEquipMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d4450
	float PlayWeaponThrowUnderhandMontage(struct UAnimMontage* ThrowUnderhandMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowUnderhandMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d43b0
	float PlayWeaponThrowOverhandMontage(struct UAnimMontage* ThrowOverhandMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowOverhandMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d4310
	struct UAudioComponent* PlayWeaponSound(struct FPerspectiveSound& Sound); // Function DonkehFramework.DFBaseWeapon.PlayWeaponSound // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d4260
	float PlayWeaponPerspectiveAnimation(struct FPerspectiveAnim& WeapAnim); // Function DonkehFramework.DFBaseWeapon.PlayWeaponPerspectiveAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d41b0
	float PlayWeaponMontage(struct UAnimMontage* WeapMontage, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseWeapon.PlayWeaponMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d40e0
	float PlayWeaponFireMontage(struct UAnimMontage* FireMontageToPlay, bool bFireLast, bool bFireADS); // Function DonkehFramework.DFBaseWeapon.PlayWeaponFireMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3fd0
	float PlayWeaponEquipMontage(struct UAnimMontage* EquipMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponEquipMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3f30
	float PlayWeaponCockMontage(struct UAnimMontage* CockMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponCockMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3e90
	float PlayWeaponActionMontage(struct UAnimMontage* ActionMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponActionMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3df0
	float PlayThrowAnimations(bool bOverhandThrow, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayThrowAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3d10
	float PlayCockAnimations(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayCockAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3c70
	void PlayActionAnimations(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayActionAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3be0
	void OnStopFiring(); // Function DonkehFramework.DFBaseWeapon.OnStopFiring // (Native|Protected|BlueprintCallable) // @ game+0x6d3ab0
	void OnStartFiring(); // Function DonkehFramework.DFBaseWeapon.OnStartFiring // (Native|Protected|BlueprintCallable) // @ game+0x6d3a90
	void OnRep_FireCounter(struct FRepShotInfo& PreviousValue); // Function DonkehFramework.DFBaseWeapon.OnRep_FireCounter // (Final|Native|Protected|HasOutParms) // @ game+0x6d3660
	void OnRep_bPrefiring(); // Function DonkehFramework.DFBaseWeapon.OnRep_bPrefiring // (Final|Native|Protected) // @ game+0x6d3a70
	bool IsFiring(); // Function DonkehFramework.DFBaseWeapon.IsFiring // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3630
	void HandleFire(); // Function DonkehFramework.DFBaseWeapon.HandleFire // (Native|Protected|BlueprintCallable) // @ game+0x6d34c0
	struct USkeletalMeshComponent* GetWeaponMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseWeapon.GetWeaponMeshToUse // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3420
	struct USkeletalMeshComponent* GetWeaponMesh1P(); // Function DonkehFramework.DFBaseWeapon.GetWeaponMesh1P // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d33e0
	struct USkeletalMeshComponent* GetWeaponMesh(); // Function DonkehFramework.DFBaseWeapon.GetWeaponMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3400
	struct UAnimMontage* GetMontageToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetMontageToUseFromPerspectiveAnimPair // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3260
	float GetMontagePlayLengthToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetMontagePlayLengthToUseFromPerspectiveAnimPair // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d31b0
	struct UAnimSequenceBase* GetAnimToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetAnimToUseFromPerspectiveAnimPair // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3060
	float GetAnimPlayLengthToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetAnimPlayLengthToUseFromPerspectiveAnimPair // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d2fb0
};

// Class DonkehFramework.DFBaseGun
// Size: 0x830 (Inherited: 0x650)
struct ADFBaseGun : ADFBaseWeapon {
	struct FMulticastInlineDelegate OnFireModeChanged; // 0x650(0x10)
	char pad_660[0x8]; // 0x660(0x08)
	float TimerIntervalAdjustment; // 0x668(0x04)
	bool bAllowAutomaticWeaponCatchup; // 0x66c(0x01)
	char pad_66D[0x3]; // 0x66d(0x03)
	float FireRate; // 0x670(0x04)
	int32_t ShotsPerBurst; // 0x674(0x04)
	char SupportedFireModes; // 0x678(0x01)
	enum class EFireMode SelectedFireMode; // 0x679(0x01)
	char pad_67A[0x6]; // 0x67a(0x06)
	struct UDFGunRecoilHandler* RecoilHandler; // 0x680(0x08)
	struct FMulticastInlineDelegate OnReloadStarted; // 0x688(0x10)
	struct FMulticastInlineDelegate OnReloadFinished; // 0x698(0x10)
	enum class EGunReloadState PendingReloadState; // 0x6a8(0x01)
	enum class EGunReloadState PreviousReloadState; // 0x6a9(0x01)
	char bKeepLoadedAmmoOnLeaveInventory : 1; // 0x6aa(0x01)
	char pad_6AA_1 : 2; // 0x6aa(0x01)
	char bUsesAmmo : 1; // 0x6aa(0x01)
	char bExhaustible : 1; // 0x6aa(0x01)
	char bCanSprintWhileReloading : 1; // 0x6aa(0x01)
	char pad_6AA_6 : 2; // 0x6aa(0x01)
	char pad_6AB[0x4d]; // 0x6ab(0x4d)
	char bReloadOnEquip : 1; // 0x6f8(0x01)
	char bInstantReloadOnEquip : 1; // 0x6f8(0x01)
	char bInstantReloadOnInitialEquip : 1; // 0x6f8(0x01)
	char bInstantReloadOnInitialEnterInventory : 1; // 0x6f8(0x01)
	char bReloadOnDryFire : 1; // 0x6f8(0x01)
	char bReloadOnStopFire : 1; // 0x6f8(0x01)
	char bSimulateGunReloadOnDedicatedServer : 1; // 0x6f8(0x01)
	char pad_6F8_7 : 1; // 0x6f8(0x01)
	enum class EAmmoClipReloadBehavior AmmoClipReloadBehavior; // 0x6f9(0x01)
	char pad_6FA[0x6]; // 0x6fa(0x06)
	struct TSet<struct ADFBaseAmmoClip*> SupportedAmmoClips; // 0x700(0x50)
	int32_t StartingAmmoClips; // 0x750(0x04)
	char bDispensedStartingAmmoClips : 1; // 0x754(0x01)
	char pad_754_1 : 7; // 0x754(0x01)
	char pad_755[0x3]; // 0x755(0x03)
	struct ADFBaseAmmoClip* CurrentAmmoClip; // 0x758(0x08)
	int32_t CurrentAmmoClipInvIndex; // 0x760(0x04)
	char pad_764[0x4]; // 0x764(0x04)
	struct ADFBaseAmmoClip* PreviousAmmoClip; // 0x768(0x08)
	int32_t CurrentAmmoInClipBeforeReload; // 0x770(0x04)
	int32_t ReloadCycleIterations; // 0x774(0x04)
	char bInfiniteClipAmmo : 1; // 0x778(0x01)
	char bInfiniteAmmo : 1; // 0x778(0x01)
	char bNoRecoil : 1; // 0x778(0x01)
	char pad_778_3 : 5; // 0x778(0x01)
	char pad_779[0x7]; // 0x779(0x07)
	struct FComponentReference CustomMuzzleAttachComponentToUse; // 0x780(0x28)
	struct FName MuzzleAttachComponentName; // 0x7a8(0x08)
	struct FName MuzzleAttachPoint; // 0x7b0(0x08)
	struct UParticleSystem* MuzzleFX; // 0x7b8(0x08)
	struct FVector MuzzleLocationOffset; // 0x7c0(0x0c)
	struct FRotator MuzzleRotationOffset; // 0x7cc(0x0c)
	char bLoopedMuzzleFX : 1; // 0x7d8(0x01)
	char pad_7D8_1 : 7; // 0x7d8(0x01)
	char pad_7D9[0x7]; // 0x7d9(0x07)
	struct UParticleSystemComponent* MuzzlePSC; // 0x7e0(0x08)
	struct FName ShellEjectAttachPoint; // 0x7e8(0x08)
	struct UParticleSystem* ShellEjectFX; // 0x7f0(0x08)
	struct FVector ShellEjectLocationOffset; // 0x7f8(0x0c)
	struct FRotator ShellEjectRotationOffset; // 0x804(0x0c)
	char bLoopedShellEjectFX : 1; // 0x810(0x01)
	char bPlayShellEjectFXOnFireLast : 1; // 0x810(0x01)
	char pad_810_2 : 6; // 0x810(0x01)
	char pad_811[0x3]; // 0x811(0x03)
	float ShellEjectDelay; // 0x814(0x04)
	struct UParticleSystemComponent* ShellEjectPSC; // 0x818(0x08)
	char pad_820[0x10]; // 0x820(0x10)

	void UnloadCurrentAmmoClip(); // Function DonkehFramework.DFBaseGun.UnloadCurrentAmmoClip // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6cbfb0
	void StopSimulatingGunReload(); // Function DonkehFramework.DFBaseGun.StopSimulatingGunReload // (Native|Public|BlueprintCallable) // @ game+0x6cbf90
	void StartReload(bool bClientSimulation); // Function DonkehFramework.DFBaseGun.StartReload // (Native|Public|BlueprintCallable) // @ game+0x6cbf00
	void SimulateGunReload(); // Function DonkehFramework.DFBaseGun.SimulateGunReload // (Native|Public|BlueprintCallable) // @ game+0x6cbee0
	bool ShouldUseRecoil(); // Function DonkehFramework.DFBaseGun.ShouldUseRecoil // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cbeb0
	bool ShouldSimulateGunReload(); // Function DonkehFramework.DFBaseGun.ShouldSimulateGunReload // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cbe80
	void SetReloadState(enum class EGunReloadState NewReloadState); // Function DonkehFramework.DFBaseGun.SetReloadState // (Native|Protected|BlueprintCallable) // @ game+0x6cbe00
	void SetFireModeBP(enum class EFireMode NewFireMode); // Function DonkehFramework.DFBaseGun.SetFireModeBP // (Final|Native|Private|BlueprintCallable) // @ game+0x6cbd80
	bool SetFireMode(enum class EFireMode NewFireMode, bool bFromPlayerInput, bool bForce); // Function DonkehFramework.DFBaseGun.SetFireMode // (Native|Public|BlueprintCallable) // @ game+0x6cbc70
	void ServerStartReload(); // Function DonkehFramework.DFBaseGun.ServerStartReload // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x6cbc20
	void ServerSetFireMode(enum class EFireMode NewFireMode); // Function DonkehFramework.DFBaseGun.ServerSetFireMode // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6cbb70
	void ReceiveReloadStarted(); // Function DonkehFramework.DFBaseGun.ReceiveReloadStarted // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveReloadFinished(); // Function DonkehFramework.DFBaseGun.ReceiveReloadFinished // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveFireModeChanged(enum class EFireMode NewFireMode, enum class EFireMode PrevFireMode, bool bFromPlayerInput); // Function DonkehFramework.DFBaseGun.ReceiveFireModeChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveAmmoExhausted(); // Function DonkehFramework.DFBaseGun.ReceiveAmmoExhausted // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	float PlayWeaponStartReloadMontage(struct UAnimMontage* StartReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponStartReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6cb830
	float PlayWeaponReloadMontage(bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6cb790
	float PlayWeaponEndReloadMontage(struct UAnimMontage* EndReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponEndReloadMontage // (Final|Native|Public|BlueprintCallable) // @ game+0x6cb6c0
	float PlayReloadTransitionAnimations(bool bStartReload, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseGun.PlayReloadTransitionAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6cb5e0
	float PlayReloadAnimations(bool bDryReload, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseGun.PlayReloadAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6cb500
	void OnRep_SelectedFireMode(enum class EFireMode PrevSelectedFireMode); // Function DonkehFramework.DFBaseGun.OnRep_SelectedFireMode // (Native|Protected) // @ game+0x6cb480
	void OnRep_PendingReloadState(enum class EGunReloadState PrevReloadState); // Function DonkehFramework.DFBaseGun.OnRep_PendingReloadState // (Native|Public) // @ game+0x6cb400
	void OnRep_CurrentAmmoClip(struct ADFBaseAmmoClip* PrevAmmoClip); // Function DonkehFramework.DFBaseGun.OnRep_CurrentAmmoClip // (Native|Public) // @ game+0x6cb370
	void OnReload(bool bClientSimulation); // Function DonkehFramework.DFBaseGun.OnReload // (Native|Public|BlueprintCallable) // @ game+0x6cb2e0
	void LoadPreviousAmmoClip(); // Function DonkehFramework.DFBaseGun.LoadPreviousAmmoClip // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6cb2c0
	void LoadNextAmmoClip(); // Function DonkehFramework.DFBaseGun.LoadNextAmmoClip // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6cb2a0
	void LoadAmmoClip(struct ADFBaseAmmoClip* ClipToLoad); // Function DonkehFramework.DFBaseGun.LoadAmmoClip // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6cb210
	bool IsReloading(); // Function DonkehFramework.DFBaseGun.IsReloading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb1e0
	bool IsDryReloading(); // Function DonkehFramework.DFBaseGun.IsDryReloading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb1a0
	bool HasExhaustedAllAmmo(); // Function DonkehFramework.DFBaseGun.HasExhaustedAllAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb170
	bool HasAmmoClip(); // Function DonkehFramework.DFBaseGun.HasAmmoClip // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb140
	int32_t GetTotalAmmo(bool bIncludeLoadedMags); // Function DonkehFramework.DFBaseGun.GetTotalAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb0b0
	char GetSupportedFireModes(); // Function DonkehFramework.DFBaseGun.GetSupportedFireModes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb090
	struct FName GetShellEjectAttachPoint(); // Function DonkehFramework.DFBaseGun.GetShellEjectAttachPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb070
	enum class EFireMode GetSelectedFireMode(); // Function DonkehFramework.DFBaseGun.GetSelectedFireMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb050
	enum class EGunReloadState GetReloadState(); // Function DonkehFramework.DFBaseGun.GetReloadState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb030
	enum class EGunReloadState GetPreviousReloadState(); // Function DonkehFramework.DFBaseGun.GetPreviousReloadState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cb010
	int32_t GetNumFreeAmmoClips(bool bIncludeEmptyMags, bool bIncludeCurrentMag); // Function DonkehFramework.DFBaseGun.GetNumFreeAmmoClips // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6caf30
	struct FVector GetMuzzleLocation(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cae80
	struct FVector GetMuzzleDirection(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleDirection // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cadd0
	struct FName GetMuzzleAttachPoint(); // Function DonkehFramework.DFBaseGun.GetMuzzleAttachPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cadb0
	struct USceneComponent* GetMuzzleAttachComponent(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleAttachComponent // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cad10
	int32_t GetClipAmmo(); // Function DonkehFramework.DFBaseGun.GetClipAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cabc0
	bool CanReload(); // Function DonkehFramework.DFBaseGun.CanReload // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ca860
};

// Class DonkehFramework.DFBaseGun_Projectile
// Size: 0x858 (Inherited: 0x830)
struct ADFBaseGun_Projectile : ADFBaseGun {
	struct ADFBaseProjectile* ProjectileClass; // 0x830(0x08)
	float ProjectileSpawnDistance; // 0x838(0x04)
	float TargetTraceDistance; // 0x83c(0x04)
	bool bUseMuzzleAsTrace; // 0x840(0x01)
	char pad_841[0x3]; // 0x841(0x03)
	struct FVector MuzzleSightOffset; // 0x844(0x0c)
	struct FMulticastSparseDelegate OnProcessValidProjCSHit; // 0x850(0x01)
	char pad_851[0x7]; // 0x851(0x07)

	void ServerNotifyCSHitPredicted(struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHitPredicted // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x6cba60
	void ServerNotifyCSHit(struct ADFBaseProjectile* HitProj, struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHit // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x6cb900
	void ClientProjDebugInfo(struct ADFBaseProjectile* Proj, struct FVector NewProjLoc, struct FVector LastProjLoc, struct FRotator NewProjRot, struct FVector NewProjVel); // Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugInfo // (Net|NetReliableNative|Event|Public|HasDefaults|NetClient) // @ game+0x6caa40
	void ClientProjDebugImpactInfo(struct ADFBaseProjectile* Proj, struct FVector ImpactLoc, struct FVector_NetQuantizeNormal ImpactNorm); // Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugImpactInfo // (Net|NetReliableNative|Event|Public|HasDefaults|NetClient) // @ game+0x6ca940
	void ClientDrawDebugFireCone(struct FVector ConeOrig, struct FVector_NetQuantizeNormal ConeDir); // Function DonkehFramework.DFBaseGun_Projectile.ClientDrawDebugFireCone // (Net|NetReliableNative|Event|Public|HasDefaults|NetClient) // @ game+0x6ca890
	void CalcShotVector(struct FVector& OutProjOrigin, struct FVector& OutProjDir); // Function DonkehFramework.DFBaseGun_Projectile.CalcShotVector // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ca770
};

// Class DonkehFramework.DFBaseImpactEffect
// Size: 0x4e8 (Inherited: 0x220)
struct ADFBaseImpactEffect : AActor {
	struct TArray<struct FDecalData> ConcreteDecals; // 0x220(0x10)
	struct TArray<struct FDecalData> MetalSolidDecals; // 0x230(0x10)
	struct TArray<struct FDecalData> WoodDecals; // 0x240(0x10)
	struct TArray<struct FDecalData> GlassBPDecals; // 0x250(0x10)
	struct TArray<struct FDecalData> GlassDecals; // 0x260(0x10)
	struct TArray<struct FDecalData> GlassWHDecals; // 0x270(0x10)
	struct TArray<struct FDecalData> MetalThinDecals; // 0x280(0x10)
	struct TArray<struct FDecalData> SandbagDecals; // 0x290(0x10)
	struct TArray<struct FDecalData> BrickWallDecals; // 0x2a0(0x10)
	struct TArray<struct FDecalData> RubberDecals; // 0x2b0(0x10)
	struct TArray<struct FDecalData> DrywallDecals; // 0x2c0(0x10)
	struct TArray<struct FDecalData> ElectricDevicesDecals; // 0x2d0(0x10)
	struct TArray<struct FDecalData> OilBarrelDecals; // 0x2e0(0x10)
	struct UParticleSystem* SnowFX; // 0x2f0(0x08)
	struct UParticleSystem* WaterFX; // 0x2f8(0x08)
	struct UParticleSystem* ConcreteFX; // 0x300(0x08)
	struct UParticleSystem* DirtFX; // 0x308(0x08)
	struct UParticleSystem* MetalSolidFX; // 0x310(0x08)
	struct UParticleSystem* WoodFX; // 0x318(0x08)
	struct UParticleSystem* GlassBPFX; // 0x320(0x08)
	struct UParticleSystem* GlassFX; // 0x328(0x08)
	struct UParticleSystem* GlassWHFX; // 0x330(0x08)
	struct UParticleSystem* GrassFX; // 0x338(0x08)
	struct UParticleSystem* MetalThinFX; // 0x340(0x08)
	struct UParticleSystem* SandbagFX; // 0x348(0x08)
	struct UParticleSystem* BrickWallFX; // 0x350(0x08)
	struct UParticleSystem* RubberFX; // 0x358(0x08)
	struct UParticleSystem* DrywallFX; // 0x360(0x08)
	struct UParticleSystem* ElectricDevicesFX; // 0x368(0x08)
	struct UParticleSystem* OilBarrelFX; // 0x370(0x08)
	struct UParticleSystem* SandFX; // 0x378(0x08)
	struct UParticleSystem* SoftFX; // 0x380(0x08)
	struct UParticleSystem* GroundFX; // 0x388(0x08)
	struct UParticleSystem* RockFX; // 0x390(0x08)
	struct UParticleSystem* FleshFX; // 0x398(0x08)
	struct USoundCue* ConcreteSound; // 0x3a0(0x08)
	struct USoundCue* DirtSound; // 0x3a8(0x08)
	struct USoundCue* SnowSound; // 0x3b0(0x08)
	struct USoundCue* SandbagSound; // 0x3b8(0x08)
	struct USoundCue* BrickWallSound; // 0x3c0(0x08)
	struct USoundCue* WaterSound; // 0x3c8(0x08)
	struct USoundCue* MetalSolidSound; // 0x3d0(0x08)
	struct USoundCue* MetalThinSound; // 0x3d8(0x08)
	struct USoundCue* WoodSound; // 0x3e0(0x08)
	struct USoundCue* GlassSound; // 0x3e8(0x08)
	struct USoundCue* GlassBPSound; // 0x3f0(0x08)
	struct USoundCue* GlassWHSound; // 0x3f8(0x08)
	struct USoundCue* GrassSound; // 0x400(0x08)
	struct USoundCue* RubberSound; // 0x408(0x08)
	struct USoundCue* DrywallSound; // 0x410(0x08)
	struct USoundCue* GroundSound; // 0x418(0x08)
	struct USoundCue* ElectricDevicesSound; // 0x420(0x08)
	struct USoundCue* OilBarrelSound; // 0x428(0x08)
	struct USoundCue* RockSound; // 0x430(0x08)
	struct USoundCue* FleshSound; // 0x438(0x08)
	struct FDecalData DefaultDecal; // 0x440(0x10)
	struct UParticleSystem* DefaultFX; // 0x450(0x08)
	struct USoundCue* DefaultSound; // 0x458(0x08)
	struct FHitResult SurfaceHit; // 0x460(0x88)

	struct USoundCue* GetImpactSound(enum class EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBaseImpactEffect.GetImpactSound // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cac80
	struct UParticleSystem* GetImpactFX(enum class EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBaseImpactEffect.GetImpactFX // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cabf0
};

// Class DonkehFramework.DFBasePickup
// Size: 0x258 (Inherited: 0x220)
struct ADFBasePickup : AActor {
	char pad_220[0x8]; // 0x220(0x08)
	struct UStaticMeshComponent* Mesh; // 0x228(0x08)
	char bActive : 1; // 0x230(0x01)
	char pad_230_1 : 7; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct ADFBaseCharacter* InvokingPawn; // 0x238(0x08)
	char pad_240[0x8]; // 0x240(0x08)
	char bUseable : 1; // 0x248(0x01)
	char bOverlap : 1; // 0x248(0x01)
	char pad_248_2 : 6; // 0x248(0x01)
	char pad_249[0x3]; // 0x249(0x03)
	float RespawnDelay; // 0x24c(0x04)
	struct USoundCue* PickupSound; // 0x250(0x08)

	void UpdatePickupState(bool bNewActive); // Function DonkehFramework.DFBasePickup.UpdatePickupState // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x6d0730
	void RespawnPickup(); // Function DonkehFramework.DFBasePickup.RespawnPickup // (Native|Protected|BlueprintCallable) // @ game+0x6cfbf0
	void OnRespawn(); // Function DonkehFramework.DFBasePickup.OnRespawn // (Native|Event|Protected|BlueprintEvent) // @ game+0x6cf9f0
	void OnRep_Active(); // Function DonkehFramework.DFBasePickup.OnRep_Active // (Native|Protected) // @ game+0x6cf950
	void OnPickup(); // Function DonkehFramework.DFBasePickup.OnPickup // (Native|Event|Protected|BlueprintEvent) // @ game+0x6cf930
	void InitializePickup(); // Function DonkehFramework.DFBasePickup.InitializePickup // (Native|Event|Protected|BlueprintEvent) // @ game+0x643c50
	void GivePickupTo(struct ADFBaseCharacter* PickupOwner); // Function DonkehFramework.DFBasePickup.GivePickupTo // (Native|Event|Protected|BlueprintEvent) // @ game+0x6cf1c0
	bool CanBePickedUp(struct ADFBaseCharacter* Invoker); // Function DonkehFramework.DFBasePickup.CanBePickedUp // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ceb50
};

// Class DonkehFramework.DFBasePickup_Health
// Size: 0x260 (Inherited: 0x258)
struct ADFBasePickup_Health : ADFBasePickup {
	float Health; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
};

// Class DonkehFramework.DFBasePickup_Item
// Size: 0x260 (Inherited: 0x258)
struct ADFBasePickup_Item : ADFBasePickup {
	struct UDFInventoryComponent* Inventory; // 0x258(0x08)
};

// Class DonkehFramework.DFBasePlayerCharacter
// Size: 0x970 (Inherited: 0x910)
struct ADFBasePlayerCharacter : ADFBaseCharacter {
	float BaseTurnRate; // 0x908(0x04)
	float BaseLookUpRate; // 0x90c(0x04)
	float InteractionDistance; // 0x914(0x04)
	char bFirstPerson : 1; // 0x918(0x01)
	char pad_91C_1 : 7; // 0x91c(0x01)
	char pad_91D[0x3]; // 0x91d(0x03)
	struct UCameraComponent* Camera; // 0x920(0x08)
	struct USpringArmComponent* CameraBoom; // 0x928(0x08)
	struct UCameraComponent* Camera1P; // 0x930(0x08)
	char bStartInFirstPerson : 1; // 0x938(0x01)
	char bTrueFirstPerson : 1; // 0x938(0x01)
	char bDisableOrientationOfRotationToMovementInFirstPerson : 1; // 0x938(0x01)
	char bDisableUsageOfControllerRotationYawInThirdPerson : 1; // 0x938(0x01)
	char pad_938_4 : 4; // 0x938(0x01)
	char pad_939[0x7]; // 0x939(0x07)
	struct USkeletalMeshComponent* Mesh1P; // 0x940(0x08)
	char bUseFirstPersonMesh : 1; // 0x948(0x01)
	char pad_948_1 : 7; // 0x948(0x01)
	char pad_949[0x3]; // 0x949(0x03)
	struct FName ItemAttachPoint1P; // 0x94c(0x08)
	char pad_954[0x4]; // 0x954(0x04)
	struct FMulticastInlineDelegate OnPlayerToggleFirstPerson; // 0x958(0x10)
	char pad_968[0x8]; // 0x968(0x08)

	void Use(); // Function DonkehFramework.DFBasePlayerCharacter.Use // (Native|Protected|BlueprintCallable) // @ game+0x6d07c0
	void TurnAtRate(float Rate); // Function DonkehFramework.DFBasePlayerCharacter.TurnAtRate // (Native|Protected|BlueprintCallable) // @ game+0x6d06b0
	void SwitchFireMode(); // Function DonkehFramework.DFBasePlayerCharacter.SwitchFireMode // (Native|Protected|BlueprintCallable) // @ game+0x6d05f0
	void SetMeshVisibility(bool bFirstPersonVisibility); // Function DonkehFramework.DFBasePlayerCharacter.SetMeshVisibility // (Final|Native|Protected|BlueprintCallable) // @ game+0x6d04b0
	void ServerUse(); // Function DonkehFramework.DFBasePlayerCharacter.ServerUse // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d03d0
	void ServerOnToggleFirstPerson(bool bNewFirstPerson); // Function DonkehFramework.DFBasePlayerCharacter.ServerOnToggleFirstPerson // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6cff70
	struct USkeletalMesh* ReceiveGetDefaultPawnMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.ReceiveGetDefaultPawnMesh1P // (Event|Protected|BlueprintEvent|Const) // @ game+0xec54e0
	void OnToggleFirstPerson(bool bNewFirstPerson); // Function DonkehFramework.DFBasePlayerCharacter.OnToggleFirstPerson // (Final|Native|Protected) // @ game+0x6cfa10
	void OnFireReleased(); // Function DonkehFramework.DFBasePlayerCharacter.OnFireReleased // (Native|Protected|BlueprintCallable) // @ game+0x6cf860
	void OnFirePressed(); // Function DonkehFramework.DFBasePlayerCharacter.OnFirePressed // (Native|Protected|BlueprintCallable) // @ game+0x6cf820
	void MoveUp(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveUp // (Native|Protected|BlueprintCallable) // @ game+0x6cf640
	void MoveRight(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveRight // (Native|Protected|BlueprintCallable) // @ game+0x6cf5c0
	void MoveForward(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveForward // (Native|Protected|BlueprintCallable) // @ game+0x6cf540
	void LookUpAtRate(float Rate); // Function DonkehFramework.DFBasePlayerCharacter.LookUpAtRate // (Native|Protected|BlueprintCallable) // @ game+0x6cf4c0
	void JumpVaultPressed(); // Function DonkehFramework.DFBasePlayerCharacter.JumpVaultPressed // (Native|Protected|BlueprintCallable) // @ game+0x6cf4a0
	bool IsUsingFirstPersonMesh(); // Function DonkehFramework.DFBasePlayerCharacter.IsUsingFirstPersonMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf470
	bool IsTrueFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsTrueFirstPerson // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf410
	bool IsLocalFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsLocalFirstPerson // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf340
	bool IsFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsFirstPerson // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf2e0
	struct USkeletalMeshComponent* GetMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetMesh1P // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cef10
	struct FName GetItemAttachPoint1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetItemAttachPoint1P // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cedf0
	struct USkeletalMesh* GetDefaultPawnMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetDefaultPawnMesh1P // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cedc0
	struct USpringArmComponent* GetCameraBoom(); // Function DonkehFramework.DFBasePlayerCharacter.GetCameraBoom // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ceda0
	struct UCameraComponent* GetCamera1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetCamera1P // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ced60
	struct UCameraComponent* GetCamera(); // Function DonkehFramework.DFBasePlayerCharacter.GetCamera // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ced80
};

// Class DonkehFramework.DFBasePlayerController
// Size: 0x5f8 (Inherited: 0x570)
struct ADFBasePlayerController : APlayerController {
	char pad_570[0x8]; // 0x570(0x08)
	struct FMulticastInlineDelegate OnPossessPawn; // 0x578(0x10)
	struct FMulticastInlineDelegate OnUnpossessPawn; // 0x588(0x10)
	char pad_598[0x8]; // 0x598(0x08)
	struct ADFBaseCharacter* DFCharacter; // 0x5a0(0x08)
	char pad_5A8[0x18]; // 0x5a8(0x18)
	char bSetGameOnlyInputOnBeginPlay : 1; // 0x5c0(0x01)
	char pad_5C0_1 : 7; // 0x5c0(0x01)
	char pad_5C1[0x7]; // 0x5c1(0x07)
	struct FMulticastInlineDelegate OnPlayerTeamNumUpdated; // 0x5c8(0x10)
	struct FMulticastInlineDelegate OnPlayerTeamStateUpdated; // 0x5d8(0x10)
	struct ADFTeamState* TeamState; // 0x5e8(0x08)
	int32_t MaxChatMsgLen; // 0x5f0(0x04)
	char pad_5F4[0x4]; // 0x5f4(0x04)

	void TeamSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.TeamSay // (Final|Exec|Native|Private|BlueprintCallable) // @ game+0x6d0610
	void ServerTeamSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.ServerTeamSay // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d0310
	void ServerSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.ServerSay // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6d0030
	void ServerNotifyProjCSHit(struct ADFBaseProjectile* HitProj, struct APawn* HitProjDamageInstigator, struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBasePlayerController.ServerNotifyProjCSHit // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x6cfdc0
	void ServerEnableCheats(); // Function DonkehFramework.DFBasePlayerController.ServerEnableCheats // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6cfd70
	void ServerAdmin(struct FString Cmd); // Function DonkehFramework.DFBasePlayerController.ServerAdmin // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x6cfcb0
	void Say(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.Say // (Final|Exec|Native|Private|BlueprintCallable) // @ game+0x6cfc10
	void ReceiveUnpossessPawn(struct APawn* UnpossessedPawn); // Function DonkehFramework.DFBasePlayerController.ReceiveUnpossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePreClientTravel(struct FString PendingURL, bool bIsSeamlessTravelWithRelativeTravelType); // Function DonkehFramework.DFBasePlayerController.ReceivePreClientTravel // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePossessPawn(struct APawn* NewPawn); // Function DonkehFramework.DFBasePlayerController.ReceivePossessPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlayerTeamStateUpdated(struct ADFTeamState* LastTeamState, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlayerTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamNumUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnRepPlayerState(); // Function DonkehFramework.DFBasePlayerController.ReceiveOnRepPlayerState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveNewChatMsg(struct FPlayerChatMsg& ChatMsg); // Function DonkehFramework.DFBasePlayerController.ReceiveNewChatMsg // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFBasePlayerController.ReceiveGameHasEnded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnFireReleased(); // Function DonkehFramework.DFBasePlayerController.OnFireReleased // (Native|Protected|BlueprintCallable) // @ game+0x6cf880
	void OnFirePressed(); // Function DonkehFramework.DFBasePlayerController.OnFirePressed // (Native|Protected|BlueprintCallable) // @ game+0x6cf840
	bool IsServerAdministrator(); // Function DonkehFramework.DFBasePlayerController.IsServerAdministrator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf3e0
	bool IsGameInputAllowed(); // Function DonkehFramework.DFBasePlayerController.IsGameInputAllowed // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x6cf310
	struct FTimerHandle GetUnFreezeTimerHandle(); // Function DonkehFramework.DFBasePlayerController.GetUnFreezeTimerHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6cf1a0
	void ClientEnableCheats(); // Function DonkehFramework.DFBasePlayerController.ClientEnableCheats // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x6cece0
	void Admin(struct FString Cmd); // Function DonkehFramework.DFBasePlayerController.Admin // (Final|Exec|Native|Public) // @ game+0x6cea80
};

// Class DonkehFramework.DFBasePlayerState
// Size: 0x378 (Inherited: 0x320)
struct ADFBasePlayerState : APlayerState {
	char pad_320[0x8]; // 0x320(0x08)
	struct FMulticastInlineDelegate OnRepPlayerName; // 0x328(0x10)
	struct FMulticastInlineDelegate OnPlayerTeamNumUpdated; // 0x338(0x10)
	char TeamNum; // 0x348(0x01)
	char PrevTeamNum; // 0x349(0x01)
	char pad_34A[0x6]; // 0x34a(0x06)
	struct ADFTeamState* TeamState; // 0x350(0x08)
	struct ADFTeamState* PrevTeamState; // 0x358(0x08)
	char bAdmin : 1; // 0x360(0x01)
	char pad_360_1 : 7; // 0x360(0x01)
	char pad_361[0x3]; // 0x361(0x03)
	int32_t NumKills; // 0x364(0x04)
	int32_t NumAssists; // 0x368(0x04)
	int32_t NumDeaths; // 0x36c(0x04)
	int32_t TeamStartTime; // 0x370(0x04)
	char pad_374[0x4]; // 0x374(0x04)

	void SetTeam(char NewTeamNum, bool bCopyToInactivePlayerState); // Function DonkehFramework.DFBasePlayerState.SetTeam // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d5020
	void SetAdminStatus(bool bNewAdminStatus); // Function DonkehFramework.DFBasePlayerState.SetAdminStatus // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d4f00
	void ScorePoints(float Points, bool bForceNetUpdate); // Function DonkehFramework.DFBasePlayerState.ScorePoints // (BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x6d4c40
	void ScoreKillPlayer(struct ADFBasePlayerState* Victim, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreKillPlayer // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d4b70
	void ScoreDeath(struct ADFBasePlayerState* KilledBy, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreDeath // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d4aa0
	void ScoreAssistPlayer(struct ADFBasePlayerState* Killer, struct ADFBasePlayerState* Victim, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreAssistPlayer // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6d49a0
	void ReceiveOnRepPlayerName(); // Function DonkehFramework.DFBasePlayerState.ReceiveOnRepPlayerName // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnTeamStateUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0x6d3b50
	void OnTeamNumUpdated(char TeamNumBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnTeamNumUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0x6d3ad0
	void OnRep_TeamState(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_TeamState // (Native|Protected) // @ game+0x6d3930
	void OnRep_TeamNum(char TeamNumBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_TeamNum // (Native|Protected) // @ game+0x6d38b0
	void OnRep_NumKills(int32_t PrevNumKills); // Function DonkehFramework.DFBasePlayerState.OnRep_NumKills // (Native|Protected) // @ game+0x6d3820
	void OnRep_NumDeaths(int32_t PrevNumDeaths); // Function DonkehFramework.DFBasePlayerState.OnRep_NumDeaths // (Native|Protected) // @ game+0x6d3790
	void OnRep_NumAssists(int32_t PrevNumAssists); // Function DonkehFramework.DFBasePlayerState.OnRep_NumAssists // (Native|Protected) // @ game+0x6d3700
	void OnRep_bAdmin(bool bAdminStatusBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_bAdmin // (Native|Protected) // @ game+0x6d39c0
	char GetTeam(); // Function DonkehFramework.DFBasePlayerState.GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d33c0
	char GetPreviousTeam(); // Function DonkehFramework.DFBasePlayerState.GetPreviousTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3340
	int32_t GetKills(); // Function DonkehFramework.DFBasePlayerState.GetKills // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3190
	int32_t GetDeaths(); // Function DonkehFramework.DFBasePlayerState.GetDeaths // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3130
	int32_t GetAssists(); // Function DonkehFramework.DFBasePlayerState.GetAssists // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3110
};

// Class DonkehFramework.DFBaseProjectile
// Size: 0x380 (Inherited: 0x220)
struct ADFBaseProjectile : AActor {
	struct UProjectileMovementComponent* ProjectileMovement; // 0x220(0x08)
	struct ADFBaseImpactEffect* ProjectileImpactFXClass; // 0x228(0x08)
	struct FTransform SpawnTransform; // 0x230(0x30)
	int32_t ShotID; // 0x260(0x04)
	struct FVector LastLoc; // 0x264(0x0c)
	char bSpawnImpactFXOnHit : 1; // 0x270(0x01)
	char bAlwaysShootable : 1; // 0x270(0x01)
	char bIgnoreInstigator : 1; // 0x270(0x01)
	char bIgnoreInstigatorOnPayloadActivation : 1; // 0x270(0x01)
	char pad_270_4 : 4; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct AController* InstigatingController; // 0x278(0x08)
	char bDebug : 1; // 0x280(0x01)
	char pad_280_1 : 7; // 0x280(0x01)
	struct FMulticastSparseDelegate OnProcessValidHit; // 0x281(0x01)
	char bIgnoreInstigatorHitEventsOnly : 1; // 0x282(0x01)
	char bProcessedAHit : 1; // 0x282(0x01)
	char bClientSideHitDetectionEnabled : 1; // 0x282(0x01)
	char bClientSideHitDamageEnabled : 1; // 0x282(0x01)
	char bNotifyOfPredictedProjectileHits : 1; // 0x282(0x01)
	char bOnlyNotifyOfPredictedProjectileHits : 1; // 0x282(0x01)
	char pad_282_6 : 2; // 0x282(0x01)
	char pad_283[0x1]; // 0x283(0x01)
	struct FCSHitInfo PendingHitInfo; // 0x284(0x70)
	char pad_2F4[0x4]; // 0x2f4(0x04)
	struct AActor* ImpactedActor; // 0x2f8(0x08)
	char bApplyDamageOnImpact : 1; // 0x300(0x01)
	char bApplyDamageOnBounceImpact : 1; // 0x300(0x01)
	char bApplyDamageToInstigator : 1; // 0x300(0x01)
	char pad_300_3 : 5; // 0x300(0x01)
	char pad_301[0x3]; // 0x301(0x03)
	struct FDFDamageParams BaseDamageParams; // 0x304(0x14)
	struct UDamageType* WeaponDamageTypeClass; // 0x318(0x08)
	struct FVector RadialDamageOriginOffset; // 0x320(0x0c)
	enum class ECollisionChannel RadialDamagePreventionChannel; // 0x32c(0x01)
	char bWantsToUseClientSidePrediction : 1; // 0x32d(0x01)
	char bReconcilePredictedProjWithServerProj : 1; // 0x32d(0x01)
	char bPredictedClientProjectile : 1; // 0x32d(0x01)
	char pad_32D_3 : 5; // 0x32d(0x01)
	char pad_32E[0x2]; // 0x32e(0x02)
	struct ADFBaseProjectile* MyPredictedClientProjectile; // 0x330(0x08)
	struct ADFBaseProjectile* ServerAuthoritativeProjectile; // 0x338(0x08)
	char pad_340[0x31]; // 0x340(0x31)
	struct FMulticastSparseDelegate OnTriggerPayload; // 0x371(0x01)
	char bPayloadTriggered : 1; // 0x372(0x01)
	char bTriggerPayloadWhenStopped : 1; // 0x372(0x01)
	char bTearOffOnPayloadActivation : 1; // 0x372(0x01)
	char bDisableOnPayloadActivation : 1; // 0x372(0x01)
	char pad_372_4 : 4; // 0x372(0x01)
	char pad_373[0xd]; // 0x373(0x0d)

	void TriggerPayload(struct FHitResult& ImpactHitResult, bool bFromTearOff); // Function DonkehFramework.DFBaseProjectile.TriggerPayload // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d54b0
	void SpawnImpactFX(struct FHitResult& Impact); // Function DonkehFramework.DFBaseProjectile.SpawnImpactFX // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d5140
	void SetProjectileUpdatedComponent(struct USceneComponent* NewProjectileUpdatedComponent); // Function DonkehFramework.DFBaseProjectile.SetProjectileUpdatedComponent // (Native|Public|BlueprintCallable) // @ game+0x6d4f90
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectile.ReceivePayloadActivated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ProjectileStop(struct FHitResult& ImpactResult); // Function DonkehFramework.DFBaseProjectile.ProjectileStop // (Native|Protected|HasOutParms) // @ game+0x6d47e0
	void ProjectileBounce(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function DonkehFramework.DFBaseProjectile.ProjectileBounce // (Native|Protected|HasOutParms|HasDefaults) // @ game+0x6d4580
	bool K2_ShouldIgnoreHit(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult& HitResult); // Function DonkehFramework.DFBaseProjectile.K2_ShouldIgnoreHit // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
	void K2_PostProcessValidHit(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector& HitLocation, struct FVector& HitNormal, struct FHitResult& HitResult, bool bFromCSHitNotify); // Function DonkehFramework.DFBaseProjectile.K2_PostProcessValidHit // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0xec54e0
	void IgnoreInstigatorWhenMoving(bool bShouldIgnore, bool bBidirectional); // Function DonkehFramework.DFBaseProjectile.IgnoreInstigatorWhenMoving // (Final|Native|Public|BlueprintCallable) // @ game+0x6d3560
	bool HasValidPredictedClientProjectile(); // Function DonkehFramework.DFBaseProjectile.HasValidPredictedClientProjectile // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d34e0
	struct UPrimitiveComponent* GetProjectileUpdatedPrimitive(); // Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedPrimitive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3390
	struct USceneComponent* GetProjectileUpdatedComponent(); // Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedComponent // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3360
	struct ADFBaseWeapon* GetOwningWeapon(); // Function DonkehFramework.DFBaseProjectile.GetOwningWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3310
	struct ADFBaseImpactEffect* GetImpactFXClass(); // Function DonkehFramework.DFBaseProjectile.GetImpactFXClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3150
	struct FDFDamageParams GetAdjustedDamageParams(struct AActor* OtherActor, struct FVector& HitLocation); // Function DonkehFramework.DFBaseProjectile.GetAdjustedDamageParams // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d2ec0
	void DisableAndDeferDestroy(); // Function DonkehFramework.DFBaseProjectile.DisableAndDeferDestroy // (Native|Public|BlueprintCallable) // @ game+0x6cf950
	float ApplyDamageToImpactedActor(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector& HitLocation, struct FVector& HitNormal, struct FHitResult& HitResult); // Function DonkehFramework.DFBaseProjectile.ApplyDamageToImpactedActor // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x6d2cc0
};

// Class DonkehFramework.DFBaseProjectileLegacy
// Size: 0x340 (Inherited: 0x220)
struct ADFBaseProjectileLegacy : AActor {
	struct UPrimitiveComponent* ProjectileCollision; // 0x220(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0x228(0x08)
	struct ADFBaseImpactEffect* ProjectileImpactFXClass; // 0x230(0x08)
	char pad_238[0x8]; // 0x238(0x08)
	struct FTransform SpawnTransform; // 0x240(0x30)
	struct FVector LastLoc; // 0x270(0x0c)
	char bListenForImpactEvents : 1; // 0x27c(0x01)
	char bIgnoreInstigator : 1; // 0x27c(0x01)
	char pad_27C_2 : 6; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	struct AController* InstigatingController; // 0x280(0x08)
	float ActiveLifeSpan; // 0x288(0x04)
	char pad_28C[0xc]; // 0x28c(0x0c)
	struct UDamageType* WeaponDamageTypeClass; // 0x298(0x08)
	char bDebug : 1; // 0x2a0(0x01)
	char bApplyDamageFromPayload : 1; // 0x2a0(0x01)
	char pad_2A0_2 : 6; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float HitDamage; // 0x2a4(0x04)
	char bApplyRadialDamage : 1; // 0x2a8(0x01)
	char pad_2A8_1 : 7; // 0x2a8(0x01)
	char pad_2A9[0x3]; // 0x2a9(0x03)
	struct FVector RadialDamageLocOffset; // 0x2ac(0x0c)
	enum class ECollisionChannel RadialDamagePreventionChannel; // 0x2b8(0x01)
	char pad_2B9[0x3]; // 0x2b9(0x03)
	float DamageRadius; // 0x2bc(0x04)
	char bPayloadTriggered : 1; // 0x2c0(0x01)
	char bTriggerPayloadWhenStopped : 1; // 0x2c0(0x01)
	char bTriggerPayloadOnDelay : 1; // 0x2c0(0x01)
	char pad_2C0_3 : 5; // 0x2c0(0x01)
	char pad_2C1[0x3]; // 0x2c1(0x03)
	float PayloadTriggerDelay; // 0x2c4(0x04)
	struct UParticleSystem* PayloadTriggerFX; // 0x2c8(0x08)
	char bAttachTriggerFXToRoot : 1; // 0x2d0(0x01)
	char pad_2D0_1 : 7; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct UParticleSystemComponent* TriggerFXPSC; // 0x2d8(0x08)
	struct USoundBase* PayloadTriggerSnd; // 0x2e0(0x08)
	char bAttachTriggerSndToRoot : 1; // 0x2e8(0x01)
	char pad_2E8_1 : 7; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct UAudioComponent* TriggerSnd; // 0x2f0(0x08)
	char pad_2F8[0x48]; // 0x2f8(0x48)

	void TriggerPayload(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectileLegacy.TriggerPayload // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d55e0
	void StopSimulatingPayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.StopSimulatingPayloadActivation // (Native|Protected|BlueprintCallable) // @ game+0x6cfaa0
	void SpawnImpactFX(struct FHitResult& Impact); // Function DonkehFramework.DFBaseProjectileLegacy.SpawnImpactFX // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6d5220
	void SimulatePayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.SimulatePayloadActivation // (Native|Protected|BlueprintCallable) // @ game+0x6cf950
	void ReceiveStopSimulatingPayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.ReceiveStopSimulatingPayloadActivation // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSimulatePayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.ReceiveSimulatePayloadActivation // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectileLegacy.ReceivePayloadActivated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ProjectileStop(struct FHitResult& ImpactResult); // Function DonkehFramework.DFBaseProjectileLegacy.ProjectileStop // (Native|Protected|HasOutParms) // @ game+0x6d48c0
	void ProjectileBounce(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function DonkehFramework.DFBaseProjectileLegacy.ProjectileBounce // (Native|Protected|HasOutParms|HasDefaults) // @ game+0x6d46b0
	void PayloadDelayElapsed(); // Function DonkehFramework.DFBaseProjectileLegacy.PayloadDelayElapsed // (Native|Protected) // @ game+0x643c70
	void OnRep_bPayloadTriggered(); // Function DonkehFramework.DFBaseProjectileLegacy.OnRep_bPayloadTriggered // (Native|Protected) // @ game+0x6d3a50
	struct ADFBaseWeapon* GetOwningWeapon(); // Function DonkehFramework.DFBaseProjectileLegacy.GetOwningWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6d3310
};

// Class DonkehFramework.DFBlueprintFunctions
// Size: 0x28 (Inherited: 0x28)
struct UDFBlueprintFunctions : UBlueprintFunctionLibrary {

	bool WasShotFired(struct FRepShotInfo& Counter, struct FRepShotInfo& OtherCounter); // Function DonkehFramework.DFBlueprintFunctions.WasShotFired // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6dc330
	void TransferInventoryItems(struct UDFInventoryComponent* FromInv, struct UDFInventoryComponent* ToInv, bool bKeepLoadedAmmo); // Function DonkehFramework.DFBlueprintFunctions.TransferInventoryItems // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x6dc230
	bool TextIsEmptyOrWhitespace(struct FText& InText); // Function DonkehFramework.DFBlueprintFunctions.TextIsEmptyOrWhitespace // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6dc160
	struct ADFBaseImpactEffect* SpawnImpactFXFromHitResult(struct UObject* WorldContextObject, struct ADFBaseImpactEffect* ImpactClass, struct FHitResult& Impact); // Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromHitResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6dbff0
	struct ADFBaseImpactEffect* SpawnImpactFXFromDamageEvent(struct UObject* WorldContextObject, struct ADFBaseImpactEffect* ImpactClass, float DamageTaken, struct FDamageEvent& DamageEvent, struct AActor* HitActor, struct AActor* HitInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromDamageEvent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6dbde0
	void SetTeamNum(struct AActor* Target, char NewTeamNum); // Function DonkehFramework.DFBlueprintFunctions.SetTeamNum // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6dbd30
	void SetStartSpot(struct AController* Controller, struct AActor* NewStartSpot); // Function DonkehFramework.DFBlueprintFunctions.SetStartSpot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6dbc80
	void SetNetAddressable(struct UActorComponent* ActorComp); // Function DonkehFramework.DFBlueprintFunctions.SetNetAddressable // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6dbc10
	void ResetPlayerVoiceTalker(struct APlayerState* InPlayerState); // Function DonkehFramework.DFBlueprintFunctions.ResetPlayerVoiceTalker // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6dbba0
	void ResetAllPlayerVoiceTalkers(); // Function DonkehFramework.DFBlueprintFunctions.ResetAllPlayerVoiceTalkers // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6dbb80
	void PrintTextToLog(struct UObject* WorldContextObject, struct FText InText, enum class ELogVerbosityBP InLogVerbosity, bool bPrintStackTrace); // Function DonkehFramework.DFBlueprintFunctions.PrintTextToLog // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6db9e0
	void PrintStringToLog(struct UObject* WorldContextObject, struct FString inString, enum class ELogVerbosityBP InLogVerbosity, bool bPrintStackTrace); // Function DonkehFramework.DFBlueprintFunctions.PrintStringToLog // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6db890
	bool IsVOIPTalkerStillAlive(struct UVOIPTalker* InTalker); // Function DonkehFramework.DFBlueprintFunctions.IsVOIPTalkerStillAlive // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6db730
	bool IsValidActor(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.IsValidActor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db7b0
	bool IsPlayInEditor(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.IsPlayInEditor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db570
	bool IsPlayerTalking(struct APlayerState* PlayerPS); // Function DonkehFramework.DFBlueprintFunctions.IsPlayerTalking // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db6b0
	bool IsPlayerMuted(struct APlayerController* PC, struct APlayerState* PSToCheck); // Function DonkehFramework.DFBlueprintFunctions.IsPlayerMuted // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db5f0
	bool IsPendingKillPending(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.IsPendingKillPending // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db490
	bool IsLocallyPlayerControlled(struct APawn* Pawn); // Function DonkehFramework.DFBlueprintFunctions.IsLocallyPlayerControlled // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db410
	bool IsEmptyOrWhitespace(struct FString inString); // Function DonkehFramework.DFBlueprintFunctions.IsEmptyOrWhitespace // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db370
	bool HasOptions(struct FString Options, struct TArray<struct FString>& Keys, bool bMatchAll); // Function DonkehFramework.DFBlueprintFunctions.HasOptions // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6db1b0
	bool HasFiringStopped(struct FRepShotInfo& Counter); // Function DonkehFramework.DFBlueprintFunctions.HasFiringStopped // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6db110
	struct AWorldSettings* GetWorldSettings(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetWorldSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db090
	struct UVOIPTalker* GetVOIPTalkerForPlayer(struct APlayerState* InPlayerState); // Function DonkehFramework.DFBlueprintFunctions.GetVOIPTalkerForPlayer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6daf90
	enum class ESlateVisibility GetVisibilityDefault(struct UWidget* Widget); // Function DonkehFramework.DFBlueprintFunctions.GetVisibilityDefault // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6db010
	struct ADFTeamState* GetTeamStateFromTeamId(struct UObject* WorldContextObject, char TeamIdNum); // Function DonkehFramework.DFBlueprintFunctions.GetTeamStateFromTeamId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6daed0
	char GetTeamNum(struct AActor* Target); // Function DonkehFramework.DFBlueprintFunctions.GetTeamNum // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6dae50
	struct FVector GetTargetLocation(struct AActor* Actor, struct AActor* RequestedBy); // Function DonkehFramework.DFBlueprintFunctions.GetTargetLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6dad50
	struct FName GetSurfaceName(enum class EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBlueprintFunctions.GetSurfaceName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6dacd0
	struct AActor* GetStartSpot(struct AController* Controller); // Function DonkehFramework.DFBlueprintFunctions.GetStartSpot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6dac50
	int32_t GetShotCounterBPCompat(struct FRepShotInfo& Counter); // Function DonkehFramework.DFBlueprintFunctions.GetShotCounterBPCompat // (Final|Native|Static|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6dabc0
	struct FString GetPluginFriendlyName(struct FString PluginName); // Function DonkehFramework.DFBlueprintFunctions.GetPluginFriendlyName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6daae0
	int32_t GetNumShotsFiredBPCompat(struct FRepShotInfo& Counter, struct FRepShotInfo& PreviousCounter); // Function DonkehFramework.DFBlueprintFunctions.GetNumShotsFiredBPCompat // (Final|Native|Static|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6da9c0
	struct FText GetMapNameForDisplay(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetMapNameForDisplay // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6da8e0
	struct FString GetMapName(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetMapName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6da810
	bool GetMapAssetVisibleInMapSelectUI(struct FPrimaryAssetId& WorldAssetId, bool& bOutVisibleInMapSelectUI); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetVisibleInMapSelectUI // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da710
	bool GetMapAssetSupportedGameModes(struct FPrimaryAssetId& WorldAssetId, struct TSet<struct TSoftClassPtr<UObject>>& OutSupportedGameModes); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetSupportedGameModes // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da5b0
	bool GetMapAssetPreviewImg(struct FPrimaryAssetId& WorldAssetId, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewImg // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da490
	bool GetMapAssetPreviewBannerImg(struct FPrimaryAssetId& WorldAssetId, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewBannerImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewBannerImg // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da370
	struct FText GetMapAssetNameForDisplay(struct FPrimaryAssetId& WorldAssetId); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetNameForDisplay // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da280
	bool GetMapAssetGameRulesetClasses(struct FPrimaryAssetId& WorldAssetId, struct TSet<struct TSoftClassPtr<UObject>>& OutGameRulesetClasses); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetGameRulesetClasses // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da120
	bool GetMapAssetDescription(struct FPrimaryAssetId& WorldAssetId, struct FString& OutMapDescription); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDescription // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6da010
	bool GetMapAssetDefaultGameMode(struct FPrimaryAssetId& WorldAssetId, struct TSoftClassPtr<UObject>& OutDefaultGameModeRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDefaultGameMode // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6d9ef0
	bool GetMapAssetDataSupportedGameModes(struct FAssetData& WorldAsset, struct TSet<struct TSoftClassPtr<UObject>>& OutSupportedGameModes); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataSupportedGameModes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d9b50
	bool GetMapAssetDataPreviewImg(struct FAssetData& WorldAsset, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewImg // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d9880
	bool GetMapAssetDataPreviewBannerImg(struct FAssetData& WorldAsset, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewBannerImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewBannerImg // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d95b0
	struct FText GetMapAssetDataNameForDisplay(struct FAssetData& WorldAsset); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataNameForDisplay // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d93c0
	bool GetMapAssetDataGameRulesetClasses(struct FAssetData& WorldAsset, struct TSet<struct TSoftClassPtr<UObject>>& OutGameRulesetClasses); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataGameRulesetClasses // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d9020
	bool GetMapAssetDataDisplayName(struct FAssetData& WorldAsset, struct FText& OutMapDisplayName); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d8e80
	bool GetMapAssetDataDescription(struct FAssetData& WorldAsset, struct FString& OutMapDescription); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDescription // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d8d10
	bool GetMapAssetDataDefaultGameMode(struct FAssetData& WorldAsset, struct TSoftClassPtr<UObject>& OutDefaultGameModeRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDefaultGameMode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d8a80
	struct FString GetGlobalDefaultGameMode(); // Function DonkehFramework.DFBlueprintFunctions.GetGlobalDefaultGameMode // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d8a00
	struct FString GetGameVersion(); // Function DonkehFramework.DFBlueprintFunctions.GetGameVersion // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d8980
	struct FText GetGameNameForDisplay(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetGameNameForDisplay // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d88a0
	struct FString GetGameModeForName(struct FString GameModeName); // Function DonkehFramework.DFBlueprintFunctions.GetGameModeForName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d87c0
	struct FString GetGameModeForMapName(struct FString MapName); // Function DonkehFramework.DFBlueprintFunctions.GetGameModeForMapName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d86e0
	struct FString GetGameDefaultMap(); // Function DonkehFramework.DFBlueprintFunctions.GetGameDefaultMap // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d8660
	struct FString GetGameBuildInfo(); // Function DonkehFramework.DFBlueprintFunctions.GetGameBuildInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d85e0
	struct FVector GetFocalPoint(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.GetFocalPoint // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6d8520
	void GetDefaultBoundingCylinder(struct AActor* Actor, float& CylinderRadius, float& CylinderHalfHeight); // Function DonkehFramework.DFBlueprintFunctions.GetDefaultBoundingCylinder // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d8400
	struct FString GetCopyrightNotice(); // Function DonkehFramework.DFBlueprintFunctions.GetCopyrightNotice // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d8380
	struct TArray<struct FString> GetAllMapNames(); // Function DonkehFramework.DFBlueprintFunctions.GetAllMapNames // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d8090
	void GameHasEnded(struct AController* Controller, struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFBlueprintFunctions.GameHasEnded // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6d7f90
	void FlushPressedKeys(struct APlayerController* PC); // Function DonkehFramework.DFBlueprintFunctions.FlushPressedKeys // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6d7f20
	struct FPrimaryAssetId FindMapIdByDisplayName(struct FText& MapDisplayName, struct TArray<struct FPrimaryAssetId>& MapIds); // Function DonkehFramework.DFBlueprintFunctions.FindMapIdByDisplayName // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6d7dc0
	bool EqualEqual_WeaponSoundCollection(struct FWeaponSoundCollection& A, struct FWeaponSoundCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponSoundCollection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d7b90
	bool EqualEqual_WeaponAnimSequence(struct FWeaponAnimSequence& A, struct FWeaponAnimSequence& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimSequence // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_WeaponAnimMontage(struct FWeaponAnimMontage& A, struct FWeaponAnimMontage& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimMontage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_WeaponAnimCollection(struct FWeaponAnimCollection& A, struct FWeaponAnimCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimCollection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d79f0
	bool EqualEqual_WeaponAnim(struct FWeaponAnim& A, struct FWeaponAnim& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnim // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_PerspectiveSound(struct FPerspectiveSound& A, struct FPerspectiveSound& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveSound // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_PerspectiveAnimSequence(struct FPerspectiveAnimSequence& A, struct FPerspectiveAnimSequence& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnimSequence // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_PerspectiveAnim(struct FPerspectiveAnim& A, struct FPerspectiveAnim& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnim // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_CharacterSoundCollection(struct FCharacterSoundCollection& A, struct FCharacterSoundCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterSoundCollection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d78e0
	bool EqualEqual_CharacterAnimCollection(struct FCharacterAnimCollection& A, struct FCharacterAnimCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterAnimCollection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6d76e0
	bool DoesMapIDSupportGMDefinition(struct FPrimaryAssetId& MapId, struct UDFGameModeDefinition* GMDef); // Function DonkehFramework.DFBlueprintFunctions.DoesMapIDSupportGMDefinition // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6d75f0
	bool CharacterVariationIsValid(struct FDFCharacterVariationDataHandle VariationData); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationIsValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d7500
	struct FDFCharacterVariationData CharacterVariationGetData(struct FDFCharacterVariationDataHandle VariationData); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationGetData // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d7380
	struct FDFCharacterVariationDataHandle CharacterVariationDataFromTableRow(struct UObject* WorldContextObject, struct FDataTableRowHandle RowHandle); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationDataFromTableRow // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6d7220
	void Array_UInt8Sort(struct TArray<char>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_UInt8Sort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d7130
	void Array_TextSort(struct TArray<struct FText>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_TextSort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6ff0
	void Array_StringSort(struct TArray<struct FString>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_StringSort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6ee0
	void Array_Reverse(struct TArray<int32_t>& TargetArray); // Function DonkehFramework.DFBlueprintFunctions.Array_Reverse // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6e40
	void Array_NameSort(struct TArray<struct FName>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_NameSort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6d50
	void Array_Int64Sort(struct TArray<int64_t>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_Int64Sort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6c60
	void Array_Int32Sort(struct TArray<int32_t>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_Int32Sort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6b70
	void Array_FloatSort(struct TArray<float>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_FloatSort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6a80
	void Array_AssetDescriptorSort(struct TArray<struct FAssetDescriptor>& ArrayToSort, bool bDescending, bool bCompareDisplayText); // Function DonkehFramework.DFBlueprintFunctions.Array_AssetDescriptorSort // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6d6900
};

// Class DonkehFramework.DFCharacterLeanHandler
// Size: 0x280 (Inherited: 0x28)
struct UDFCharacterLeanHandler : UObject {
	struct FRuntimeFloatCurve StationaryStandLeanCurve; // 0x28(0x88)
	struct FRuntimeFloatCurve MobileStandLeanCurve; // 0xb0(0x88)
	struct FRuntimeFloatCurve StationaryCrouchLeanCurve; // 0x138(0x88)
	struct FRuntimeFloatCurve MobileCrouchLeanCurve; // 0x1c0(0x88)
	float LeanTransitionSpeed; // 0x248(0x04)
	float StandLeanInYOffset; // 0x24c(0x04)
	float CrouchLeanInYOffset; // 0x250(0x04)
	float LeanRollAmount; // 0x254(0x04)
	enum class ELeanDirection LeanDirection; // 0x258(0x01)
	char pad_259[0x3]; // 0x259(0x03)
	float LeanTarget; // 0x25c(0x04)
	char bAtFullLeanTarget : 1; // 0x260(0x01)
	char pad_260_1 : 7; // 0x260(0x01)
	char pad_261[0x3]; // 0x261(0x03)
	float LeanAmount; // 0x264(0x04)
	char pad_268[0x18]; // 0x268(0x18)

	void UpdateLeanDirection(enum class ELeanDirection NewLeanDir); // Function DonkehFramework.DFCharacterLeanHandler.UpdateLeanDirection // (Final|Native|Public|BlueprintCallable) // @ game+0x6e0610
	void ReceiveTick(float DeltaTime); // Function DonkehFramework.DFCharacterLeanHandler.ReceiveTick // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveReset(); // Function DonkehFramework.DFCharacterLeanHandler.ReceiveReset // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsMoving(); // Function DonkehFramework.DFCharacterLeanHandler.IsMoving // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfb20
	bool IsLeaning(); // Function DonkehFramework.DFCharacterLeanHandler.IsLeaning // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfac0
	enum class ECharacterStance GetStance(); // Function DonkehFramework.DFCharacterLeanHandler.GetStance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df990
	enum class ECharacterStance GetPreviousStance(); // Function DonkehFramework.DFCharacterLeanHandler.GetPreviousStance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df920
	struct UDFCharacterMovementComponent* GetOwningCharacterMovement(); // Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacterMovement // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df8f0
	struct ADFBaseCharacter* GetOwningCharacter(); // Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df8c0
	float GetMaxLeanXOffset(enum class ELeanDirection NewLeanDir, enum class ECharacterStance LeanStance, bool bMoving); // Function DonkehFramework.DFCharacterLeanHandler.GetMaxLeanXOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df7b0
	float GetLeanYOffset(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanYOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df720
	float GetLeanXOffset(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanXOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df690
	float GetLeanRollRot(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanRollRot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df600
	float DetermineLeanTargetAmount(enum class ELeanDirection DesiredLeanDir, bool bMoving); // Function DonkehFramework.DFCharacterLeanHandler.DetermineLeanTargetAmount // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df460
};

// Class DonkehFramework.DFCharacterMovementComponent
// Size: 0x750 (Inherited: 0x610)
struct UDFCharacterMovementComponent : UCharacterMovementComponent {
	struct ADFBaseCharacter* DFCharacterOwner; // 0x610(0x08)
	enum class EMovementMode LastMovementMode; // 0x618(0x01)
	char LastCustomMovementMode; // 0x619(0x01)
	char pad_61A[0x2]; // 0x61a(0x02)
	struct FFloatRange StandWalkSpeedMultiplierRange; // 0x61c(0x10)
	struct FFloatRange CrouchedWalkSpeedMultiplierRange; // 0x62c(0x10)
	struct FFloatRange ProneWalkSpeedMultiplierRange; // 0x63c(0x10)
	float LeanSpeedMultiplier; // 0x64c(0x04)
	char bUseLeanSpeedMultiplierWhileAiming : 1; // 0x650(0x01)
	char bCanCrouchWhileFalling : 1; // 0x650(0x01)
	char pad_650_2 : 6; // 0x650(0x01)
	char pad_651[0x3]; // 0x651(0x03)
	char bUseJumpStamina : 1; // 0x654(0x01)
	char pad_654_1 : 7; // 0x654(0x01)
	char pad_655[0x3]; // 0x655(0x03)
	float JumpMaxStamina; // 0x658(0x04)
	float JumpStaminaCost; // 0x65c(0x04)
	float JumpStaminaRecoveryRate; // 0x660(0x04)
	float JumpStaminaThreshold; // 0x664(0x04)
	struct UCurveVector* VaultOverVelocityCurve; // 0x668(0x08)
	struct UCurveVector* SprintVaultOverVelocityCurve; // 0x670(0x08)
	struct UCurveVector* ClimbOntoVelocityCurve; // 0x678(0x08)
	struct UCurveVector* SprintClimbOntoVelocityCurve; // 0x680(0x08)
	float VaultViewPitch; // 0x688(0x04)
	float VaultReachDistance; // 0x68c(0x04)
	float SprintVaultReachDistance; // 0x690(0x04)
	float VaultReachRadius; // 0x694(0x04)
	float VaultCapsuleLOSRadius; // 0x698(0x04)
	float MaxVaultObstacleVelocitySquared; // 0x69c(0x04)
	float VaultOverDisplacementXOffset; // 0x6a0(0x04)
	float ClimbOntoDisplacementXOffset; // 0x6a4(0x04)
	float VaultOverDisplacementZOffset; // 0x6a8(0x04)
	float ClimbOntoDisplacementZOffset; // 0x6ac(0x04)
	float VaultOverLedgeSurfaceThreshold; // 0x6b0(0x04)
	float ClimbOntoLedgeSurfaceThreshold; // 0x6b4(0x04)
	float MinVaultOverLedgeHeight; // 0x6b8(0x04)
	float MaxVaultOverLedgeHeight; // 0x6bc(0x04)
	float MinClimbOntoLedgeHeight; // 0x6c0(0x04)
	float MaxClimbOntoLedgeHeight; // 0x6c4(0x04)
	char bWantsToSprint : 1; // 0x6c8(0x01)
	char pad_6C8_1 : 7; // 0x6c8(0x01)
	char pad_6C9[0x3]; // 0x6c9(0x03)
	float SprintSpeedMultiplier; // 0x6cc(0x04)
	float SprintAccelerationMultiplier; // 0x6d0(0x04)
	float SprintStrafingThreshold; // 0x6d4(0x04)
	char bUseSprintStamina : 1; // 0x6d8(0x01)
	char pad_6D8_1 : 7; // 0x6d8(0x01)
	char pad_6D9[0x3]; // 0x6d9(0x03)
	float SprintMaxStamina; // 0x6dc(0x04)
	float SprintStaminaDelta; // 0x6e0(0x04)
	float SprintStaminaThreshold; // 0x6e4(0x04)
	char bWantsToAim : 1; // 0x6e8(0x01)
	char pad_6E8_1 : 7; // 0x6e8(0x01)
	char pad_6E9[0x3]; // 0x6e9(0x03)
	float AimSpeedMultiplier; // 0x6ec(0x04)
	char bWantsToLeanLeft : 1; // 0x6f0(0x01)
	char bWantsToLeanRight : 1; // 0x6f0(0x01)
	char pad_6F0_2 : 6; // 0x6f0(0x01)
	char pad_6F1[0x3]; // 0x6f1(0x03)
	float ProneHalfHeight; // 0x6f4(0x04)
	char bCanWalkOffLedgesWhenProne : 1; // 0x6f8(0x01)
	char bProneMaintainsBaseLocation : 1; // 0x6f8(0x01)
	char pad_6F8_2 : 6; // 0x6f8(0x01)
	char pad_6F9[0x3]; // 0x6f9(0x03)
	float MaxWalkSpeedProne; // 0x6fc(0x04)
	char bWantsToBeProne : 1; // 0x700(0x01)
	char bCanSwimUnderwater : 1; // 0x700(0x01)
	char pad_700_2 : 6; // 0x700(0x01)
	char pad_701[0x3]; // 0x701(0x03)
	float JumpStamina; // 0x704(0x04)
	char bCanSprint : 1; // 0x708(0x01)
	char pad_708_1 : 7; // 0x708(0x01)
	char pad_709[0x3]; // 0x709(0x03)
	float SprintStamina; // 0x70c(0x04)
	char bCanAim : 1; // 0x710(0x01)
	char bCanLean : 1; // 0x710(0x01)
	char bCanBeProne : 1; // 0x710(0x01)
	char bCanVault : 1; // 0x710(0x01)
	char pad_710_4 : 4; // 0x710(0x01)
	char pad_711[0x2f]; // 0x711(0x2f)
	char bJustLeftWater : 1; // 0x740(0x01)
	char pad_740_1 : 7; // 0x740(0x01)
	char pad_741[0xf]; // 0x741(0x0f)

	struct FDFVaultTraceResult VaultTrace(); // Function DonkehFramework.DFCharacterMovementComponent.VaultTrace // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e0690
	bool IsVaulting(); // Function DonkehFramework.DFCharacterMovementComponent.IsVaulting // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfd70
	bool IsStrafing(float Threshold); // Function DonkehFramework.DFCharacterMovementComponent.IsStrafing // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfce0
	bool IsStanding(); // Function DonkehFramework.DFCharacterMovementComponent.IsStanding // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfcb0
	bool IsSprinting(); // Function DonkehFramework.DFCharacterMovementComponent.IsSprinting // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfc80
	bool IsReloading(); // Function DonkehFramework.DFCharacterMovementComponent.IsReloading // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfc50
	bool IsProne(); // Function DonkehFramework.DFCharacterMovementComponent.IsProne // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfc20
	bool IsMovingForward(); // Function DonkehFramework.DFCharacterMovementComponent.IsMovingForward // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfbf0
	bool IsMoving(bool bIgnoreZVel); // Function DonkehFramework.DFCharacterMovementComponent.IsMoving // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfb50
	bool IsLeaning(); // Function DonkehFramework.DFCharacterMovementComponent.IsLeaning // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfaf0
	bool IsCrawling(); // Function DonkehFramework.DFCharacterMovementComponent.IsCrawling // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfa90
	bool IsAlive(); // Function DonkehFramework.DFCharacterMovementComponent.IsAlive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfa60
	bool IsAiming(); // Function DonkehFramework.DFCharacterMovementComponent.IsAiming // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6dfa30
	enum class ECharacterStance GetStance(); // Function DonkehFramework.DFCharacterMovementComponent.GetStance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df9c0
	enum class ECharacterStance GetPreviousStance(); // Function DonkehFramework.DFCharacterMovementComponent.GetPreviousStance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df950
	enum class ELeanDirection GetLeanDirection(); // Function DonkehFramework.DFCharacterMovementComponent.GetLeanDirection // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df5d0
	float GetLeanAmount(); // Function DonkehFramework.DFCharacterMovementComponent.GetLeanAmount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df590
	struct ADFBaseCharacter* GetDFCharacterOwner(); // Function DonkehFramework.DFCharacterMovementComponent.GetDFCharacterOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c1ef0
	float ClampSpeedMultiplier(float MultValue); // Function DonkehFramework.DFCharacterMovementComponent.ClampSpeedMultiplier // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df360
};

// Class DonkehFramework.DFCheatManager
// Size: 0x78 (Inherited: 0x78)
struct UDFCheatManager : UCheatManager {

	void ToggleItemDebug(); // Function DonkehFramework.DFCheatManager.ToggleItemDebug // (Exec|Native|Public|BlueprintCallable) // @ game+0x6e05f0
	void ToggleGunRecoil(); // Function DonkehFramework.DFCheatManager.ToggleGunRecoil // (Exec|Native|Public|BlueprintCallable) // @ game+0x6e05d0
	void ToggleGunInfiniteClipAmmo(); // Function DonkehFramework.DFCheatManager.ToggleGunInfiniteClipAmmo // (Exec|Native|Public|BlueprintCallable) // @ game+0x6e05b0
	void ToggleGunInfiniteAmmo(); // Function DonkehFramework.DFCheatManager.ToggleGunInfiniteAmmo // (Exec|Native|Public|BlueprintCallable) // @ game+0x6e0590
};

// Class DonkehFramework.DFDamageType
// Size: 0x48 (Inherited: 0x40)
struct UDFDamageType : UDamageType {
	struct ADFBaseImpactEffect* ImpactFXClass; // 0x40(0x08)
};

// Class DonkehFramework.DFPrimaryDataAsset
// Size: 0x30 (Inherited: 0x30)
struct UDFPrimaryDataAsset : UPrimaryDataAsset {
};

// Class DonkehFramework.DFFactionInfo
// Size: 0x90 (Inherited: 0x30)
struct UDFFactionInfo : UDFPrimaryDataAsset {
	struct FPrimaryAssetType FactionType; // 0x30(0x08)
	struct FName FactionName; // 0x38(0x08)
	char bVisibleInFactionSelectUI : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FText DisplayName; // 0x48(0x18)
	struct FText DisplayNameShort; // 0x60(0x18)
	struct FText DisplayNameAcronym; // 0x78(0x18)
};

// Class DonkehFramework.DFFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDFFunctionLibrary : UObject {

	void SetEnableAutoBlendOutForActiveMontage(struct UAnimMontage* AnimMontage, struct USkeletalMeshComponent* AnimSourceMesh, bool bNewEnableAutoBlendOut); // Function DonkehFramework.DFFunctionLibrary.SetEnableAutoBlendOutForActiveMontage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e0490
	void ClearMeshAnimInstance(struct USkeletalMeshComponent* MeshToClear); // Function DonkehFramework.DFFunctionLibrary.ClearMeshAnimInstance // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6df3f0
};

// Class DonkehFramework.DFGameEngine
// Size: 0xe30 (Inherited: 0xe30)
struct UDFGameEngine : UGameEngine {
};

// Class DonkehFramework.DFGameModeDefinition
// Size: 0xe8 (Inherited: 0x30)
struct UDFGameModeDefinition : UPrimaryDataAsset {
	bool bSupportsAllMaps; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TSet<struct FPrimaryAssetId> SpecificMapsToSupport; // 0x38(0x50)
	bool bShowInFrontEnd; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FText Title; // 0x90(0x18)
	struct FText Description; // 0xa8(0x18)
	struct TSoftObjectPtr<UTexture2D> PreviewBannerImg; // 0xc0(0x28)
};

// Class DonkehFramework.DFGameRulesetBase
// Size: 0x58 (Inherited: 0x28)
struct UDFGameRulesetBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	char bTickable : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FText DisplayName; // 0x38(0x18)
	int32_t Priority; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)

	void UnregisterActor(struct AActor* UnregisteredActor); // Function DonkehFramework.DFGameRulesetBase.UnregisterActor // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void RegisterActor(struct AActor* RegisteredActor); // Function DonkehFramework.DFGameRulesetBase.RegisterActor // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaTime); // Function DonkehFramework.DFGameRulesetBase.ReceiveTick // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PlayerWounded(struct AController* Victim, float DamageAmount, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function DonkehFramework.DFGameRulesetBase.PlayerWounded // (Native|Event|Public|BlueprintEvent) // @ game+0x6e0300
	void PlayerSuicide(struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerSuicide // (Native|Event|Public|BlueprintEvent) // @ game+0x6e0270
	void PlayerSpawn(struct AController* Player, struct APawn* NewPlayerPawn); // Function DonkehFramework.DFGameRulesetBase.PlayerSpawn // (Native|Event|Public|BlueprintEvent) // @ game+0x6e01a0
	void PlayerPostLogout(struct AController* ExitingPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerPostLogout // (Native|Event|Public|BlueprintEvent) // @ game+0x6e0110
	void PlayerPostLogin(struct APlayerController* NewPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerPostLogin // (Native|Event|Public|BlueprintEvent) // @ game+0x6e0080
	void PlayerKilled(struct AController* Killer, struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerKilled // (Native|Event|Public|BlueprintEvent) // @ game+0x6dffb0
	void PlayerJoinedTeam(struct AController* JoiningPlayer, char TeamNum); // Function DonkehFramework.DFGameRulesetBase.PlayerJoinedTeam // (Native|Event|Public|BlueprintEvent) // @ game+0x6dfee0
	void PlayerJoined(struct APlayerController* NewPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerJoined // (Native|Event|Public|BlueprintEvent) // @ game+0x6dfe50
	void PlayerDied(struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerDied // (Native|Event|Public|BlueprintEvent) // @ game+0x6dfdc0
	void MatchHasEnded(); // Function DonkehFramework.DFGameRulesetBase.MatchHasEnded // (Native|Event|Public|BlueprintEvent) // @ game+0x6dfda0
	void Init(); // Function DonkehFramework.DFGameRulesetBase.Init // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	struct ADFBaseGameState* GetGameState(); // Function DonkehFramework.DFGameRulesetBase.GetGameState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df560
	struct ADFBaseGameMode* GetGameMode(); // Function DonkehFramework.DFGameRulesetBase.GetGameMode // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df530
};

// Class DonkehFramework.DFGameSession
// Size: 0x270 (Inherited: 0x238)
struct ADFGameSession : AGameSession {
	struct FString ServerName; // 0x238(0x10)
	char pad_248[0x10]; // 0x248(0x10)
	int32_t MinPlayers; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FString Password; // 0x260(0x10)
};

// Class DonkehFramework.DFGunRecoilHandler
// Size: 0x28 (Inherited: 0x28)
struct UDFGunRecoilHandler : UObject {

	void OnWeaponStopFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponStopFire // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed2f0
	void OnWeaponStartFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponStartFire // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed2d0
	void OnWeaponFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponFire // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed2b0
	void OnTick(float DeltaTime); // Function DonkehFramework.DFGunRecoilHandler.OnTick // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed230
	bool IsFiring(); // Function DonkehFramework.DFGunRecoilHandler.IsFiring // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed0a0
	struct APawn* GetOwningPawn(); // Function DonkehFramework.DFGunRecoilHandler.GetOwningPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecf00
	struct ADFBaseGun* GetOwningGun(); // Function DonkehFramework.DFGunRecoilHandler.GetOwningGun // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6df8c0
	struct FVector GetConeOfFireOffset(); // Function DonkehFramework.DFGunRecoilHandler.GetConeOfFireOffset // (Native|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x6ecc80
};

// Class DonkehFramework.DFHandlerInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFHandlerInterface : UInterface {

	void EventUpdate(float DeltaTime, bool bMakeDecision); // Function DonkehFramework.DFHandlerInterface.EventUpdate // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool EventShouldUpdateThisFrame(float DeltaTime, bool bActiveAndSpawnedInWorld); // Function DonkehFramework.DFHandlerInterface.EventShouldUpdateThisFrame // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void EventRespawn(); // Function DonkehFramework.DFHandlerInterface.EventRespawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void EventReset(); // Function DonkehFramework.DFHandlerInterface.EventReset // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void EventOnNewPawn(struct APawn* NewPawn, struct APawn* PreviousPawn); // Function DonkehFramework.DFHandlerInterface.EventOnNewPawn // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void EventInit(); // Function DonkehFramework.DFHandlerInterface.EventInit // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class DonkehFramework.DFInfo
// Size: 0x220 (Inherited: 0x220)
struct ADFInfo : AInfo {
};

// Class DonkehFramework.DFIntrinsicCharAnimInstInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFIntrinsicCharAnimInstInterface : UInterface {

	float PlayDeathMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicCharAnimInstInterface.PlayDeathMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed310
};

// Class DonkehFramework.DFIntrinsicWeapAnimInstInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFIntrinsicWeapAnimInstInterface : UInterface {

	float PlayUnEquipMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayUnEquipMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed700
	float PlayReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayReloadMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed3b0
	float PlayFireMontage(struct UAnimMontage* MontageToPlay, bool bFireLast, bool bAiming); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayFireMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed520
	float PlayEquipMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayEquipMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed480
};

// Class DonkehFramework.DFInventoryComponent
// Size: 0xf0 (Inherited: 0xb0)
struct UDFInventoryComponent : UActorComponent {
	struct FMulticastInlineDelegate OnItemAdded; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnItemRemoved; // 0xc0(0x10)
	struct TArray<struct ADFBaseItem*> Items; // 0xd0(0x10)
	struct TArray<struct ADFBaseItem*> DefaultItemClasses; // 0xe0(0x10)

	int32_t Size(); // Function DonkehFramework.DFInventoryComponent.Size // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed990
	bool RemoveItemAt(int32_t Index, struct ADFBaseItem*& OutRemovedItem, bool bDestroyItem); // Function DonkehFramework.DFInventoryComponent.RemoveItemAt // (BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6ed870
	bool Remove(struct ADFBaseItem* Item, bool bDestroyItem); // Function DonkehFramework.DFInventoryComponent.Remove // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6ed7a0
	bool IsValidIndex(int32_t Index); // Function DonkehFramework.DFInventoryComponent.IsValidIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed190
	bool GetItem(int32_t Index, struct ADFBaseItem*& OutItem); // Function DonkehFramework.DFInventoryComponent.GetItem // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecde0
	bool FindItemByClass(struct ADFBaseItem*& ItemClass, struct ADFBaseItem*& OutItem); // Function DonkehFramework.DFInventoryComponent.FindItemByClass // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6eca40
	bool Find(struct ADFBaseItem* ItemToCompare, int32_t& OutIndex); // Function DonkehFramework.DFInventoryComponent.Find // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ec960
	void Clear(bool bDestroyItems); // Function DonkehFramework.DFInventoryComponent.Clear // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6ec8d0
	void AddDefaultInventoryItems(); // Function DonkehFramework.DFInventoryComponent.AddDefaultInventoryItems // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6e05d0
	bool Add(struct ADFBaseItem* Item); // Function DonkehFramework.DFInventoryComponent.Add // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6ec800
};

// Class DonkehFramework.DFLevelScriptActor
// Size: 0x228 (Inherited: 0x228)
struct ADFLevelScriptActor : ALevelScriptActor {
};

// Class DonkehFramework.DFLoadout
// Size: 0x40 (Inherited: 0x30)
struct UDFLoadout : UDataAsset {
	struct TArray<struct ADFBaseItem*> ItemClasses; // 0x30(0x10)
};

// Class DonkehFramework.DFNavigationSystem
// Size: 0x538 (Inherited: 0x538)
struct UDFNavigationSystem : UNavigationSystemV1 {
};

// Class DonkehFramework.DFNavigationSystemConfig
// Size: 0x60 (Inherited: 0x58)
struct UDFNavigationSystemConfig : UNavigationSystemModuleConfig {
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class DonkehFramework.DFNetworkEventSubsystem
// Size: 0xa0 (Inherited: 0x30)
struct UDFNetworkEventSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate OnPlayersUpdatedDynamic; // 0x30(0x10)
	struct FMulticastInlineDelegate OnTeamsUpdatedDynamic; // 0x40(0x10)
	char pad_50[0x50]; // 0x50(0x50)

	void OnGameStateEventDynamic__DelegateSignature(struct AGameStateBase* GameState); // DelegateFunction DonkehFramework.DFNetworkEventSubsystem.OnGameStateEventDynamic__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xec54e0
	struct UDFNetworkEventSubsystem* Get(struct UObject* WorldContextObject); // Function DonkehFramework.DFNetworkEventSubsystem.Get // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6ecb40
};

// Class DonkehFramework.DFOnlineSessionClient
// Size: 0x190 (Inherited: 0x190)
struct UDFOnlineSessionClient : UOnlineSessionClient {
};

// Class DonkehFramework.DFPhysicalMaterial
// Size: 0x90 (Inherited: 0x80)
struct UDFPhysicalMaterial : UPhysicalMaterial {
	struct UParticleSystem* CollisionFX; // 0x80(0x08)
	struct USoundCue* CollisionSound; // 0x88(0x08)
};

// Class DonkehFramework.DFPhysicsCollisionHandler
// Size: 0x40 (Inherited: 0x40)
struct UDFPhysicsCollisionHandler : UPhysicsCollisionHandler {
};

// Class DonkehFramework.DFPlayerCameraManager
// Size: 0x2740 (Inherited: 0x2740)
struct ADFPlayerCameraManager : APlayerCameraManager {
	float AimingFOV; // 0x2738(0x04)
	float AimInterpSpeed; // 0x273c(0x04)
};

// Class DonkehFramework.DFPlayerComponent
// Size: 0xc8 (Inherited: 0xb0)
struct UDFPlayerComponent : UActorComponent {
	struct AController* ControllerOwner; // 0xb0(0x08)
	char bWantsToRestart : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0xf]; // 0xb9(0x0f)

	void RestartPlayer(); // Function DonkehFramework.DFPlayerComponent.RestartPlayer // (Native|Public|BlueprintCallable) // @ game+0x6e05b0
	void ReceiveSeamlessTravelToCommon(struct AController* NewC, struct UDFPlayerComponent* NewCPlayerComp); // Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelToCommon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveSeamlessTravelFromCommon(struct AController* OldC, struct UDFPlayerComponent* OldCPlayerComp); // Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelFromCommon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePawnLeavingGame(); // Function DonkehFramework.DFPlayerComponent.ReceivePawnLeavingGame // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFPlayerComponent.ReceiveGameHasEnded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsPendingRestart(); // Function DonkehFramework.DFPlayerComponent.IsPendingRestart // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed0d0
	struct ADFTeamState* GetTeamState(); // Function DonkehFramework.DFPlayerComponent.GetTeamState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed070
	struct APlayerState* GetPlayerState(); // Function DonkehFramework.DFPlayerComponent.GetPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecf70
	struct APawn* GetPawnOwner(); // Function DonkehFramework.DFPlayerComponent.GetPawnOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecf30
	float GetMinRestartDelay(); // Function DonkehFramework.DFPlayerComponent.GetMinRestartDelay // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x6ecec0
	bool CanRestartPlayer(); // Function DonkehFramework.DFPlayerComponent.CanRestartPlayer // (Native|Public|BlueprintCallable) // @ game+0x6ec8a0
};

// Class DonkehFramework.DFProjectileSubsystem
// Size: 0x58 (Inherited: 0x30)
struct UDFProjectileSubsystem : UWorldSubsystem {
	struct TArray<struct ADFBaseProjectile*> PredictedProjectiles; // 0x30(0x10)
	int32_t MaxFiredShots; // 0x40(0x04)
	char pad_44[0x14]; // 0x44(0x14)
};

// Class DonkehFramework.DFRecastNavMesh
// Size: 0x4b8 (Inherited: 0x4b8)
struct ADFRecastNavMesh : ARecastNavMesh {
};

// Class DonkehFramework.DFReplInfo
// Size: 0x220 (Inherited: 0x220)
struct ADFReplInfo : ADFInfo {
};

// Class DonkehFramework.DFServerAdminSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UDFServerAdminSubsystem : UEngineSubsystem {
	struct TArray<struct UDFCfgDataManager*> DataMgrs; // 0x30(0x10)
};

// Class DonkehFramework.DFSingleActionWeapAnimInstInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFSingleActionWeapAnimInstInterface : UInterface {

	float PlayActionMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFSingleActionWeapAnimInstInterface.PlayActionMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed310
};

// Class DonkehFramework.DFSingleLoadWeapAnimInstInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFSingleLoadWeapAnimInstInterface : UInterface {

	float PlayStartReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayStartReloadMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed630
	float PlayEndReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayEndReloadMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed3b0
};

// Class DonkehFramework.DFTableLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDFTableLibrary : UBlueprintFunctionLibrary {

	int32_t GetRowInvFromIndex(int32_t Index, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetRowInvFromIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6ecfb0
	int32_t GetRowFromIndex(int32_t Index, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetRowFromIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6ecfb0
	int32_t GetIndexFromRowColumnPair(int32_t Row, int32_t Column, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetIndexFromRowColumnPair // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6eccf0
	int32_t GetIndexFromColumnRowPair(int32_t Column, int32_t Row, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetIndexFromColumnRowPair // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6eccf0
	int32_t GetColumnInvFromIndex(int32_t Index, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetColumnInvFromIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6ecbc0
	int32_t GetColumnFromIndex(int32_t Index, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetColumnFromIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6ecbc0
};

// Class DonkehFramework.DFTeamAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFTeamAgentInterface : UGenericTeamAgentInterface {

	void EventSetTeamNum(char NewTeamNum); // Function DonkehFramework.DFTeamAgentInterface.EventSetTeamNum // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	char EventGetTeamNum(); // Function DonkehFramework.DFTeamAgentInterface.EventGetTeamNum // (Event|Public|BlueprintEvent|Const) // @ game+0xec54e0
};

// Class DonkehFramework.DFTeamDefinition
// Size: 0x58 (Inherited: 0x28)
struct UDFTeamDefinition : UObject {
	struct FName TeamName; // 0x28(0x08)
	struct TSoftClassPtr<UObject> FactionInfoClass; // 0x30(0x28)
};

// Class DonkehFramework.DFTeamState
// Size: 0x250 (Inherited: 0x220)
struct ADFTeamState : AInfo {
	char pad_220[0x8]; // 0x220(0x08)
	char bInitialized : 1; // 0x228(0x01)
	char pad_228_1 : 7; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
	struct UDFFactionInfo* FactionInfoClass; // 0x230(0x08)
	char TeamNum; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct FMulticastInlineDelegate OnPostInitTeam; // 0x240(0x10)

	void ReceivePostInitTeam(); // Function DonkehFramework.DFTeamState.ReceivePostInitTeam // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveInitTeam(struct UDFTeamDefinition* InTeamDef); // Function DonkehFramework.DFTeamState.ReceiveInitTeam // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsReadyToInitialize(); // Function DonkehFramework.DFTeamState.IsReadyToInitialize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ed100
	bool IsPendingSetupBP(); // Function DonkehFramework.DFTeamState.IsPendingSetupBP // (Event|Protected|BlueprintEvent|Const) // @ game+0xec54e0
	struct UDFFactionInfo* GetFactionInfo(); // Function DonkehFramework.DFTeamState.GetFactionInfo // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x6eccc0
};

// Class DonkehFramework.DFThrowableWeapAnimInstInterface
// Size: 0x28 (Inherited: 0x28)
struct UDFThrowableWeapAnimInstInterface : UInterface {

	float PlayThrowUnderhandMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowUnderhandMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed310
	float PlayThrowOverhandMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowOverhandMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6f24a0
	float PlayCockMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayCockMontage // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed700
};

// Class DonkehFramework.DFTokenStore
// Size: 0xc8 (Inherited: 0x78)
struct UDFTokenStore : UDFCfgDataManager {
	char pad_78[0x50]; // 0x78(0x50)
};

// Class DonkehFramework.DFWorldSettings
// Size: 0x4c8 (Inherited: 0x3a0)
struct ADFWorldSettings : AWorldSettings {
	char bVisibleInMapSelectUI : 1; // 0x3a0(0x01)
	char pad_3A0_1 : 7; // 0x3a0(0x01)
	char pad_3A1[0x7]; // 0x3a1(0x07)
	struct FText MapDisplayName; // 0x3a8(0x18)
	struct FText MapDescription; // 0x3c0(0x18)
	struct TSoftObjectPtr<UTexture2D> MapPreviewImg; // 0x3d8(0x28)
	struct TSoftObjectPtr<UTexture2D> MapPreviewBannerImg; // 0x400(0x28)
	struct TSet<struct TSoftClassPtr<UObject>> SupportedGameModes; // 0x428(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> GameRulesetClasses; // 0x478(0x50)
};

// Class DonkehFramework.GameSessionBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UGameSessionBlueprintLibrary : UBlueprintFunctionLibrary {

	void RemoveAdmin(struct UObject* WorldContextObj, struct APlayerController* AdminPlayer); // Function DonkehFramework.GameSessionBlueprintLibrary.RemoveAdmin // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6f2540
	int32_t GetMinPlayers(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMinPlayers // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6f2420
	int32_t GetMaxSpectators(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxSpectators // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6f23a0
	int32_t GetMaxPlayers(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxPlayers // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6f2320
	void AddAdmin(struct UObject* WorldContextObj, struct APlayerController* AdminPlayer); // Function DonkehFramework.GameSessionBlueprintLibrary.AddAdmin // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x6f2270
};

// Class DonkehFramework.SpawnPointProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct USpawnPointProviderInterface : UInterface {

	bool GetSpawnPointCollisionHandlingOverrideBP(struct FSpawnPointDef& SpawnPoint, enum class ESpawnActorCollisionHandlingMethod& OutSpawnCollisionMethod); // Function DonkehFramework.SpawnPointProviderInterface.GetSpawnPointCollisionHandlingOverrideBP // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
	int32_t GetAllSpawnPointsBP(struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function DonkehFramework.SpawnPointProviderInterface.GetAllSpawnPointsBP // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
	bool FindSpawnPointBP(int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function DonkehFramework.SpawnPointProviderInterface.FindSpawnPointBP // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
	bool CanSpawnActorFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AActor* SpawnActorClass); // Function DonkehFramework.SpawnPointProviderInterface.CanSpawnActorFromSpawnPointBP // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
	bool CanRestartPlayerFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AController* Player, struct APawn* PlayerPawnClass); // Function DonkehFramework.SpawnPointProviderInterface.CanRestartPlayerFromSpawnPointBP // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0xec54e0
};

// Class DonkehFramework.SpawnPointStatics
// Size: 0x28 (Inherited: 0x28)
struct USpawnPointStatics : UBlueprintFunctionLibrary {

	bool SpawnPointExists(struct UObject* Target, int32_t SpawnPointID); // Function DonkehFramework.SpawnPointStatics.SpawnPointExists // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6f3c20
	bool GetSpawnPointCollisionHandlingOverride(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, enum class ESpawnActorCollisionHandlingMethod& OutSpawnCollisionMethod); // Function DonkehFramework.SpawnPointStatics.GetSpawnPointCollisionHandlingOverride // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f3ad0
	int32_t GetAllSpawnPointTransforms(struct UObject* Target, struct TArray<struct FTransform>& SpawnPointTransforms); // Function DonkehFramework.SpawnPointStatics.GetAllSpawnPointTransforms // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f38f0
	int32_t GetAllSpawnPoints(struct UObject* Target, struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function DonkehFramework.SpawnPointStatics.GetAllSpawnPoints // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f39e0
	bool FindSpawnPoint(struct UObject* Target, int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function DonkehFramework.SpawnPointStatics.FindSpawnPoint // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f37b0
	bool CanSpawnActorFromSpawnPoint(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, struct AActor*& SpawnActorClass); // Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromSpawnPoint // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f3660
	bool CanSpawnActorFromAnySpawnPoint(struct UObject* Target, struct AActor*& SpawnActorClass); // Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromAnySpawnPoint // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f3590
	bool CanRestartPlayerFromSpawnPoint(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, struct AController* Player, struct APawn*& PlayerPawnClass); // Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromSpawnPoint // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f3400
	bool CanRestartPlayerFromAnySpawnPoint(struct UObject* Target, struct AController* Player, struct APawn*& PlayerPawnClass); // Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromAnySpawnPoint // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6f3300
};

// Class DonkehFramework.UseableInterface
// Size: 0x28 (Inherited: 0x28)
struct UUseableInterface : UInterface {

	void Used(struct AActor* Invoker); // Function DonkehFramework.UseableInterface.Used // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x6f3ce0
};

// Class DonkehFramework.VisibilityInterface
// Size: 0x28 (Inherited: 0x28)
struct UVisibilityInterface : UInterface {

	struct FVector EventGetFocalPoint(); // Function DonkehFramework.VisibilityInterface.EventGetFocalPoint // (Event|Protected|HasDefaults|BlueprintEvent|Const) // @ game+0xec54e0
};

