// AnimBlueprintGeneratedClass ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C
// Size: 0x28 (Inherited: 0x28)
struct UABPI_WeaponAnimLayer_C : UAnimLayerInterface {

	void WeaponJumpLoop(struct FPoseLink LowerJumpLoop, struct FPoseLink& WeaponJumpLoop); // Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponJumpLoop // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Move(struct FPoseLink Move, struct FPoseLink& Move); // Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.Move // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void WeaponAdditive(struct FPoseLink& WeaponAdditive); // Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponAdditive // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void WeaponUpperBody(struct FPoseLink UpperBody, struct FPoseLink& WeaponUpperBody); // Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponUpperBody // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

