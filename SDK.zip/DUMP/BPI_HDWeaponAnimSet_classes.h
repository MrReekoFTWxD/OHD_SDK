// BlueprintGeneratedClass BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_HDWeaponAnimSet_C : UInterface {

	void ShouldUseMirroredLowerBodyLoco(bool& bOutUseMirrored); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.ShouldUseMirroredLowerBodyLoco // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetLocoTPPAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoTPPAnimSet // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetLocoAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoAnimSet // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
};

