// BlueprintGeneratedClass BPI_RadialSlot.BPI_RadialSlot_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_RadialSlot_C : UInterface {

	void OnUnhighlight(); // Function BPI_RadialSlot.BPI_RadialSlot_C.OnUnhighlight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnHighlight(); // Function BPI_RadialSlot.BPI_RadialSlot_C.OnHighlight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

