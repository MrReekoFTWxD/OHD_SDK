// WidgetBlueprintGeneratedClass WBP_Checkbox.WBP_Checkbox_C
// Size: 0x260 (Inherited: 0x230)
struct UWBP_Checkbox_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UCheckBox* CBox; // 0x238(0x08)
	struct FMulticastInlineDelegate CheckStateChanged; // 0x240(0x10)
	struct FMulticastInlineDelegate CheckStateChangedBool; // 0x250(0x10)

	void SetCheckedState(enum class ECheckBoxState NewCheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.SetCheckedState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetIsChecked(bool bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.SetIsChecked // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsChecked(bool& bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.IsChecked // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetCheckedState(enum class ECheckBoxState& CheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.GetCheckedState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void BndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_Checkbox.WBP_Checkbox_C.BndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_Checkbox(int32_t EntryPoint); // Function WBP_Checkbox.WBP_Checkbox_C.ExecuteUbergraph_WBP_Checkbox // (Final|UbergraphFunction) // @ game+0xec54e0
	void CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChangedBool__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CheckStateChanged__DelegateSignature(enum class ECheckBoxState CheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

