// Class ArcVehicles.ArcVehiclePlayerSeatComponent
// Size: 0x198 (Inherited: 0xb0)
struct UArcVehiclePlayerSeatComponent : UActorComponent {
	struct FArcVehicleSeatReference CurrentSeatConfig; // 0xb0(0x10)
	struct FArcVehicleSeatReference PreviousSeatConfig; // 0xc0(0x10)
	struct APlayerState* StoredPlayerState; // 0xd0(0x08)
	char pad_D8[0x58]; // 0xd8(0x58)
	struct TArray<struct FString> ServerDebugStrings; // 0x130(0x10)
	char pad_140[0x8]; // 0x140(0x08)
	struct TMap<struct UPrimitiveComponent*, enum class ECollisionResponse> PreviousVehicleCollisionResponses; // 0x148(0x50)

	void ServerPrintDebug_Request(); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.ServerPrintDebug_Request // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x7fdd60
	void OnSeatChangeEvent(enum class EArcVehicleSeatChangeType SeatChangeType); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnSeatChangeEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x7fda70
	void OnRep_StoredPlayerState(struct APlayerState* InPreviousPlayerState); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_StoredPlayerState // (Native|Public) // @ game+0x7fd0d0
	void OnRep_ServerDebugStrings(); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_ServerDebugStrings // (Final|Native|Public) // @ game+0x6c7310
	void OnRep_SeatConfig(struct FArcVehicleSeatReference& InPreviousSeatConfig); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_SeatConfig // (Native|Public|HasOutParms) // @ game+0x7fd950
	void BP_OnRep_StoredPlayerState(struct APlayerState* InPreviousPlayerState); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.BP_OnRep_StoredPlayerState // (Event|Public|BlueprintEvent) // @ game+0xec54e0
};

// Class ArcVehicles.ArcVehiclePawn
// Size: 0x280 (Inherited: 0x280)
struct AArcVehiclePawn : APawn {

	void NotifyPlayerSeatChangeEvent(struct APlayerState* Player, struct UArcVehicleSeatConfig* ToSeat, struct UArcVehicleSeatConfig* FromSeat, enum class EArcVehicleSeatChangeType SeatChangeEvent); // Function ArcVehicles.ArcVehiclePawn.NotifyPlayerSeatChangeEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x7fd810
	struct UArcVehicleSeatConfig* GetSeatConfig(); // Function ArcVehicles.ArcVehiclePawn.GetSeatConfig // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd380
	struct AArcBaseVehicle* GetOwningVehicle(); // Function ArcVehicles.ArcVehiclePawn.GetOwningVehicle // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd350
};

// Class ArcVehicles.ArcBaseVehicle
// Size: 0x2c8 (Inherited: 0x280)
struct AArcBaseVehicle : AArcVehiclePawn {
	struct UArcVehicleSeatConfig* DriverSeatConfig; // 0x280(0x08)
	struct TArray<struct UArcVehicleSeatConfig*> AdditionalSeatConfigs; // 0x288(0x10)
	struct TArray<struct UArcVehicleSeatConfig*> ReplicatedSeatConfigs; // 0x298(0x10)
	struct TArray<struct FArcVehicleSeatChangeEvent> SeatChangeQueue; // 0x2a8(0x10)
	struct TArray<struct FString> ServerDebugStrings; // 0x2b8(0x10)

	void SetupSeat(struct UArcVehicleSeatConfig* SeatConfig); // Function ArcVehicles.ArcBaseVehicle.SetupSeat // (Native|Event|Public|BlueprintEvent) // @ game+0x7fde80
	void ServerPrintDebug_Request(); // Function ArcVehicles.ArcBaseVehicle.ServerPrintDebug_Request // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x7fdd10
	void RequestLeaveVehicle(struct APlayerState* InPlayerState); // Function ArcVehicles.ArcBaseVehicle.RequestLeaveVehicle // (Native|Public|BlueprintCallable) // @ game+0x7fdc80
	void RequestEnterSeat(struct APlayerState* InPlayerState, int32_t RequestedSeatIndex, bool bIgnoreRestrictions); // Function ArcVehicles.ArcBaseVehicle.RequestEnterSeat // (Native|Public|BlueprintCallable) // @ game+0x7fdb80
	void RequestEnterAnySeat(struct APlayerState* InPlayerState); // Function ArcVehicles.ArcBaseVehicle.RequestEnterAnySeat // (Native|Public|BlueprintCallable) // @ game+0x7fdaf0
	void OnRep_ServerDebugStrings(); // Function ArcVehicles.ArcBaseVehicle.OnRep_ServerDebugStrings // (Final|Native|Public) // @ game+0x6c7310
	bool IsValidSeatIndex(int32_t InSeatIndex); // Function ArcVehicles.ArcBaseVehicle.IsValidSeatIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fd780
	void GetSortedExitPoints(struct FTransform InputLocation, struct TArray<struct FTransform>& OutTransformArray); // Function ArcVehicles.ArcBaseVehicle.GetSortedExitPoints // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fd3b0
	struct FTransform GetNearestExitTransform(struct FTransform InputLocation); // Function ArcVehicles.ArcBaseVehicle.GetNearestExitTransform // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x7fd240
	struct UArcVehicleSeatConfig* GetDriverSeat(); // Function ArcVehicles.ArcBaseVehicle.GetDriverSeat // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd210
	void GetAllSeats(struct TArray<struct UArcVehicleSeatConfig*>& Seats); // Function ArcVehicles.ArcBaseVehicle.GetAllSeats // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7fd160
};

// Class ArcVehicles.ArcVehicleBPFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UArcVehicleBPFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsSeatRefValid(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.IsSeatRefValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd6e0
	struct UArcVehicleSeatConfig* GetVehicleSeatConfigFromRef(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleSeatConfigFromRef // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd5e0
	struct AArcBaseVehicle* GetVehicleFromSeatConfig(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleFromSeatConfig // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7fd510
};

// Class ArcVehicles.ArcVehicleDeveloperSettings
// Size: 0x48 (Inherited: 0x38)
struct UArcVehicleDeveloperSettings : UDeveloperSettings {
	struct UArcVehiclePlayerSeatComponent* PlayerSeatComponentClass; // 0x38(0x08)
	struct UArcVehiclePlayerStateComponent* PlayerStateComponentClass; // 0x40(0x08)
};

// Class ArcVehicles.ArcVehicleEngineSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UArcVehicleEngineSubsystem : UEngineSubsystem {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class ArcVehicles.ArcVehicleExitPoint
// Size: 0x1f0 (Inherited: 0x1f0)
struct UArcVehicleExitPoint : USceneComponent {
};

// Class ArcVehicles.ArcVehiclePlayerStateComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UArcVehiclePlayerStateComponent : UActorComponent {
	struct APawn* StoredPlayerPawn; // 0xb0(0x08)
};

// Class ArcVehicles.ArcVehicleSeat
// Size: 0x288 (Inherited: 0x280)
struct AArcVehicleSeat : AArcVehiclePawn {
	struct UArcVehicleSeatConfig* SeatConfig; // 0x280(0x08)
};

// Class ArcVehicles.ArcVehicleSeatConfig
// Size: 0xd8 (Inherited: 0xb0)
struct UArcVehicleSeatConfig : UActorComponent {
	struct FArcOwnerAttachmentReference AttachSeatToComponent; // 0xb0(0x10)
	struct APlayerState* PlayerInSeat; // 0xc0(0x08)
	struct UArcVehiclePlayerSeatComponent* PlayerSeatComponent; // 0xc8(0x08)
	bool bPlayerVisible; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	void UnAttachPlayerFromSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.UnAttachPlayerFromSeat // (Native|Public) // @ game+0x7fdf30
	void SetupSeatAttachment(); // Function ArcVehicles.ArcVehicleSeatConfig.SetupSeatAttachment // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x7fdf10
	bool IsOpenSeat(); // Function ArcVehicles.ArcVehicleSeatConfig.IsOpenSeat // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fd6b0
	bool IsDriverSeat(); // Function ArcVehicles.ArcVehicleSeatConfig.IsDriverSeat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fd680
	struct AArcBaseVehicle* GetVehicleOwner(); // Function ArcVehicles.ArcVehicleSeatConfig.GetVehicleOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fd5b0
	void BP_UnAttachPlayerFromSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.BP_UnAttachPlayerFromSeat // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BP_AttachPlayerToSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.BP_AttachPlayerToSeat // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void AttachPlayerToSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.AttachPlayerToSeat // (Native|Public) // @ game+0x7fd0d0
};

// Class ArcVehicles.ArcVehicleSeatConfig_PlayerAttachment
// Size: 0xd8 (Inherited: 0xd8)
struct UArcVehicleSeatConfig_PlayerAttachment : UArcVehicleSeatConfig {
};

// Class ArcVehicles.ArcVehicleSeatConfig_SeatPawn
// Size: 0x100 (Inherited: 0xd8)
struct UArcVehicleSeatConfig_SeatPawn : UArcVehicleSeatConfig_PlayerAttachment {
	struct AArcVehicleSeat* SeatPawnClass; // 0xd8(0x08)
	struct FArcOwnerAttachmentReference PlayerCharacterAttachToComponent; // 0xe0(0x10)
	bool bResetControlRotationOnEnter; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct AArcVehiclePawn* SeatPawn; // 0xf8(0x08)

	void OnRep_SeatPawn(struct AArcVehiclePawn* OldSeatPawn); // Function ArcVehicles.ArcVehicleSeatConfig_SeatPawn.OnRep_SeatPawn // (Final|Native|Public) // @ game+0x7fd9f0
};

// Class ArcVehicles.ArcVehicleTurretMovementComp
// Size: 0x1c0 (Inherited: 0x138)
struct UArcVehicleTurretMovementComp : UPawnMovementComponent {
	bool bIgnoreBaseRotation; // 0x138(0x01)
	bool bIgnorePitch; // 0x139(0x01)
	bool bIgnoreYaw; // 0x13a(0x01)
	bool bIgnoreRoll; // 0x13b(0x01)
	char pad_13C[0x4]; // 0x13c(0x04)
	struct USceneComponent* UpdatedPitchComponent; // 0x140(0x08)
	struct FRotator RotationRate; // 0x148(0x0c)
	char pad_154[0x2c]; // 0x154(0x2c)
	struct USceneComponent* CurrentBase; // 0x180(0x08)
	struct FArcVehicleTurretMovementPostPhysicsTickFunction PostPhysicsTickFunction; // 0x188(0x30)
	char pad_1B8[0x8]; // 0x1b8(0x08)

	void Server_ServerMove(struct FRotator FullRotation); // Function ArcVehicles.ArcVehicleTurretMovementComp.Server_ServerMove // (Net|NetReliableNative|Event|Public|NetServer|HasDefaults|NetValidate) // @ game+0x7fddb0
};

