// Class RCON.RCONServerSystem
// Size: 0x70 (Inherited: 0x28)
struct URCONServerSystem : UObject {
	bool bEnabled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString ListenAddress; // 0x30(0x10)
	uint16_t ListenPort; // 0x40(0x02)
	char pad_42[0x6]; // 0x42(0x06)
	struct FString Password; // 0x48(0x10)
	uint32_t MaxActiveConnections; // 0x58(0x04)
	uint32_t MaxAuthAttempts; // 0x5c(0x04)
	char pad_60[0x10]; // 0x60(0x10)

	void Shutdown(); // Function RCON.RCONServerSystem.Shutdown // (Native|Public|BlueprintCallable) // @ game+0x6ed2b0
	void Init(); // Function RCON.RCONServerSystem.Init // (Native|Public|BlueprintCallable) // @ game+0x7ddba0
};

