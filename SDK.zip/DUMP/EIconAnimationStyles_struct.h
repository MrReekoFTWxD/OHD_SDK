// UserDefinedEnum EIconAnimationStyles.EIconAnimationStyles
enum class EIconAnimationStyles : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	EIconAnimationStyles_MAX = 3
};

