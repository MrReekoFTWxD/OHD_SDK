// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C
// Size: 0x2c9 (Inherited: 0x238)
struct UWBP_DeployMenu_SquadMemberListing_C : UDeployMenu_SquadMemberListingBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct USizeBox* DummyOption; // 0x240(0x08)
	struct UButton* DummyOptionBtn; // 0x248(0x08)
	struct UWBP_SQMemberOption_C* KickMemberOption; // 0x250(0x08)
	struct UButton* KickMemberOptionBtn; // 0x258(0x08)
	struct UButton* MemberBtn; // 0x260(0x08)
	struct UImage* PlayerClassIcon; // 0x268(0x08)
	struct UImage* PlayerClassIconBg; // 0x270(0x08)
	struct UTextBlock* PlayerNameText; // 0x278(0x08)
	struct UHorizontalBox* SQMOptionsHBox; // 0x280(0x08)
	struct FLinearColor OddListingBtnBgColor; // 0x288(0x10)
	struct FLinearColor OddListingIconBgColor; // 0x298(0x10)
	struct FLinearColor EvenListingBgColor; // 0x2a8(0x10)
	struct UWBP_DeployMenu_SquadList_C* ParentContainerWidget; // 0x2b8(0x08)
	struct UHDKit* LastLoadout; // 0x2c0(0x08)
	bool bMemberSet; // 0x2c8(0x01)

	void GetClassIconForLoadout(struct UHDKit* Loadout, struct FSlateBrush& ClassIconToUse); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.GetClassIconForLoadout // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void UpdatePlayerClassIcon(struct UHDKit* Loadout); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdatePlayerClassIcon // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupOptions(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetupOptions // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TestOptionPrereqs(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.TestOptionPrereqs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateColorOffset(bool bEvenNumberListing); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdateColorOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetPlayerNameText(struct FText NewPlayerName); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetPlayerNameText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__KickMemberBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.BndEvt__KickMemberBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnMemberSet(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.OnMemberSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnMemberPlayerNameUpdated(struct FString NewPlayerName); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.OnMemberPlayerNameUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_SquadMemberListing(int32_t EntryPoint); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.ExecuteUbergraph_WBP_DeployMenu_SquadMemberListing // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

