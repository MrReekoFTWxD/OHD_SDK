// WidgetBlueprintGeneratedClass WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C
// Size: 0x260 (Inherited: 0x230)
struct UWBP_JoinServerFiltersPanel_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_ServerListModifierSettings_AdvancedFilters_C* AdvancedFilterSettings; // 0x238(0x08)
	struct UWBP_ServerListModifierSettings_BasicFilters_C* BasicFilterSettings; // 0x240(0x08)
	struct UVerticalBox* FiltersVBox; // 0x248(0x08)
	struct FMulticastInlineDelegate OnServerFiltersChanged; // 0x250(0x10)

	void GetFilterRules(bool bActiveOnly, struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.GetFilterRules // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void FilterSettingsChanged(struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.FilterSettingsChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_JoinServerFiltersPanel(int32_t EntryPoint); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.ExecuteUbergraph_WBP_JoinServerFiltersPanel // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnServerFiltersChanged__DelegateSignature(struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.OnServerFiltersChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

