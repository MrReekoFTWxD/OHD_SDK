// WidgetBlueprintGeneratedClass WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C
// Size: 0x320 (Inherited: 0x230)
struct UWBP_ModifierSetting_ComboBox_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UComboBoxString* ModifierComboBox; // 0x238(0x08)
	struct UWBP_ModifierSettingBox_C* ModifierSetting; // 0x240(0x08)
	struct FText SettingText; // 0x248(0x18)
	struct FFModifierTextStyle SettingTextStyle; // 0x260(0x78)
	struct FMargin SettingComboBoxPadding; // 0x2d8(0x10)
	struct TArray<struct FString> DefaultOptions; // 0x2e8(0x10)
	int32_t DefaultSelectedOptionIdx; // 0x2f8(0x04)
	char pad_2FC[0x4]; // 0x2fc(0x04)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x300(0x10)
	struct FMulticastInlineDelegate OnOpening; // 0x310(0x10)

	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.GetSettingText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.SetSettingText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.BndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_1_OnOpeningEvent__DelegateSignature(); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.BndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_1_OnOpeningEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ModifierSetting_ComboBox(int32_t EntryPoint); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.ExecuteUbergraph_WBP_ModifierSetting_ComboBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnOpening__DelegateSignature(); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.OnOpening__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSelectionChanged__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.OnSelectionChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

