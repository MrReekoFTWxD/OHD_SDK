// WidgetBlueprintGeneratedClass WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C
// Size: 0x278 (Inherited: 0x230)
struct UWBP_FactionGameModifierSettings_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_ModifierSetting_ComboBox_C* FactionBlufor; // 0x238(0x08)
	struct UWBP_ModifierSetting_ComboBox_C* FactionOpfor; // 0x240(0x08)
	struct UWBP_ModifierSetting_CheckBox_C* KitRestrictionsToggle; // 0x248(0x08)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x250(0x08)
	struct UWBP_ModifierSetting_Numeric_C* TicketCountBlufor; // 0x258(0x08)
	struct UWBP_ModifierSetting_Numeric_C* TicketCountOpfor; // 0x260(0x08)
	struct TArray<struct FPrimaryAssetId> SelectableFactionAssetIds; // 0x268(0x10)

	void GetTravelURLOptions(struct FString& Options); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.GetTravelURLOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsEnabled(bool& bEnabled); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.IsEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BuildTicketCountURLOption(enum class EHDTeam Team, int32_t Count, struct FString& Pair); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildTicketCountURLOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void BuildFactionURLOption(enum class EHDTeam Team, struct FName PackageName, struct FString& Pair); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildFactionURLOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void Completed_7DC7FCB348F23B6EEE29D0A8EBA2EF94(struct TArray<struct UObject*>& Loaded); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.Completed_7DC7FCB348F23B6EEE29D0A8EBA2EF94 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.SetupModifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Destruct(); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_FactionGameModifierSettings(int32_t EntryPoint); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.ExecuteUbergraph_WBP_FactionGameModifierSettings // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

