// BlueprintGeneratedClass BP_HDHUDBase.BP_HDHUDBase_C
// Size: 0x494 (Inherited: 0x310)
struct ABP_HDHUDBase_C : AHDHUD {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x318(0x08)
	bool bDrawCrosshair; // 0x320(0x01)
	bool bShowCompass; // 0x321(0x01)
	bool bShowPlayerStatus; // 0x322(0x01)
	bool bShowWeaponStatus; // 0x323(0x01)
	bool bShowCaptureStatus; // 0x324(0x01)
	bool bShowEquipmentSelect; // 0x325(0x01)
	bool bShowWatermark; // 0x326(0x01)
	bool bInitialized; // 0x327(0x01)
	float CrosshairWidth; // 0x328(0x04)
	float CrosshairHeight; // 0x32c(0x04)
	struct UWBP_HUD_C* HUDContainerUWClass; // 0x330(0x08)
	enum class ESlateVisibility HUDContainerUWVisibilityOverride; // 0x338(0x01)
	bool bHUDWidgetShown; // 0x339(0x01)
	char pad_33A[0x6]; // 0x33a(0x06)
	struct APawn* LastOwningPawn; // 0x340(0x08)
	struct ABP_HDPlayerControllerBase_C* OwningHDPC; // 0x348(0x08)
	struct ABP_HDPlayerCharacterBase_C* OwningHDPawn; // 0x350(0x08)
	struct ADFBaseItem* OwningPawnEquippedItem; // 0x358(0x08)
	bool bDrawNametags; // 0x360(0x01)
	char pad_361[0x3]; // 0x361(0x03)
	float DrawNametagDistanceMin; // 0x364(0x04)
	float DrawNametagDistanceMax; // 0x368(0x04)
	char pad_36C[0x4]; // 0x36c(0x04)
	struct UWBP_HUD_C* HUDContainerUW; // 0x370(0x08)
	float DrawDotsDistanceMin; // 0x378(0x04)
	float DrawDotsDistanceMax; // 0x37c(0x04)
	struct UFont* NametagFont; // 0x380(0x08)
	float NametagTextVerticalOffset; // 0x388(0x04)
	int32_t NametagTextLengthMax; // 0x38c(0x04)
	bool bNametagUseTextScaling; // 0x390(0x01)
	char pad_391[0x3]; // 0x391(0x03)
	float NametagTextScaleMin; // 0x394(0x04)
	float NametagTextScaleMax; // 0x398(0x04)
	bool bEnableNametagTextFade; // 0x39c(0x01)
	char pad_39D[0x3]; // 0x39d(0x03)
	float NametagTextFadeRangeNear; // 0x3a0(0x04)
	float NametagDotVerticalOffset; // 0x3a4(0x04)
	bool bNametagUseDotSymbolScaling; // 0x3a8(0x01)
	char pad_3A9[0x3]; // 0x3a9(0x03)
	float NametagDotScaleMin; // 0x3ac(0x04)
	float NametagDotScaleMax; // 0x3b0(0x04)
	bool bEnableNametagDotFade; // 0x3b4(0x01)
	char pad_3B5[0x3]; // 0x3b5(0x03)
	float NametagDotFadeRangeNear; // 0x3b8(0x04)
	float NametagDotFadeRangeFar; // 0x3bc(0x04)
	struct FLinearColor NametagTextColorSquad; // 0x3c0(0x10)
	struct UTexture2D* NametagDotSymbolSquad; // 0x3d0(0x08)
	struct FLinearColor NametagDotSymbolSquadColor; // 0x3d8(0x10)
	float NametagDotSymbolSquadWidth; // 0x3e8(0x04)
	float NametagDotSymbolSquadHeight; // 0x3ec(0x04)
	struct FLinearColor NametagTextColorOther; // 0x3f0(0x10)
	struct UTexture2D* NametagDotSymbolOther; // 0x400(0x08)
	struct FLinearColor NametagDotSymbolOtherColor; // 0x408(0x10)
	float NametagDotSymbolOtherWidth; // 0x418(0x04)
	float NametagDotSymbolOtherHeight; // 0x41c(0x04)
	struct FLinearColor NametagTextColorDefault; // 0x420(0x10)
	struct UTexture2D* NametagDotSymbolDefault; // 0x430(0x08)
	struct FLinearColor NametagDotSymbolDefaultColor; // 0x438(0x10)
	float NametagDotSymbolDefaultWidth; // 0x448(0x04)
	float NametagDotSymbolDefaultHeight; // 0x44c(0x04)
	bool bNametagUseLineTraces; // 0x450(0x01)
	char pad_451[0x3]; // 0x451(0x03)
	struct FVector2D NametagReferenceResolution; // 0x454(0x08)
	float NametagLineTraceOffsetTop; // 0x45c(0x04)
	bool bNametagUseAdditionalLineTraces; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	float NametagAdditionalLineTraceOffsetSides; // 0x464(0x04)
	float NametagTextFadeRangeFar; // 0x468(0x04)
	bool bEnableNametagTextFrame; // 0x46c(0x01)
	char pad_46D[0x3]; // 0x46d(0x03)
	float NametagTextFrameHorizontalMargin; // 0x470(0x04)
	float NametagTextFrameHorizontalFade; // 0x474(0x04)
	float NametagTextFrameVerticalMargin; // 0x478(0x04)
	float NametagTextFrameVerticalFade; // 0x47c(0x04)
	bool bEnableNametagDotFrame; // 0x480(0x01)
	char pad_481[0x3]; // 0x481(0x03)
	float NametagDotFrameHorizontalMargin; // 0x484(0x04)
	float NametagDotFrameHorizontalFade; // 0x488(0x04)
	float NametagDotFrameVerticalMargin; // 0x48c(0x04)
	float NametagDotFrameVerticalFade; // 0x490(0x04)

	bool NametagsSingleLinetrace(struct FVector Start, struct FVector End, struct ABP_HDPlayerCharacterBase_C* OtherPlayer); // Function BP_HDHUDBase.BP_HDHUDBase_C.NametagsSingleLinetrace // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CanDrawNametag(struct ABP_HDPlayerCharacterBase_C* InOtherPawn, float InVerticalOffset, struct FVector InOwnerCameraLocation, bool& bCanDrawNametag, struct FVector2D& NametagScreenPosition); // Function BP_HDHUDBase.BP_HDHUDBase_C.CanDrawNametag // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void DrawNametags(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.DrawNametags // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DrawCrosshair(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.DrawCrosshair // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsTextChatHistoryVisible(bool& bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.IsTextChatHistoryVisible // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetTextChatHistoryVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetTextChatHistoryVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetMedicHealingEffectVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetMedicHealingEffectVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetAmmoResupplyEffectVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetAmmoResupplyEffectVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ResetPlayerStatusEffectsUI(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ResetPlayerStatusEffectsUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearOwningPawnReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ClearOwningPawnReferences // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ForceUpdateOwningPawnReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ForceUpdateOwningPawnReferences // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearAllOwningPlayerReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ClearAllOwningPlayerReferences // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ForceUpdateAllOwningPlayerReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ForceUpdateAllOwningPlayerReferences // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CleanupDelegatesForHDPawn(struct ABP_HDPlayerCharacterBase_C* PlayerChar); // Function BP_HDHUDBase.BP_HDHUDBase_C.CleanupDelegatesForHDPawn // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitOwningHDPawnDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.InitOwningHDPawnDelegates // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CleanupOwningHDPCDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.CleanupOwningHDPCDelegates // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitOwningHDPCDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.InitOwningHDPCDelegates // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateHUDVisibility(bool bDestroyOnHide); // Function BP_HDHUDBase.BP_HDHUDBase_C.UpdateHUDVisibility // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HideHUDWidget(bool bDestroyWidgetOnHide); // Function BP_HDHUDBase.BP_HDHUDBase_C.HideHUDWidget // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ShowHUDWidget(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ShowHUDWidget // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentSelectEquippedItem(struct UHDKit* CurrentLoadout, struct AHDBaseWeapon* EquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectEquippedItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentSelectItemBySlotNum(int32_t SlotNum, bool& bOutNewSelection); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectItemBySlotNum // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentGetSelectedItemSlotNum(int32_t& OutSlotNum, bool& bFoundItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentGetSelectedItemSlotNum // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void EquipmentGetSelectedItem(struct AHDBaseWeapon*& OutItemToEquip, bool& bFoundItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentGetSelectedItem // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void EquipmentAddItemsFromLoadout(struct UHDKit* NewLoadout, struct UDFInventoryComponent* PlayerInventory, struct ADFBaseWeapon* EquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentAddItemsFromLoadout // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentSelectItem(int32_t ItemIndex); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentSelectPrevItem(); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectPrevItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipmentSelectNextItem(); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectNextItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleWeaponStatusUI(bool bShown); // Function BP_HDHUDBase.BP_HDHUDBase_C.ToggleWeaponStatusUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleEquipmentUI(bool bShown); // Function BP_HDHUDBase.BP_HDHUDBase_C.ToggleEquipmentUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveDrawHUD(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveDrawHUD // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveBeginPlay(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaSeconds); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OwningPawnUpdated(struct APawn* NewOwningPawn, struct APawn* PrevOwningPawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPawnUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwningPawnEquipmentItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPawnEquipmentItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwningPlayerPossessPawn(struct APawn* Pawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPlayerPossessPawn // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwningPlayerUnpossessPawn(struct APawn* Pawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPlayerUnpossessPawn // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDHUDBase(int32_t EntryPoint); // Function BP_HDHUDBase.BP_HDHUDBase_C.ExecuteUbergraph_BP_HDHUDBase // (Final|UbergraphFunction) // @ game+0xec54e0
};

