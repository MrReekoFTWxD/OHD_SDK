// WidgetBlueprintGeneratedClass WBP_TextButton.WBP_TextButton_C
// Size: 0x631 (Inherited: 0x230)
struct UWBP_TextButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* Button; // 0x238(0x08)
	struct UTextBlock* ButtonText; // 0x240(0x08)
	struct FText BtnText; // 0x248(0x18)
	struct FMulticastInlineDelegate ButtonClicked; // 0x260(0x10)
	struct FMulticastInlineDelegate ButtonPressed; // 0x270(0x10)
	struct FMulticastInlineDelegate ButtonReleased; // 0x280(0x10)
	struct FMulticastInlineDelegate ButtonHovered; // 0x290(0x10)
	struct FMulticastInlineDelegate ButtonUnhovered; // 0x2a0(0x10)
	struct FMargin TextPadding; // 0x2b0(0x10)
	struct FSlateColor TextColorNormal; // 0x2c0(0x28)
	struct FSlateColor TextColorPressed; // 0x2e8(0x28)
	struct FSlateColor TextColorHovered; // 0x310(0x28)
	struct FButtonStyle BtnStyle; // 0x338(0x278)
	struct FSlateFontInfo TextFont; // 0x5b0(0x50)
	bool bUppercaseText; // 0x600(0x01)
	char pad_601[0x7]; // 0x601(0x07)
	struct FSlateColor TextColorCustom; // 0x608(0x28)
	bool bUseCustomTextColor; // 0x630(0x01)

	void PreConstruct(bool IsDesignTime); // Function WBP_TextButton.WBP_TextButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Button_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_TextButton(int32_t EntryPoint); // Function WBP_TextButton.WBP_TextButton_C.ExecuteUbergraph_WBP_TextButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void ButtonUnhovered__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.ButtonUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ButtonHovered__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.ButtonHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ButtonReleased__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.ButtonReleased__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ButtonPressed__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.ButtonPressed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ButtonClicked__DelegateSignature(); // Function WBP_TextButton.WBP_TextButton_C.ButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

