// WidgetBlueprintGeneratedClass WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C
// Size: 0x264 (Inherited: 0x238)
struct UWBP_OptionMenu_Credits_C : UDFBaseMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UScrollBox* CreditsScrollBox; // 0x240(0x08)
	struct UDataTable* CreditsEntriesTable; // 0x248(0x08)
	struct FMargin EntryPadding; // 0x250(0x10)
	float AutoScrollSpeed; // 0x260(0x04)

	void GetCreditEntriesForHeader(struct FName HeaderRowName, struct TArray<struct FFGameCreditsEntry>& CreditEntries); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.GetCreditEntriesForHeader // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionMenu_Credits(int32_t EntryPoint); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.ExecuteUbergraph_WBP_OptionMenu_Credits // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

