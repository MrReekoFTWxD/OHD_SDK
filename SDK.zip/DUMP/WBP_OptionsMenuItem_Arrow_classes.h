// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C
// Size: 0x2e0 (Inherited: 0x230)
struct UWBP_OptionsMenuItem_Arrow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* NextOptionBtn; // 0x238(0x08)
	struct UTextBlock* OptionText; // 0x240(0x08)
	struct UButton* PrevOptionBtn; // 0x248(0x08)
	struct USizeBox* SelectedOptionSizeBox; // 0x250(0x08)
	struct UTextBlock* SelectedOptionText; // 0x258(0x08)
	struct FText Text; // 0x260(0x18)
	struct TArray<struct FFOptionItemSelection> Options; // 0x278(0x10)
	int32_t SelectedOptionIndex; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x290(0x10)
	struct FText TextDescription; // 0x2a0(0x18)
	float TextWidth; // 0x2b8(0x04)
	enum class EArrowOptionsPreset OptionsPreset; // 0x2bc(0x01)
	char pad_2BD[0x3]; // 0x2bd(0x03)
	struct TArray<struct FFOptionItemSelection> ScalabilityOptions; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnSelectionChangedByUser; // 0x2d0(0x10)

	void FindOptionIndex(struct FText OptionDisplayName, int32_t& Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSelectedOption(struct FText OptionDisplayName); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOption // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSelectedOptionByValue(struct FString OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PopulateOptionsByPreset(enum class EArrowOptionsPreset Preset); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PopulateOptionsByPreset // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void FindOptionValueIndex(struct FString OptionValue, int32_t& Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionValueIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSelectedOptionByIndex(int32_t Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearSelection(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ClearSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void INTERNAL_ClearSelection(enum class ESelectInfo DeselectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_ClearSelection // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveOptionAtIndex(int32_t IndexToRemove, bool& bRemovalSuccess); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.RemoveOptionAtIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetOptionCount(int32_t& OptionCount); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AddOption(struct FFOptionItemSelection& NewOption); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.AddOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetOptionValueAtIndex(int32_t Index, struct FString& OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionValueAtIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetSelectedOptionValue(struct FString& OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetSelectedOptionValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void INTERNAL_SetSelectedOptionByIndex(int32_t Index, enum class ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_SetSelectedOptionByIndex // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearOptions(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ClearOptions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__PrevOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.BndEvt__PrevOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NextOptionBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.BndEvt__NextOptionBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnItemSelectionChanged(struct FString SelectedItemValue, enum class ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnItemSelectionChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionsMenuItem_Arrow(int32_t EntryPoint); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ExecuteUbergraph_WBP_OptionsMenuItem_Arrow // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChangedByUser__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSelectionChanged__DelegateSignature(struct FString SelectedItemValue, enum class ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

