// WidgetBlueprintGeneratedClass WBP_ServerListModifierSettings_AdvancedServerData.WBP_ServerListModifierSettings_AdvancedServerData_C
// Size: 0x240 (Inherited: 0x230)
struct UWBP_ServerListModifierSettings_AdvancedServerData_C : UUserWidget {
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x230(0x08)
	struct UTextBlock* ServerAddrText; // 0x238(0x08)
};

