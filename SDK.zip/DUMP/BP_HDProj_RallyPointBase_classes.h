// BlueprintGeneratedClass BP_HDProj_RallyPointBase.BP_HDProj_RallyPointBase_C
// Size: 0x430 (Inherited: 0x430)
struct ABP_HDProj_RallyPointBase_C : ABP_HDProj_SPDeployableBase_C {
};

