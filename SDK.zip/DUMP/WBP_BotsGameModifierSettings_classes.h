// WidgetBlueprintGeneratedClass WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C
// Size: 0x250 (Inherited: 0x230)
struct UWBP_BotsGameModifierSettings_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x238(0x08)
	struct UWBP_ModifierSetting_Numeric_C* TeamBotCountBlufor; // 0x240(0x08)
	struct UWBP_ModifierSetting_Numeric_C* TeamBotCountOpfor; // 0x248(0x08)

	void GetTravelURLOptions(struct FString& Options); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.GetTravelURLOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsEnabled(bool& bEnabled); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.IsEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BuildBotCountURLOption(enum class EHDTeam Team, int32_t Count, struct FString& Pair); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.BuildBotCountURLOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.SetupModifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_BotsGameModifierSettings(int32_t EntryPoint); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.ExecuteUbergraph_WBP_BotsGameModifierSettings // (Final|UbergraphFunction) // @ game+0xec54e0
};

