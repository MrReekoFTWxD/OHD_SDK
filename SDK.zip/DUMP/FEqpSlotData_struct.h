// UserDefinedStruct FEqpSlotData.FEqpSlotData
// Size: 0x18 (Inherited: 0x00)
struct FFEqpSlotData {
	struct FHDItemEntry EqpInfo_2_EAD02B2F4A66639E8B16A2868345A25B; // 0x00(0x10)
	struct AHDBaseWeapon* EqpItem_5_AA8380E94CCBE9B6415708811D76C341; // 0x10(0x08)
};

