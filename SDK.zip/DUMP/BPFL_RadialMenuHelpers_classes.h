// BlueprintGeneratedClass BPFL_RadialMenuHelpers.BPFL_RadialMenuHelpers_C
// Size: 0x28 (Inherited: 0x28)
struct UBPFL_RadialMenuHelpers_C : UBlueprintFunctionLibrary {

	void CenterMousePosition(int32_t PlayerIndex, struct APlayerController* PlayerController, struct UObject* __WorldContext); // Function BPFL_RadialMenuHelpers.BPFL_RadialMenuHelpers_C.CenterMousePosition // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

