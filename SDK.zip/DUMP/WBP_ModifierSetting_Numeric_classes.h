// WidgetBlueprintGeneratedClass WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C
// Size: 0x360 (Inherited: 0x230)
struct UWBP_ModifierSetting_Numeric_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_ModifierSettingBox_C* ModifierSetting; // 0x238(0x08)
	struct UTextBlock* NumericHintText; // 0x240(0x08)
	struct USpinBox* NumericSpinBox; // 0x248(0x08)
	struct FText SettingText; // 0x250(0x18)
	struct TMap<float, struct FText> MagicValues; // 0x268(0x50)
	struct FText MagicValueText; // 0x2b8(0x18)
	float ValueSnapDelta; // 0x2d0(0x04)
	float ValueInitial; // 0x2d4(0x04)
	struct FFNumericModifierValueBound ValueMinInitial; // 0x2d8(0x08)
	struct FFNumericModifierValueBound ValueMaxInitial; // 0x2e0(0x08)
	struct FSlateColor VisibleSpinBoxForegroundColor; // 0x2e8(0x28)
	int32_t MinFractionalDigitsInitial; // 0x310(0x04)
	int32_t MaxFractionalDigitsInitial; // 0x314(0x04)
	struct FSlateColor HiddenSpinBoxForegroundColor; // 0x318(0x28)
	struct FMulticastInlineDelegate OnValueChanged; // 0x340(0x10)
	struct FMulticastInlineDelegate OnValueCommitted; // 0x350(0x10)

	void UpdateMagicValueState(); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.UpdateMagicValueState // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetValueSnapDelta(float& Delta); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValueSnapDelta // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetValueSnapDelta(float InDelta); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValueSnapDelta // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetValue(float& Value); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetValue(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetMagicValueText(struct FText& MagicValueText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetMagicValueText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetMagicValueText(struct FText InMagicValueText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetMagicValueText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetSettingText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetSettingText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ModifierSetting_Numeric(int32_t EntryPoint); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.ExecuteUbergraph_WBP_ModifierSetting_Numeric // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnValueCommitted__DelegateSignature(float InValue, enum class ETextCommit CommitMethod); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueCommitted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnValueChanged__DelegateSignature(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

