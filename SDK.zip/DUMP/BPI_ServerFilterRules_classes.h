// BlueprintGeneratedClass BPI_ServerFilterRules.BPI_ServerFilterRules_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_ServerFilterRules_C : UInterface {

	void GetFilterRules(bool bActiveOnly, struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function BPI_ServerFilterRules.BPI_ServerFilterRules_C.GetFilterRules // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
};

