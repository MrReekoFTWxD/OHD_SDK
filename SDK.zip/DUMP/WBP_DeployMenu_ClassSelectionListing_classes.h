// WidgetBlueprintGeneratedClass WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C
// Size: 0xa18 (Inherited: 0x230)
struct UWBP_DeployMenu_ClassSelectionListing_C : UDeployMenu_ClassSelectionListing {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* ClassBg; // 0x238(0x08)
	struct UTextBlock* ClassNameText; // 0x240(0x08)
	struct UTextBlock* ClassRestrictedText; // 0x248(0x08)
	struct UImage* ClassSymbol; // 0x250(0x08)
	struct UUniformGridPanel* EqpGrid; // 0x258(0x08)
	struct UImage* EqpSlot1; // 0x260(0x08)
	struct UImage* EqpSlot2; // 0x268(0x08)
	struct UImage* EqpSlot3; // 0x270(0x08)
	struct UImage* EqpSlot4; // 0x278(0x08)
	struct UImage* EqpSlot5; // 0x280(0x08)
	struct UImage* EqpSlot6; // 0x288(0x08)
	struct UImage* EqpSlot7; // 0x290(0x08)
	struct UImage* EqpSlot8; // 0x298(0x08)
	struct UImage* Image_11; // 0x2a0(0x08)
	struct UImage* Image_12; // 0x2a8(0x08)
	struct UImage* Image_13; // 0x2b0(0x08)
	struct UImage* Image_14; // 0x2b8(0x08)
	struct UImage* PrimaryWeaponIcon; // 0x2c0(0x08)
	struct UOverlay* RestrictedOverlay; // 0x2c8(0x08)
	struct UButton* SelectClassBtn; // 0x2d0(0x08)
	struct UHDKit* Kit; // 0x2d8(0x08)
	bool bListingInitialized; // 0x2e0(0x01)
	char pad_2E1[0x7]; // 0x2e1(0x07)
	struct ABP_HDPlayerControllerBase_C* HDOwningPlayer; // 0x2e8(0x08)
	struct FMulticastInlineDelegate OnClassSelected; // 0x2f0(0x10)
	bool bSelected; // 0x300(0x01)
	bool bRestricted; // 0x301(0x01)
	char pad_302[0x6]; // 0x302(0x06)
	struct FMulticastInlineDelegate OnClassDeselected; // 0x308(0x10)
	struct FSlateBrush DefaultDisplaySymbolBrush; // 0x318(0x88)
	struct FLinearColor NoSymbolColor; // 0x3a0(0x10)
	struct FText DefaultDisplayNameText; // 0x3b0(0x18)
	struct FButtonStyle SelectedBtnStyle; // 0x3c8(0x278)
	struct FButtonStyle DeselectedBtnStyle; // 0x640(0x278)
	struct FSlateColor ClassSymbolDisabledTint; // 0x8b8(0x28)
	struct FSlateColor ClassSymbolEnabledTint; // 0x8e0(0x28)
	struct TArray<struct FHDItemEntry> KitItemEntries; // 0x908(0x10)
	struct FSlateBrush DefaultEqpSymbolBrush; // 0x918(0x88)
	struct FLinearColor DefaultEqpSymbolColor; // 0x9a0(0x10)
	struct FSlateColor RestrictedTextColor; // 0x9b0(0x28)
	struct FSlateColor UnrestrictedTextColor; // 0x9d8(0x28)
	struct FText KitLimitationDisplayText; // 0xa00(0x18)

	void AreColorsNearlyEqual(struct FLinearColor ColorOne, struct FLinearColor ColorTwo, bool& bEqual); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.AreColorsNearlyEqual // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void InternalFillEqpSlots(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalFillEqpSlots // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SortItemEntriesInPlaceBySlotNum(struct TArray<struct FHDItemEntry>& EntriesToSort); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SortItemEntriesInPlaceBySlotNum // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetEqpDisplaySymbolBySlotNum(int32_t SlotNum, struct UTexture2D* SlotSymbolToUse, bool bDesignTime); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetEqpDisplaySymbolBySlotNum // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetupKitDisplayEqpSlots(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayEqpSlots // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalGetEqpSlotImageWidgetByNum(int32_t SlotNum, struct UImage*& EqpSlotImage); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalGetEqpSlotImageWidgetByNum // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void InternalSetClassRestrictedState(bool bNewRestricted, struct FText& NewRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassRestrictedState // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalUpdateClassRestrictedText(bool bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalUpdateClassRestrictedText // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetupKitRestrictionDisplay(bool bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitRestrictionDisplay // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalIsKitRestricted(bool& bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalIsKitRestricted // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void InternalSetupKitDisplayName(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayName // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetupKitDisplaySymbol(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplaySymbol // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSelected(bool bSelected); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SetSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleClassSelection(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ToggleClassSelection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetClassSelectionState(bool bNewSelected); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassSelectionState // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DeselectClass(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.DeselectClass // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectClass(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SelectClass // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalSetupPrimaryWeaponIcon(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupPrimaryWeaponIcon // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateRestrictedState(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.UpdateRestrictedState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalKitDisplaySetup(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalKitDisplaySetup // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Init(struct UHDKit* Kit, struct ABP_HDPlayerControllerBase_C* OwningPC); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SelectClassBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.BndEvt__SelectClassBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing(int32_t EntryPoint); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnClassDeselected__DelegateSignature(struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassDeselected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnClassSelected__DelegateSignature(struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

