// WidgetBlueprintGeneratedClass WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C
// Size: 0x270 (Inherited: 0x264)
struct UWBP_OptionMenu_HDCredits_C : UWBP_OptionMenu_Credits_C {
	char pad_264[0x4]; // 0x264(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x268(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionMenu_HDCredits(int32_t EntryPoint); // Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.ExecuteUbergraph_WBP_OptionMenu_HDCredits // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

