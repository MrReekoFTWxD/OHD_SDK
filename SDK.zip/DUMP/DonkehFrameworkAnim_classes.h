// Class DonkehFrameworkAnim.AnimNotify_PlayFootstepFX
// Size: 0x150 (Inherited: 0x38)
struct UAnimNotify_PlayFootstepFX : UAnimNotify {
	struct TMap<enum class EPhysicalSurface, struct FPerspectiveSound> SoundsToPlay; // 0x38(0x50)
	float VolumeMultiplier; // 0x88(0x04)
	float PitchMultiplier; // 0x8c(0x04)
	char bAttachSound : 1; // 0x90(0x01)
	char bPlaySoundsWithPerspMeshOnly : 1; // 0x90(0x01)
	char pad_90_2 : 6; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct TMap<enum class EPhysicalSurface, struct UFXSystemAsset*> EffectsToSpawn; // 0x98(0x50)
	char bAttachEffect : 1; // 0xe8(0x01)
	char pad_E8_1 : 7; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct FVector EffectLocationOffset; // 0xec(0x0c)
	struct FRotator EffectRotationOffset; // 0xf8(0x0c)
	char pad_104[0x1c]; // 0x104(0x1c)
	struct FVector EffectScale; // 0x120(0x0c)
	char bSpawnEffectsWithPerspMeshOnly : 1; // 0x12c(0x01)
	char pad_12C_1 : 7; // 0x12c(0x01)
	enum class EFootstepVariant FootstepVariant; // 0x12d(0x01)
	char pad_12E[0x2]; // 0x12e(0x02)
	struct FName FootstepVariantParamName; // 0x130(0x08)
	struct FName FootBoneName; // 0x138(0x08)
	float FootTraceOffset; // 0x140(0x04)
	char bDebug : 1; // 0x144(0x01)
	char pad_144_1 : 7; // 0x144(0x01)
	char pad_145[0xb]; // 0x145(0x0b)

	void SetFootstepNotifyProps(struct FFootstepFXSettings& PropsToUse); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.SetFootstepNotifyProps // (Final|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x70b7a0
	struct FFootstepFXSettings GetFootstepNotifyProps(); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.GetFootstepNotifyProps // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x70b510
	bool EqualProps(struct FFootstepFXSettings& Props, struct FFootstepFXSettings& OtherProps); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.EqualProps // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x70b120
};

// Class DonkehFrameworkAnim.DFCharacterAnimInstance
// Size: 0x2c0 (Inherited: 0x270)
struct UDFCharacterAnimInstance : UAnimInstance {
	char bPreviewAnimInstance : 1; // 0x268(0x01)
	struct APawn* CachedPawnOwner; // 0x270(0x08)
	struct ADFBaseCharacter* DFCharOwner; // 0x278(0x08)
	struct AController* ControllerOwner; // 0x280(0x08)
	struct ADFBaseItem* EquippedWeapon; // 0x288(0x08)
	enum class EMovementMode MoveMode; // 0x290(0x01)
	enum class ECharacterStance MoveStance; // 0x291(0x01)
	char pad_292_1 : 7; // 0x292(0x01)
	char pad_293[0x1]; // 0x293(0x01)
	struct FVector MoveVelocity; // 0x294(0x0c)
	float MoveSpeed; // 0x2a0(0x04)
	float MoveDirectionDeg; // 0x2a4(0x04)
	char bMoving : 1; // 0x2a8(0x01)
	char bInAir : 1; // 0x2a8(0x01)
	char bJumped : 1; // 0x2a8(0x01)
	char bSprinting : 1; // 0x2a8(0x01)
	char bAiming : 1; // 0x2a8(0x01)
	char bLeaning : 1; // 0x2a8(0x01)
	char pad_2A8_6 : 2; // 0x2a8(0x01)
	struct FDFCharStanceContext StandState; // 0x2a9(0x01)
	struct FDFCharStanceContext CrouchState; // 0x2aa(0x01)
	struct FDFCharStanceContext ProneState; // 0x2ab(0x01)
	struct FRotator AimOffsets; // 0x2ac(0x0c)
	char pad_2B8[0x8]; // 0x2b8(0x08)

	struct ADFBaseItem* TryGetOwnerWeapon(); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetOwnerWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x70b8b0
	struct AController* TryGetControllerOwner(); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetControllerOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x70b880
	void EquippedWeaponChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedWeap, struct ADFBaseItem* PrevEquippedWeap); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.EquippedWeaponChanged // (Final|Native|Private) // @ game+0x70b410
	void BlueprintUpdatePawnOwnerRefs(struct APawn* NewPawn); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdatePawnOwnerRefs // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BlueprintUpdateEquippedWeaponRefs(struct ADFBaseItem* NewWeap); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateEquippedWeaponRefs // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BlueprintUpdateControllerOwnerRefs(struct AController* NewC); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateControllerOwnerRefs // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class DonkehFrameworkAnim.DFWeaponAnimInstance
// Size: 0x280 (Inherited: 0x270)
struct UDFWeaponAnimInstance : UAnimInstance {
	char bPreviewAnimInstance : 1; // 0x268(0x01)
	struct ADFBaseWeapon* WeaponOwner; // 0x270(0x08)
	char pad_278_1 : 7; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)

	struct ADFBaseWeapon* TryGetWeaponOwner(); // Function DonkehFrameworkAnim.DFWeaponAnimInstance.TryGetWeaponOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x70b8e0
	void BlueprintUpdateWeaponOwnerRefs(struct ADFBaseWeapon* NewWeap); // Function DonkehFrameworkAnim.DFWeaponAnimInstance.BlueprintUpdateWeaponOwnerRefs // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

