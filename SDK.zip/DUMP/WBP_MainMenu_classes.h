// WidgetBlueprintGeneratedClass WBP_MainMenu.WBP_MainMenu_C
// Size: 0x3ec (Inherited: 0x238)
struct UWBP_MainMenu_C : UDFBaseMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* MainMenuOpenUIAnim; // 0x240(0x08)
	struct UNamedSlot* BgSlot; // 0x248(0x08)
	struct UTextBlock* CopyrightNoticeText; // 0x250(0x08)
	struct UWBP_MainMenu_NavBarButton_C* CreditsNavBtn; // 0x258(0x08)
	struct UWBP_MainMenu_NavBarButton_C* ExitGameNavBtn; // 0x260(0x08)
	struct UImage* FooterBg; // 0x268(0x08)
	struct UWBP_MainMenu_NavBarButton_C* HomeNavBtn; // 0x270(0x08)
	struct UWBP_MainMenu_NavBarButton_C* LeaveGameNavBtn; // 0x278(0x08)
	struct UImage* Logo; // 0x280(0x08)
	struct UHorizontalBox* MainMenuNavHBox; // 0x288(0x08)
	struct UWBP_MainMenu_NavBarButton_C* ModsNavBtn; // 0x290(0x08)
	struct UWBP_MainMenu_NavBarButton_C* MultiplayerNavBtn; // 0x298(0x08)
	struct UImage* NavBarBg; // 0x2a0(0x08)
	struct UWidgetSwitcher* NavBarWS; // 0x2a8(0x08)
	struct UBorder* OptionMenuContainer; // 0x2b0(0x08)
	struct UWBP_MainMenu_NavBarButton_C* OptionsNavBtn; // 0x2b8(0x08)
	struct UWBP_MainMenu_NavBarButton_C* PauseExitGameNavBtn; // 0x2c0(0x08)
	struct UHorizontalBox* PauseMenuNavHBox; // 0x2c8(0x08)
	struct UWBP_MainMenu_NavBarButton_C* ResumeNavBtn; // 0x2d0(0x08)
	struct UWBP_MainMenu_NavBarButton_C* ShootingRangeNavBtn; // 0x2d8(0x08)
	struct UWBP_MainMenu_NavBarButton_C* SingleplayerNavBtn; // 0x2e0(0x08)
	struct USizeBox* SubNavBar; // 0x2e8(0x08)
	struct UVerticalBox* SubNavVBox; // 0x2f0(0x08)
	bool bPauseMenu; // 0x2f8(0x01)
	bool bShowPauseMenuInDesigner; // 0x2f9(0x01)
	char pad_2FA[0x2]; // 0x2fa(0x02)
	int32_t MenuIndex; // 0x2fc(0x04)
	bool bShowReferenceBackground; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)
	struct UUserWidget* MenuBackgroundUWClass; // 0x308(0x08)
	struct UUserWidget* PauseMenuBackgroundUWClass; // 0x310(0x08)
	struct FVector2D LogoPosition; // 0x318(0x08)
	struct FSlateBrush LogoBrush; // 0x320(0x88)
	struct TArray<struct FFSubMenuOption> CurrentSubMenuOptions; // 0x3a8(0x10)
	struct UDFBaseMenu* CurrentOptionMenu; // 0x3b8(0x08)
	struct FMargin SubNavBtnPadding; // 0x3c0(0x10)
	struct USoundBase* MenuMusic; // 0x3d0(0x08)
	struct UAudioComponent* MenuMusicAC; // 0x3d8(0x08)
	bool bShowShootingRangeBtn; // 0x3e0(0x01)
	char pad_3E1[0x3]; // 0x3e1(0x03)
	struct FName ShootingRangeLevelName; // 0x3e4(0x08)

	void PlayMenuMusic(); // Function WBP_MainMenu.WBP_MainMenu_C.PlayMenuMusic // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MainMenu.WBP_MainMenu_C.OnMouseWheel // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MainMenu.WBP_MainMenu_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TeardownSubNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.TeardownSubNavBarClickEvents // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupSubNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupSubNavBarClickEvents // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleSubNavBar(bool bNewVisible); // Function WBP_MainMenu.WBP_MainMenu_C.ToggleSubNavBar // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearCurrentOptionMenu(); // Function WBP_MainMenu.WBP_MainMenu_C.ClearCurrentOptionMenu // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PopulateSubNavBar(struct TArray<struct FFSubMenuOption>& SubMenuOptions); // Function WBP_MainMenu.WBP_MainMenu_C.PopulateSubNavBar // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearSubNavBarOptions(); // Function WBP_MainMenu.WBP_MainMenu_C.ClearSubNavBarOptions // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateSubNavBarOptions(struct TScriptInterface<IBPI_OptionMenu_C> NewOptionMenu); // Function WBP_MainMenu.WBP_MainMenu_C.UpdateSubNavBarOptions // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetNavBarHBox(struct UHorizontalBox*& HBoxToUse); // Function WBP_MainMenu.WBP_MainMenu_C.GetNavBarHBox // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetOptionMenu(struct UDFBaseMenu* NewOptionMenuClass, bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.SetOptionMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetNavBtnCount(int32_t& Count); // Function WBP_MainMenu.WBP_MainMenu_C.GetNavBtnCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupCopyrightNotice(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupCopyrightNotice // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetActiveMenu(int32_t NewIndex, struct UDFBaseMenu* NewOptionMenuClass, bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.SetActiveMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupNavBarClickEvents // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupMenuBackgroundWidget(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupMenuBackgroundWidget // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitMenuState(bool bIsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.InitMenuState // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_MainMenu.WBP_MainMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnNavBtnClicked(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.OnNavBtnClicked // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnSubNavBtnClicked(struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.OnSubNavBtnClicked // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPauseMenuPressed(); // Function WBP_MainMenu.WBP_MainMenu_C.OnPauseMenuPressed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_MainMenu.WBP_MainMenu_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_MainMenu(int32_t EntryPoint); // Function WBP_MainMenu.WBP_MainMenu_C.ExecuteUbergraph_WBP_MainMenu // (Final|UbergraphFunction) // @ game+0xec54e0
};

