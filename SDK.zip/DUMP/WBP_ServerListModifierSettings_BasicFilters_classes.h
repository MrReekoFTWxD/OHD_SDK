// WidgetBlueprintGeneratedClass WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C
// Size: 0x2a0 (Inherited: 0x230)
struct UWBP_ServerListModifierSettings_BasicFilters_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_ServerListModifierSetting_FilterRule_C* ModdedFilter; // 0x238(0x08)
	struct UWBP_ServerListModifierSetting_FilterRule_Toggle_C* NoPasswordToggle; // 0x240(0x08)
	struct UWBP_ServerListModifierSetting_FilterRule_Toggle_C* NotFullToggle; // 0x248(0x08)
	struct UWBP_ServerListModifierSetting_FilterRule_Toggle_C* SameVersionToggle; // 0x250(0x08)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x258(0x08)
	struct UVerticalBox* SettingsListVBox; // 0x260(0x08)
	struct UWBP_ModifierSetting_ComboBox_C* SortByOrder; // 0x268(0x08)
	struct UWBP_ModifierSetting_ComboBox_C* SortByPreference; // 0x270(0x08)
	struct UWBP_ServerListModifierSetting_FilterRule_C* SupporterOnlyFilter; // 0x278(0x08)
	struct FMulticastInlineDelegate OnFilterSettingsChanged; // 0x280(0x10)
	struct FMulticastInlineDelegate OnSortPreferenceChanged; // 0x290(0x10)

	void GetFilterRules(bool bActiveOnly, struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.GetFilterRules // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetSelectedServerSortPreference(struct FFServerSortPreference& SortPreference); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.GetSelectedServerSortPreference // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void BndEvt__SortByPreference_K2Node_ComponentBoundEvent_0_OnSelectionChanged__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.BndEvt__SortByPreference_K2Node_ComponentBoundEvent_0_OnSelectionChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SectionContainer_K2Node_ComponentBoundEvent_1_OnActivated__DelegateSignature(); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.BndEvt__SectionContainer_K2Node_ComponentBoundEvent_1_OnActivated__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SectionContainer_K2Node_ComponentBoundEvent_2_OnDeactivated__DelegateSignature(); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.BndEvt__SectionContainer_K2Node_ComponentBoundEvent_2_OnDeactivated__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SortByOrder_K2Node_ComponentBoundEvent_3_OnSelectionChanged__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.BndEvt__SortByOrder_K2Node_ComponentBoundEvent_3_OnSelectionChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void FilterSettingChanged(struct UHDServerListFilterRule* Rule, struct FHDFilterRuleParams RuleParams); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.FilterSettingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ServerListModifierSettings_BasicFilters(int32_t EntryPoint); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.ExecuteUbergraph_WBP_ServerListModifierSettings_BasicFilters // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnFilterSettingsChanged__DelegateSignature(struct TMap<struct UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.OnFilterSettingsChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSortPreferenceChanged__DelegateSignature(struct FFServerSortPreference SortPreference); // Function WBP_ServerListModifierSettings_BasicFilters.WBP_ServerListModifierSettings_BasicFilters_C.OnSortPreferenceChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

