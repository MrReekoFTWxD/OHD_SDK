// WidgetBlueprintGeneratedClass WBP_HDPOI_Player.WBP_HDPOI_Player_C
// Size: 0x410 (Inherited: 0x3a0)
struct UWBP_HDPOI_Player_C : UDFPOIWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UImage* PlayerIcon; // 0x3a8(0x08)
	struct UTextBlock* SquadNumberText; // 0x3b0(0x08)
	bool POIWidgetInitialized; // 0x3b8(0x01)
	char pad_3B9[0x7]; // 0x3b9(0x07)
	struct FSlateColor SelectedTintColor; // 0x3c0(0x28)
	struct FSlateColor DeselectedTintColor; // 0x3e8(0x28)

	void ReceivePOISelected(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ReceivePOISelected // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePOIDeselected(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ReceivePOIDeselected // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void SetIconBrush(struct FSlateBrush& NewIconBrush); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.SetIconBrush // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDPOI_Player(int32_t EntryPoint); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ExecuteUbergraph_WBP_HDPOI_Player // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

