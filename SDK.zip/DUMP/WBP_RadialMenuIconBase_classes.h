// WidgetBlueprintGeneratedClass WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C
// Size: 0x2a4 (Inherited: 0x230)
struct UWBP_RadialMenuIconBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWidgetAnimation* Shake; // 0x238(0x08)
	struct UWidgetAnimation* Grow; // 0x240(0x08)
	struct UImage* Icon; // 0x248(0x08)
	struct USizeBox* Sizer; // 0x250(0x08)
	struct UTexture2D* IconImage; // 0x258(0x08)
	float IconSize; // 0x260(0x04)
	struct FSRadialMenuIconSettings Settings; // 0x264(0x28)
	struct FLinearColor CurrentColor; // 0x28c(0x10)
	bool highlighted; // 0x29c(0x01)
	char pad_29D[0x3]; // 0x29d(0x03)
	float Alpha; // 0x2a0(0x04)

	struct FLinearColor Get_Icon_ColorAndOpacity_1(); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.Get_Icon_ColorAndOpacity_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnHighlight(); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.OnHighlight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnUnhighlight(); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.OnUnhighlight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_RadialMenuIconBase(int32_t EntryPoint); // Function WBP_RadialMenuIconBase.WBP_RadialMenuIconBase_C.ExecuteUbergraph_WBP_RadialMenuIconBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

