// UserDefinedEnum EEntitlementType.EEntitlementType
enum class EEntitlementType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EEntitlementType_MAX = 2
};

