// Enum HDCoreUGC.EHDCoreUGCTargetState
enum class EHDCoreUGCTargetState : uint8 {
	Installed = 0,
	Registered = 1,
	Loaded = 2,
	Active = 3,
	EHDCoreUGCTargetState_MAX = 4
};

// ScriptStruct HDCoreUGC.UGCPrimaryAssetSearchInfo
// Size: 0x18 (Inherited: 0x00)
struct FUGCPrimaryAssetSearchInfo {
	struct FPrimaryAssetType AssetType; // 0x00(0x08)
	struct FString Directory; // 0x08(0x10)
};

// ScriptStruct HDCoreUGC.HDCoreUGCPluginStateMachineProperties
// Size: 0xe8 (Inherited: 0x00)
struct FHDCoreUGCPluginStateMachineProperties {
	char pad_0[0x90]; // 0x00(0x90)
	struct UHDCoreUGCData* UGCData; // 0x90(0x08)
	char pad_98[0x50]; // 0x98(0x50)
};

