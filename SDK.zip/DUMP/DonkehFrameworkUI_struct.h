// Enum DonkehFrameworkUI.EMenuActivationMode
enum class EMenuActivationMode : uint8 {
	Transparent = 0,
	Opaque = 1,
	Exclusive = 2,
	EMenuActivationMode_MAX = 3
};

// ScriptStruct DonkehFrameworkUI.MenuStackEntry
// Size: 0x10 (Inherited: 0x00)
struct FMenuStackEntry {
	struct UDFBaseMenu* Menu; // 0x00(0x08)
	enum class EMenuActivationMode ActivationMode; // 0x08(0x01)
	bool bShowMouseCursor; // 0x09(0x01)
	bool bUIOnlyInput; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
};

// ScriptStruct DonkehFrameworkUI.MinimapPOITableRow
// Size: 0x130 (Inherited: 0x08)
struct FMinimapPOITableRow : FTableRowBase {
	struct TSoftClassPtr<UObject> ActorClass; // 0x08(0x28)
	char bMatchChildClasses : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TSoftClassPtr<UObject> ToolTipWidgetClass; // 0x38(0x28)
	struct TSoftClassPtr<UObject> WidgetClass; // 0x60(0x28)
	struct FSlateBrush IconBrush; // 0x88(0x88)
	struct FText ToolTipText; // 0x110(0x18)
	char bSelectable : 1; // 0x128(0x01)
	char bDynamic : 1; // 0x128(0x01)
	char bFixedRotation : 1; // 0x128(0x01)
	char pad_128_3 : 5; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

