// BlueprintGeneratedClass BP_HDPlatoonInfoBase.BP_HDPlatoonInfoBase_C
// Size: 0x68 (Inherited: 0x68)
struct UBP_HDPlatoonInfoBase_C : UHDPlatoonInfo {
};

