// Class TinkerUI.TBButton
// Size: 0x460 (Inherited: 0x428)
struct UTBButton : UButton {
	struct FMulticastInlineDelegate OnDoubleClicked; // 0x428(0x10)
	char pad_438[0x10]; // 0x438(0x10)
	char pad_448_0 : 2; // 0x448(0x01)
	char bStopDoubleClickPropagation : 1; // 0x448(0x01)
	char pad_448_3 : 5; // 0x448(0x01)
	char pad_449[0x17]; // 0x449(0x17)

	void StopDoubleClickPropagation(); // Function TinkerUI.TBButton.StopDoubleClickPropagation // (Final|Native|Public|BlueprintCallable) // @ game+0x815f70
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // Function TinkerUI.TBButton.SetIsInteractionEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x815dd0
	void SetIsFocusable(bool bInIsFocusable); // Function TinkerUI.TBButton.SetIsFocusable // (Final|Native|Public|BlueprintCallable) // @ game+0x815d40
	bool IsInteractionEnabled(); // Function TinkerUI.TBButton.IsInteractionEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x815d10
	bool GetIsFocusable(); // Function TinkerUI.TBButton.GetIsFocusable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x815ce0
};

// Class TinkerUI.TBListView
// Size: 0x378 (Inherited: 0x368)
struct UTBListView : UListView {
	struct FMulticastInlineDelegate BP_OnPreviewItemCreated; // 0x368(0x10)
};

// Class TinkerUI.TBSlider
// Size: 0x508 (Inherited: 0x4f8)
struct UTBSlider : USlider {
	struct FLinearColor SliderFgBarColor; // 0x4f8(0x10)

	void SetSliderFgBarColor(struct FLinearColor InValue); // Function TinkerUI.TBSlider.SetSliderFgBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x815ef0
	void SetMouseUsesStep(bool bInValue); // Function TinkerUI.TBSlider.SetMouseUsesStep // (Final|Native|Public|BlueprintCallable) // @ game+0x815e60
};

// Class TinkerUI.TBSliderWidgetStyle
// Size: 0x370 (Inherited: 0x30)
struct UTBSliderWidgetStyle : USlateWidgetStyleContainerBase {
	struct FSliderStyle SliderStyle; // 0x30(0x340)
};

