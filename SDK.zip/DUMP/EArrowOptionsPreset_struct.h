// UserDefinedEnum EArrowOptionsPreset.EArrowOptionsPreset
enum class EArrowOptionsPreset : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EArrowOptionsPreset_MAX = 2
};

