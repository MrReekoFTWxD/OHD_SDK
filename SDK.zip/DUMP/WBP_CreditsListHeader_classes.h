// WidgetBlueprintGeneratedClass WBP_CreditsListHeader.WBP_CreditsListHeader_C
// Size: 0x278 (Inherited: 0x230)
struct UWBP_CreditsListHeader_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* DividerLine; // 0x238(0x08)
	struct UTextBlock* HeaderText; // 0x240(0x08)
	struct FFGameCreditsEntry CreditsEntry; // 0x248(0x30)

	void SetCreditsEntry(struct FFGameCreditsEntry& Entry, struct FMargin HeaderPadding); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.SetCreditsEntry // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CreditsListHeader(int32_t EntryPoint); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.ExecuteUbergraph_WBP_CreditsListHeader // (Final|UbergraphFunction) // @ game+0xec54e0
};

