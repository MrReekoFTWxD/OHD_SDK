// WidgetBlueprintGeneratedClass WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C
// Size: 0x802 (Inherited: 0x230)
struct UWBP_DeployMenu_DeployButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* DeployBtn; // 0x238(0x08)
	struct UTextBlock* DeployBtnText; // 0x240(0x08)
	bool bCloseBtnBehavior; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
	struct FText DeployText; // 0x250(0x18)
	struct FText CloseMenuText; // 0x268(0x18)
	struct FMulticastInlineDelegate OnClicked; // 0x280(0x10)
	struct FMulticastInlineDelegate OnPressed; // 0x290(0x10)
	struct FMulticastInlineDelegate OnReleased; // 0x2a0(0x10)
	struct FMulticastInlineDelegate OnHovered; // 0x2b0(0x10)
	struct FMulticastInlineDelegate OnUnhovered; // 0x2c0(0x10)
	struct FText SelectSpawnText; // 0x2d0(0x18)
	bool bDeploying; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct FButtonStyle DeployBtnStyle; // 0x2f0(0x278)
	struct FButtonStyle CancelBtnStyle; // 0x568(0x278)
	bool bDesignPreviewCancelBtn; // 0x7e0(0x01)
	char pad_7E1[0x7]; // 0x7e1(0x07)
	struct FText CancelDeploymentText; // 0x7e8(0x18)
	bool bSpawnPointSelected; // 0x800(0x01)
	bool bUseCancelBehavior; // 0x801(0x01)

	void InternalGetSpawnTimeRemaining(int32_t& SpawnSeconds); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalGetSpawnTimeRemaining // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void InternalUpdateBtnStyle(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnStyle // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalUpdateBtnText(bool bDeploying, bool bSpawnPointSelected); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateDeployBtnState(bool bPlayerAlive, bool bDeploymentQueued, bool bSpawnPointSelected); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.UpdateDeployBtnState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_DeployButton(int32_t EntryPoint); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.ExecuteUbergraph_WBP_DeployMenu_DeployButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnUnhovered__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnUnhovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnHovered__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnReleased__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnReleased__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPressed__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnPressed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnClicked__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

