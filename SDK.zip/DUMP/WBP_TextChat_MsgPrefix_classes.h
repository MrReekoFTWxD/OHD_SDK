// WidgetBlueprintGeneratedClass WBP_TextChat_MsgPrefix.WBP_TextChat_MsgPrefix_C
// Size: 0x240 (Inherited: 0x230)
struct UWBP_TextChat_MsgPrefix_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* MsgIcon; // 0x238(0x08)

	void SetupMsgPrefix(struct UHDTextChatMsgInfo* Msg); // Function WBP_TextChat_MsgPrefix.WBP_TextChat_MsgPrefix_C.SetupMsgPrefix // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_TextChat_MsgPrefix(int32_t EntryPoint); // Function WBP_TextChat_MsgPrefix.WBP_TextChat_MsgPrefix_C.ExecuteUbergraph_WBP_TextChat_MsgPrefix // (Final|UbergraphFunction) // @ game+0xec54e0
};

