// Enum HDMain.EHDTeam
enum class EHDTeam : uint8 {
	Red = 0,
	Blue = 1,
	NoTeam = 255,
	EHDTeam_MAX = 256
};

// Enum HDMain.EHDWeaponAimStyle
enum class EHDWeaponAimStyle : uint8 {
	None = 0,
	PointAim = 1,
	OpticMode1 = 2,
	OpticMode2 = 3,
	OpticMode3 = 4,
	EHDWeaponAimStyle_MAX = 5
};

// Enum HDMain.EHDAIThreatLevel
enum class EHDAIThreatLevel : uint8 {
	None = 0,
	Safe = 1,
	Aware = 2,
	Combat = 3,
	Danger = 4,
	EHDAIThreatLevel_MAX = 5
};

// Enum HDMain.EHDPrimaryAssetType
enum class EHDPrimaryAssetType : uint8 {
	Faction = 0,
	GameMode = 1,
	Map = 2,
	Platoon = 3,
	Ruleset = 4,
	EHDPrimaryAssetType_MAX = 5
};

// Enum HDMain.EHDAIVocalizationType
enum class EHDAIVocalizationType : uint8 {
	None = 0,
	Contact = 1,
	LostContact = 2,
	Reloading = 3,
	BeenHit = 4,
	UnderSuppression = 5,
	Death = 6,
	EHDAIVocalizationType_MAX = 7
};

// Enum HDMain.EHDAICaptureMode
enum class EHDAICaptureMode : uint8 {
	Attack = 0,
	Defend = 1,
	None = 2,
	EHDAICaptureMode_MAX = 3
};

// Enum HDMain.EHDControlPointObjectiveType
enum class EHDControlPointObjectiveType : uint8 {
	Offensive = 0,
	Defensive = 1,
	NoObjective = 2,
	EHDControlPointObjectiveType_MAX = 3
};

// Enum HDMain.EHDServerListSortBy
enum class EHDServerListSortBy : uint8 {
	None = 0,
	Name = 1,
	Mode = 2,
	Map = 3,
	PlayerCount = 4,
	Ping = 5,
	Version = 6,
	EHDServerListSortBy_MAX = 7
};

// Enum HDMain.EHDFilterRuleComparisonOp
enum class EHDFilterRuleComparisonOp : uint8 {
	EqualTo = 0,
	NotEqualTo = 1,
	EHDFilterRuleComparisonOp_MAX = 2
};

// Enum HDMain.EHDFilterRuleBehavior
enum class EHDFilterRuleBehavior : uint8 {
	Show = 0,
	Hide = 1,
	OnlyShow = 2,
	EHDFilterRuleBehavior_MAX = 3
};

// Enum HDMain.EHDUICharacterStanceState
enum class EHDUICharacterStanceState : uint8 {
	Stand = 0,
	StandAim = 1,
	StandMount = 2,
	Sprint = 3,
	Crouch = 4,
	CrouchAim = 5,
	CrouchMount = 6,
	Prone = 7,
	EHDUICharacterStanceState_MAX = 8
};

// ScriptStruct HDMain.HDSquadAssignmentInfo
// Size: 0x10 (Inherited: 0x00)
struct FHDSquadAssignmentInfo {
	struct AHDSquadState* SquadState; // 0x00(0x08)
	float SquadAssignmentTime; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct HDMain.HDAISpecificItemTypeAttackData
// Size: 0x2c (Inherited: 0x00)
struct FHDAISpecificItemTypeAttackData {
	float AttackRateMin; // 0x00(0x04)
	float AttackRateMax; // 0x04(0x04)
	float BurstAttackProbability; // 0x08(0x04)
	int32_t BurstAttackNumberMin; // 0x0c(0x04)
	int32_t BurstAttackNumberMax; // 0x10(0x04)
	float WeaponStopFireTimeMin; // 0x14(0x04)
	float WeaponStopFireTimeMax; // 0x18(0x04)
	float AfterEquipCooldownTime; // 0x1c(0x04)
	float SpecialtyItemUseTimeLimit; // 0x20(0x04)
	float AfterSpecialtyItemUsedTimeLimit; // 0x24(0x04)
	char bWeaponMovementFire : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
};

// ScriptStruct HDMain.HDAIItemData
// Size: 0x08 (Inherited: 0x00)
struct FHDAIItemData {
	enum class ESpecificItemType SpecificType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t InventoryIndex; // 0x04(0x04)
};

// ScriptStruct HDMain.HDAIGroupData
// Size: 0x28 (Inherited: 0x00)
struct FHDAIGroupData {
	struct AHDBaseCapturePoint* CapturePoint; // 0x00(0x08)
	enum class EHDAICaptureMode CaptureMode; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	struct FVector GroupCenter; // 0x0c(0x0c)
	struct FVector TargetLocation; // 0x18(0x0c)
	int32_t FormationIndex; // 0x24(0x04)
};

// ScriptStruct HDMain.HDAIMasterNavPoint
// Size: 0x10 (Inherited: 0x00)
struct FHDAIMasterNavPoint {
	struct FVector Location; // 0x00(0x0c)
	float DistanceToNext; // 0x0c(0x04)
};

// ScriptStruct HDMain.HDPrimaryAssetSearchPath
// Size: 0x18 (Inherited: 0x00)
struct FHDPrimaryAssetSearchPath {
	enum class EHDPrimaryAssetType AssetType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Directory; // 0x08(0x10)
};

// ScriptStruct HDMain.PTTKeyState
// Size: 0x0c (Inherited: 0x00)
struct FPTTKeyState {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct HDMain.ControlPointRulesetSettings
// Size: 0x20 (Inherited: 0x00)
struct FControlPointRulesetSettings {
	int32_t TicketsGainedForCapture; // 0x00(0x04)
	int32_t TicketsGainedForCaptureFromNeutral; // 0x04(0x04)
	int32_t TicketsLostOnCapture; // 0x08(0x04)
	float PointsForNeutralize; // 0x0c(0x04)
	float PointsForCapture; // 0x10(0x04)
	float PointsForDefense; // 0x14(0x04)
	float PointsOnCaptureProgress; // 0x18(0x04)
	float PointsOnDefenseProgress; // 0x1c(0x04)
};

// ScriptStruct HDMain.KillDeathRulesetSettings
// Size: 0x28 (Inherited: 0x00)
struct FKillDeathRulesetSettings {
	int32_t TicketsGainedForKill; // 0x00(0x04)
	int32_t TicketsLostOnKill; // 0x04(0x04)
	int32_t TicketsLostOnTeamKill; // 0x08(0x04)
	int32_t TicketsLostOnDeath; // 0x0c(0x04)
	int32_t TicketsLostOnSuicide; // 0x10(0x04)
	float PointsForKill; // 0x14(0x04)
	float PointsForAssist; // 0x18(0x04)
	float PointsForTeamKill; // 0x1c(0x04)
	float PointsForDeath; // 0x20(0x04)
	float PointsForSuicide; // 0x24(0x04)
};

// ScriptStruct HDMain.TicketBleedRulesetSettings
// Size: 0x0c (Inherited: 0x00)
struct FTicketBleedRulesetSettings {
	int32_t TicketBleed; // 0x00(0x04)
	int32_t MercyTicketBleed; // 0x04(0x04)
	char bAllowMercyTicketBleed : 1; // 0x08(0x01)
	char pad_8_1 : 7; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct HDMain.AICharacterVocalProfile
// Size: 0x68 (Inherited: 0x08)
struct FAICharacterVocalProfile : FTableRowBase {
	struct TArray<struct USoundBase*> ContactSounds; // 0x08(0x10)
	struct TArray<struct USoundBase*> LostContactSounds; // 0x18(0x10)
	struct TArray<struct USoundBase*> ReloadingSounds; // 0x28(0x10)
	struct TArray<struct USoundBase*> BeenHitSounds; // 0x38(0x10)
	struct TArray<struct USoundBase*> UnderSuppressionSounds; // 0x48(0x10)
	struct TArray<struct USoundBase*> DeathSounds; // 0x58(0x10)
};

// ScriptStruct HDMain.HDGameRoundEndEventDetails
// Size: 0x10 (Inherited: 0x00)
struct FHDGameRoundEndEventDetails {
	int32_t ElapsedTime; // 0x00(0x04)
	enum class EHDTeam WinningTeam; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	int32_t BluforTickets; // 0x08(0x04)
	int32_t OpforTickets; // 0x0c(0x04)
};

// ScriptStruct HDMain.HDCharacterVariationData
// Size: 0x68 (Inherited: 0x68)
struct FHDCharacterVariationData : FDFCharacterVariationData {
};

// ScriptStruct HDMain.HDPlatoonCreationParams
// Size: 0x10 (Inherited: 0x00)
struct FHDPlatoonCreationParams {
	struct UHDPlatoonInfo* Info; // 0x00(0x08)
	struct AHDTeamState* OwnerTeam; // 0x08(0x08)
};

// ScriptStruct HDMain.HDSquadCreationParams
// Size: 0x30 (Inherited: 0x00)
struct FHDSquadCreationParams {
	struct FText DisplayName; // 0x00(0x18)
	struct AHDPlatoonState* OwnerPlatoon; // 0x18(0x08)
	struct AHDPlayerState* SquadLeader; // 0x20(0x08)
	char bLocked : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct HDMain.HDPlatoonAttributes
// Size: 0x20 (Inherited: 0x00)
struct FHDPlatoonAttributes {
	int32_t ID; // 0x00(0x04)
	char TeamId; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FText DisplayName; // 0x08(0x18)
};

// ScriptStruct HDMain.HDItemEntry
// Size: 0x10 (Inherited: 0x00)
struct FHDItemEntry {
	struct AHDBaseWeapon* ItemClass; // 0x00(0x08)
	int32_t SlotNum; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct HDMain.HDServerInfo
// Size: 0xa0 (Inherited: 0x00)
struct FHDServerInfo {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString GameVersion; // 0x08(0x10)
	struct FString ServerName; // 0x18(0x10)
	char pad_28[0x10]; // 0x28(0x10)
	struct FHDServerInfoFlags ServerFlags; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString ModName; // 0x40(0x10)
	struct FString GameMode; // 0x50(0x10)
	struct FString MapName; // 0x60(0x10)
	struct FPrimaryAssetId MapId; // 0x70(0x10)
	struct UTexture2D* MapBannerImg; // 0x80(0x08)
	struct UTexture2D* MapThumbnailImg; // 0x88(0x08)
	int32_t CurrentPlayers; // 0x90(0x04)
	int32_t MaxPlayers; // 0x94(0x04)
	int32_t Ping; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct HDMain.HDServerInfoFlags
// Size: 0x04 (Inherited: 0x00)
struct FHDServerInfoFlags {
	bool bPasswordProtected; // 0x00(0x01)
	enum class EDFPlayerWhitelistType WhitelistType; // 0x01(0x01)
	bool bSupportersOnlyWhitelist; // 0x02(0x01)
	bool bUtilizesUGC; // 0x03(0x01)
};

// ScriptStruct HDMain.HDFilterRuleParams
// Size: 0x02 (Inherited: 0x00)
struct FHDFilterRuleParams {
	enum class EHDFilterRuleBehavior Behavior; // 0x00(0x01)
	enum class EHDFilterRuleComparisonOp ComparisonOp; // 0x01(0x01)
};

// ScriptStruct HDMain.HDUIWeaponAmmoState
// Size: 0x18 (Inherited: 0x00)
struct FHDUIWeaponAmmoState {
	int32_t TotalFreeAmmo; // 0x00(0x04)
	int32_t NumFreeAmmoClips; // 0x04(0x04)
	int32_t CurrentClipAmmo; // 0x08(0x04)
	int32_t CurrentClipMaxAmmo; // 0x0c(0x04)
	struct ADFBaseAmmoClip* CurrentClipAmmoClass; // 0x10(0x08)
};

// ScriptStruct HDMain.UniqueNetIdVoipWrapper
// Size: 0x18 (Inherited: 0x00)
struct FUniqueNetIdVoipWrapper {
	char pad_0[0x18]; // 0x00(0x18)
};

