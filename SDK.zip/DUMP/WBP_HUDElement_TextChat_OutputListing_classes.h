// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C
// Size: 0x2b0 (Inherited: 0x230)
struct UWBP_HUDElement_TextChat_OutputListing_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWidgetAnimation* FadeOutAnim; // 0x238(0x08)
	struct URichTextBlock* MsgContentText; // 0x240(0x08)
	struct UWBP_TextChat_MsgPrefix_C* MsgPrefix; // 0x248(0x08)
	struct UHDTextChatMsgInfo* ChatMsg; // 0x250(0x08)
	float MsgLifeTime; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FSlateColor EnemyMsgColor; // 0x260(0x28)
	struct FSlateColor FriendlyMsgColor; // 0x288(0x28)

	void Finished_54BC5F4D4E481384960AD59474319862(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.Finished_54BC5F4D4E481384960AD59474319862 // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LifetimeExpired(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.LifetimeExpired // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void SetupListing(struct UHDTextChatMsgInfo* Msg); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.SetupListing // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing(int32_t EntryPoint); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.ExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

