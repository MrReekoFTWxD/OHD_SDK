// BlueprintGeneratedClass BP_HDGameInstance.BP_HDGameInstance_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct UBP_HDGameInstance_C : UBP_HDGameInstanceBase_C {
};

