// BlueprintGeneratedClass BPFL_HDComms.BPFL_HDComms_C
// Size: 0x28 (Inherited: 0x28)
struct UBPFL_HDComms_C : UBlueprintFunctionLibrary {

	void GetTextChatIconForCommChannel(struct UDFCommChannel* Channel, struct UObject* __WorldContext, struct UTexture2D*& ChannelChatIcon); // Function BPFL_HDComms.BPFL_HDComms_C.GetTextChatIconForCommChannel // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupNewSquadChannel(struct UDFCommChannel* CreatedChannel, struct AHDSquadState* SquadToAssociate, struct UObject* __WorldContext); // Function BPFL_HDComms.BPFL_HDComms_C.SetupNewSquadChannel // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupNewTeamChannel(struct UDFCommChannel* CreatedChannel, struct AHDTeamState* TeamToAssociate, struct UObject* __WorldContext); // Function BPFL_HDComms.BPFL_HDComms_C.SetupNewTeamChannel // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetColorForCommChannel(struct UDFCommChannel* Channel, struct UObject* __WorldContext, struct FSlateColor& ChannelColor); // Function BPFL_HDComms.BPFL_HDComms_C.GetColorForCommChannel // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetValidCommsComponentForPlayer(struct APlayerController* Player, struct UObject* __WorldContext, struct UDFPlayerCommsComponent*& PlayerCommsComp); // Function BPFL_HDComms.BPFL_HDComms_C.GetValidCommsComponentForPlayer // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
};

