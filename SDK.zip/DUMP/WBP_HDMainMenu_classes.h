// WidgetBlueprintGeneratedClass WBP_HDMainMenu.WBP_HDMainMenu_C
// Size: 0x3f8 (Inherited: 0x3ec)
struct UWBP_HDMainMenu_C : UWBP_MainMenu_C {
	char pad_3EC[0x4]; // 0x3ec(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f0(0x08)

	void PreConstruct(bool IsDesignTime); // Function WBP_HDMainMenu.WBP_HDMainMenu_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDMainMenu(int32_t EntryPoint); // Function WBP_HDMainMenu.WBP_HDMainMenu_C.ExecuteUbergraph_WBP_HDMainMenu // (Final|UbergraphFunction) // @ game+0xec54e0
};

