// WidgetBlueprintGeneratedClass WBP_ServerListModifierSettings_AdvancedFilters.WBP_ServerListModifierSettings_AdvancedFilters_C
// Size: 0x240 (Inherited: 0x230)
struct UWBP_ServerListModifierSettings_AdvancedFilters_C : UUserWidget {
	struct UWBP_ModifierSetting_EditableText_C* IPAddress; // 0x230(0x08)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x238(0x08)
};

