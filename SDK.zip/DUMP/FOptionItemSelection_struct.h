// UserDefinedStruct FOptionItemSelection.FOptionItemSelection
// Size: 0x28 (Inherited: 0x00)
struct FFOptionItemSelection {
	struct FText DisplayName_2_80BDEF844537817E72247F98867E41BC; // 0x00(0x18)
	struct FString Value_5_05EE01DF46E006A98E0EC2B2FAA6A78D; // 0x18(0x10)
};

