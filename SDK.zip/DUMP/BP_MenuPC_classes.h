// BlueprintGeneratedClass BP_MenuPC.BP_MenuPC_C
// Size: 0x6a0 (Inherited: 0x6a0)
struct ABP_MenuPC_C : AHDPlayerController {
};

