// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C
// Size: 0x318 (Inherited: 0x2a8)
struct UWBP_HUDElement_TextChat_C : UHDTextChatWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UWidgetAnimation* DisplayChatInputUI; // 0x2b0(0x08)
	struct UWidgetAnimation* DisplayChatHistoryUI; // 0x2b8(0x08)
	struct UOverlay* ChatHistory; // 0x2c0(0x08)
	struct UOverlay* ChatInput; // 0x2c8(0x08)
	struct UWBP_HUDElement_TextChat_InputHandler_C* ChatInputHandler; // 0x2d0(0x08)
	struct UScrollBox* ChatMsgLogSBox; // 0x2d8(0x08)
	int32_t NumFakeChatMsgs; // 0x2e0(0x04)
	int32_t MaxChatMsgs; // 0x2e4(0x04)
	struct FMargin ChatMsgPadding; // 0x2e8(0x10)
	float ChatHistoryFadeOutDelay; // 0x2f8(0x04)
	bool bChatHistoryVisible; // 0x2fc(0x01)
	char pad_2FD[0x3]; // 0x2fd(0x03)
	struct FTimerHandle ChatHistoryTimeoutHandle; // 0x300(0x08)
	bool bWantsScrollToEnd; // 0x308(0x01)
	char pad_309[0x7]; // 0x309(0x07)
	struct UWidget* ScrollToWidget; // 0x310(0x08)

	void OnPaint(struct FPaintContext& Context); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.OnPaint // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetChatHistoryIsVisible(bool& bVisible); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.GetChatHistoryIsVisible // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AddNewOutputListing(struct UHDTextChatMsgInfo* ChatMsg, struct UWidget*& Listing); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.AddNewOutputListing // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void DisplayChatMessage(struct UHDTextChatMsgInfo* NewChatMsg); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.DisplayChatMessage // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void StartTalking(struct UDFCommChannel* TalkChannel); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.StartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void StopTalking(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.StopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature(struct FText Text, enum class ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ChatHistoryTimeout(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.ChatHistoryTimeout // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetChatHistoryIsVisible(bool bVisible); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.SetChatHistoryIsVisible // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature(float CurrentOffset); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_TextChat(int32_t EntryPoint); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.ExecuteUbergraph_WBP_HUDElement_TextChat // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

