// WidgetBlueprintGeneratedClass WBP_ServerListEntryColumn.WBP_ServerListEntryColumn_C
// Size: 0x348 (Inherited: 0x230)
struct UWBP_ServerListEntryColumn_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct USizeBox* ItemSBox; // 0x238(0x08)
	struct UTextBlock* ItemSubText; // 0x240(0x08)
	struct UTextBlock* ItemText; // 0x248(0x08)
	struct FText Text; // 0x250(0x18)
	float TextMinDesiredWidth; // 0x268(0x04)
	int32_t TextMaxStartLength; // 0x26c(0x04)
	int32_t TextMaxEndLength; // 0x270(0x04)
	char pad_274[0x4]; // 0x274(0x04)
	struct FSlateFontInfo TextFont; // 0x278(0x50)
	struct FText SubText; // 0x2c8(0x18)
	float SubTextMinDesiredWidth; // 0x2e0(0x04)
	int32_t SubTextMaxStartLength; // 0x2e4(0x04)
	int32_t SubTextMaxEndLength; // 0x2e8(0x04)
	float ItemMinDesiredWidth; // 0x2ec(0x04)
	float ItemMaxDesiredWidth; // 0x2f0(0x04)
	char pad_2F4[0x4]; // 0x2f4(0x04)
	struct FSlateFontInfo SubTextFont; // 0x2f8(0x50)

	void SetItemSubText(struct FText InText); // Function WBP_ServerListEntryColumn.WBP_ServerListEntryColumn_C.SetItemSubText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemText(struct FText InText); // Function WBP_ServerListEntryColumn.WBP_ServerListEntryColumn_C.SetItemText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ServerListEntryColumn.WBP_ServerListEntryColumn_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ServerListEntryColumn(int32_t EntryPoint); // Function WBP_ServerListEntryColumn.WBP_ServerListEntryColumn_C.ExecuteUbergraph_WBP_ServerListEntryColumn // (Final|UbergraphFunction) // @ game+0xec54e0
};

