// WidgetBlueprintGeneratedClass WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C
// Size: 0xa95 (Inherited: 0x230)
struct UWBP_CreateGameSelectionListEntry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* ItemBg; // 0x238(0x08)
	struct USizeBox* ItemBox; // 0x240(0x08)
	struct UCheckBox* ItemCheckBox; // 0x248(0x08)
	struct UImage* ItemSelectionHighlight; // 0x250(0x08)
	struct UTextBlock* ItemSubText; // 0x258(0x08)
	struct UTextBlock* ItemText; // 0x260(0x08)
	struct FMulticastInlineDelegate OnSelectionStateChanged; // 0x268(0x10)
	struct FCheckBoxStyle ItemStyle; // 0x278(0x580)
	struct FFSelectionItemTextStyle ItemTextStyle; // 0x7f8(0x130)
	struct FFSelectionItemTextStyle ItemSubTextStyle; // 0x928(0x130)
	int32_t ItemMinWidth; // 0xa58(0x04)
	char pad_A5C[0x4]; // 0xa5c(0x04)
	struct FText Text; // 0xa60(0x18)
	struct FText SubText; // 0xa78(0x18)
	int32_t ItemMinHeight; // 0xa90(0x04)
	bool bSelectionToggle; // 0xa94(0x01)

	void GetBrushWithImageTexture(struct FSlateBrush& Brush, struct UTexture2D* Image, struct FSlateBrush& UpdatedBrush); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetBrushWithImageTexture // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void InternalRefreshDimensions(); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalRefreshDimensions // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemMinHeight(int32_t& MinHeight); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemMinHeight // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemMinWidth(int32_t& MinWidth); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemMinWidth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemMinDimensions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemSubText(struct FText& Text); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSubText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemText(struct FText& Text); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemSubText(struct FText InText); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSubText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemText(struct FText InText); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemSubTextStyle(struct FFSelectionItemTextStyle& TextStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSubTextStyle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemTextStyle(struct FFSelectionItemTextStyle& TextStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemTextStyle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemStyle(struct FCheckBoxStyle& ItemStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemStyle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemImage(struct UTexture2D* InItemImg); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemImage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemSubTextStyle(struct FFSelectionItemTextStyle InItemSubTextStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSubTextStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemTextStyle(struct FFSelectionItemTextStyle InItemTextStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemTextStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemStyle(struct FCheckBoxStyle InItemStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalUpdateItemBgTintColor(bool bSelected); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalUpdateItemBgTintColor // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InternalApplyStyleToText(struct UTextBlock* Text, struct FFSelectionItemTextStyle& TextStyle); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalApplyStyleToText // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsItemSelected(bool& bSelected); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.IsItemSelected // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetItemSelectionState(enum class ECheckBoxState& SelectionState); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSelectionState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetItemIsSelected(bool bSelected); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemIsSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetItemSelectionState(enum class ECheckBoxState InSelectionState); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSelectionState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CreateGameSelectionListEntry(int32_t EntryPoint); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.ExecuteUbergraph_WBP_CreateGameSelectionListEntry // (Final|UbergraphFunction) // @ game+0xec54e0
	void OnSelectionStateChanged__DelegateSignature(struct UWBP_CreateGameSelectionListEntry_C* Item, bool bSelected); // Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.OnSelectionStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

