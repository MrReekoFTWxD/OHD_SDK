// WidgetBlueprintGeneratedClass WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C
// Size: 0x240 (Inherited: 0x230)
struct UWBP_SelectionListEntry_GameMode_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_CreateGameSelectionListEntry_C* SelectionEntry; // 0x238(0x08)

	void BP_OnEntryReleased(); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SelectionItem_K2Node_ComponentBoundEvent_0_OnSelectionStateChanged__DelegateSignature(struct UWBP_CreateGameSelectionListEntry_C* Item, bool bSelected); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.BndEvt__SelectionItem_K2Node_ComponentBoundEvent_0_OnSelectionStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_SelectionListEntry_GameMode(int32_t EntryPoint); // Function WBP_SelectionListEntry_GameMode.WBP_SelectionListEntry_GameMode_C.ExecuteUbergraph_WBP_SelectionListEntry_GameMode // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

