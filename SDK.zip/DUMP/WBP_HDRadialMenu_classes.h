// WidgetBlueprintGeneratedClass WBP_HDRadialMenu.WBP_HDRadialMenu_C
// Size: 0x3a4 (Inherited: 0x278)
struct UWBP_HDRadialMenu_C : UWBP_HDRadialMenuBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)
	struct UWidgetAnimation* ShowFirst; // 0x280(0x08)
	struct UWidgetAnimation* ShowCategory; // 0x288(0x08)
	struct UWidgetAnimation* ShowBuild; // 0x290(0x08)
	struct UTextBlock* CategoryTitle; // 0x298(0x08)
	struct UImage* CenterCircle; // 0x2a0(0x08)
	struct UWBP_RadialMenuBase_C* MenuOptionsRing; // 0x2a8(0x08)
	struct UTextBlock* MenuSubselection; // 0x2b0(0x08)
	struct FName SelectedItem; // 0x2b8(0x08)
	struct FName SelectedMenuOption; // 0x2c0(0x08)
	struct FSHDRadialMenu_OptionData CategoryData; // 0x2c8(0x28)
	bool bPickingItem; // 0x2f0(0x01)
	char pad_2F1[0x7]; // 0x2f1(0x07)
	struct FSHDRadialMenu_OptionData SelectedItemData; // 0x2f8(0x28)
	int32_t SelectedIndex; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
	struct USoundBase* CategorySelectSound; // 0x328(0x08)
	struct USoundBase* GoBackSound; // 0x330(0x08)
	struct FSRadialMenuIconSettings IconStyle; // 0x338(0x28)
	struct UDataTable* MenuOptionsMain; // 0x360(0x08)
	struct UDataTable* MenuOptionsSelected; // 0x368(0x08)
	struct FSRadialMenuIconSettings DisabledIconStyle; // 0x370(0x28)
	float RallypointRespawnTimeDefault; // 0x398(0x04)
	float OutpostRespawnTime; // 0x39c(0x04)
	int32_t NumberOfSegments; // 0x3a0(0x04)

	struct FText GetOutpostName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostName // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetOutpostTimeRemaining(struct ABP_HDPlayerCharacterBase_C* OwnerPawn, struct FText& TimeRemaining); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostTimeRemaining // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	struct FText GetRallypointName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointName // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetRallypointTimeRemaining(struct ABP_HDPlayerCharacterBase_C* OwnerPawn, struct FText& TimeRemaining); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointTimeRemaining // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void OwnerPawnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.OwnerPawnDeath // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void MakeOutpostIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeOutpostIcon // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void MakeRallypointIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeRallypointIcon // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void MakeSpottingIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeSpottingIcon // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectSubmenu(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.SelectSubmenu // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PopulateSubmenuOptions(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateSubmenuOptions // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PopulateMenuOptions(struct UDataTable* MenuOptions); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateMenuOptions // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemData(struct FName RowName, struct FSHDRadialMenu_OptionData& ItemData); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetItemNamesForSelectedOption(struct TArray<struct FName>& OutRowNames); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemNamesForSelectedOption // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetCategoryData(struct FName Category, struct FSHDRadialMenu_OptionData& CategoryData); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetCategories(struct TArray<struct FName>& Categories); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategories // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FText GetCategoryName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryName // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void BndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature(int32_t NewSelection, int32_t OldSelection); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.BndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void Submit(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Submit // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GoBack(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GoBack // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnCancel(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.OnCancel // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDRadialMenu(int32_t EntryPoint); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.ExecuteUbergraph_WBP_HDRadialMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

