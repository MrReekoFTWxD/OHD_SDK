// WidgetBlueprintGeneratedClass WBP_OptionMenu_HDHome.WBP_OptionMenu_HDHome_C
// Size: 0x280 (Inherited: 0x280)
struct UWBP_OptionMenu_HDHome_C : UWBP_OptionMenu_Home_C {
};

