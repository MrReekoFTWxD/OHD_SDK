// BlueprintGeneratedClass CS_ReceiveDamageShake.CS_ReceiveDamageShake_C
// Size: 0x160 (Inherited: 0x160)
struct UCS_ReceiveDamageShake_C : UCameraShake {
};

