// WidgetBlueprintGeneratedClass WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C
// Size: 0x368 (Inherited: 0x238)
struct UWBP_OptionMenu_CreateGame_C : UDFBaseMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UTBListView* GMList; // 0x240(0x08)
	struct UTBListView* MapList; // 0x248(0x08)
	struct UImage* MapPreviewImg; // 0x250(0x08)
	struct UScrollBox* ModifierListScrollBox; // 0x258(0x08)
	struct UWBP_BotsGameModifierSettings_C* SettingsModifierBots; // 0x260(0x08)
	struct UWBP_FactionGameModifierSettings_C* SettingsModifierFactions; // 0x268(0x08)
	struct UButton* StartGameBtn; // 0x270(0x08)
	bool bAutoSelectFirstMap; // 0x278(0x01)
	bool bUsePredefinedMapList; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
	struct TArray<struct FFMapInfo> PredefinedMapList; // 0x280(0x10)
	bool bAutoSelectFirstGame; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct UTexture2D* DefaultGMBanner; // 0x298(0x08)
	struct TSoftClassPtr<UObject> LegacyAASGMClass; // 0x2a0(0x28)
	bool bUsePredefinedGameList; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct TArray<struct FFGameModeInfo> PredefinedGameList; // 0x2d0(0x10)
	struct FMulticastInlineDelegate OnBuildTravelURL; // 0x2e0(0x10)
	struct FString TravelURL; // 0x2f0(0x10)
	struct TMap<struct FName, struct FText> PredefinedMapParentNameOverrides; // 0x300(0x50)
	struct TArray<struct UHDGameModeDefinition*> SelectableGMDefs; // 0x350(0x10)
	struct UHDGameModeDefinition* SelectedGM; // 0x360(0x08)

	void GetValidDisplayNameForGMDefinition(struct UHDGameModeDefinition* GMDef, struct FText& DisplayName); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetValidDisplayNameForGMDefinition // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FindGMDefinitionByClassName(struct FString& ClassName, struct UHDGameModeDefinition*& GMDef); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FindGMDefinitionByClassName // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ContainsGMByClass(struct TSoftClassPtr<UObject> GMClass, bool& bContainsGM); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ContainsGMByClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FilterExcludesGMClass(struct TSoftClassPtr<UObject> GMClass, bool bLegacyAASSupport, bool& bExcludeGM); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesGMClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FilterExcludesMapPrefix(struct FString MapName, bool& bExcludePrefix); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesMapPrefix // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SortGMList(struct TArray<struct FFGameModeInfo>& GMListToSort, bool bDescending); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortGMList // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SortMapList(struct TArray<struct FFMapInfo>& MapListToSort, bool bDescending); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortMapList // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateStartButtonState(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.UpdateStartButtonState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearMapPreviewImage(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ClearMapPreviewImage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetMapPreviewImage(struct UTexture2D* NewImg); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SetMapPreviewImage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddGMToList(struct FFGameModeInfo& GMInfo, struct UBP_GMListItemData_C*& NewGMItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddGMToList // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CreateGMListItem(struct FFGameModeInfo& GMInfo, struct UBP_GMListItemData_C*& GMItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateGMListItem // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HandleStartGame(struct FFMapInfo& SelectedMapInfo, struct FFGameModeInfo& SelectedGMInfo); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.HandleStartGame // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AppendOptionsFromActiveModifiers(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendOptionsFromActiveModifiers // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetActiveModifiers(struct TArray<struct TScriptInterface<IBPI_GameModifierSettings_C>>& ActiveModifiers); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetActiveModifiers // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AppendTravelURL(struct FString& OptionsToAdd); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendTravelURL // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddMapToList(struct FFMapInfo& MapInfo, struct UBP_MapListItemData_C*& NewMapItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddMapToList // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CreateMapListItem(struct FFMapInfo& MapInfo, struct UBP_MapListItemData_C*& MapItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateMapListItem // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RepopulateMapListFromRegistry(struct UBP_GMListItemData_C* GMItemFilter); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateMapListFromRegistry // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RepopulateGameListFromRegistry(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateGameListFromRegistry // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ShouldAddGMListing(struct UHDGameModeDefinition* GMDef, bool& bAddListing); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddGMListing // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FetchGameModesFromRegistry(struct TArray<struct FFGameModeInfo>& GMsFound); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchGameModesFromRegistry // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ShouldAddMapListing(struct FPrimaryAssetId& MapAssetId, bool& bAddListing); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddMapListing // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void FetchMapsFromRegistry(struct TArray<struct FFMapInfo>& MapsFound); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchMapsFromRegistry // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Completed_D5E8D9AE41A0DF3C4DEC0184D72FF481(struct TArray<struct UObject*>& Loaded); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.Completed_D5E8D9AE41A0DF3C4DEC0184D72FF481 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__CreateGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__CreateGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void FetchGameModes(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchGameModes // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Destruct(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionMenu_CreateGame(int32_t EntryPoint); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ExecuteUbergraph_WBP_OptionMenu_CreateGame // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnBuildTravelURL__DelegateSignature(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.OnBuildTravelURL__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

