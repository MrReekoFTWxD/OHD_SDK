// WidgetBlueprintGeneratedClass WBP_OptionMenu_HDCreateGame.WBP_OptionMenu_HDCreateGame_C
// Size: 0x368 (Inherited: 0x368)
struct UWBP_OptionMenu_HDCreateGame_C : UWBP_OptionMenu_CreateGame_C {
};

