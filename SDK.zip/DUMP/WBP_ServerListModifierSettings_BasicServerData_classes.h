// WidgetBlueprintGeneratedClass WBP_ServerListModifierSettings_BasicServerData.WBP_ServerListModifierSettings_BasicServerData_C
// Size: 0x254 (Inherited: 0x230)
struct UWBP_ServerListModifierSettings_BasicServerData_C : UUserWidget {
	struct UWBP_GameModifierSettingsSection_C* SectionContainer; // 0x230(0x08)
	struct UTextBlock* ServerDescriptionText; // 0x238(0x08)
	struct UTextBlock* ServerNameText; // 0x240(0x08)
	struct UTextBlock* ServerPlayersText; // 0x248(0x08)
	int32_t ServerNameMaxLength; // 0x250(0x04)
};

