// WidgetBlueprintGeneratedClass WBP_ServerDetails.WBP_ServerDetails_C
// Size: 0x298 (Inherited: 0x230)
struct UWBP_ServerDetails_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UCheckBox* FavoriteServerBtn; // 0x238(0x08)
	struct UButton* JoinServerBtn; // 0x240(0x08)
	struct UTextBlock* ServerAddrText; // 0x248(0x08)
	struct UTextBlock* ServerDataDescriptionText; // 0x250(0x08)
	struct UTextBlock* ServerDataNameText; // 0x258(0x08)
	struct UTextBlock* ServerDataSubtitleText; // 0x260(0x08)
	struct UTextBlock* ServerGMText; // 0x268(0x08)
	struct UImage* ServerMapPreviewImg; // 0x270(0x08)
	struct UTextBlock* ServerMapText; // 0x278(0x08)
	struct UTextBlock* ServerStatusText; // 0x280(0x08)
	struct FMulticastInlineDelegate OnJoinServerBtnClicked; // 0x288(0x10)

	void UpdateServerMetaData(struct FHDServerInfo& ServerInfo); // Function WBP_ServerDetails.WBP_ServerDetails_C.UpdateServerMetaData // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateServerData(struct FHDServerInfo& ServerInfo); // Function WBP_ServerDetails.WBP_ServerDetails_C.UpdateServerData // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupServerDetails(struct FHDServerInfo ServerInfo); // Function WBP_ServerDetails.WBP_ServerDetails_C.SetupServerDetails // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__JoinServerBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_ServerDetails.WBP_ServerDetails_C.BndEvt__JoinServerBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ServerDetails(int32_t EntryPoint); // Function WBP_ServerDetails.WBP_ServerDetails_C.ExecuteUbergraph_WBP_ServerDetails // (Final|UbergraphFunction) // @ game+0xec54e0
	void OnJoinServerBtnClicked__DelegateSignature(); // Function WBP_ServerDetails.WBP_ServerDetails_C.OnJoinServerBtnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

