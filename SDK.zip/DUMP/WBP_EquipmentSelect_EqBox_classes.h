// WidgetBlueprintGeneratedClass WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C
// Size: 0x291 (Inherited: 0x230)
struct UWBP_EquipmentSelect_EqBox_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UTextBlock* EquipmentNumber; // 0x238(0x08)
	struct UImage* Image_11; // 0x240(0x08)
	struct UImage* Image_12; // 0x248(0x08)
	struct UImage* Image_13; // 0x250(0x08)
	struct UImage* Image_14; // 0x258(0x08)
	struct UImage* Item; // 0x260(0x08)
	struct UOverlay* RestrictedOverlay; // 0x268(0x08)
	struct UImage* Selected; // 0x270(0x08)
	struct UTexture2D* Icon; // 0x278(0x08)
	int32_t SlotNum; // 0x280(0x04)
	bool bEnabled; // 0x284(0x01)
	char pad_285[0x3]; // 0x285(0x03)
	struct AHDBaseWeapon* EqpItem; // 0x288(0x08)
	bool bHighlighted; // 0x290(0x01)

	void SetEnabled(bool bEnabled); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetEnabled // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsHighlighted(bool& bHighlight); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.IsHighlighted // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetHighlight(bool bHighlighted); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetHighlight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_EquipmentSelect_EqBox(int32_t EntryPoint); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.ExecuteUbergraph_WBP_EquipmentSelect_EqBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

