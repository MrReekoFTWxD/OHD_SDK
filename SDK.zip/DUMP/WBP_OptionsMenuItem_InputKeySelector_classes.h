// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C
// Size: 0x2c0 (Inherited: 0x230)
struct UWBP_OptionsMenuItem_InputKeySelector_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_InputKeySelector_C* OptionIKS; // 0x238(0x08)
	struct UTextBlock* OptionText; // 0x240(0x08)
	struct FText Text; // 0x248(0x18)
	struct FText TextDescription; // 0x260(0x18)
	struct FName InputName; // 0x278(0x08)
	struct FMulticastInlineDelegate OnKeySelected; // 0x280(0x10)
	float InputScale; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct FKey MappedKey; // 0x298(0x18)
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged; // 0x2b0(0x10)

	void IsSelectingKey(bool& IsSelecting); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.IsSelectingKey // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearSelectedKey(struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS, struct FKey NewKey, bool bIsPlayerChangingKeyBindings); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ClearSelectedKey // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSelectedKey(struct FKey SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.SetSelectedKey // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSelectedKey(struct FKey& SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.GetSelectedKey // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.BndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__OptionIKS_K2Node_ComponentBoundEvent_0_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.BndEvt__OptionIKS_K2Node_ComponentBoundEvent_0_OnIsSelectingKeyChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector(int32_t EntryPoint); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.OnIsSelectingKeyChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.OnKeySelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

