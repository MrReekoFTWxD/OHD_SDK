// WidgetBlueprintGeneratedClass WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C
// Size: 0x2d8 (Inherited: 0x250)
struct UWBP_DeployMenu_PlatoonSquadList_C : UDeployMenu_PlatoonSquadListBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x250(0x08)
	struct UButton* CreateSquadBtn; // 0x258(0x08)
	struct UImage* Image_11; // 0x260(0x08)
	struct UTextBlock* PlatoonNameText; // 0x268(0x08)
	struct UTextBlock* SquadCountText; // 0x270(0x08)
	struct UVerticalBox* SquadsList; // 0x278(0x08)
	struct UButton* ToggleListVisibilityBtn; // 0x280(0x08)
	struct UImage* ToggleListVisibilityImg; // 0x288(0x08)
	bool bExpanded; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct FText PlatoonTextFormat; // 0x298(0x18)
	bool bExpandListInDesigner; // 0x2b0(0x01)
	char pad_2B1[0x3]; // 0x2b1(0x03)
	int32_t NumFakeSquadItems; // 0x2b4(0x04)
	struct FMargin SquadItemPadding; // 0x2b8(0x10)
	bool bCollapsedByUser; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct UWBP_DeployMenu_SquadSelectionPanel_C* ParentContainerWidget; // 0x2d0(0x08)

	void IsPlatoonValid(bool& bValidPLTN); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.IsPlatoonValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void WasListCollapsedByUser(bool& bCollapsedByUser); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.WasListCollapsedByUser // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void HasAnySquads(bool& bValidSquadsPresent); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.HasAnySquads // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetPlatoonNameText(struct FText NewPlatoonName); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SetPlatoonNameText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateCreateBtnAvailability(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateCreateBtnAvailability // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateSquadCountText(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateSquadCountText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CollapseListIfEmpty(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.CollapseListIfEmpty // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CollapseList(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.CollapseList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExpandList(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExpandList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveSquadItemWidgetFromList(struct USquadListEntry* RemovedSquadData, int32_t RemoveIdx); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.RemoveSquadItemWidgetFromList // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddNewSquadItemWidget(struct USquadListEntry* SquadData, struct UWBP_DeployMenu_SquadList_C*& SquadItemWidget); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.AddNewSquadItemWidget // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GenerateSquad(struct USquadListEntry* SquadData); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.GenerateSquad // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructSquad(struct USquadListEntry* RemovedSquadData, int32_t RemovedSquadIdx); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.DeconstructSquad // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ListToggleBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.BndEvt__ListToggleBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void SquadsListExpanded(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SquadsListExpanded // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SquadsListCollapsed(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SquadsListCollapsed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__CreateSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.BndEvt__CreateSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnPlatoonSet(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.OnPlatoonSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList(int32_t EntryPoint); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList // (Final|UbergraphFunction) // @ game+0xec54e0
};

