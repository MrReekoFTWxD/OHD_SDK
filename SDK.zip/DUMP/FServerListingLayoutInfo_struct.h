// UserDefinedStruct FServerListingLayoutInfo.FServerListingLayoutInfo
// Size: 0x34 (Inherited: 0x00)
struct FFServerListingLayoutInfo {
	struct FText HeaderLabel_19_1F3495A44170D55BD20587BF982EEAAB; // 0x00(0x18)
	enum class ETextJustify LabelJustification_20_FDBD545240CA011C3132D58BE708809B; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	struct FMargin SlotPadding_15_16A3E958452039B138BC338AD775C2D9; // 0x1c(0x10)
	float MinDesiredWidth_16_81A194A649DD44332AC5FC91B6521D2A; // 0x2c(0x04)
	float MaxDesiredWidth_17_1583BB354DB575BC6BB54E8AF33C09C1; // 0x30(0x04)
};

