// BlueprintGeneratedClass BP_HDCapturePointBase.BP_HDCapturePointBase_C
// Size: 0x398 (Inherited: 0x350)
struct ABP_HDCapturePointBase_C : AHDBaseCapturePoint {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct UWidgetComponent* IconWidget; // 0x358(0x08)
	bool bDebug; // 0x360(0x01)
	bool bDebugFlagClothLOD; // 0x361(0x01)
	bool bOnlyShowDebugIfActive; // 0x362(0x01)
	char pad_363[0x5]; // 0x363(0x05)
	struct UDFMinimap* Minimap; // 0x368(0x08)
	bool bShowIconWidget; // 0x370(0x01)
	char pad_371[0x7]; // 0x371(0x07)
	struct FMulticastInlineDelegate OnCaptureStatusUpdated; // 0x378(0x10)
	struct AHDPlayerController* LocalPC; // 0x388(0x08)
	struct UNavigationInvokerComponent* NavInvoker; // 0x390(0x08)

	void UpdateFlagClothLOD(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagClothLOD // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddPOI(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.AddPOI // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemovePOI(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.RemovePOI // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdatePOIState(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdatePOIState // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InitPOI(struct UDFMinimap* Minimap); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.InitPOI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateFlagIcon(enum class EHDTeam InOwningTeam, struct AHUD* InLocalPlayerHUD); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateFlagColor(enum class EHDTeam InOwningTeam); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UserConstructionScript(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaSeconds); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnOwningTeamUpdated(enum class EHDTeam LastOwningTeam); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnOwningTeamUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnCaptureProgress(bool bNewContested); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnCaptureProgress // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnCaptureUpdate(bool bContested, int32_t Progress); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnActive(bool bNewActive); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnActive // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnLocked(bool bNewLocked); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnLocked // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveBeginPlay(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnTeamCaptureStatusUpdated(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnTeamCaptureStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDCapturePointBase(int32_t EntryPoint); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ExecuteUbergraph_BP_HDCapturePointBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnCaptureStatusUpdated__DelegateSignature(struct ABP_HDCapturePointBase_C* ControlPoint); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureStatusUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

