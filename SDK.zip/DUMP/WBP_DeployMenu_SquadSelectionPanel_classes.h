// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C
// Size: 0x274 (Inherited: 0x250)
struct UWBP_DeployMenu_SquadSelectionPanel_C : UDeployMenu_SquadSelectionWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x250(0x08)
	struct UScrollBox* PlatoonsList; // 0x258(0x08)
	int32_t NumFakePlatoonItems; // 0x260(0x04)
	struct FMargin PlatoonItemPadding; // 0x264(0x10)

	void RemovePlatoonItemWidgetFromList(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemoveIdx); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.RemovePlatoonItemWidgetFromList // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddNewPlatoonItemWidget(struct UPlatoonListEntry* PlatoonData); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.AddNewPlatoonItemWidget // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GeneratePlatoon(struct UPlatoonListEntry* PlatoonData); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.GeneratePlatoon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructPlatoon(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemovedPlatoonIdx); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.DeconstructPlatoon // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel(int32_t EntryPoint); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel // (Final|UbergraphFunction) // @ game+0xec54e0
};

