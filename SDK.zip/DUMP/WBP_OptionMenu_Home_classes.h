// WidgetBlueprintGeneratedClass WBP_OptionMenu_Home.WBP_OptionMenu_Home_C
// Size: 0x280 (Inherited: 0x238)
struct UWBP_OptionMenu_Home_C : UDFBaseMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UUniformGridPanel* EntitlementBadgeGrid; // 0x240(0x08)
	struct UVerticalBox* MediaLinkVBox; // 0x248(0x08)
	struct UDataTable* EntitlementBadgeDefinitionSource; // 0x250(0x08)
	struct UDataTable* MediaLinkDefinitionSource; // 0x258(0x08)
	int32_t BadgeMaxRows; // 0x260(0x04)
	int32_t BadgeMaxColumns; // 0x264(0x04)
	struct FMargin BadgeSlotPadding; // 0x268(0x10)
	float BadgeMinDesiredSlotWidth; // 0x278(0x04)
	float BadgeMinDesiredSlotHeight; // 0x27c(0x04)

	void IsEntitledToBadge(struct TArray<struct FFEntitlementDefinition>& Entitlements, bool& bEntitled); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.IsEntitledToBadge // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetMaxGridSize(int32_t& MaxSize); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.GetMaxGridSize // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void InsertMediaLink(struct FFCommunityMediaLinkUIDefinition& LinkUIDef); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertMediaLink // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InsertEntitlementBadge(struct FFEntitlementBadgeUIDefinition& EntitlementUIDef); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertEntitlementBadge // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionMenu_Home(int32_t EntryPoint); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.ExecuteUbergraph_WBP_OptionMenu_Home // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

