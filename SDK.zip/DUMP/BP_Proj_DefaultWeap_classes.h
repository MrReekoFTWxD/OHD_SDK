// BlueprintGeneratedClass BP_Proj_DefaultWeap.BP_Proj_DefaultWeap_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_Proj_DefaultWeap_C : ADFBaseProjectile {
};

