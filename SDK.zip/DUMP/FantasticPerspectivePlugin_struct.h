// Enum FantasticPerspectivePlugin.EFantasticPerspectiveStereoscopicPass
enum class EFantasticPerspectiveStereoscopicPass : uint8 {
	eFPSSP_FULL = 0,
	eFPSSP_LEFT_EYE = 1,
	eFPSSP_RIGHT_EYE = 2,
	eFPSSP_LEFT_EYE_SIDE = 3,
	eFPSSP_RIGHT_EYE_SIDE = 4,
	eFPSSP_MAX = 5
};

// Enum FantasticPerspectivePlugin.EFantasticPerspectiveType
enum class EFantasticPerspectiveType : uint8 {
	eFPT_EFFECTS = 0,
	eFPT_POINTS = 1,
	eFPT_MAX = 2
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveSettings
// Size: 0xe4 (Inherited: 0x00)
struct FFantasticPerspectiveSettings {
	enum class EFantasticPerspectiveType Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FFantasticPerspectiveFrustum Frustum; // 0x04(0x44)
	struct FFantasticPerspectivePoints Points; // 0x48(0x48)
	struct FFantasticPerspectiveTransform Transform; // 0x90(0x3c)
	struct FFantasticPerspectiveDebug Debug; // 0xcc(0x18)
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveDebug
// Size: 0x18 (Inherited: 0x00)
struct FFantasticPerspectiveDebug {
	bool DrawOriginalFrustum; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FColor OriginalFrustumColor; // 0x04(0x04)
	bool DrawAdjustedFrustum; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	struct FColor AdjustedFrustumColor; // 0x0c(0x04)
	float LineThickness; // 0x10(0x04)
	float FrustumDepth; // 0x14(0x04)
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveTransform
// Size: 0x3c (Inherited: 0x00)
struct FFantasticPerspectiveTransform {
	struct FVector ViewOriginWorldOffset; // 0x00(0x0c)
	struct FVector WorldTranslation; // 0x0c(0x0c)
	struct FRotator WorldRotation; // 0x18(0x0c)
	struct FVector LocalTranslation; // 0x24(0x0c)
	struct FRotator LocalRotation; // 0x30(0x0c)
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectivePoints
// Size: 0x48 (Inherited: 0x00)
struct FFantasticPerspectivePoints {
	bool OverrideViewTransform; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector ViewOrigin; // 0x04(0x0c)
	float NearClipPlane; // 0x10(0x04)
	float OrthoFrustumDepth; // 0x14(0x04)
	struct FVector LeftBottom; // 0x18(0x0c)
	struct FVector LeftTop; // 0x24(0x0c)
	struct FVector RightTop; // 0x30(0x0c)
	struct FVector RightBottom; // 0x3c(0x0c)
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveFrustum
// Size: 0x44 (Inherited: 0x00)
struct FFantasticPerspectiveFrustum {
	struct FVector2D LensShift; // 0x00(0x08)
	struct FVector2D LensTilt; // 0x08(0x08)
	struct FVector2D PositionShift; // 0x10(0x08)
	struct FVector2D Skew; // 0x18(0x08)
	struct FVector2D PreAspectScale; // 0x20(0x08)
	struct FVector2D PostAspectScale; // 0x28(0x08)
	struct FVector2D ClippingPlaneSkew; // 0x30(0x08)
	struct FFantasticPerspectiveDollyZoom DollyZoom; // 0x38(0x08)
	bool CompensateAspectRatio; // 0x40(0x01)
	bool CompensateFOV; // 0x41(0x01)
	bool SeamlessLensTilt; // 0x42(0x01)
	char pad_43[0x1]; // 0x43(0x01)
};

// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveDollyZoom
// Size: 0x08 (Inherited: 0x00)
struct FFantasticPerspectiveDollyZoom {
	float DollyZoom; // 0x00(0x04)
	float FocalDistance; // 0x04(0x04)
};

