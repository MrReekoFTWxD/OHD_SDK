// WidgetBlueprintGeneratedClass WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C
// Size: 0x300 (Inherited: 0x230)
struct UWBP_ModifierSetting_CheckBox_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UCheckBox* ModifierCheckBox; // 0x238(0x08)
	struct USizeBox* ModifierSBox; // 0x240(0x08)
	struct UWBP_ModifierSettingBox_C* ModifierSetting; // 0x248(0x08)
	bool bDefaultIsChecked; // 0x250(0x01)
	char pad_251[0x7]; // 0x251(0x07)
	struct FText SettingText; // 0x258(0x18)
	struct FMulticastInlineDelegate OnCheckStateChanged; // 0x270(0x10)
	struct FFModifierTextStyle SettingTextStyle; // 0x280(0x78)
	struct FVector2D CheckBoxMinSize; // 0x2f8(0x08)

	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.GetSettingText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.SetSettingText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.BndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ModifierSetting_CheckBox(int32_t EntryPoint); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.ExecuteUbergraph_WBP_ModifierSetting_CheckBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnCheckStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.OnCheckStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

