// WidgetBlueprintGeneratedClass WBP_DeathScreen.WBP_DeathScreen_C
// Size: 0x240 (Inherited: 0x230)
struct UWBP_DeathScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UTextBlock* DeathKeyBindText; // 0x238(0x08)

	void UpdateDeathKeyText(struct FKey& Key); // Function WBP_DeathScreen.WBP_DeathScreen_C.UpdateDeathKeyText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeathScreen.WBP_DeathScreen_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeathScreen(int32_t EntryPoint); // Function WBP_DeathScreen.WBP_DeathScreen_C.ExecuteUbergraph_WBP_DeathScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

