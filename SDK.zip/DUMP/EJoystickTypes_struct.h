// UserDefinedEnum EJoystickTypes.EJoystickTypes
enum class EJoystickTypes : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EJoystickTypes_MAX = 2
};

