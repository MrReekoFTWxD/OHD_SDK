// WidgetBlueprintGeneratedClass WBP_EntitlementBadge.WBP_EntitlementBadge_C
// Size: 0x2d8 (Inherited: 0x230)
struct UWBP_EntitlementBadge_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* BadgeIcon; // 0x238(0x08)
	struct FFEntitlementBadgeUIDefinition BadgeUIDefinition; // 0x240(0x98)

	void PreConstruct(bool IsDesignTime); // Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_EntitlementBadge(int32_t EntryPoint); // Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.ExecuteUbergraph_WBP_EntitlementBadge // (Final|UbergraphFunction) // @ game+0xec54e0
};

