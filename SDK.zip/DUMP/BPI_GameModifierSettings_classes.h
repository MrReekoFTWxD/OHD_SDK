// BlueprintGeneratedClass BPI_GameModifierSettings.BPI_GameModifierSettings_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_GameModifierSettings_C : UInterface {

	void GetTravelURLOptions(struct FString& Options); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.GetTravelURLOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsEnabled(bool& bEnabled); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.IsEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.SetupModifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

