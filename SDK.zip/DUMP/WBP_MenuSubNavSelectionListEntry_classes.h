// WidgetBlueprintGeneratedClass WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C
// Size: 0x270 (Inherited: 0x230)
struct UWBP_MenuSubNavSelectionListEntry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_CreateGameSelectionListEntry_C* SelectionEntry; // 0x238(0x08)
	struct FText ItemText; // 0x240(0x18)
	int32_t SubMenuIndex; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FMulticastInlineDelegate ButtonClicked; // 0x260(0x10)

	void SetSubMenuIndex(int32_t Idx); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.SetSubMenuIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnItemSelectionChanged(bool bIsSelected); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.OnItemSelectionChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature(struct UWBP_CreateGameSelectionListEntry_C* Item, bool bSelected); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.BndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_MenuSubNavSelectionListEntry(int32_t EntryPoint); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ExecuteUbergraph_WBP_MenuSubNavSelectionListEntry // (Final|UbergraphFunction) // @ game+0xec54e0
	void ButtonClicked__DelegateSignature(struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

