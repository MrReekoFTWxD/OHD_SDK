// Class GOAPNPC.GOAPAction
// Size: 0x98 (Inherited: 0x28)
struct UGOAPAction : UObject {
	struct FString Name; // 0x28(0x10)
	float Cost; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct AActor* TargetClass; // 0x40(0x08)
	struct TArray<struct FAtom> Preconditions; // 0x48(0x10)
	struct TArray<struct FAtom> Effects; // 0x58(0x10)
	struct AActor* Target; // 0x68(0x08)
	bool bActivated; // 0x70(0x01)
	char pad_71[0x27]; // 0x71(0x27)

	bool Validate(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.Validate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8066f0
	bool ReceiveIsActionInvalid(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.ReceiveIsActionInvalid // (Event|Protected|BlueprintEvent|Const) // @ game+0xec54e0
	bool HasCompleted(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.HasCompleted // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x8060a0
	struct TArray<struct AActor*> GetTargetsList(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.GetTargetsList // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805fc0
	void EndAction(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.EndAction // (Native|Event|Protected|BlueprintEvent) // @ game+0x6e0110
	bool DoAction(struct APawn* Pawn, struct FString& FailureReason); // Function GOAPNPC.GOAPAction.DoAction // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x805aa0
	bool CheckProceduralPrecondition(struct APawn* Pawn, bool bPlanning); // Function GOAPNPC.GOAPAction.CheckProceduralPrecondition // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x805970
	void BeginAction(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.BeginAction // (Native|Event|Protected|BlueprintEvent) // @ game+0x6e0080
};

// Class GOAPNPC.GOAPComponent
// Size: 0x168 (Inherited: 0xb0)
struct UGOAPComponent : UActorComponent {
	struct TArray<struct FAtom> CurrentWorldInitial; // 0xb0(0x10)
	struct TArray<struct FAtom> DesiredWorldInitial; // 0xc0(0x10)
	struct UGOAPGoal* GoalInitial; // 0xd0(0x08)
	struct TSoftObjectPtr<UGOAPGoalSet> GoalSetInitial; // 0xd8(0x28)
	struct TArray<struct UGOAPAction*> ActionClasses; // 0x100(0x10)
	int32_t MaxDepth; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct AAIController* AIOwner; // 0x118(0x08)
	struct APawn* AIPawnOwner; // 0x120(0x08)
	char pad_128[0x8]; // 0x128(0x08)
	struct UGOAPGoalManager* GoalManager; // 0x130(0x08)
	struct TArray<struct UGOAPAction*> AuxActions; // 0x138(0x10)
	struct TArray<struct UGOAPAction*> Plan; // 0x148(0x10)
	char pad_158[0x10]; // 0x158(0x10)

	void UpdateCurrentWorld(struct TArray<struct FAtom>& Atoms); // Function GOAPNPC.GOAPComponent.UpdateCurrentWorld // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8065a0
	void SetGoal(struct UGOAPGoal* NewGoal); // Function GOAPNPC.GOAPComponent.SetGoal // (Final|Native|Public|BlueprintCallable) // @ game+0x8064a0
	void SetCurrentWorld(struct TArray<struct FAtom>& NewCurrentWorld); // Function GOAPNPC.GOAPComponent.SetCurrentWorld // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8063d0
	void Reset(); // Function GOAPNPC.GOAPComponent.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0x8062e0
	void ReceiveOnReset(); // Function GOAPNPC.GOAPComponent.ReceiveOnReset // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	bool IsPlanValid(); // Function GOAPNPC.GOAPComponent.IsPlanValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8061f0
	void InvalidatePlan(); // Function GOAPNPC.GOAPComponent.InvalidatePlan // (Final|Native|Public|BlueprintCallable) // @ game+0x8061b0
	void InvalidateGoalSelection(); // Function GOAPNPC.GOAPComponent.InvalidateGoalSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x806170
	bool HasPlan(); // Function GOAPNPC.GOAPComponent.HasPlan // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x806140
	struct TArray<struct UGOAPAction*> GetPlanSnapshot(); // Function GOAPNPC.GOAPComponent.GetPlanSnapshot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805f00
	struct TArray<struct FAtom> GetDesiredWorldStateAtoms(); // Function GOAPNPC.GOAPComponent.GetDesiredWorldStateAtoms // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805e50
	struct TArray<struct FAtom> GetCurrentWorldStateAtoms(); // Function GOAPNPC.GOAPComponent.GetCurrentWorldStateAtoms // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805dd0
	bool GeneratePlan(); // Function GOAPNPC.GOAPComponent.GeneratePlan // (Final|Native|Public|BlueprintCallable) // @ game+0x805d20
	bool ExecuteGOAP(bool bCreatePlan, bool bRemoveActionOnComplete); // Function GOAPNPC.GOAPComponent.ExecuteGOAP // (Final|Native|Public|BlueprintCallable) // @ game+0x805ba0
	void ClearPlan(); // Function GOAPNPC.GOAPComponent.ClearPlan // (Final|Native|Public|BlueprintCallable) // @ game+0x805a60
};

// Class GOAPNPC.GOAPGoalManager
// Size: 0x60 (Inherited: 0x28)
struct UGOAPGoalManager : UObject {
	struct UGOAPGoalSet* GoalSet; // 0x28(0x08)
	struct TArray<struct UGOAPGoal*> AuxGoals; // 0x30(0x10)
	struct UGOAPGoal* CurrentGoal; // 0x40(0x08)
	char pad_48[0x18]; // 0x48(0x18)

	void UpdateGoalSet(struct UGOAPGoalSet* InGoalSet); // Function GOAPNPC.GOAPGoalManager.UpdateGoalSet // (Final|Native|Public|BlueprintCallable) // @ game+0x806670
	void SetGoalSet(struct UGOAPGoalSet* InGoalSet); // Function GOAPNPC.GOAPGoalManager.SetGoalSet // (Final|Native|Public|BlueprintCallable) // @ game+0x806520
	void SetCurrentGoal(struct UGOAPGoal* NewGoal, bool bDeactivatePreviousGoal); // Function GOAPNPC.GOAPGoalManager.SetCurrentGoal // (Final|Native|Public|BlueprintCallable) // @ game+0x806300
	void RemoveGoal(struct UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.RemoveGoal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x806220
	void InvalidatePlan(); // Function GOAPNPC.GOAPGoalManager.InvalidatePlan // (Final|Native|Public|BlueprintCallable) // @ game+0x8061d0
	void InvalidateGoalSelection(); // Function GOAPNPC.GOAPGoalManager.InvalidateGoalSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x806190
	struct UGOAPComponent* GetOuterGOAPComp(); // Function GOAPNPC.GOAPGoalManager.GetOuterGOAPComp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805ed0
	struct TArray<struct FAtom> GetCurrentGoalAtoms(); // Function GOAPNPC.GOAPGoalManager.GetCurrentGoalAtoms // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805d50
	struct UGOAPGoal* FindGoal(struct UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.FindGoal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x805c80
	void ClearGoals(); // Function GOAPNPC.GOAPGoalManager.ClearGoals // (Final|Native|Public|BlueprintCallable) // @ game+0x805a40
	struct UGOAPGoal* AddGoal(struct UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.AddGoal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8058b0
};

// Class GOAPNPC.GOAPGoal
// Size: 0x68 (Inherited: 0x28)
struct UGOAPGoal : UObject {
	struct FString GoalName; // 0x28(0x10)
	struct TArray<struct FAtom> DesiredWorldInitial; // 0x38(0x10)
	char pad_48[0x10]; // 0x48(0x10)
	float RelevanceWeightBase; // 0x58(0x04)
	float RelevanceWeight; // 0x5c(0x04)
	struct AAIController* AIOwner; // 0x60(0x08)

	bool RequiresNewPlan(); // Function GOAPNPC.GOAPGoal.RequiresNewPlan // (Native|Event|Public|BlueprintEvent) // @ game+0x8062b0
	struct UGOAPGoalManager* GetOuterGoalManager(); // Function GOAPNPC.GOAPGoal.GetOuterGoalManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805ed0
	void GeneratePlanFailure(); // Function GOAPNPC.GOAPGoal.GeneratePlanFailure // (Native|Event|Protected|BlueprintEvent) // @ game+0x7ddba0
	void Deactivate(); // Function GOAPNPC.GOAPGoal.Deactivate // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed2d0
	void ClearRelevance(); // Function GOAPNPC.GOAPGoal.ClearRelevance // (Final|Native|Public|BlueprintCallable) // @ game+0x805a80
	void CalculateRelevance(); // Function GOAPNPC.GOAPGoal.CalculateRelevance // (Native|Event|Public|BlueprintEvent) // @ game+0x805950
	void Activate(); // Function GOAPNPC.GOAPGoal.Activate // (Native|Event|Public|BlueprintEvent) // @ game+0x6ed2b0
};

// Class GOAPNPC.GOAPAIController
// Size: 0x330 (Inherited: 0x328)
struct AGOAPAIController : AAIController {
	struct UGOAPComponent* GOAPComponent; // 0x328(0x08)
};

// Class GOAPNPC.GOAPGoalSet
// Size: 0x90 (Inherited: 0x30)
struct UGOAPGoalSet : UPrimaryDataAsset {
	struct FString Name; // 0x30(0x10)
	struct TSet<struct UGOAPGoal*> Goals; // 0x40(0x50)
};

