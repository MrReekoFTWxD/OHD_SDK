// WidgetBlueprintGeneratedClass WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C
// Size: 0x4b0 (Inherited: 0x230)
struct UWBP_CaptureStatus_UnitIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* UnitIcon; // 0x238(0x08)
	enum class ECaptureUnitType UnitType; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct FSlateBrush UnoccupiedUnitImage; // 0x248(0x88)
	struct FSlateBrush FriendlyUnitImage; // 0x2d0(0x88)
	struct FSlateBrush EnemyUnitImage; // 0x358(0x88)
	struct FSlateBrush MultipleUnitImage; // 0x3e0(0x88)
	bool bUseFriendlyUnitColor; // 0x468(0x01)
	char pad_469[0x3]; // 0x469(0x03)
	struct FLinearColor UnoccupiedUnitColor; // 0x46c(0x10)
	struct FLinearColor FriendlyUnitColor; // 0x47c(0x10)
	struct FLinearColor EnemyUnitColor; // 0x48c(0x10)
	bool bUnitMultiple; // 0x49c(0x01)
	bool bIsDesignTime; // 0x49d(0x01)
	char pad_49E[0x2]; // 0x49e(0x02)
	struct FLinearColor LocalUnitColorToUse; // 0x4a0(0x10)

	void SetIsMultipleUnit(bool bNewUnitMultiple); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetIsMultipleUnit // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetUnitType(enum class ECaptureUnitType NewUnitType); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetUnitType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CaptureStatus_UnitIcon(int32_t EntryPoint); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.ExecuteUbergraph_WBP_CaptureStatus_UnitIcon // (Final|UbergraphFunction) // @ game+0xec54e0
};

