// BlueprintGeneratedClass BP_HDVehicleSeatAttachment_Player.BP_HDVehicleSeatAttachment_Player_C
// Size: 0xe1 (Inherited: 0xd8)
struct UBP_HDVehicleSeatAttachment_Player_C : UArcVehicleSeatConfig_PlayerAttachment {
	struct UAnimInstance* SeatAnimInstanceLinked; // 0xd8(0x08)
	enum class EDFItemEnabledMode SeatItemMode; // 0xe0(0x01)
};

