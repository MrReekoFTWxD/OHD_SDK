// WidgetBlueprintGeneratedClass WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C
// Size: 0x330 (Inherited: 0x250)
struct UWBP_HDVictoryMenuBase_C : UVictoryMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x250(0x08)
	struct UTextBlock* BluforForceText; // 0x258(0x08)
	struct UTextBlock* BluforTeamScoreText; // 0x260(0x08)
	struct UTextBlock* ElapsedTimeText; // 0x268(0x08)
	struct UTextBlock* GameModeNameText; // 0x270(0x08)
	struct UTextBlock* MapNameText; // 0x278(0x08)
	struct UTextBlock* OpforForceText; // 0x280(0x08)
	struct UTextBlock* OpforTeamScoreText; // 0x288(0x08)
	struct UTextBlock* VictoryText; // 0x290(0x08)
	struct FText BluforVictoryText; // 0x298(0x18)
	struct FText OpforVictoryText; // 0x2b0(0x18)
	struct FText NoTeamVictoryText; // 0x2c8(0x18)
	struct UAudioComponent* MenuMusicAC; // 0x2e0(0x08)
	struct USoundBase* WinMusicBlufor; // 0x2e8(0x08)
	struct USoundBase* WinMusicOpfor; // 0x2f0(0x08)
	struct USoundBase* LossMusicBlufor; // 0x2f8(0x08)
	struct USoundBase* LossMusicOpfor; // 0x300(0x08)
	struct AHDTeamState* WinningTeamState; // 0x308(0x08)
	struct AHDTeamState* BluforTeamState; // 0x310(0x08)
	struct UBP_HDFactionInfoBase_C* BluforFactionInfoClass; // 0x318(0x08)
	struct AHDTeamState* OpforTeamState; // 0x320(0x08)
	struct UBP_HDFactionInfoBase_C* OpforFactionInfoClass; // 0x328(0x08)

	void GetPlayerTeam(enum class EHDTeam& PlayerTeam); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetPlayerTeam // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void GetMusicTrackToUse(enum class EHDTeam PlayerTeam, bool bPlayerWon, struct USoundBase*& SoundToUse); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetMusicTrackToUse // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void PlayWinLossMenuMusic(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.PlayWinLossMenuMusic // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupTeamScoreText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupTeamScoreText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupGameModeNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupGameModeNameText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupElapsedTimeText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupElapsedTimeText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupMapNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupMapNameText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupForceNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupForceNameText // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupVictoryText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupVictoryText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDoubleClick // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnVictoryInit(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnVictoryInit // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HDVictoryMenuBase(int32_t EntryPoint); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.ExecuteUbergraph_WBP_HDVictoryMenuBase // (Final|UbergraphFunction) // @ game+0xec54e0
};

