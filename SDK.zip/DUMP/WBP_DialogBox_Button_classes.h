// WidgetBlueprintGeneratedClass WBP_DialogBox_Button.WBP_DialogBox_Button_C
// Size: 0x340 (Inherited: 0x230)
struct UWBP_DialogBox_Button_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* DlgBtn; // 0x238(0x08)
	struct UTextBlock* DlgText; // 0x240(0x08)
	struct FText BtnText; // 0x248(0x18)
	struct FMulticastInlineDelegate ButtonClicked; // 0x260(0x10)
	bool bActive; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct FSlateColor TextColor; // 0x278(0x28)
	struct FSlateColor TextColorActive; // 0x2a0(0x28)
	struct FSlateColor BtnTint; // 0x2c8(0x28)
	struct FSlateColor TextColorPressed; // 0x2f0(0x28)
	struct FSlateColor TextColorHovered; // 0x318(0x28)

	void UpdateAppearance(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.UpdateAppearance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetActive(bool bNewActive); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.SetActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DialogBox_Button(int32_t EntryPoint); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ExecuteUbergraph_WBP_DialogBox_Button // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void ButtonClicked__DelegateSignature(struct UWBP_DialogBox_Button_C* ClickedBtn); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

