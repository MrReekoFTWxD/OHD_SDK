// BlueprintGeneratedClass BP_HDWeaponBase.BP_HDWeaponBase_C
// Size: 0xa54 (Inherited: 0x870)
struct ABP_HDWeaponBase_C : AHDBaseWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x870(0x08)
	struct USceneComponent* Muzzle; // 0x878(0x08)
	struct USceneComponent* DefaultBipod; // 0x880(0x08)
	struct USceneComponent* DefaultGrip; // 0x888(0x08)
	struct USceneComponent* DefaultBarrel; // 0x890(0x08)
	struct USceneComponent* DefaultSight; // 0x898(0x08)
	struct TMap<struct FName, struct UAnimSequenceBase*> LocoAnimSet; // 0x8a0(0x50)
	struct TMap<struct FName, struct UAnimSequenceBase*> LocoTPPAnimSet; // 0x8f0(0x50)
	bool bUseMirroredLowerBodyLocomotion; // 0x940(0x01)
	char pad_941[0x3]; // 0x941(0x03)
	struct FVector FirstPersonPositionOffset; // 0x944(0x0c)
	bool bHasGrip; // 0x950(0x01)
	bool bHasBipod; // 0x951(0x01)
	char pad_952[0x2]; // 0x952(0x02)
	struct FVector BracedAimPosition; // 0x954(0x0c)
	struct USceneComponent* CurrentSight; // 0x960(0x08)
	struct USceneComponent* CurrentBarrel; // 0x968(0x08)
	struct USceneComponent* CurrentGrip; // 0x970(0x08)
	struct USceneComponent* CurrentBipod; // 0x978(0x08)
	struct TArray<struct USceneComponent*> Sights; // 0x980(0x10)
	struct FMulticastInlineDelegate OnUpdateAttachments; // 0x990(0x10)
	float ADSOffset; // 0x9a0(0x04)
	float BipodPlayerDistance; // 0x9a4(0x04)
	float BipodCameraHeight; // 0x9a8(0x04)
	char pad_9AC[0x4]; // 0x9ac(0x04)
	struct UCameraShake* FiringScreenShake; // 0x9b0(0x08)
	float BracedAimTilt; // 0x9b8(0x04)
	struct FVector ThirdPersonPositionOffset; // 0x9bc(0x0c)
	struct FVector ThirdPersonAimOffset; // 0x9c8(0x0c)
	float KickAmount; // 0x9d4(0x04)
	float KickNoiseAmount; // 0x9d8(0x04)
	char pad_9DC[0x4]; // 0x9dc(0x04)
	struct TArray<struct FName> BasePoseBonesToHide; // 0x9e0(0x10)
	struct FName SecondMagBoneName; // 0x9f0(0x08)
	struct FName BulletBoneName; // 0x9f8(0x08)
	struct FRotator LowReadyRotationOffset; // 0xa00(0x0c)
	struct FVector LowReadyPositionOffset; // 0xa0c(0x0c)
	struct FMulticastInlineDelegate OnUpdateSights; // 0xa18(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> ThirdPersonMatArray; // 0xa28(0x10)
	float AmmoPercent; // 0xa38(0x04)
	char pad_A3C[0x4]; // 0xa3c(0x04)
	struct TArray<struct UMaterialInstanceDynamic*> FirstPersonMatArray; // 0xa40(0x10)
	float ResetAmmoPercentTime; // 0xa50(0x04)

	void ShouldUseMirroredLowerBodyLoco(bool& bOutUseMirrored); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ShouldUseMirroredLowerBodyLoco // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetLocoTPPAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLocoTPPAnimSet // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void GetLocoAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLocoAnimSet // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void SetAmmoPercent(struct ADFBaseAmmoClip* FromAmmoClip); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.SetAmmoPercent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnRep_AmmoPercent(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnRep_AmmoPercent // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void FindNextMagazine(struct ADFBaseAmmoClip*& NextClip); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.FindNextMagazine // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	bool CanFire(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.CanFire // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void InternalSetVisibilityForAttachment(struct USceneComponent* Attachment, bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.InternalSetVisibilityForAttachment // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateAttachmentVisibility(bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.UpdateAttachmentVisibility // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	bool RemoveLegacyLocomotionAnims(bool bFPP); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.RemoveLegacyLocomotionAnims // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct TMap<struct FName, struct UAnimSequenceBase*> GetLegacyLocomotionAnims(bool bFPP); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLegacyLocomotionAnims // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void UserConstructionScript(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CycleSight(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.CycleSight // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetCurrentSight(struct USceneComponent* Sight); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.SetCurrentSight // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveFire(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveFire // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveVisibilityChanged(bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEquip(struct ADFBaseItem* LastItem); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveOnEquip // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ResetBullets(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ResetBullets // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveReloadFinished(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveReloadFinished // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ServerResetAmmoPercent(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ServerResetAmmoPercent // (Net|NetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDWeaponBase(int32_t EntryPoint); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ExecuteUbergraph_BP_HDWeaponBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnUpdateSights__DelegateSignature(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnUpdateSights__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnUpdateAttachments__DelegateSignature(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnUpdateAttachments__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

