// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C
// Size: 0x340 (Inherited: 0x260)
struct UWBP_DeployMenu_SquadList_C : UDeployMenu_SquadListBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCanvasPanel* CanvasPanel_2; // 0x268(0x08)
	struct USizeBox* DummyOption; // 0x270(0x08)
	struct UButton* DummyOptionBtn; // 0x278(0x08)
	struct UImage* Image_6; // 0x280(0x08)
	struct UWBP_SQOption_C* JoinLeaveSQOption; // 0x288(0x08)
	struct UButton* JoinLeaveSQOptionBtn; // 0x290(0x08)
	struct UTextBlock* JoinLeaveSQOptionText; // 0x298(0x08)
	struct UWBP_SQOption_C* LockUnlockSQOption; // 0x2a0(0x08)
	struct UButton* LockUnlockSQOptionBtn; // 0x2a8(0x08)
	struct UTextBlock* LockUnlockSQOptionText; // 0x2b0(0x08)
	struct UHorizontalBox* SQOptionsHBox; // 0x2b8(0x08)
	struct UTextBlock* SquadMemberCountText; // 0x2c0(0x08)
	struct UVerticalBox* SquadMembersList; // 0x2c8(0x08)
	struct UTextBlock* SquadNameText; // 0x2d0(0x08)
	struct UButton* ToggleListVisibilityBtn; // 0x2d8(0x08)
	struct UImage* ToggleListVisibilityImg; // 0x2e0(0x08)
	bool bExpanded; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct FText SquadTextFormat; // 0x2f0(0x18)
	bool bExpandListInDesigner; // 0x308(0x01)
	char pad_309[0x3]; // 0x309(0x03)
	int32_t NumFakeSquadMemberItems; // 0x30c(0x04)
	struct FMargin SquadMemberItemPadding; // 0x310(0x10)
	bool bCollapsedByUser; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)
	struct UWBP_DeployMenu_PlatoonSquadList_C* ParentContainerWidget; // 0x328(0x08)
	struct FMargin OptionPadding; // 0x330(0x10)

	void IsSquadValid(bool& bValidSQ); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsSquadValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void OnPaint(struct FPaintContext& Context); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnPaint // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void SetSquadLockedState(bool bNewLocked); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadLockedState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UnlockSquad(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UnlockSquad // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LockSquad(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.LockSquad // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void KickSquadMember(struct AHDPlayerState* MemberPSToKick); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.KickSquadMember // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void WasListCollapsedByUser(bool& bCollapsedByUser); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.WasListCollapsedByUser // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void UpdateLockUnlockBtnState(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateLockUnlockBtnState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HasAnySquadMembers(bool& bValidMembersPresent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.HasAnySquadMembers // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetupSQOptions(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetupSQOptions // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsOwningPlayerInMemberWidgetList(bool& bOwnsMemberWidget); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerInMemberWidgetList // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void TestPrereqsForAllMembers(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestPrereqsForAllMembers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TestSquadAndMemberPrereqs(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestSquadAndMemberPrereqs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TestSQPrereqs(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestSQPrereqs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsOwningPlayerRegisteredSquadLeader(bool& bSquadLeader); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadLeader // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsOwningPlayerRegisteredSquadMember(bool bIgnorePendingRemoval, bool& bRegisteredMember); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadMember // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void UpdateJoinLeaveBtnState(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateJoinLeaveBtnState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateSquadMemberCountText(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateSquadMemberCountText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CollapseListIfEmpty(bool bCollapseParentIfEmpty); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseListIfEmpty // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSquadNameText(struct FText NewSquadName); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadNameText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RemoveSquadMemberItemWidgetFromList(struct USquadMemberInfo* RemovedMemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.RemoveSquadMemberItemWidgetFromList // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AddNewSquadMemberItemWidget(struct USquadMemberInfo* MemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.AddNewSquadMemberItemWidget // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CollapseList(bool bCollapseParent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExpandList(bool bExpandParent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExpandList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__LockUnlockSQOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__LockUnlockSQOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void GenerateSquadMember(struct USquadMemberInfo* MemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.GenerateSquadMember // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void DeconstructSquadMember(struct USquadMemberInfo* RemovedMemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.DeconstructSquadMember // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__LeaveSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__LeaveSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ExpandBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__ExpandBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void SquadMembersListExpanded(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SquadMembersListExpanded // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SquadMembersListCollapsed(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SquadMembersListCollapsed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSquadSet(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadSet // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnSquadNameUpdated(struct FText& NewSquadName, struct FText& PreviousSquadName); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadNameUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void OnSquadLeaderUpdated(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLeaderUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OnSquadLockStateUpdated(bool bNewLockedState); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLockStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DeployMenu_SquadList(int32_t EntryPoint); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExecuteUbergraph_WBP_DeployMenu_SquadList // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

