// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C
// Size: 0x270 (Inherited: 0x240)
struct UWBP_HUDElement_TextChat_InputHandler_C : UHDTextChatInputWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct UTextBlock* ChannelNameText; // 0x248(0x08)
	struct UEditableTextBox* MsgInputTextBox; // 0x250(0x08)
	struct UDFCommChannel* CurrentChannel; // 0x258(0x08)
	struct FMulticastInlineDelegate OnInputTextCommitted; // 0x260(0x10)

	void StartTalking(struct UDFCommChannel* NewTalkChannel); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StartTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void StopTalking(struct UDFCommChannel* CurrentChannel); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StopTalking // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void InputTextEntered(struct FText Text); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.InputTextEntered // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.BndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler(int32_t EntryPoint); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.ExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnInputTextCommitted__DelegateSignature(struct FText Text, enum class ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.OnInputTextCommitted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

