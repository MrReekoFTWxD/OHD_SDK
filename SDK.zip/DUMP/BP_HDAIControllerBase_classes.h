// BlueprintGeneratedClass BP_HDAIControllerBase.BP_HDAIControllerBase_C
// Size: 0x390 (Inherited: 0x360)
struct ABP_HDAIControllerBase_C : AHDAIController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x360(0x08)
	struct UAIPerceptionComponent* PerceptionComp; // 0x368(0x08)
	struct UHDGOAPComponent* GOAPComp; // 0x370(0x08)
	float SavedMaxConeOfFireAngleDegrees; // 0x378(0x04)
	float SavedMinConeOfFireAngleDegrees; // 0x37c(0x04)
	bool bSavedInfiniteAmmo; // 0x380(0x01)
	bool bSavedInfiniteClipAmmo; // 0x381(0x01)
	char pad_382[0x6]; // 0x382(0x06)
	struct UDataTable* DefaultFactionVocalProfiles; // 0x388(0x08)

	void SetupVocalProfile(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupVocalProfile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ResetWeaponBase(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetWeaponBase // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupWeaponBase(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupWeaponBase // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ClearWeaponSavedValues(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ClearWeaponSavedValues // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RestorePreviousValuesForWeapon(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.RestorePreviousValuesForWeapon // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SaveAndApplyNewValuesToWeapon(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SaveAndApplyNewValuesToWeapon // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ResetRecoilHandler(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetRecoilHandler // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupRecoilHandler(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupRecoilHandler // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CharacterCleanup(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.CharacterCleanup // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UnbindEventsFromCharacter(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.UnbindEventsFromCharacter // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BindEventsToCharacter(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.BindEventsToCharacter // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void WarnOfNoRecoilHandler(struct ABP_HDWeaponBase_C* EquippedWeapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.WarnOfNoRecoilHandler // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct UHDKit* GetFactionSpecifiedSquadMemberKit(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadMemberKit // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	struct UHDKit* GetFactionSpecifiedSquadLeaderKit(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadLeaderKit // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void OnOwnerPawnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnDeath // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnOwnerPawnEquippedItemChange(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnEquippedItemChange // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceivePossess(struct APawn* PossessedPawn); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceivePossess // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void SuppressionEvent(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SuppressionEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HitDamageEvent(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.HitDamageEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveUnPossess(struct APawn* UnpossessedPawn); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceiveUnPossess // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDAIControllerBase(int32_t EntryPoint); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ExecuteUbergraph_BP_HDAIControllerBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

