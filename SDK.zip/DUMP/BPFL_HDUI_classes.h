// BlueprintGeneratedClass BPFL_HDUI.BPFL_HDUI_C
// Size: 0x28 (Inherited: 0x28)
struct UBPFL_HDUI_C : UBlueprintFunctionLibrary {

	void ParseServerBadgesFromTable(struct UDataTable* BadgeTable, struct UObject* __WorldContext, struct TArray<struct FFServerBadgeUIDefinition>& SortedBadgeDefs); // Function BPFL_HDUI.BPFL_HDUI_C.ParseServerBadgesFromTable // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetIconBrushForStanceState(enum class EHDUICharacterStanceState State, struct UObject* __WorldContext, struct FSlateBrush& IconBrush); // Function BPFL_HDUI.BPFL_HDUI_C.GetIconBrushForStanceState // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetIconTextureForStanceState(enum class EHDUICharacterStanceState State, struct UObject* __WorldContext, struct UTexture2D*& IconTex); // Function BPFL_HDUI.BPFL_HDUI_C.GetIconTextureForStanceState // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetNormHealthColorByRatio(float HealthValueNorm, struct UObject* __WorldContext, struct FLinearColor& ColorToUse); // Function BPFL_HDUI.BPFL_HDUI_C.GetNormHealthColorByRatio // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetHealthColorByRatio(float Health, float MaxHealth, struct UObject* __WorldContext, struct FLinearColor& ColorToUse); // Function BPFL_HDUI.BPFL_HDUI_C.GetHealthColorByRatio // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
};

