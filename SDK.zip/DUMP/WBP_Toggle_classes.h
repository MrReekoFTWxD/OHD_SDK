// WidgetBlueprintGeneratedClass WBP_Toggle.WBP_Toggle_C
// Size: 0x290 (Inherited: 0x230)
struct UWBP_Toggle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWBP_TextButton_C* OffBtn; // 0x238(0x08)
	struct UWBP_TextButton_C* OnBtn; // 0x240(0x08)
	bool bToggleOn; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
	struct FMulticastInlineDelegate ToggleStateChanged; // 0x250(0x10)
	struct FText OnText; // 0x260(0x18)
	struct FText OffText; // 0x278(0x18)

	void UpdateDesignerView(); // Function WBP_Toggle.WBP_Toggle_C.UpdateDesignerView // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsToggledOn(bool& bToggledOn); // Function WBP_Toggle.WBP_Toggle_C.IsToggledOn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetToggle(bool bInToggle); // Function WBP_Toggle.WBP_Toggle_C.SetToggle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__OnBtn_K2Node_ComponentBoundEvent_1_ButtonClicked__DelegateSignature(); // Function WBP_Toggle.WBP_Toggle_C.BndEvt__OnBtn_K2Node_ComponentBoundEvent_1_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__OffBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature(); // Function WBP_Toggle.WBP_Toggle_C.BndEvt__OffBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_Toggle.WBP_Toggle_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_Toggle(int32_t EntryPoint); // Function WBP_Toggle.WBP_Toggle_C.ExecuteUbergraph_WBP_Toggle // (Final|UbergraphFunction) // @ game+0xec54e0
	void ToggleStateChanged__DelegateSignature(bool bToggledOn); // Function WBP_Toggle.WBP_Toggle_C.ToggleStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

