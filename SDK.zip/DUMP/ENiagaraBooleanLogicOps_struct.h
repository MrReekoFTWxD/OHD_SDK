// UserDefinedEnum ENiagaraBooleanLogicOps.ENiagaraBooleanLogicOps
enum class ENiagaraBooleanLogicOps : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator2 = 1,
	NewEnumerator4 = 2,
	NewEnumerator5 = 3,
	ENiagaraBooleanLogicOps_MAX = 4
};

