// UserDefinedStruct FEntitlementDefinition.FEntitlementDefinition
// Size: 0x10 (Inherited: 0x00)
struct FFEntitlementDefinition {
	enum class EEntitlementType AppType_9_59A34CB643EFB5B38A4B959FC285E1FF; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t AppID_5_6EE051BA41BB4AD74980F6A1D69E9ADC; // 0x08(0x08)
};

