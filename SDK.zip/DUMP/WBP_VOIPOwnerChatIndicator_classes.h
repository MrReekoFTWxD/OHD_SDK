// WidgetBlueprintGeneratedClass WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C
// Size: 0x291 (Inherited: 0x230)
struct UWBP_VOIPOwnerChatIndicator_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWidgetAnimation* OwnerVOIPInputUIAnim; // 0x238(0x08)
	struct UImage* IndicatorSpeakerIcon; // 0x240(0x08)
	struct UTextBlock* IndicatorText; // 0x248(0x08)
	struct FText IndicatorNameText; // 0x250(0x18)
	struct FSlateColor IndicatorColor; // 0x268(0x28)
	bool bActive; // 0x290(0x01)

	void PreConstruct(bool IsDesignTime); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Activate(); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.Activate // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Deactivate(); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.Deactivate // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void InputAnimFinished(); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.InputAnimFinished // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_VOIPOwnerChatIndicator(int32_t EntryPoint); // Function WBP_VOIPOwnerChatIndicator.WBP_VOIPOwnerChatIndicator_C.ExecuteUbergraph_WBP_VOIPOwnerChatIndicator // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

