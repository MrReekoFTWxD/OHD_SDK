// BlueprintGeneratedClass BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C
// Size: 0xdb8 (Inherited: 0xa40)
struct ABP_HDPlayerCharacterBase_C : AHDPlayerCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa40(0x08)
	struct UHDAIPerceptionComponent* HDAIPerception; // 0xa48(0x08)
	struct USceneComponent* TargetCameraPoint; // 0xa50(0x08)
	struct USceneComponent* RefPoint; // 0xa58(0x08)
	struct UNavigationInvokerComponent* NavigationInvoker; // 0xa60(0x08)
	struct UBoxComponent* Suppression_B; // 0xa68(0x08)
	struct UBoxComponent* Suppression_A; // 0xa70(0x08)
	struct UBoxComponent* Suppression_L; // 0xa78(0x08)
	struct UBoxComponent* Suppression_R; // 0xa80(0x08)
	struct UBP_HDVOIPTalker_C* VOIPTalker; // 0xa88(0x08)
	struct UTextRenderComponent* PlayerNameTextRender; // 0xa90(0x08)
	struct UDFPOIComponent* POI; // 0xa98(0x08)
	struct FVector VaultCameraTimeline_VaultCamera_22F2E311466556389CC02182AEE99CCA; // 0xaa0(0x0c)
	enum class ETimelineDirection VaultCameraTimeline__Direction_22F2E311466556389CC02182AEE99CCA; // 0xaac(0x01)
	char pad_AAD[0x3]; // 0xaad(0x03)
	struct UTimelineComponent* VaultCameraTimeline; // 0xab0(0x08)
	float LerpTimeline_Lerp_5E919E724A951192A68B8180576AB695; // 0xab8(0x04)
	enum class ETimelineDirection LerpTimeline__Direction_5E919E724A951192A68B8180576AB695; // 0xabc(0x01)
	char pad_ABD[0x3]; // 0xabd(0x03)
	struct UTimelineComponent* LerpTimeline; // 0xac0(0x08)
	struct FVector DamageEffectTimeline_DamageEffect_BEBC6E9841C4A26EF0A22DA008BD6CA4; // 0xac8(0x0c)
	enum class ETimelineDirection DamageEffectTimeline__Direction_BEBC6E9841C4A26EF0A22DA008BD6CA4; // 0xad4(0x01)
	char pad_AD5[0x3]; // 0xad5(0x03)
	struct UTimelineComponent* DamageEffectTimeline; // 0xad8(0x08)
	struct FVector SuppressionTimeline_SuppressionCurve_83869DB54889A3FECCAF0E83EA19C04B; // 0xae0(0x0c)
	enum class ETimelineDirection SuppressionTimeline__Direction_83869DB54889A3FECCAF0E83EA19C04B; // 0xaec(0x01)
	char pad_AED[0x3]; // 0xaed(0x03)
	struct UTimelineComponent* SuppressionTimeline; // 0xaf0(0x08)
	float FallDamageDivisor; // 0xaf8(0x04)
	float FallDamageThreshold; // 0xafc(0x04)
	float EquipmentTimerDelay; // 0xb00(0x04)
	bool bEquipmentKeyPressed; // 0xb04(0x01)
	bool bSelectingEquipmentBySlot; // 0xb05(0x01)
	bool bNextItem; // 0xb06(0x01)
	char pad_B07[0x1]; // 0xb07(0x01)
	struct APlayerState* LastValidPlayerState; // 0xb08(0x08)
	bool bTintTeamColorForPlayerPOIs; // 0xb10(0x01)
	bool bUseSpecialSymbolForLocalPlayerPOIs; // 0xb11(0x01)
	char pad_B12[0x6]; // 0xb12(0x06)
	struct UTexture2D* LocalPlayerPOISymbol; // 0xb18(0x08)
	struct USoundAttenuation* VOIPSpatializedAttenuation; // 0xb20(0x08)
	struct USoundEffectSourcePresetChain* VOIPSpatializedSrcEffectChain; // 0xb28(0x08)
	struct FTimerHandle HealthRegenTimer; // 0xb30(0x08)
	bool bHealthRegenEnabled; // 0xb38(0x01)
	char pad_B39[0x3]; // 0xb39(0x03)
	float HealthRegenAmount; // 0xb3c(0x04)
	float HealthRegenTimerInterval; // 0xb40(0x04)
	struct FLinearColor LocalPlayerPOITint; // 0xb44(0x10)
	struct FColor RedTeamColor; // 0xb54(0x04)
	struct FColor BlueTeamColor; // 0xb58(0x04)
	struct FColor NoTeamColor; // 0xb5c(0x04)
	bool bRadialMenuEnabled; // 0xb60(0x01)
	char pad_B61[0x7]; // 0xb61(0x07)
	struct UWBP_HDRadialMenu_C* RadialMenu; // 0xb68(0x08)
	struct USoundBase* RadialMenuExitSnd; // 0xb70(0x08)
	struct UDataTable* RadialMenuOptions; // 0xb78(0x08)
	bool bRallypointsEnabled; // 0xb80(0x01)
	char pad_B81[0x3]; // 0xb81(0x03)
	float RadialMenuRallypointTimeDeployed; // 0xb84(0x04)
	bool bSpatializedVOIPTalker; // 0xb88(0x01)
	bool bOutpostsEnabled; // 0xb89(0x01)
	char pad_B8A[0x2]; // 0xb8a(0x02)
	float RadialMenuOutpostTimeDeployed; // 0xb8c(0x04)
	struct USoundBase* SuppressionSound; // 0xb90(0x08)
	float SuppressionSoundVolume; // 0xb98(0x04)
	bool bBracedAim; // 0xb9c(0x01)
	bool bWantsMount; // 0xb9d(0x01)
	bool bMounted; // 0xb9e(0x01)
	char pad_B9F[0x1]; // 0xb9f(0x01)
	struct FVector MountDirection; // 0xba0(0x0c)
	struct FVector MountPosition; // 0xbac(0x0c)
	char pad_BB8[0x8]; // 0xbb8(0x08)
	struct FTransform MountTransform; // 0xbc0(0x30)
	struct FVector SmoothSightDirection; // 0xbf0(0x0c)
	struct FVector SmoothSightOffset; // 0xbfc(0x0c)
	float AimSpeed; // 0xc08(0x04)
	float SightDirectionSmoothingSpeed; // 0xc0c(0x04)
	float SightPositionSmoothingSpeed; // 0xc10(0x04)
	float MountDistance; // 0xc14(0x04)
	float AimAlpha; // 0xc18(0x04)
	float MountHeight; // 0xc1c(0x04)
	struct ABP_HDWeaponBase_C* EquippedWeapon; // 0xc20(0x08)
	struct ABP_HDProj_SPDeployableBase_C* SpawnedFOB; // 0xc28(0x08)
	struct ABP_HDProj_SPDeployableBase_C* SpawnedRallypoint; // 0xc30(0x08)
	struct FMulticastInlineDelegate OnSuppression; // 0xc38(0x10)
	struct FMulticastInlineDelegate OnHitDamage; // 0xc48(0x10)
	bool bSpottingEnabled; // 0xc58(0x01)
	char pad_C59[0x7]; // 0xc59(0x07)
	struct UCurveVector* SuppressionCurve; // 0xc60(0x08)
	struct UCurveVector* HitDamageCurve; // 0xc68(0x08)
	struct UCameraShake* SuppressionCameraShake; // 0xc70(0x08)
	struct UCameraShake* ReceiveDamageCameraShake; // 0xc78(0x08)
	struct FLinearColor HitEffectValues; // 0xc80(0x10)
	struct FLinearColor BleedingEffectValues; // 0xc90(0x10)
	float DamageEffectStartPercent; // 0xca0(0x04)
	bool bVariationDataSet; // 0xca4(0x01)
	char pad_CA5[0x3]; // 0xca5(0x03)
	float MinVaultViewYaw; // 0xca8(0x04)
	float MaxVaultViewYaw; // 0xcac(0x04)
	struct UCurveVector* VaultOverCameraCurve; // 0xcb0(0x08)
	struct UCurveVector* SprintVaultOverCameraCurve; // 0xcb8(0x08)
	struct UCurveVector* ClimbOntoCameraCurve; // 0xcc0(0x08)
	struct UCurveVector* SprintClimbOntoCameraCurve; // 0xcc8(0x08)
	struct FVector Camera1POffsetBeforeVault; // 0xcd0(0x0c)
	struct FVector Mesh1POffsetBeforeVault; // 0xcdc(0x0c)
	struct FWeightedBlendable SuppresionEffect; // 0xce8(0x10)
	struct FWeightedBlendable DamageEffect; // 0xcf8(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> ThirdPersonCharMatArray; // 0xd08(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> FirstPersonCharMatArray; // 0xd18(0x10)
	bool bUseSpecialSymbolForSquadMatePOIs; // 0xd28(0x01)
	char pad_D29[0x7]; // 0xd29(0x07)
	struct UTexture2D* SquadMatePOISymbol; // 0xd30(0x08)
	struct FLinearColor SquadMatePOITint; // 0xd38(0x10)
	struct UTexture2D* NonSquadMatePOISymbol; // 0xd48(0x08)
	struct FLinearColor NonSquadMatePOITint; // 0xd50(0x10)
	bool bUseSpecialSymbolForSquadLeaderPOIs; // 0xd60(0x01)
	char pad_D61[0x7]; // 0xd61(0x07)
	struct UTexture2D* SquadLeaderPOISymbol; // 0xd68(0x08)
	struct FLinearColor SquadLeaderPOITint; // 0xd70(0x10)
	struct FLinearColor SquadLeaderPOITextColor; // 0xd80(0x10)
	struct UTexture2D* NonSquadLeaderPOISymbol; // 0xd90(0x08)
	struct FLinearColor NonSquadLeaderPOITint; // 0xd98(0x10)
	struct FLinearColor NonSquadLeaderPOITextColor; // 0xda8(0x10)

	struct FVector EventGetFocalPoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EventGetFocalPoint // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void IsSameSquad(struct ABP_HDPlayerControllerBase_C* LocalController, bool& bSameSquad); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSameSquad // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetVaultCameraCurveForBehavior(enum class EVaultBehavior VaultBehavior, struct UCurveVector*& CameraCurve); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetVaultCameraCurveForBehavior // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void RestorePCViewRotationYawLimits(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RestorePCViewRotationYawLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetPCViewRotationYawLimits(float ViewYawMin, float ViewYawMax, bool bRelativeToActorRotation); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetPCViewRotationYawLimits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateCharMesh(struct USkeletalMesh* NewMesh, bool bUpdateFPPMesh); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSuppressionCompIsActive(struct UPrimitiveComponent* PrimComp, bool bNewActive); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionCompIsActive // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetSuppressionActive(bool bActive); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CalcOutpostEnemiesNearbyRestriction(bool& bAreEnemiesNearby); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostEnemiesNearbyRestriction // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CalcRallypointEnemiesNearbyRestriction(bool& bAreEnemiesNearby); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointEnemiesNearbyRestriction // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsOutpostNumberLimitReached(bool& bNumberLimitReached); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsOutpostNumberLimitReached // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsRallypointNumberLimitReached(bool& bNumberLimitReached); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsRallypointNumberLimitReached // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CalcOutpostDistanceRestriction(bool& bIsOutpostDistanceRestricted); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostDistanceRestriction // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CalcRallypointDistanceRestriction(bool& bIsRallypointDistanceRestricted); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointDistanceRestriction // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetIsSpawnedRallypointValid(bool& bIsSpawnedRallypointValid); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedRallypointValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetIsSpawnedOutpostValid(bool& bIsSpawnedOutpostValid); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedOutpostValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetProneMountPosition(struct FVector BoxSize, float Distance, float MaxHeight, float MinHeight, float MinSpace, bool& bCouldMount, struct FVector& MountPosition); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetProneMountPosition // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void AlignSights(float MinSightDistance); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.AlignSights // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetMountPosition(struct FVector Direction, float WallDistance, float TraceRadius, float CornerDistance, float CapsuleHeight, bool& bCouldMount, struct FVector& Position, struct FTransform& Transform); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMountPosition // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnRep_bSpatializedVOIPTalker(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnRep_bSpatializedVOIPTalker // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HasSquadLeaderKit(bool bRequireRallyPointAbility, bool& bUsingSquadLeaderKit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HasSquadLeaderKit // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void IsSquadLeader(bool& bSquadLeader); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSquadLeader // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetSquadState(struct AHDSquadState*& SquadState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetSquadState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void CanSelectAnyRadialMenuOption(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CanSelectAnyRadialMenuOption // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void RadialMenuCanSelectOutpost(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectOutpost // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void RadialMenuCanSelectRallypoint(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectRallypoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void RadialMenuCanSelectSpot(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectSpot // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void RadialMenuSelectOutpost(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectOutpost // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RadialMenuSelectRallypoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectRallypoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void RadialMenuSelectSpot(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectSpot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectRadialMenuItem(struct FName Category, struct FName SubItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectRadialMenuItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SpawnAndInitDeployableSPAtPawn(struct ABP_HDProj_SPDeployableBase_C* SPDeployableClass, struct FVector SpawnOffset, struct ABP_HDProj_SPDeployableBase_C*& SpawnedDeployableSP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SpawnAndInitDeployableSPAtPawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void LeanDebug(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LeanDebug // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsMatchingTeam(struct AController* LocalController, bool& bMatchingTeam); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsMatchingTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void GetPlayerFactionInfoClass(enum class EHDTeam PlayerTeam, struct UBP_HDFactionInfoBase_C*& FactionInfoClass); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetPlayerFactionInfoClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void ClearHealthRegenTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ClearHealthRegenTimer // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetHealthRegenTimerIfInvalid(float NewHealth); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetHealthRegenTimerIfInvalid // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HealthRegenTimerElapsed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HealthRegenTimerElapsed // (Private|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CleanupVOIPTalker(bool& bDestroyedComp); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CleanupVOIPTalker // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetupVOIPTalker(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetupVOIPTalker // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void EquipSelectedItemFromInventory(bool bSwitchFireModeForSelected); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EquipSelectedItemFromInventory // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetMostValidLoadout(struct UHDKit*& PlayerLoadout); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidLoadout // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetMostValidTeamFactionInfo(struct UDFFactionInfo*& FactionInfoClass); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamFactionInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetMostValidTeamState(struct ADFTeamState*& TeamState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetMostValidPlayerState(struct APlayerState*& PlayerState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidPlayerState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	struct USkeletalMesh* ReceiveGetDefaultPawnMesh1P(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveGetDefaultPawnMesh1P // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void UpdateEquipmentItems(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateEquipmentItems // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdatePOIState(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdatePOIState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetMinimapWidget(struct AController* Controller, struct UDFMinimap*& MinimapWidget); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMinimapWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void ApplyCharacterVariation(struct FDFCharacterVariationDataHandle VariationHandle, bool bApplyToFPP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ApplyCharacterVariation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateCharMeshes(struct USkeletalMesh* MeshFPP, struct USkeletalMesh* MeshTPP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshes // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UpdateCharMeshesFromFaction(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshesFromFaction // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SelectEquipmentBySlotNum(int32_t EquipSlotNum, bool bEquipImmediately, bool bFromInput); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectEquipmentBySlotNum // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetEquipmentTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetEquipmentTimer // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void StartEquipmentTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.StartEquipmentTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void FreeAiming(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FreeAiming // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void UserConstructionScript(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SuppressionTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xec54e0
	void SuppressionTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xec54e0
	void DamageEffectTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.DamageEffectTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xec54e0
	void DamageEffectTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.DamageEffectTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xec54e0
	void LerpTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LerpTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xec54e0
	void LerpTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LerpTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xec54e0
	void VaultCameraTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.VaultCameraTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xec54e0
	void VaultCameraTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.VaultCameraTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_NextItem_K2Node_InputActionEvent_17(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_NextItem_K2Node_InputActionEvent_17 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_PreviousItem_K2Node_InputActionEvent_16(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PreviousItem_K2Node_InputActionEvent_16 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_CameraToggle_K2Node_InputActionEvent_15(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CameraToggle_K2Node_InputActionEvent_15 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot0_K2Node_InputActionEvent_14(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot0_K2Node_InputActionEvent_14 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot1_K2Node_InputActionEvent_13(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot1_K2Node_InputActionEvent_13 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot2_K2Node_InputActionEvent_12(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot2_K2Node_InputActionEvent_12 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot3_K2Node_InputActionEvent_11(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot3_K2Node_InputActionEvent_11 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot4_K2Node_InputActionEvent_10(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot4_K2Node_InputActionEvent_10 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot5_K2Node_InputActionEvent_9(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot5_K2Node_InputActionEvent_9 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot6_K2Node_InputActionEvent_8(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot6_K2Node_InputActionEvent_8 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot7_K2Node_InputActionEvent_7(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot7_K2Node_InputActionEvent_7 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot8_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot8_K2Node_InputActionEvent_6 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_EqpSlot9_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot9_K2Node_InputActionEvent_5 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_RadialMenu_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_4 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_RadialMenu_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_3 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2 // (BlueprintEvent) // @ game+0xec54e0
	void InpActEvt_PointAimToggle_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PointAimToggle_K2Node_InputActionEvent_1 // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void EventResetHealthEffect(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EventResetHealthEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GenericDamageFeedback(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GenericDamageFeedback // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveTick(float DeltaSeconds); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnDeath(float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnDeath // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void OnEquipmentTimerElapsed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnEquipmentTimerElapsed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveCurrentLoadout(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveCurrentLoadout // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void RetryLoadout(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RetryLoadout // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceivePossessed(struct AController* NewController); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePossessed // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnPCFirePressed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnPCFirePressed // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnLanded(struct FHitResult& Hit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnLanded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveRestart(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveRestart // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveDestroyed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceivePawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamNumUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveFreeAim(float DeltaSeconds); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveFreeAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void NotifyPlayerStateChanged(struct APlayerState* NewPlayerState, struct APlayerState* OldPlayerState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.NotifyPlayerStateChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveBeginPlay(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void FirstPersonToggled(bool bFirstPerson); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FirstPersonToggled // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnPCFireReleased(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnPCFireReleased // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PlayerNameChanged(struct APlayerState* PS, struct FString NewPlayerName); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.PlayerNameChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveUnpossessed // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceivePawnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void K2_OnMovementModeChanged(enum class EMovementMode PrevMovementMode, enum class EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.K2_OnMovementModeChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Hit Damage(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.Hit Damage // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerRadialMenuSelectOutpost(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectOutpost // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerRadialMenuSelectRallypoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectRallypoint // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ServerRadialMenuSelectSpot(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectSpot // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVoipTalkerMsgReceived // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartAim(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnStartAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndAim(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnEndAim // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void EnterRadialMenu(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EnterRadialMenu // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExitRadialMenu(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ExitRadialMenu // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SubmenuCommited(struct FName Category, struct FName SubItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SubmenuCommited // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveEquippedItemChanged(struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEquippedItemChanged // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceivePlayHit(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser, bool bKilled); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePlayHit // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveVariationDataChanged(struct FDFCharacterVariationData& NewVariation, struct FDFCharacterVariationData& PreviousVariation); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVariationDataChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ReceiveHealthChanged(float NewHealthTotal, float PrevHealthTotal); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveHealthChanged // (Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnStartVault(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnStartVault // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ReceiveOnEndVault(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnEndVault // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void SuppressionEffect(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup, struct UPrimitiveComponent* SuppressionVolume); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDPlayerCharacterBase(int32_t EntryPoint); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ExecuteUbergraph_BP_HDPlayerCharacterBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnHitDamage__DelegateSignature(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnHitDamage__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnSuppression__DelegateSignature(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnSuppression__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

