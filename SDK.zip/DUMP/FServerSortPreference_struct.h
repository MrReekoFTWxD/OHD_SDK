// UserDefinedStruct FServerSortPreference.FServerSortPreference
// Size: 0x02 (Inherited: 0x00)
struct FFServerSortPreference {
	enum class EHDListSortOrder Order_9_083C1029475FF29C3E8E84A4A2979A0C; // 0x00(0x01)
	enum class EHDServerListSortBy SortBy_2_BDA3B8F147C4E4C4C53B148171996893; // 0x01(0x01)
};

