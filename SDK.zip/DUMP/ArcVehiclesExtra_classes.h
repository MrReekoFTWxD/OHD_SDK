// Class ArcVehiclesExtra.ArcVehicleSampleCharacter
// Size: 0x4c0 (Inherited: 0x4c0)
struct AArcVehicleSampleCharacter : ACharacter {
	bool bUseAttachedVehicleRelevancy; // 0x4b8(0x01)
};

// Class ArcVehiclesExtra.ArcVehicleSpawner
// Size: 0x258 (Inherited: 0x220)
struct AArcVehicleSpawner : AActor {
	struct UChildActorComponent* EditorVehicleMesh; // 0x220(0x08)
	struct AArcBaseVehicle* VehicleClass; // 0x228(0x08)
	bool bSpawnImmediately; // 0x230(0x01)
	char pad_231[0x3]; // 0x231(0x03)
	float RespawnDelay; // 0x234(0x04)
	int32_t MaxVehiclesAlive; // 0x238(0x04)
	char pad_23C[0x1c]; // 0x23c(0x1c)

	void SpawnVehicleTimerEnd(); // Function ArcVehiclesExtra.ArcVehicleSpawner.SpawnVehicleTimerEnd // (Native|Public) // @ game+0x6cf9f0
	void OnVehicleDestroyed(struct AActor* DestroyedActor); // Function ArcVehiclesExtra.ArcVehicleSpawner.OnVehicleDestroyed // (Native|Public) // @ game+0x807400
};

