// WidgetBlueprintGeneratedClass WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C
// Size: 0x260 (Inherited: 0x230)
struct UWBP_DlgBox_ServerPasswordPrompt_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UEditableTextBox* PromptTextBox; // 0x238(0x08)
	struct FMulticastInlineDelegate OnConfirmInput; // 0x240(0x10)
	struct FMulticastInlineDelegate OnCancelInput; // 0x250(0x10)

	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnPreviewKeyDown // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void DummyInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.DummyInput // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ConfirmInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.ConfirmInput // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CancelInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.CancelInput // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnRemovedFromFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt(int32_t EntryPoint); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.ExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnCancelInput__DelegateSignature(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnCancelInput__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnConfirmInput__DelegateSignature(struct FText InputText); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnConfirmInput__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

