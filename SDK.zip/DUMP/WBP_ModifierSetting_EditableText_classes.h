// WidgetBlueprintGeneratedClass WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C
// Size: 0x340 (Inherited: 0x230)
struct UWBP_ModifierSetting_EditableText_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UEditableText* ModifierEditableText; // 0x238(0x08)
	struct UWBP_ModifierSettingBox_C* ModifierSetting; // 0x240(0x08)
	struct FText SettingLabelText; // 0x248(0x18)
	struct FFModifierTextStyle SettingLabelTextStyle; // 0x260(0x78)
	struct FText DefaultText; // 0x2d8(0x18)
	struct FText DefaultHintText; // 0x2f0(0x18)
	struct TArray<struct FString> DefaultOptions; // 0x308(0x10)
	int32_t DefaultSelectedOptionIdx; // 0x318(0x04)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct FMulticastInlineDelegate OnTextChanged; // 0x320(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0x330(0x10)

	void GetSettingLabel(struct FText& SettingText); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.GetSettingLabel // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSettingLabel(struct FText InSettingText); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.SetSettingLabel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ModifierSetting_EditableText(int32_t EntryPoint); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.ExecuteUbergraph_WBP_ModifierSetting_EditableText // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnTextCommitted__DelegateSignature(struct FText Text, enum class ETextCommit CommitMethod); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextCommitted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnTextChanged__DelegateSignature(struct FText Text); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

