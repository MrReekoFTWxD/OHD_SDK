// BlueprintGeneratedClass BPI_RadialInput.BPI_RadialInput_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_RadialInput_C : UInterface {

	void GetJoystickDirection(enum class EJoystickTypes Stick, struct FVector2D& StickInput); // Function BPI_RadialInput.BPI_RadialInput_C.GetJoystickDirection // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

