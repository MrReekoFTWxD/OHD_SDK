// BlueprintGeneratedClass BPFL_DebugUtils.BPFL_DebugUtils_C
// Size: 0x28 (Inherited: 0x28)
struct UBPFL_DebugUtils_C : UBlueprintFunctionLibrary {

	void PrintFloat(struct FString Name, float InFloat, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintFloat // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PrintInt(struct FString Name, int32_t InInteger, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintInt // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PrintBool(struct FString Name, bool bInBool, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintBool // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PrintStr(struct FString Name, struct FString Value, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintStr // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PrintProperty(struct FString PropName, struct FString Value, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintProperty // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

