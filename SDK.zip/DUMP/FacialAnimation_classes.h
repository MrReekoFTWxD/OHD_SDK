// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x810 (Inherited: 0x7d0)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_7D0[0x8]; // 0x7d0(0x08)
	struct FName CurveSourceBindingName; // 0x7d8(0x08)
	float CurveSyncOffset; // 0x7e0(0x04)
	char pad_7E4[0x2c]; // 0x7e4(0x2c)
};

