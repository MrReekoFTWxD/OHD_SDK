// BlueprintGeneratedClass BP_HDPlayerCameraManagerBase.BP_HDPlayerCameraManagerBase_C
// Size: 0x2740 (Inherited: 0x2740)
struct ABP_HDPlayerCameraManagerBase_C : AHDPlayerCameraManager {
};

