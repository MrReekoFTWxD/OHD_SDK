// WidgetBlueprintGeneratedClass WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C
// Size: 0x368 (Inherited: 0x230)
struct UWBP_MainMenu_NavBarButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UButton* NavBarBtn; // 0x238(0x08)
	struct UTextBlock* NavBarText; // 0x240(0x08)
	bool bHasAssociatedOptionMenu; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
	struct UDFBaseMenu* OptionMenuClass; // 0x250(0x08)
	struct FText BtnText; // 0x258(0x18)
	struct FMulticastInlineDelegate ButtonClicked; // 0x270(0x10)
	bool bActive; // 0x280(0x01)
	char pad_281[0x3]; // 0x281(0x03)
	struct FMargin TextPadding; // 0x284(0x10)
	bool bDisabledInDemoBuilds; // 0x294(0x01)
	bool bHiddenInDemoBuilds; // 0x295(0x01)
	char pad_296[0x2]; // 0x296(0x02)
	struct FSlateColor TextColor; // 0x298(0x28)
	struct FSlateColor TextColorActive; // 0x2c0(0x28)
	bool bUseBtnTint; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct FSlateColor BtnTint; // 0x2f0(0x28)
	struct FSlateColor TextColorPressed; // 0x318(0x28)
	struct FSlateColor TextColorHovered; // 0x340(0x28)

	void UpdateAppearance(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.UpdateAppearance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetActive(bool bNewActive); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.SetActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OnInitialized(); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_MainMenu_NavBarButton(int32_t EntryPoint); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.ExecuteUbergraph_WBP_MainMenu_NavBarButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.ButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

