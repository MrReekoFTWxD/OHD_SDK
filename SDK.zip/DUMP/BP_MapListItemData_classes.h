// BlueprintGeneratedClass BP_MapListItemData.BP_MapListItemData_C
// Size: 0x70 (Inherited: 0x28)
struct UBP_MapListItemData_C : UObject {
	struct FFMapInfo MapInfo; // 0x28(0x48)
};

