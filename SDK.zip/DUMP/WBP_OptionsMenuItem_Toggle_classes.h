// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C
// Size: 0x2b8 (Inherited: 0x230)
struct UWBP_OptionsMenuItem_Toggle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UTextBlock* OptionText; // 0x238(0x08)
	struct UWBP_Toggle_C* OptionToggle; // 0x240(0x08)
	struct FText Text; // 0x248(0x18)
	struct FText TextTooltip; // 0x260(0x18)
	struct FMulticastInlineDelegate ToggleStateChanged; // 0x278(0x10)
	struct FText OnText; // 0x288(0x18)
	struct FText OffText; // 0x2a0(0x18)

	void IsToggledOn(bool& bToggledOn); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.IsToggledOn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetToggle(bool bInToggle); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.SetToggle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__OptionToggle_K2Node_ComponentBoundEvent_2_ToggleStateChanged__DelegateSignature(bool bToggledOn); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.BndEvt__OptionToggle_K2Node_ComponentBoundEvent_2_ToggleStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_OptionsMenuItem_Toggle(int32_t EntryPoint); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.ExecuteUbergraph_WBP_OptionsMenuItem_Toggle // (Final|UbergraphFunction) // @ game+0xec54e0
	void ToggleStateChanged__DelegateSignature(bool bToggledOn); // Function WBP_OptionsMenuItem_Toggle.WBP_OptionsMenuItem_Toggle_C.ToggleStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

