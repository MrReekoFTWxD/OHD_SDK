// WidgetBlueprintGeneratedClass WBP_PlayerStatus.WBP_PlayerStatus_C
// Size: 0x2b0 (Inherited: 0x258)
struct UWBP_PlayerStatus_C : UHDUIUWPlayerStatus {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x258(0x08)
	struct UWidgetAnimation* EffectChangeUIAnim; // 0x260(0x08)
	struct UWidgetAnimation* StanceChangeUIAnim; // 0x268(0x08)
	struct UWidgetAnimation* AllStaminaFullUIAnim; // 0x270(0x08)
	struct UWidgetAnimation* SprintInputUIAnim; // 0x278(0x08)
	struct UImage* AmmoResupplyFXIcon; // 0x280(0x08)
	struct UHorizontalBox* EffectStack; // 0x288(0x08)
	struct UWBP_MobilityStatusBar_C* JumpStaminaBar; // 0x290(0x08)
	struct UHorizontalBox* MedicHealFXIcon; // 0x298(0x08)
	struct UWBP_MobilityStatusBar_C* SprintStaminaBar; // 0x2a0(0x08)
	struct UWBP_StanceIndicator_C* StanceIndicator; // 0x2a8(0x08)

	void SetPlayerEffectVisibility(struct UWidget* EffectWidget, bool bVisible); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.SetPlayerEffectVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetMedicHealingEffectVisibility(bool bVisible); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.SetMedicHealingEffectVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetAmmoResupplyEffectVisibility(bool bVisible); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.SetAmmoResupplyEffectVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetHealth(float NewValueNorm, float OldValueNorm, bool bInitial); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerSetHealth // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetSprintStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerSetSprintStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetJumpStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerSetJumpStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerStartSprint(); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerStartSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerEndSprint(); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerEndSprint // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerUpdateStamina(float SprintValueNorm, float JumpValueNorm, bool bInitial); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerUpdateStamina // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void OwnerSetStanceState(enum class EHDUICharacterStanceState NewState, enum class EHDUICharacterStanceState OldState, bool bInitial); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerSetStanceState // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void OwnerActivatePlayerEffect(struct UWidget* EffectIndicatorWidget); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerActivatePlayerEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OwnerDeactivatePlayerEffect(struct UWidget* EffectIndicatorWidget); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.OwnerDeactivatePlayerEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BPOwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.BPOwnerDeath // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_PlayerStatus(int32_t EntryPoint); // Function WBP_PlayerStatus.WBP_PlayerStatus_C.ExecuteUbergraph_WBP_PlayerStatus // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

