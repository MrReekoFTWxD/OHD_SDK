// BlueprintGeneratedClass BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C
// Size: 0x430 (Inherited: 0x390)
struct ABP_HDProj_SPDeployableBase_C : AHDProj_SpawnPointDeployable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct USphereComponent* HitDetectionSphere; // 0x398(0x08)
	struct USphereComponent* SpawnSphere; // 0x3a0(0x08)
	struct UStaticMeshComponent* ProjectileCollision; // 0x3a8(0x08)
	struct UDFPOIComponent* POI; // 0x3b0(0x08)
	bool bOnlySquadMembersCanSpawn; // 0x3b8(0x01)
	char pad_3B9[0x3]; // 0x3b9(0x03)
	float PostTriggerLifeSpan; // 0x3bc(0x04)
	float PlacementRestrictionDistance; // 0x3c0(0x04)
	bool bSpawnable; // 0x3c4(0x01)
	char pad_3C5[0x3]; // 0x3c5(0x03)
	struct FMulticastInlineDelegate OnSpawnPointActivationChanged; // 0x3c8(0x10)
	struct TArray<struct FVector> SpawnPointLocOffsets; // 0x3d8(0x10)
	struct TArray<struct FSpawnPointDef> GeneratedSpawnPoints; // 0x3e8(0x10)
	bool bIgnoreFriendlyFire; // 0x3f8(0x01)
	char pad_3F9[0x3]; // 0x3f9(0x03)
	float Health; // 0x3fc(0x04)
	bool bDisableWhenOverrun; // 0x400(0x01)
	char pad_401[0x3]; // 0x401(0x03)
	int32_t NumberOfEnemiesToDisable; // 0x404(0x04)
	bool bDestroyWhenOverrun; // 0x408(0x01)
	char pad_409[0x3]; // 0x409(0x03)
	int32_t NumberOfEnemiesToDestroy; // 0x40c(0x04)
	int32_t CurrentNumberOfEnemies; // 0x410(0x04)
	char pad_414[0x4]; // 0x414(0x04)
	struct AHDSquadState* OwnerSquadState; // 0x418(0x08)
	bool bDestroyWhenSquadDisbands; // 0x420(0x01)
	bool bOnlyOnePerSquad; // 0x421(0x01)
	char pad_422[0x2]; // 0x422(0x02)
	int32_t MaxNumberOfInstances; // 0x424(0x04)
	float EnemyTolerance_Radius; // 0x428(0x04)
	int32_t EnemyTolerance_MaxNumberOfChars; // 0x42c(0x04)

	bool GetSpawnPointCollisionHandlingOverrideBP(struct FSpawnPointDef& SpawnPoint, enum class ESpawnActorCollisionHandlingMethod& OutSpawnCollisionMethod); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPointCollisionHandlingOverrideBP // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	bool CanRestartPlayerFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AController* Player, struct APawn* PlayerPawnClass); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanRestartPlayerFromSpawnPointBP // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	bool CanSpawnActorFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AActor* SpawnActorClass); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanSpawnActorFromSpawnPointBP // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	bool FindSpawnPointBP(int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.FindSpawnPointBP // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	int32_t GetAllSpawnPointsBP(struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetAllSpawnPointsBP // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xec54e0
	void CanPlayerSpawnHere(struct AController* InPlayer, bool& bPlayerCanSpawn); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanPlayerSpawnHere // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void InitDeployable(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.InitDeployable // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void CheckEnemyOverrun(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckEnemyOverrun // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HandleTakeDamageFromProjectile(struct ADFBaseProjectile* InProjectile, float InDamage); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HandleTakeDamageFromProjectile // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GenerateSpawnPointList(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GenerateSpawnPointList // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetTransformOffsetBySpawnIndex(int32_t& SpawnIdx, struct FTransform Transform, struct FTransform& NewTransform); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetTransformOffsetBySpawnIndex // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void GetActorTransformOffsetByMeshZBounds(struct FTransform& OffsetActorWorldXForm); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetActorTransformOffsetByMeshZBounds // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void CheckForEnemyChars(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckForEnemyChars // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetIsSpawnable(bool bNewEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.SetIsSpawnable // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void IsSpawnable(bool& bSpawnPointEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsSpawnable // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void AreSpawnPointsEqual(struct FSpawnPointDef& SpawnPointOne, struct FSpawnPointDef& SpawnPointTwo, bool& bEqual); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.AreSpawnPointsEqual // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void GetSpawnPoint(bool bMeshZOffset, int32_t SpawnPointIdx, struct FSpawnPointDef& SpawnPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPoint // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xec54e0
	void IsEnemyChar(struct ADFBaseCharacter* Char, bool& bEnemyChar); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsEnemyChar // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void HasServerAuthority(bool& bAuthority); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HasServerAuthority // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceivePayloadActivated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void OverlappingPawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OverlappingPawnTeamNumUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void MemberPreUnregisteredFromOwnerSquad(struct AHDSquadState* Squad, struct AHDPlayerState* MemberPS); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.MemberPreUnregisteredFromOwnerSquad // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDProj_SPDeployableBase(int32_t EntryPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ExecuteUbergraph_BP_HDProj_SPDeployableBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnSpawnPointActivationChanged__DelegateSignature(struct ABP_HDProj_SPDeployableBase_C* Deployable, bool bSpawnPointEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OnSpawnPointActivationChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

