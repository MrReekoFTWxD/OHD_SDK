// BlueprintGeneratedClass BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C
// Size: 0x2b0 (Inherited: 0x280)
struct UBP_HDCharacterLeanHandler_C : UDFCharacterLeanHandler {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x280(0x08)
	struct UCameraComponent* CachedFPPCamera; // 0x288(0x08)
	struct USkeletalMeshComponent* CachedFPPMesh; // 0x290(0x08)
	float LastLeanRollAmt; // 0x298(0x04)
	float LastXOffset; // 0x29c(0x04)
	float LastYOffset; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct USpringArmComponent* CachedFPPSpringArm; // 0x2a8(0x08)

	void TickRot(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickRot // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TickYOffset(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickYOffset // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void TickXOffset(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickXOffset // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetFPPSpringArmComp(struct USpringArmComponent*& FPPSpringArm); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPSpringArmComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetFPPCameraComp(struct UCameraComponent*& FPPCamera); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPCameraComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void GetFPPMeshComp(struct USkeletalMeshComponent*& FPPMesh); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPMeshComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void ReceiveTick(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ReceiveTick // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_BP_HDCharacterLeanHandler(int32_t EntryPoint); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ExecuteUbergraph_BP_HDCharacterLeanHandler // (Final|UbergraphFunction) // @ game+0xec54e0
};

