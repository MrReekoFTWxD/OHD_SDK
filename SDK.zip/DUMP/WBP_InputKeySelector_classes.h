// WidgetBlueprintGeneratedClass WBP_InputKeySelector.WBP_InputKeySelector_C
// Size: 0x260 (Inherited: 0x230)
struct UWBP_InputKeySelector_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UInputKeySelector* IKS; // 0x238(0x08)
	struct FMulticastInlineDelegate OnKeySelected; // 0x240(0x10)
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged; // 0x250(0x10)

	void SetSelectedKey(struct FKey SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.SetSelectedKey // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSelectedKey(struct FKey& SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.GetSelectedKey // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void BndEvt__IKS_K2Node_ComponentBoundEvent_2_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.BndEvt__IKS_K2Node_ComponentBoundEvent_2_OnIsSelectingKeyChanged__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void BndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.BndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature // (BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_InputKeySelector(int32_t EntryPoint); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.ExecuteUbergraph_WBP_InputKeySelector // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
	void OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.OnIsSelectingKeyChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.OnKeySelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

