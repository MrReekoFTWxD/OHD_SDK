// WidgetBlueprintGeneratedClass WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C
// Size: 0x718 (Inherited: 0x230)
struct UWBP_CaptureStatus_FlagIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* Bg; // 0x238(0x08)
	struct UImage* Icon; // 0x240(0x08)
	struct UImage* IconFrame; // 0x248(0x08)
	struct FSlateBrush IconFrameNoTeam; // 0x250(0x88)
	struct FSlateBrush BgNoTeam; // 0x2d8(0x88)
	struct FSlateBrush IconLocked; // 0x360(0x88)
	struct FSlateBrush IconFlag; // 0x3e8(0x88)
	struct FSlateBrush IconFrameEnemy; // 0x470(0x88)
	float IconOpacityCapturable; // 0x4f8(0x04)
	float IconOpacityUncapturable; // 0x4fc(0x04)
	float IconOpacityOffensive; // 0x500(0x04)
	char pad_504[0x4]; // 0x504(0x04)
	struct FSlateBrush IconFrameFriendly; // 0x508(0x88)
	struct FSlateBrush BgEnemy; // 0x590(0x88)
	struct FSlateBrush BgFriendly; // 0x618(0x88)
	struct FSlateColor ColorFriendly; // 0x6a0(0x28)
	struct FSlateColor ColorEnemy; // 0x6c8(0x28)
	struct FSlateColor ColorNoTeam; // 0x6f0(0x28)

	void SetBrushOpacityByCaptureStatus(struct FSlateBrush& BrushToUpdate, bool bLocked, enum class EHDControlPointObjectiveType ObjType, struct FSlateBrush& NewBrush); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushOpacityByCaptureStatus // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void TintBrushByTeam(struct FSlateBrush& BrushToTint, enum class EHDTeam Team, struct FSlateBrush& NewBrush); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.TintBrushByTeam // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void UpdateBrushesByTeam(bool bLocked, enum class EHDTeam Team, enum class EHDControlPointObjectiveType ObjType); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.UpdateBrushesByTeam // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetBrushes(struct FSlateBrush& IconFrame, struct FSlateBrush& Bg, struct FSlateBrush& Icon); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushes // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void OnUpdateIcon(bool bActive, enum class EHDTeam Team, bool bLocked, enum class EHDControlPointObjectiveType ObjType); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.OnUpdateIcon // (BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CaptureStatus_FlagIcon(int32_t EntryPoint); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.ExecuteUbergraph_WBP_CaptureStatus_FlagIcon // (Final|UbergraphFunction) // @ game+0xec54e0
};

