// Class Tinkerbox.TBGameInstance
// Size: 0x2a0 (Inherited: 0x250)
struct UTBGameInstance : UDFBaseGameInstance {
	struct UDFBaseMenu* MainMenu; // 0x250(0x08)
	struct UDFBaseMenu* MainMenuClass; // 0x258(0x08)
	struct FSoftClassPath MenuGameMode; // 0x260(0x18)
	char bHidePlayerHUDInMainMenu : 1; // 0x278(0x01)
	char bUseMenuBackgroundMaps : 1; // 0x278(0x01)
	char pad_278_2 : 6; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct TArray<struct FSoftObjectPath> MenuBackgroundMaps; // 0x280(0x10)
	char pad_290[0x8]; // 0x290(0x08)
	struct URCONServerSystem* RCONServerSystem; // 0x298(0x08)

	void UnloadMainMenu(); // Function Tinkerbox.TBGameInstance.UnloadMainMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x7d7b10
	void LoadMainMenu(bool bExclusive); // Function Tinkerbox.TBGameInstance.LoadMainMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x7d3d20
	void HandleGoToMainMenu(); // Function Tinkerbox.TBGameInstance.HandleGoToMainMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x7d38a0
	void GoToMainMenu(); // Function Tinkerbox.TBGameInstance.GoToMainMenu // (Native|Public|BlueprintCallable) // @ game+0x7d3880
	void GetGameBuildInfo(); // Function Tinkerbox.TBGameInstance.GetGameBuildInfo // (Final|Exec|Native|Private) // @ game+0x7d23b0
	bool GetCurrentSessionHostAddressStr(struct FString& OutHostAddrStr, bool bPreferSteamP2PAddr, bool bAppendPort); // Function Tinkerbox.TBGameInstance.GetCurrentSessionHostAddressStr // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2030
};

// Class Tinkerbox.TBWorldSettings
// Size: 0x518 (Inherited: 0x4c8)
struct ATBWorldSettings : ADFWorldSettings {
	struct FMinimapGenerationSettings MinimapSettings; // 0x4c8(0x28)
	struct TSoftObjectPtr<UTexture2D> MinimapImg; // 0x4f0(0x28)
};

// Class Tinkerbox.TBGameUserDeveloperSettings
// Size: 0x98 (Inherited: 0x38)
struct UTBGameUserDeveloperSettings : UDeveloperSettings {
	struct FSoftObjectPath SFXSoundMix; // 0x38(0x18)
	struct FSoftObjectPath MusicSoundMix; // 0x50(0x18)
	struct FSoftObjectPath VOSoundMix; // 0x68(0x18)
	struct FSoftObjectPath VoiPSoundMix; // 0x80(0x18)
};

// Class Tinkerbox.TBGameUserSettings
// Size: 0xa40 (Inherited: 0x120)
struct UTBGameUserSettings : UGameUserSettings {
	uint32_t CustomVersion; // 0x120(0x04)
	bool bUseSmoothFrameRate; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	float DesiredDisplayGamma; // 0x128(0x04)
	float DesiredFOV; // 0x12c(0x04)
	bool bUseMotionBlur; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float DesiredMouseSensitivityX; // 0x134(0x04)
	float DesiredMouseSensitivityY; // 0x138(0x04)
	bool bInvertMousePitch; // 0x13c(0x01)
	bool bUseMouseSmoothing; // 0x13d(0x01)
	bool DesiredSwitchFireModeOnReselect; // 0x13e(0x01)
	bool LastConfirmedSwitchFireModeOnReselect; // 0x13f(0x01)
	bool bUseHeadphoneMode; // 0x140(0x01)
	bool bAllowSoundInBackground; // 0x141(0x01)
	char pad_142[0x2]; // 0x142(0x02)
	float DesiredMasterVolumeLevel; // 0x144(0x04)
	float LastConfirmedMasterVolumeLevel; // 0x148(0x04)
	float DesiredSFXVolumeLevel; // 0x14c(0x04)
	float LastConfirmedSFXVolumeLevel; // 0x150(0x04)
	float DesiredMusicVolumeLevel; // 0x154(0x04)
	float LastConfirmedMusicVolumeLevel; // 0x158(0x04)
	float DesiredVOVolumeLevel; // 0x15c(0x04)
	float LastConfirmedVOVolumeLevel; // 0x160(0x04)
	float DesiredVoiPVolumeLevel; // 0x164(0x04)
	float LastConfirmedVoiPVolumeLevel; // 0x168(0x04)
	bool bPlayerIsChangingKeyBindings; // 0x16c(0x01)
	char pad_16D[0x3]; // 0x16d(0x03)
	struct FKey DesiredMoveForwardKey; // 0x170(0x18)
	struct FKey LastConfirmedMoveForwardKey; // 0x188(0x18)
	struct FKey DesiredMoveBackwardKey; // 0x1a0(0x18)
	struct FKey LastConfirmedMoveBackwardKey; // 0x1b8(0x18)
	struct FKey DesiredMoveLeftKey; // 0x1d0(0x18)
	struct FKey LastConfirmedMoveLeftKey; // 0x1e8(0x18)
	struct FKey DesiredMoveRightKey; // 0x200(0x18)
	struct FKey LastConfirmedMoveRightKey; // 0x218(0x18)
	struct FKey DesiredLeanLeftKey; // 0x230(0x18)
	struct FKey LastConfirmedLeanLeftKey; // 0x248(0x18)
	struct FKey DesiredLeanLeftToggleKey; // 0x260(0x18)
	struct FKey LastConfirmedLeanLeftToggleKey; // 0x278(0x18)
	struct FKey DesiredLeanRightKey; // 0x290(0x18)
	struct FKey LastConfirmedLeanRightKey; // 0x2a8(0x18)
	struct FKey DesiredLeanRightToggleKey; // 0x2c0(0x18)
	struct FKey LastConfirmedLeanRightToggleKey; // 0x2d8(0x18)
	struct FKey DesiredSprintKey; // 0x2f0(0x18)
	struct FKey LastConfirmedSprintKey; // 0x308(0x18)
	struct FKey DesiredSprintToggleKey; // 0x320(0x18)
	struct FKey LastConfirmedSprintToggleKey; // 0x338(0x18)
	struct FKey DesiredCrouchKey; // 0x350(0x18)
	struct FKey LastConfirmedCrouchKey; // 0x368(0x18)
	struct FKey DesiredCrouchToggleKey; // 0x380(0x18)
	struct FKey LastConfirmedCrouchToggleKey; // 0x398(0x18)
	struct FKey DesiredProneKey; // 0x3b0(0x18)
	struct FKey LastConfirmedProneKey; // 0x3c8(0x18)
	struct FKey DesiredJumpVaultKey; // 0x3e0(0x18)
	struct FKey LastConfirmedJumpVaultKey; // 0x3f8(0x18)
	struct FKey DesiredJumpKey; // 0x410(0x18)
	struct FKey LastConfirmedJumpKey; // 0x428(0x18)
	struct FKey DesiredVaultKey; // 0x440(0x18)
	struct FKey LastConfirmedVaultKey; // 0x458(0x18)
	struct FKey DesiredFireKey; // 0x470(0x18)
	struct FKey LastConfirmedFireKey; // 0x488(0x18)
	struct FKey DesiredSwitchFireModeKey; // 0x4a0(0x18)
	struct FKey LastConfirmedSwitchFireModeKey; // 0x4b8(0x18)
	struct FKey DesiredReloadKey; // 0x4d0(0x18)
	struct FKey LastConfirmedReloadKey; // 0x4e8(0x18)
	struct FKey DesiredAimKey; // 0x500(0x18)
	struct FKey LastConfirmedAimKey; // 0x518(0x18)
	struct FKey DesiredAimToggleKey; // 0x530(0x18)
	struct FKey LastConfirmedAimToggleKey; // 0x548(0x18)
	struct FKey DesiredPointAimToggleKey; // 0x560(0x18)
	struct FKey LastConfirmedPointAimToggleKey; // 0x578(0x18)
	struct FKey DesiredCycleWeaponSightsKey; // 0x590(0x18)
	struct FKey LastConfirmedCycleWeaponSightsKey; // 0x5a8(0x18)
	struct FKey DesiredNextItemKey; // 0x5c0(0x18)
	struct FKey LastConfirmedNextItemKey; // 0x5d8(0x18)
	struct FKey DesiredPreviousItemKey; // 0x5f0(0x18)
	struct FKey LastConfirmedPreviousItemKey; // 0x608(0x18)
	struct FKey DesiredItemSlot0Key; // 0x620(0x18)
	struct FKey LastConfirmedItemSlot0Key; // 0x638(0x18)
	struct FKey DesiredItemSlot1Key; // 0x650(0x18)
	struct FKey LastConfirmedItemSlot1Key; // 0x668(0x18)
	struct FKey DesiredItemSlot2Key; // 0x680(0x18)
	struct FKey LastConfirmedItemSlot2Key; // 0x698(0x18)
	struct FKey DesiredItemSlot3Key; // 0x6b0(0x18)
	struct FKey LastConfirmedItemSlot3Key; // 0x6c8(0x18)
	struct FKey DesiredItemSlot4Key; // 0x6e0(0x18)
	struct FKey LastConfirmedItemSlot4Key; // 0x6f8(0x18)
	struct FKey DesiredItemSlot5Key; // 0x710(0x18)
	struct FKey LastConfirmedItemSlot5Key; // 0x728(0x18)
	struct FKey DesiredItemSlot6Key; // 0x740(0x18)
	struct FKey LastConfirmedItemSlot6Key; // 0x758(0x18)
	struct FKey DesiredItemSlot7Key; // 0x770(0x18)
	struct FKey LastConfirmedItemSlot7Key; // 0x788(0x18)
	struct FKey DesiredItemSlot8Key; // 0x7a0(0x18)
	struct FKey LastConfirmedItemSlot8Key; // 0x7b8(0x18)
	struct FKey DesiredItemSlot9Key; // 0x7d0(0x18)
	struct FKey LastConfirmedItemSlot9Key; // 0x7e8(0x18)
	struct FKey DesiredPushToTalkLocalKey; // 0x800(0x18)
	struct FKey LastConfirmedPushToTalkLocalKey; // 0x818(0x18)
	struct FKey DesiredPushToTalkSquadKey; // 0x830(0x18)
	struct FKey LastConfirmedPushToTalkSquadKey; // 0x848(0x18)
	struct FKey DesiredPushToTalkCommandKey; // 0x860(0x18)
	struct FKey LastConfirmedPushToTalkCommandKey; // 0x878(0x18)
	struct FKey DesiredSayAllKey; // 0x890(0x18)
	struct FKey LastConfirmedSayAllKey; // 0x8a8(0x18)
	struct FKey DesiredSayTeamKey; // 0x8c0(0x18)
	struct FKey LastConfirmedSayTeamKey; // 0x8d8(0x18)
	struct FKey DesiredSaySquadKey; // 0x8f0(0x18)
	struct FKey LastConfirmedSaySquadKey; // 0x908(0x18)
	struct FKey DesiredUseKey; // 0x920(0x18)
	struct FKey LastConfirmedUseKey; // 0x938(0x18)
	struct FKey DesiredShowScoreboardKey; // 0x950(0x18)
	struct FKey LastConfirmedShowScoreboardKey; // 0x968(0x18)
	struct FKey DesiredDeployMenuKey; // 0x980(0x18)
	struct FKey LastConfirmedDeployMenuKey; // 0x998(0x18)
	struct FKey DesiredRadialMenuKey; // 0x9b0(0x18)
	struct FKey LastConfirmedRadialMenuKey; // 0x9c8(0x18)
	struct FKey DesiredCameraToggleKey; // 0x9e0(0x18)
	struct FKey LastConfirmedCameraToggleKey; // 0x9f8(0x18)
	struct FKey DesiredConsoleKey; // 0xa10(0x18)
	struct FKey LastConfirmedConsoleKey; // 0xa28(0x18)

	void SetWeaponSlot9KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot9KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d7a00
	void SetWeaponSlot8KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot8KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d78f0
	void SetWeaponSlot7KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot7KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d77e0
	void SetWeaponSlot6KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot6KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d76d0
	void SetWeaponSlot5KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot5KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d75c0
	void SetWeaponSlot4KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot4KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d74b0
	void SetWeaponSlot3KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot3KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d73a0
	void SetWeaponSlot2KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot2KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d7290
	void SetWeaponSlot1KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot1KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d7180
	void SetWeaponSlot0KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot0KeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d7070
	void SetVoiceVolumeLevelNormalized(float NormVoiceVolume); // Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6ff0
	void SetVoiceVolumeLevel(float VoiceVolume); // Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6f70
	void SetVaultKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetVaultKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6e60
	void SetUseKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetUseKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6d50
	void SetSwitchFireModeOnReselect(bool bEnable); // Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeOnReselect // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6cc0
	void SetSwitchFireModeKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6bb0
	void SetSprintToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSprintToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6aa0
	void SetSprintKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSprintKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6990
	void SetSoundEffectsVolumeLevelNormalized(float NormSFXVolume); // Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6910
	void SetSoundEffectsVolumeLevel(float SFXVolume); // Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6890
	void SetSmoothMouseEnabled(bool bEnable); // Function Tinkerbox.TBGameUserSettings.SetSmoothMouseEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6800
	void SetSmoothFrameRateEnabled(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.SetSmoothFrameRateEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6770
	void SetShowScoreboardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetShowScoreboardKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6660
	void SetSayTeamKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSayTeamKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6550
	void SetSaySquadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSaySquadKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6440
	void SetSayAllKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSayAllKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6330
	void SetReloadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetReloadKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6220
	void SetRadialMenuKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetRadialMenuKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6110
	void SetPushToTalkSquadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkSquadKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d6000
	void SetPushToTalkLocalKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkLocalKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5ef0
	void SetPushToTalkCommandKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkCommandKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5de0
	void SetProneKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetProneKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5cd0
	void SetPreviousItemKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPreviousItemKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5bc0
	void SetPointAimToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPointAimToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5ab0
	void SetPlayerIsChangingKeyBindings(bool NewValue); // Function Tinkerbox.TBGameUserSettings.SetPlayerIsChangingKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5a20
	void SetNextItemKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetNextItemKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5910
	void SetMusicVolumeLevelNormalized(float NormMusicVolume); // Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5890
	void SetMusicVolumeLevel(float MusicVolume); // Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5810
	void SetMoveRightKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveRightKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5700
	void SetMoveLeftKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveLeftKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d55f0
	void SetMoveForwardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveForwardKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d54e0
	void SetMoveBackwardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveBackwardKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d53d0
	void SetMouseSensitivityNormalized(float NormSensitivityX, float NormSensitivityY); // Function Tinkerbox.TBGameUserSettings.SetMouseSensitivityNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5310
	void SetMouseSensitivity(float SensitivityX, float SensitivityY); // Function Tinkerbox.TBGameUserSettings.SetMouseSensitivity // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5250
	void SetMotionBlurEnabled(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.SetMotionBlurEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x7d51c0
	void SetMasterVolumeLevelNormalized(float NormMasterVolume); // Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d5140
	void SetMasterVolumeLevel(float MasterVolume); // Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x7d50c0
	void SetLeanRightToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanRightToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4fb0
	void SetLeanRightKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanRightKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4ea0
	void SetLeanLeftToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanLeftToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4d90
	void SetLeanLeftKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanLeftKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4c80
	void SetJumpVaultKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetJumpVaultKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4b70
	void SetJumpKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetJumpKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4a60
	void SetInvertMousePitch(bool bInvertPitch); // Function Tinkerbox.TBGameUserSettings.SetInvertMousePitch // (Final|Native|Public|BlueprintCallable) // @ game+0x7d49d0
	void SetFireKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetFireKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d48c0
	void SetFieldOfView(float NewFOV); // Function Tinkerbox.TBGameUserSettings.SetFieldOfView // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4840
	void SetDisplayGamma(float NewGamma); // Function Tinkerbox.TBGameUserSettings.SetDisplayGamma // (Final|Native|Public|BlueprintCallable) // @ game+0x7d47c0
	void SetDialogueVolumeLevelNormalized(float NormDialogueVolume); // Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4740
	void SetDialogueVolumeLevel(float DialogueVolume); // Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x7d46c0
	void SetDeployMenuKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetDeployMenuKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d45b0
	void SetCycleWeaponSightsKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCycleWeaponSightsKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d44a0
	void SetCrouchToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCrouchToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4390
	void SetCrouchKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCrouchKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4280
	void SetConsoleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetConsoleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4170
	void SetCameraToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCameraToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d4060
	void SetAllowSoundInBackground(bool bAllow); // Function Tinkerbox.TBGameUserSettings.SetAllowSoundInBackground // (Final|Native|Public|BlueprintCallable) // @ game+0x7d3fd0
	void SetAimDownSightsToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetAimDownSightsToggleKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d3ec0
	void SetAimDownSightsKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetAimDownSightsKeyBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x7d3db0
	bool IsVoiceVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsVoiceVolumeLevelDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3cf0
	bool IsSwitchFireModeOnReselectDirty(); // Function Tinkerbox.TBGameUserSettings.IsSwitchFireModeOnReselectDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3cc0
	bool IsSoundInBackgroundAllowed(); // Function Tinkerbox.TBGameUserSettings.IsSoundInBackgroundAllowed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3ca0
	bool IsSoundEffectsVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsSoundEffectsVolumeLevelDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3c70
	bool IsSmoothMouseEnabled(); // Function Tinkerbox.TBGameUserSettings.IsSmoothMouseEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3c40
	bool IsSmoothMouseDirty(); // Function Tinkerbox.TBGameUserSettings.IsSmoothMouseDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3c10
	bool IsSmoothFrameRateEnabled(); // Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3be0
	bool IsSmoothFrameRateDirty(); // Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3bb0
	bool IsPlayerChangingKeyBindings(); // Function Tinkerbox.TBGameUserSettings.IsPlayerChangingKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x7d3b80
	bool IsMusicVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsMusicVolumeLevelDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3b50
	bool IsMouseSensitivityDirty(); // Function Tinkerbox.TBGameUserSettings.IsMouseSensitivityDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3b20
	bool IsMotionBlurEnabled(); // Function Tinkerbox.TBGameUserSettings.IsMotionBlurEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3af0
	bool IsMotionBlurDirty(); // Function Tinkerbox.TBGameUserSettings.IsMotionBlurDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3ac0
	bool IsMasterVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsMasterVolumeLevelDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3a90
	bool IsInvertMouseDirty(); // Function Tinkerbox.TBGameUserSettings.IsInvertMouseDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3a60
	bool IsHeadphoneModeEnabled(); // Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3a40
	bool IsHeadphoneModeDirty(); // Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3a10
	bool IsFrameRateLimitDirty(); // Function Tinkerbox.TBGameUserSettings.IsFrameRateLimitDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d39e0
	bool IsFieldOfViewDirty(); // Function Tinkerbox.TBGameUserSettings.IsFieldOfViewDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d39b0
	bool IsDisplayGammaDirty(); // Function Tinkerbox.TBGameUserSettings.IsDisplayGammaDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3980
	bool IsDialogueVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsDialogueVolumeLevelDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3950
	bool IsAudioQualityDirty(); // Function Tinkerbox.TBGameUserSettings.IsAudioQualityDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3920
	bool IsAnyInputKeyBindingDirty(); // Function Tinkerbox.TBGameUserSettings.IsAnyInputKeyBindingDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d38f0
	bool IsAllowSoundInBackgroundDirty(); // Function Tinkerbox.TBGameUserSettings.IsAllowSoundInBackgroundDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d38c0
	struct FKey GetWeaponSlot9KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot9KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3810
	struct FKey GetWeaponSlot8KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot8KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d37a0
	struct FKey GetWeaponSlot7KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot7KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3730
	struct FKey GetWeaponSlot6KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot6KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d36c0
	struct FKey GetWeaponSlot5KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot5KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3650
	struct FKey GetWeaponSlot4KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot4KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d35e0
	struct FKey GetWeaponSlot3KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot3KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3570
	struct FKey GetWeaponSlot2KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot2KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3500
	struct FKey GetWeaponSlot1KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot1KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3490
	struct FKey GetWeaponSlot0KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot0KeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3420
	float GetVoiceVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d33f0
	float GetVoiceVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d33c0
	struct FKey GetVaultKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetVaultKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3350
	struct FKey GetUseKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetUseKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d32e0
	bool GetSwitchFireModeOnReselect(bool bLastConfirmed); // Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeOnReselect // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3250
	struct FKey GetSwitchFireModeKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d31e0
	struct FKey GetSprintToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSprintToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3170
	struct FKey GetSprintKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSprintKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3100
	float GetSoundEffectsVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d30d0
	float GetSoundEffectsVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d30a0
	struct FKey GetShowScoreboardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetShowScoreboardKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d3030
	struct FKey GetSayTeamKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSayTeamKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2fc0
	struct FKey GetSaySquadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSaySquadKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2f50
	struct FKey GetSayAllKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSayAllKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2ee0
	struct FKey GetReloadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetReloadKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2e70
	struct FKey GetRadialMenuKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetRadialMenuKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2e00
	struct FKey GetPushToTalkSquadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkSquadKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2d90
	struct FKey GetPushToTalkLocalKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkLocalKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2d20
	struct FKey GetPushToTalkCommandKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkCommandKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2cb0
	struct FKey GetProneKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetProneKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2c40
	struct FKey GetPreviousItemKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPreviousItemKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2bd0
	struct FKey GetPointAimToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPointAimToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2b60
	struct FKey GetNextItemKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetNextItemKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2af0
	float GetMusicVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2ac0
	float GetMusicVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2a90
	struct FKey GetMoveRightKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveRightKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2a20
	struct FKey GetMoveLeftKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveLeftKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d29b0
	struct FKey GetMoveForwardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveForwardKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2940
	struct FKey GetMoveBackwardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveBackwardKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d28d0
	float GetMouseSensitivityYNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityYNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d28a0
	float GetMouseSensitivityY(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityY // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2870
	float GetMouseSensitivityXNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityXNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2840
	float GetMouseSensitivityX(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityX // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2810
	float GetMasterVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d27e0
	float GetMasterVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d27b0
	struct APlayerController* GetLocalPlayerControllerBP(); // Function Tinkerbox.TBGameUserSettings.GetLocalPlayerControllerBP // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2700
	struct FKey GetLeanRightKeyToggleBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyToggleBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2690
	struct FKey GetLeanRightKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2620
	struct FKey GetLeanLeftToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanLeftToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d25b0
	struct FKey GetLeanLeftKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanLeftKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2540
	float GetLastConfirmedMasterVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2510
	float GetLastConfirmedMasterVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d24e0
	struct FKey GetJumpVaultKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetJumpVaultKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2470
	struct FKey GetJumpKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetJumpKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2400
	bool GetInvertMousePitch(); // Function Tinkerbox.TBGameUserSettings.GetInvertMousePitch // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d23d0
	float GetFrameRateLimitCurrent(); // Function Tinkerbox.TBGameUserSettings.GetFrameRateLimitCurrent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2380
	struct FKey GetFireKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetFireKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2310
	float GetFieldOfView(); // Function Tinkerbox.TBGameUserSettings.GetFieldOfView // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d22e0
	float GetDisplayGamma(); // Function Tinkerbox.TBGameUserSettings.GetDisplayGamma // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d22b0
	float GetDialogueVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevelNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2280
	float GetDialogueVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2250
	struct FKey GetDeployMenuKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetDeployMenuKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d21e0
	struct FKey GetCycleWeaponSightsKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCycleWeaponSightsKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d2170
	struct FKey GetCrouchToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCrouchToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1fc0
	struct FKey GetCrouchKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCrouchKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1f50
	struct FKey GetConsoleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetConsoleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1ee0
	struct FKey GetCameraToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCameraToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1e70
	struct FKey GetAimDownSightsToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetAimDownSightsToggleKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1e00
	struct FKey GetAimDownSightsKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetAimDownSightsKeyBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d1d90
	bool FirstRunHardwareBenchmark(int32_t WorkScale, float CPUMultiplier, float GPUMultiplier); // Function Tinkerbox.TBGameUserSettings.FirstRunHardwareBenchmark // (Native|Public|BlueprintCallable) // @ game+0x7d1c80
	void EnableHeadphoneMode(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.EnableHeadphoneMode // (Final|Native|Public|BlueprintCallable) // @ game+0x7d1bf0
};

// Class Tinkerbox.TBLevelScriptActor
// Size: 0x228 (Inherited: 0x228)
struct ATBLevelScriptActor : ADFLevelScriptActor {
};

// Class Tinkerbox.TBVoiceIndicator
// Size: 0x248 (Inherited: 0x230)
struct UTBVoiceIndicator : UUserWidget {
	struct UTBVoiceIndicatorListing* VoiceListingClass; // 0x230(0x08)
	struct UPanelWidget* ActiveVoiceList; // 0x238(0x08)
	int32_t MaxActiveVoices; // 0x240(0x04)
	int32_t ActiveVoices; // 0x244(0x04)

	void ActiveVoiceRemoved(struct APlayerState* PlayerState, struct UPanelSlot* NewVoiceWidget); // Function Tinkerbox.TBVoiceIndicator.ActiveVoiceRemoved // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ActiveVoiceAdded(struct APlayerState* PlayerState, struct UPanelSlot* NewVoiceWidget); // Function Tinkerbox.TBVoiceIndicator.ActiveVoiceAdded // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
};

// Class Tinkerbox.TBVoiceIndicatorListing
// Size: 0x258 (Inherited: 0x230)
struct UTBVoiceIndicatorListing : UUserWidget {
	struct UTextBlock* PlayerName; // 0x230(0x08)
	struct UTBVoiceIndicator* ParentMenu; // 0x238(0x08)
	char pad_240[0x18]; // 0x240(0x18)

	void Init(struct UTBVoiceIndicator* InParentMenu, struct FUniqueNetIdRepl& InUniqueNetId, struct FString& InPlayerName); // Function Tinkerbox.TBVoiceIndicatorListing.Init // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x7d83c0
};

