// WidgetBlueprintGeneratedClass WBP_ModifierSettingBox.WBP_ModifierSettingBox_C
// Size: 0x2d8 (Inherited: 0x230)
struct UWBP_ModifierSettingBox_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UNamedSlot* Content; // 0x238(0x08)
	struct UTextBlock* SettingLabel; // 0x240(0x08)
	struct FText SettingText; // 0x248(0x18)
	struct FFModifierTextStyle SettingTextStyle; // 0x260(0x78)

	void SetSettingTextStyle(struct FFModifierTextStyle& InSettingTextStyle); // Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.SetSettingTextStyle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.GetSettingText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xec54e0
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.SetSettingText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ModifierSettingBox(int32_t EntryPoint); // Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.ExecuteUbergraph_WBP_ModifierSettingBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

