// BlueprintGeneratedClass Startup.Startup_C
// Size: 0x230 (Inherited: 0x228)
struct AStartup_C : ATBLevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)

	void ReceiveBeginPlay(); // Function Startup.Startup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_Startup(int32_t EntryPoint); // Function Startup.Startup_C.ExecuteUbergraph_Startup // (Final|UbergraphFunction) // @ game+0xec54e0
};

