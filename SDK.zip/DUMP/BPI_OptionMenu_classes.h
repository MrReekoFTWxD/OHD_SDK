// BlueprintGeneratedClass BPI_OptionMenu.BPI_OptionMenu_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_OptionMenu_C : UInterface {

	void GetDesiredVerticalAlignment(enum class EVerticalAlignment& Alignment); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredVerticalAlignment // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetDesiredHorizontalAlignment(enum class EHorizontalAlignment& Alignment); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredHorizontalAlignment // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void GetSubMenuOptions(struct TArray<struct FFSubMenuOption>& SubOptions); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetSubMenuOptions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void SetActiveSubMenuByIndex(int32_t SubMenuIndex); // Function BPI_OptionMenu.BPI_OptionMenu_C.SetActiveSubMenuByIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void HasSubMenus(bool& bSubMenuOptions); // Function BPI_OptionMenu.BPI_OptionMenu_C.HasSubMenus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
};

