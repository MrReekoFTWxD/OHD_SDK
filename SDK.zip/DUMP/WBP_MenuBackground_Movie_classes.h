// WidgetBlueprintGeneratedClass WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C
// Size: 0x2f0 (Inherited: 0x230)
struct UWBP_MenuBackground_Movie_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* BgFilterImg; // 0x238(0x08)
	struct UImage* BgMovieImg; // 0x240(0x08)
	struct UMediaPlayer* MoviePlayer; // 0x248(0x08)
	struct UMediaPlaylist* MoviePlaylist; // 0x250(0x08)
	struct FSlateBrush FilterImgBrush; // 0x258(0x88)
	struct FLinearColor FilterImgColor; // 0x2e0(0x10)

	void OnInitialized(); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void Destruct(); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_MenuBackground_Movie(int32_t EntryPoint); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.ExecuteUbergraph_WBP_MenuBackground_Movie // (Final|UbergraphFunction) // @ game+0xec54e0
};

