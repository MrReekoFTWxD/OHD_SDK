// UserDefinedStruct FServerBadgeUIDefinition.FServerBadgeUIDefinition
// Size: 0x94 (Inherited: 0x00)
struct FFServerBadgeUIDefinition {
	enum class EServerBadgeType Type_11_EDB490C54973A52E253141B62C748510; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSlateBrush Icon_3_FCCFEB524CD1FF61B4B6B8AB1739316E; // 0x08(0x88)
	int32_t OrderingIdx_8_900B3535409A63FA032C5D866D3A48AF; // 0x90(0x04)
};

