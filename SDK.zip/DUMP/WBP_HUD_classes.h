// WidgetBlueprintGeneratedClass WBP_HUD.WBP_HUD_C
// Size: 0x27d (Inherited: 0x238)
struct UWBP_HUD_C : UHDUIUWHUD {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWBP_CaptureStatus_C* CaptureStatus; // 0x240(0x08)
	struct UWBP_HUDElement_Compass_C* Compass; // 0x248(0x08)
	struct UWBP_HUDElement_EquipmentSelect_C* EquipmentSelect; // 0x250(0x08)
	struct UWBP_PlayerStatus_C* PlayerStatus; // 0x258(0x08)
	struct UWBP_HUDElement_TextChat_C* TextChat; // 0x260(0x08)
	struct UWBP_HUDElement_VOIPIndicator_C* VOIPStatus; // 0x268(0x08)
	struct UWBP_WeaponStatus_C* WeaponStatus; // 0x270(0x08)
	bool bShowCompass; // 0x278(0x01)
	bool bShowPlayerStatus; // 0x279(0x01)
	bool bShowWeaponStatus; // 0x27a(0x01)
	bool bShowCaptureStatus; // 0x27b(0x01)
	bool bShowEquipmentSelect; // 0x27c(0x01)

	void SetHUDElementVisibility(struct UWidget* Widget, bool bShown); // Function WBP_HUD.WBP_HUD_C.SetHUDElementVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleWeaponStatus(bool bVisible); // Function WBP_HUD.WBP_HUD_C.ToggleWeaponStatus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void ToggleEquipmentSelect(bool bVisible); // Function WBP_HUD.WBP_HUD_C.ToggleEquipmentSelect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void Construct(); // Function WBP_HUD.WBP_HUD_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_HUD(int32_t EntryPoint); // Function WBP_HUD.WBP_HUD_C.ExecuteUbergraph_WBP_HUD // (Final|UbergraphFunction) // @ game+0xec54e0
};

