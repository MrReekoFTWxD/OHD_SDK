// WidgetBlueprintGeneratedClass WBP_ServerBadge.WBP_ServerBadge_C
// Size: 0x2d8 (Inherited: 0x230)
struct UWBP_ServerBadge_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UImage* BadgeIcon; // 0x238(0x08)
	struct FFServerBadgeUIDefinition BadgeUIDefinition; // 0x240(0x98)

	void PreConstruct(bool IsDesignTime); // Function WBP_ServerBadge.WBP_ServerBadge_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_ServerBadge(int32_t EntryPoint); // Function WBP_ServerBadge.WBP_ServerBadge_C.ExecuteUbergraph_WBP_ServerBadge // (Final|UbergraphFunction) // @ game+0xec54e0
};

