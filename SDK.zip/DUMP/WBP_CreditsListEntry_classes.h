// WidgetBlueprintGeneratedClass WBP_CreditsListEntry.WBP_CreditsListEntry_C
// Size: 0x298 (Inherited: 0x230)
struct UWBP_CreditsListEntry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UTextBlock* EntryBodyText; // 0x238(0x08)
	struct UWBP_CreditsListHeader_C* EntryHeader; // 0x240(0x08)
	struct FFGameCreditsEntry Header; // 0x248(0x30)
	struct FMargin HeaderPadding; // 0x278(0x10)
	struct TArray<struct FFGameCreditsEntry> BodyEntries; // 0x288(0x10)

	void CombineBodyText(struct FString& BodyCombinedStr); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.CombineBodyText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xec54e0
	void PreConstruct(bool IsDesignTime); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xec54e0
	void ExecuteUbergraph_WBP_CreditsListEntry(int32_t EntryPoint); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.ExecuteUbergraph_WBP_CreditsListEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0xec54e0
};

